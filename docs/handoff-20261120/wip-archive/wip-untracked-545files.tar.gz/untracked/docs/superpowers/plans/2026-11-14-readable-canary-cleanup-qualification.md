# 同源 cleanup v2、既有 capabilities 衔接与独立 readable-canary 方案

> 执行者按 superpowers:subagent-driven-development 或 superpowers:executing-plans 逐任务执行；当前只交Root核接口，未授SOURCE写入/native执行。
**Goal:** 先恢复当前cf95/f503的真实normal→bootstrap-exit及既有capabilities证据链；readable-canary只支撑独立“可读不可改”声明。
**Architecture:** 主线沿用NativeFixture/cleanup-ordering.v1与原Capture→Warm→Inputs流程；可读实验是其冻结源码的独立固定变体，不给主线新增门槛。
**Tech Stack:** Windows x64；既有PS7外层/PS5.1 bootstrap、C11、Framework csc、SourceProcess/owned-child监督。
**Spec:** Root最新门槛区分；S/aa-fr-cleanup-ordering-v1-design-decision.md:18；Agorai b09dd22d、39b981ee。
**路径别名:** NF=AcceptanceHarness/FullRestricted.NativeFixture；CF=AcceptanceHarness/FullRestricted.CdbOwnedWaitFixture；FP=AcceptanceHarness/FullRestricted.FreshPreflight；H=tools/headless。
**路径别名:** S=.superpowers/sdd/azurite-authoring-20261108；B=artifacts/aa-fr-native-lifecycle-fixture；RP=B/readable-canary1-preparation/source；均相对固定C仓库。

## 全局与真实准入边界

- Full保持cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533，Shared保持f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921；两生产CS不改。
- flags1、三restricting SIDs、权限/default DACL、桌面/Job/lease/超时/cleanup算法不变；不切flags9，不改GENERIC_READ或八个单权限mask。
- 939 lab原位保留；adfefa/e8/598b/c03a、旧cleanup1及失败历史不动；本方案不改NativeControl2或CF生产文件，不新建隔离/审批框架。
- 新输出必须不存在，冲突即停；JSON显式UTF8；全部SOURCE子过程复用既有hidden/BelowNormal/bounded监督并留PID/creation/exit，禁自动commit。
- 优先顺序A→B；C可独立并行准备。现合同未把owner-only读成功、Wait12/12或universal isolation设为capabilities前置，本方案不得自行增加。
- capabilities只按已有真实同源harmless、source/tooling pins、同run baseline/identity/shared/fresh-preflight、输入与Root授权合同判定；诊断未通过不冒充通过，未来声明另列。

## A. 现有NativeFixture严格9974、同包normal→bootstrap-exit

**Modify:** NF/Build-Fixture.ps1、Run-Fixture.ps1、FixtureRules.psm1、FixtureBootstrap.ps1、FixtureAcl.psm1、Test-FixtureAcl.ps1；Test-Fixture.ps1/Test-NormalReceipt.ps1仅加精确漂移负控。
**Create:** B/cleanup9974-qual1-preparation/Invoke-CleanupFixtureHeld.ps1；只窄复制旧cleanup1 held wrapper的包/源码身份，保留hold/拒绝/once-close策略。
- [ ] 全部固定metadata改为唯一B/build-cleanup9974-qual1及B/lab-cleanup9974-qual1，旧包不动；Build核实际cf95/f503，保留仅Lab/Executable两常量变换及逆还原。
- [ ] 只移植CF/FixtureRules.psm1 SHA cf16be42aa10ce38cef64ff52d955406ffdc8a8828e65ac9d591a859a508e10d中已审image/monitor pin语义，不复制其它生命周期算法。
- [ ] user32固定10.0.26100.9818/4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91/RVA0x2a9a0；win32u固定10.0.26100.9974/5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc/RVA0x1610。
- [ ] actual/expected版本及hash逐image严格匹配，五row字段和完整identity先string再精确比较；保留NF既有Assert-FixtureOuter，不再继承9818旧win32u pin。
- [ ] SOURCE RED/GREEN调用真实消费者：旧pin/跨image错值/Boolean拒绝；normal前置错package/lineage/run/path/hash或缺cleanup trace拒绝；不重跑无关旧组。
- [ ] 真编译新probe/FixtureOnly，冻结实际源码/生成物/原始编译过程/manifest；限定review后才交Root，无receipt输出。
- [ ] **仅Root随后执行:** 新held入口 -Scenario normal -Execute -ReviewedPackageSha256 P；P取新manifest实际SHA，N取实际normal result路径/hash。
- [ ] **仅Root随后执行:** 同一P入口 -Scenario bootstrap-exit -Execute -NormalReceiptPath N.path -NormalReceiptSha256 N.sha256；939不是该包前置。
- [ ] 独立审normal+bootstrap-exit原始cleanup-ordering.v1 trace后，Root才生成真实同源v2；无v1捷径、无预填true、无external-live-interval声明。

## B. Capture/FreshPreflight旧d599/498a同步到真实新产物

**Create:** S/aa-fr-ftarget-cf95-build-20261114/Build-Tooling.ps1；窄复制S/aa-fr-ftarget-startup-build-20261113/Build-Tooling.ps1，旧cleanup/startup builder与产物不改。
- [ ] 以当前H的cf95/f503替旧d599 freeze输入，冻结七份tooling源码；沿原Framework64 csc两CS/library/x64/warnaserror及System.Web.Extensions引用实际编译。
- [ ] 真产出tooling/RestrictedCliNative.dll、source.zip、result.json、verification.json、tooling/tooling-manifest.json；八成员manifest与canonical result/archive/DLL pins只取实测。
**Modify:** H/Capture-AzuriteFullCapabilitiesIdentityShared.ps1:7,33,35-37：新tooling目录、cf95及真实DLL SHA；三现用PS模块pins75f2/452a/495e及采集语义不动。
**Modify:** FP/Capture-FreshPreflight.ps1:169-172的Full条件；FP/Test-FreshPreflight.ps1、Test-FreshPreflightInputs.ps1仅相关旧pin负控；FP/source-index.json重算实际11项；FP/Build-FreshPreflight.ps1仅必要UTF8/既有有界调用适配。
- [ ] 原Build-FreshPreflight -Build -ReviewedSourceIndexSha256 I -DotnetPath D -DotnetSha256 DH -OutputDirectory O；I/DH实读，O为唯一artifacts/aa-fr-fresh-preflight-tooling/build-cf95-qual1。
- [ ] Warm实际复制既有Program.cs/SourceLinkedInterop.cs/SourceLinkedCache.cs/FixtureSupport.cs/CachePrerequisites.csproj/NuGet.Config，dotnet net6/UseAppHost=false产新helper/provenance/manifest；不把Full/Shared说成其编译输入。
**Modify:** H/AzuriteCapabilitiesSequence.psm1:19,23-24仅四artifact路径：WarmManifest→O/manifest；CaptureNative与RuntimeNative→同一新实编译DLL；ToolingManifest→其新manifest。
- [ ] 由最终实字节生成新的28-role source manifest；Inputs:270-275的DLL↔两CS↔canonical result↔source.zip规则不改，禁止旧manifest/result重标签。
- [ ] SOURCE负控覆盖旧d599/498a/ae352、错archive/canonical result、旧index、simulated→reviewed-real；只运行纯manifest/字段核验，不执行collector或读取F-stage。
- [ ] B的SOURCE构建可与A并行；实际Capture→Warm→Assemble/Apply只在A真实v2及其余既有合同满足、Root按原授权调度后执行；不复用旧gate/approval。

## C. 独立readable-canary实验，不成为A/B新增准入条件

**Create:** B/readable-canary1-preparation/Build-ReadableVariant.ps1与RP；从A固定新包source逐字节快照，记录base manifest/source pins，不改NF工作源或A包。
**Private-copy modifications:** RP/Build-Fixture.ps1、Run-Fixture.ps1、FixtureRules.psm1、FixtureBootstrap.ps1、FixtureAcl.psm1、Test-FixtureAcl.ps1只改明确repo/source/build/lab身份。
**New semantic files:** RP/CanaryProbe.h、Test-CanaryPair.ps1；仅RP/LifecycleProbe.c、Run-Fixture.ps1、FixtureRules.psm1加入下述normal诊断，不修改bootstrap-exit故障时序。
- [ ] 固定新B/build-readable-canary1、B/lab-readable-canary1；复用A builder/监督和原normal API，不新增运行调度框架；此变体不充当A的normal prerequisite。
**Native API:** 私有probe_canaries(void)，仅normal在entry.json后调用两个编译期固定路径，写protection-result.json/readable-protection-result.json，禁外来路径或mask。
**来源:** 只移植CF/ProtectionProbe.h SHA dcc28226655e8501c2f753c2ee425ee0e39eaa78165a65d172e2e5841a4dd976的open/read/八权/close逻辑；原文件不改。
**ACL:** install/protected/proof.bin仍owner-only一ACE；install/readable/proof.bin用已有$readFile，目录用$traverse：owner/SY/BA FA加logon文件0x120089/目录0x1200A9，严格四ACE/原继承flags。
**Consumer API:** Assert-FixtureCanaryPair(OwnerProbe,ReadableProbe,Snapshots,RunId,Pid,Tid,OwnerSid,LogonSid)返回ownerOnlyReadDenied/readableCanaryQualified，scope=owned-canary-pair.v1，applicationAccepted=false。
**来源:** 从CF已审保护快照/八权/private-output核验窄移植；owner-only仍一ACE，readable另核四ACE，不通过放松旧规则支持新样本。
**Read正控:** 保持GENERIC_READ/OPEN_EXISTING/share7；实际36字节写72位hex，consumer解码hash必须f73c5b91dbc65bf121fd36cfa7da58fbd1f49986e564f5efd1276d2722ff70b5，并核内容及同一file identity。
**写拒绝:** 正控read/info/close全成功后，同对象八单权限全部error5；before/after身份/hash/SDDL/rawSD/属性/单link/非reparse/子项不变；两child私有输出真实CreateNew/Write/Flush/Close。
**负控:** owner-only保留readOpenError5及八权拒绝；两记录核同RunId/PID/TID；该读拒绝不更名为权限bug。
- [ ] SOURCE RED/GREEN真实消费者覆盖read失败、35/37字节/坏hex/hash/identity、任一grant/非5错误、extra ACE、路径混淆、Boolean及伪输出；纯数据显式simulated。
- [ ] 限定review该变体真实编译后，仅Root运行其normal实验；失败只禁止“可读不可改”声明，不能改写A/B既有准入或939结果。

## 交付、归档、停点

- [ ] 每段交精确delta/实际pins/RED-GREEN/失败原记录，沿用原performance限定review与Root调度；不新增批准层。
- [ ] 939 lab原位不动；A的normal前置N在exit消费前留B/evidence/<runid>/result.json；不先整体移入任意archive。
- [ ] 最终harmless可引用本repo非reparse普通归档receipt(≤128KiB)，保留历史raw bytes/路径文本；迁移摘要需原链重绑input/gate，禁junction或改旧receipt。
- [ ] 当前只交计划；Root核范围后另授SOURCE写入。真实receipt/native/AA归Root；未测Wait、Protection、registry、普通Editor不得宣称通过，也不擅自增加其成功标准。
