param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$ResultPath=[IO.Path]::GetFullPath($ResultPath)
$artifactRoot=Join-Path $repo 'artifacts\aa-fr-prepared-hash-case-fix-20261113'
if(-not $ResultPath.StartsWith($artifactRoot+'\',[StringComparison]::OrdinalIgnoreCase) -or [IO.File]::Exists($ResultPath)){throw 'Test result must be a new file under the C-only correction artifact directory'}
$core=Join-Path $repo 'tools\headless\RestrictedCliCore.psm1';$current=Join-Path $repo 'tools\headless\CurrentAccountCli.psm1'
Import-Module $core -Scope Global -DisableNameChecking
Import-Module $current -Scope Global -DisableNameChecking
if((Get-Command Assert-AzuritePreparedHash).Module.Path -cne $current -or (Get-Command Get-AzuriteSha256).Module.Path -cne $core){throw 'Test must use the real production functions'}
$fixture=Join-Path $artifactRoot ('fixture-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($fixture)
$path=Join-Path $fixture 'abc.bin';[IO.File]::WriteAllBytes($path,[byte[]]@(97,98,99))
# Independently known SHA-256 of the three ASCII bytes abc.
$lower='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad';$upper=$lower.ToUpperInvariant()
if((Get-AzuriteSha256 $path) -cne $upper){throw 'Known-answer fixture or real file hashing failed'}
function Mixed([string]$value){$chars=$value.ToCharArray();for($i=0;$i -lt $chars.Length;$i++){$chars[$i]=if(($i%2) -eq 0){[char]::ToUpperInvariant($chars[$i])}else{[char]::ToLowerInvariant($chars[$i])}};return (-join $chars)}
$mixed=Mixed $lower;if($mixed -ceq $lower -or $mixed -ceq $upper){throw 'Mixed-case fixture must contain both cases'}
$cases=@(
 [pscustomobject]@{name='correct-uppercase';value=$upper;accept=$true},
 [pscustomobject]@{name='correct-lowercase';value=$lower;accept=$true},
 [pscustomobject]@{name='correct-mixed-case';value=$mixed;accept=$true},
 [pscustomobject]@{name='wrong-uppercase-digest';value=('A'+$upper.Substring(1));accept=$false},
 [pscustomobject]@{name='wrong-lowercase-digest';value=('a'+$lower.Substring(1));accept=$false},
 [pscustomobject]@{name='wrong-mixed-case-digest';value=('a'+$mixed.Substring(1));accept=$false},
 [pscustomobject]@{name='empty';value='';accept=$false},
 [pscustomobject]@{name='null';value=$null;accept=$false},
 [pscustomobject]@{name='short-63';value=$upper.Substring(1);accept=$false},
 [pscustomobject]@{name='long-65';value=($upper+'0');accept=$false},
 [pscustomobject]@{name='nonhex-uppercase';value=('G'+$upper.Substring(1));accept=$false},
 [pscustomobject]@{name='nonhex-lowercase';value=('g'+$lower.Substring(1));accept=$false},
 [pscustomobject]@{name='fullwidth-hex-letter';value=([string][char]0xFF22+$upper.Substring(1));accept=$false},
 [pscustomobject]@{name='arabic-indic-digit';value=($upper.Substring(0,2)+[char]0x0667+$upper.Substring(3));accept=$false},
 [pscustomobject]@{name='fullwidth-digit';value=($upper.Substring(0,2)+[char]0xFF17+$upper.Substring(3));accept=$false},
 [pscustomobject]@{name='leading-space';value=(' '+$upper);accept=$false},
 [pscustomobject]@{name='trailing-space';value=($upper+' ');accept=$false},
 [pscustomobject]@{name='whitespace-only';value=(' '*64);accept=$false},
 [pscustomobject]@{name='leading-LF';value=([string][char]10+$upper);accept=$false},
 [pscustomobject]@{name='trailing-LF';value=($upper+[char]10);accept=$false},
 [pscustomobject]@{name='trailing-CRLF';value=($upper+"`r`n");accept=$false},
 [pscustomobject]@{name='embedded-LF';value=($upper.Substring(0,32)+[char]10+$upper.Substring(33));accept=$false},
 [pscustomobject]@{name='embedded-NUL';value=($upper.Substring(0,32)+[char]0+$upper.Substring(33));accept=$false},
 [pscustomobject]@{name='0x-prefix';value=('0x'+$upper);accept=$false},
 [pscustomobject]@{name='separated-hex';value=($upper.Substring(0,32)+'-'+$upper.Substring(32));accept=$false}
)
$rows=[Collections.Generic.List[object]]::new()
function Check-Prepared([string]$name,[string]$file,$expected,[bool]$accept){
 $errorText=$null;$accepted=$false
 try{$null=Assert-AzuritePreparedHash -Path $file -ExpectedHash $expected;$accepted=$true}catch{$errorText=$_.Exception.Message}
 $rows.Add([pscustomobject]@{name=$name;path=$file;expectedHash=$expected;expectedLength=$(if($null -eq $expected){$null}else{$expected.Length});shouldAccept=$accept;accepted=$accepted;passed=($accepted -eq $accept);error=$errorText})
}
foreach($case in $cases){Check-Prepared $case.name $path $case.value $case.accept}
$changed=Join-Path $fixture 'changed.bin';[IO.File]::WriteAllBytes($changed,[byte[]]@(97,98,100))
foreach($format in @([pscustomobject]@{name='uppercase';value=$upper},[pscustomobject]@{name='lowercase';value=$lower},[pscustomobject]@{name='mixed-case';value=$mixed})){Check-Prepared ('changed-file-bytes-'+$format.name) $changed $format.value $false}
Check-Prepared 'missing-file' (Join-Path $fixture 'missing.bin') $upper $false
# Exercise the earliest actual full-runtime call's exact C file and contract pin.
# Do not call Assert-AzuriteFullWarmInputs: its later instructions inspect F.
$contractPath=Join-Path $repo 'tools\headless\full-restricted-capabilities-contract.json'
if((Get-FileHash -LiteralPath $contractPath).Hash.ToLowerInvariant() -cne '319a0e0a4b2b603f7aaf651250fa7553620bb918b513700e38b028a31f79f7cd'){throw 'Accepted contract changed'}
$contract=[IO.File]::ReadAllText($contractPath)|ConvertFrom-Json
$warm=Join-Path $repo 'artifacts\aa-fr-cache-prerequisites\warm-stamp-result.json';$warmExpected=$contract.cachePrerequisites.warmResultSha256;$warmActual=Get-AzuriteSha256 $warm
if($warmExpected -cne 'ae20a85d28f254d14851deeb9d4ff0627bb7d821bd04154814c8fdfcca830fb6' -or $warmActual.ToLowerInvariant() -cne $warmExpected){throw 'Actual C warm proof source changed'}
Check-Prepared 'actual-C-warm-contract-lowercase' $warm $warmExpected $true
Check-Prepared 'actual-C-warm-equivalent-uppercase' $warm $warmExpected.ToUpperInvariant() $true
Check-Prepared 'actual-C-warm-equivalent-mixed-case' $warm (Mixed $warmExpected) $true
if((Get-AzuriteSha256 $path) -cne $upper -or (Get-AzuriteSha256 $warm) -cne $warmActual){throw 'Read-only verification changed input bytes'}
$report=[ordered]@{schema=1;scope='C-only production Assert-AzuritePreparedHash representation regression';host=$PSVersionTable.PSVersion.ToString();passed=(@($rows|Where-Object {-not $_.passed}).Count -eq 0);checks=$rows.Count;failedChecks=@($rows|Where-Object {-not $_.passed}|ForEach-Object name);productionModulePath=$current;productionModuleSha256=(Get-FileHash -LiteralPath $current).Hash.ToLowerInvariant();hashFunctionModulePath=$core;hashFunctionModuleSha256=(Get-FileHash -LiteralPath $core).Hash.ToLowerInvariant();testScriptSha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant();fixtureDirectory=$fixture;knownAnswerSha256=$lower;actualWarmPath=$warm;actualWarmBytes=(Get-Item -LiteralPath $warm).Length;actualWarmExpectedHash=$warmExpected;actualWarmComputedHash=$warmActual;actualWarmBytesUnchanged=$true;cases=$rows.ToArray();mockFunctionsUsed=$false;fullRuntimeCalled=$false;warmRuntimeWrapperCalled=$false;stageApplyCalled=$false;targetAccess=$false;registryAccess=$false;nativeHelperCalled=$false;aaLaunched=$false;cleanupPerformed=$false}
[IO.File]::WriteAllText($ResultPath,($report|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
[ordered]@{passed=$report.passed;host=$report.host;checks=$report.checks;failedChecks=$report.failedChecks;moduleSha256=$report.productionModuleSha256;resultPath=$ResultPath}|ConvertTo-Json
if(-not $report.passed){exit 1}
