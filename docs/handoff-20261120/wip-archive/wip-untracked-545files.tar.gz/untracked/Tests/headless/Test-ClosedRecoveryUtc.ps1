param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));Import-Module (Join-Path $repo 'tools/headless/FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($out)
 Assert-RecoveryCPath $out $false;Assert-Recovery (-not [IO.Directory]::Exists($out)) 'Fresh C output required';[void][IO.Directory]::CreateDirectory($out)
 $manifest=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC (Join-Path $script:RecoveryRepo 'artifacts\aa-fr-failed-run-preservation-9c\actual-capture-01\archive-manifest.json') '19d1aef7c64461272524577e0e6b37b314e98221ea4349a1815bc561e1bba55c');$entry=$manifest.files|Where-Object {$_.source.EndsWith('\tooling\CurrentAccountCli.psm1',[StringComparison]::Ordinal)}
 $scope=[pscustomobject]@{identitySid='fixture';roots=@()};$hash=(Get-RecoveryHash ([Text.Encoding]::UTF8.GetBytes(($scope|ConvertTo-Json -Depth 8 -Compress)))).ToUpperInvariant();$checks=@()
 foreach($time in @('2026-11-13T00:00:00','11/13/2026 00:00:00','2026-13-50T00:00:00Z',[datetime]::SpecifyKind([datetime]::Parse('2026-11-13T00:00:00'),[DateTimeKind]::Unspecified))){
  $before=[pscustomobject]@{schema=1;runId='r';phase='Before';identitySid='fixture';specSha256=$hash;capturedUtc=$time;roots=@();directories=@();files=@();registry=[pscustomobject]@{exists=$false;keys=@();values=@()}};$after=$before.PSObject.Copy();$after.phase='After';$after.capturedUtc='2026-11-13T00:00:01Z';$denied=$false;try{Compare-ClosedArchivedShared $entry $before $after $scope 'r'|Out-Null}catch{$denied=$true};$checks+=,[pscustomobject]@{case=[string]$time;type=$time.GetType().FullName;passed=$denied}
 }
 $failed=@($checks|Where-Object {-not $_.passed}).Count;$result=[pscustomobject]@{passed=($failed -eq 0);total=$checks.Count;failed=$failed;checks=$checks;FReadPerformed=$false;registryAccessPerformed=$false};Write-RecoveryCRecord (Join-Path $out 'result.json') $result;$result|ConvertTo-Json -Depth 4;if($failed){exit 1}
} $OutputDirectory
