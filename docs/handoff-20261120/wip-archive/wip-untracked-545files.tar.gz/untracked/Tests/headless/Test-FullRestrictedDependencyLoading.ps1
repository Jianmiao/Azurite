param(
 [Parameter(Mandatory)][string]$InputDirectory,
 [Parameter(Mandatory)][string]$ApprovalPath,
 [Parameter(Mandatory)][string]$ResultPath,
 [ValidateSet('Green','FakeUtc','ShadowModule','PathDrift','HashDrift')][string]$Case='Green',
 [string]$Dependency='RestrictedCliCore.psm1'
)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$InputDirectory=[IO.Path]::GetFullPath($InputDirectory);$ApprovalPath=[IO.Path]::GetFullPath($ApprovalPath);$ResultPath=[IO.Path]::GetFullPath($ResultPath)
$moduleNames=@('HeadlessCore','RestrictedCliCore','CurrentAccountCli','FullRestrictedCapabilitiesPlan','FullRestrictedCapabilitiesRuntime')
function Read-Json([string]$p){$text=[IO.File]::ReadAllText($p);if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){return $text|ConvertFrom-Json -DateKind String};return $text|ConvertFrom-Json}
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save-New([string]$p,$value){if([IO.File]::Exists($p)){throw ('Test evidence already exists: '+$p)};[IO.File]::WriteAllText($p,($value|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))}
if(@(Get-Module -All -Name $moduleNames).Count -ne 0 -or (Get-Command ConvertTo-AzuriteUtcInstant -ErrorAction SilentlyContinue)){throw 'Fresh child process required; dependency already loaded'}
if([IO.File]::Exists($ResultPath)){throw 'Result must be new'}
$manifestPath=Join-Path $InputDirectory 'source-manifest.json';$plan=Read-Json (Join-Path $InputDirectory 'plan.json')
$fixture=Join-Path (Split-Path -Parent $ResultPath) ('dependency-case-'+[guid]::NewGuid().ToString('N'))
if($Case -in @('PathDrift','HashDrift','ShadowModule')){[void][IO.Directory]::CreateDirectory($fixture)}
if($Case -in @('PathDrift','HashDrift')){
 $manifest=Read-Json $manifestPath;$entry=@($manifest.files|Where-Object name -CEQ $Dependency)[0]
 if($Case -ceq 'PathDrift'){$copy=Join-Path $fixture $Dependency;[IO.File]::WriteAllBytes($copy,[IO.File]::ReadAllBytes($entry.path));$entry.path=$copy}else{$entry.sha256='0'*64}
 $manifestPath=Join-Path $fixture 'source-manifest.json';Save-New $manifestPath $manifest
}
if($Case -ceq 'FakeUtc'){function global:ConvertTo-AzuriteUtcInstant {throw 'Fake UTC command must never execute'}}
if($Case -ceq 'ShadowModule'){
 $shadow=Join-Path $fixture $Dependency
 [IO.File]::WriteAllText($shadow,"# Deliberate same-name module from wrong path; must be rejected before production imports.`r`nExport-ModuleMember -Function @()",[Text.UTF8Encoding]::new($false))
 Import-Module $shadow -Scope Global -DisableNameChecking
}
$modulesBefore=@(Get-Module -All -Name $moduleNames|ForEach-Object {$_.Path})
$parameters=@{SourceManifestPath=$manifestPath;ExpectedSourceManifestSha256=(Hash $manifestPath);ControlPath=(Join-Path $InputDirectory 'control.json');ExpectedControlSha256=(Hash (Join-Path $InputDirectory 'control.json'));GatePath=(Join-Path $InputDirectory 'gate.json');ExpectedGateSha256=(Hash (Join-Path $InputDirectory 'gate.json'));ExpectedPlanSha256=$plan.PlanSha256;ApprovalPath=$ApprovalPath;ExpectedApprovalSha256=(Hash $ApprovalPath)}
$result=$null;$failure=$null;$exitCode=$null
try{
 $output=& (Join-Path $repo 'tools\headless\Prepare-AzuriteFullCapabilitiesRun.ps1') @parameters
 $exitCode=$LASTEXITCODE;$result=($output -join "`n")|ConvertFrom-Json
 if($result.PSObject.Properties['error']){$failure=$result.error}
}catch{$failure=$_.Exception.Message}
$modulesAfter=@(Get-Module -All -Name $moduleNames|ForEach-Object {$_.Path})
$dependencyImports=@($modulesAfter|Where-Object {$_ -cnotin $modulesBefore})
$sources=[Collections.Generic.List[object]]::new();$visible=[Collections.Generic.List[object]]::new()
$assertion=$null
if($Case -ceq 'Green'){
 try{
  if($failure -or $exitCode -ne 0 -or $result.mode -cne 'planning-only' -or -not $result.approvalPresent -or $result.willMutate -or $result.willLaunch -or $result.runtimeAllowed -or $result.existingObjects -ne 1228 -or $result.aclTargets -ne 1252){throw ('Public Plan with approval did not pass: '+$failure)}
  foreach($name in $moduleNames){
   $path=Join-Path $repo ('tools\headless\'+$name+'.psm1');$loaded=@(Get-Module -All -Name $name)
   if($loaded.Count -ne 1 -or $loaded[0].Path -cne $path){throw ('Loaded module source differs: '+$name)}
   $sources.Add([pscustomobject]@{name=$name;path=$loaded[0].Path;sha256=(Hash $path);exports=$loaded[0].ExportedFunctions.Count})
   foreach($commandName in $loaded[0].ExportedFunctions.Keys){
    $command=Get-Command $commandName -ErrorAction Stop
    if(-not $command.Module -or $command.Module.Path -cne $path){throw ('Command source differs: '+$commandName)}
    $visible.Add([pscustomobject]@{command=$commandName;modulePath=$command.Module.Path})
   }
  }
  if((Get-Command ConvertTo-AzuriteUtcInstant).Module.Path -cne (Join-Path $repo 'tools\headless\RestrictedCliCore.psm1')){throw 'UTC conversion source differs'}
 }catch{$assertion=$_.Exception.Message}
}else{
 $expected=if($Case -ceq 'FakeUtc'){'*Shadowed dependency command before import*'}elseif($Case -ceq 'ShadowModule'){'*different dependency module is already loaded*'}elseif($Case -ceq 'PathDrift'){'*Executing dependency path differs*'}else{'*Frozen C source digest differs*'}
 if(-not $failure -or $failure -notlike $expected -or $dependencyImports.Count -ne 0){$assertion='Negative control must reject before any dependency import; error='+$failure+'; imports='+$dependencyImports.Count}
}
$report=[ordered]@{schema=1;evidenceClass='simulated-test-only';scope='fresh child public Prepare default Plan with canonical test approval; never Apply';case=$Case;dependency=$Dependency;host=$PSVersionTable.PSVersion.ToString();passed=($null -eq $assertion);failure=$failure;assertion=$assertion;exitCode=$exitCode;globalCorePreloaded=$false;rootWrapperDependencyPreload=$false;applyCalled=$false;nativeCalled=$false;targetAccess=$false;newDependencyModules=$dependencyImports;newDependencyModuleCount=$dependencyImports.Count;modulePathsBefore=$modulesBefore;modulePathsAfter=$modulesAfter;loadedModules=$sources.ToArray();visibleCommands=$visible.ToArray();commandCount=$visible.Count;planResult=$result;approvalPath=$ApprovalPath;approvalSha256=(Hash $ApprovalPath);sourceManifestPath=$manifestPath;sourceManifestSha256=(Hash $manifestPath);fixtureDirectory=$fixture}
Save-New $ResultPath $report
$report|ConvertTo-Json -Depth 30
if($assertion){throw $assertion}
