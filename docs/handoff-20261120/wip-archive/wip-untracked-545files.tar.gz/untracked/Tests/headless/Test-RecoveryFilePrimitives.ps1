param([Parameter(Mandatory)][string]$HelperPath,[Parameter(Mandatory)][string]$ExpectedHelperSha256,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$artifact=Join-Path $repo 'artifacts\aa-fr-empty-directory-helper-20261113'
$HelperPath=[IO.Path]::GetFullPath($HelperPath);$ResultPath=[IO.Path]::GetFullPath($ResultPath)
if(-not $HelperPath.StartsWith($repo+'\',[StringComparison]::Ordinal) -or -not $ResultPath.StartsWith($artifact+'\',[StringComparison]::Ordinal) -or (Test-Path -LiteralPath $ResultPath)){throw 'Expected pinned C helper and new bounded result'}
$runId=[guid]::NewGuid().ToString('N');$root=Join-Path $artifact ('owned-'+$runId);$steps=[Collections.Generic.List[object]]::new();$held=[Collections.Generic.List[object]]::new()
$result=[ordered]@{schema=1;scope='actual file-only native qualification on fresh owned C tree';runId=$runId;root=$root;host=$PSVersionTable.PSVersion.ToString();helperPath=$HelperPath;helperSha256=$ExpectedHelperSha256;passed=$false;error=$null;startedUtc=[DateTimeOffset]::UtcNow.ToString('o');targetAccess=$false;registryAccess=$false;tokenCreatedOrModified=$false;jobOrDesktopApi=$false;aaLaunched=$false;stageApply=$false;automaticCleanup=$false;objectsRetained=$true}
function Check([bool]$ok,[string]$name,$evidence=$null){$steps.Add([pscustomobject]@{name=$name;passed=$ok;evidence=$evidence});if(-not $ok){throw ('ASSERT '+$name)}}
function Refuse([string]$name,[scriptblock]$body,[string]$message='',[int]$native=-1){$failure=$null;try{& $body|Out-Null}catch{$failure=$_.Exception;while($failure.InnerException){$failure=$failure.InnerException}};Check ($null -ne $failure) ($name+'-refused');if($native -ge 0){Check ($failure -is [ComponentModel.Win32Exception] -and $failure.NativeErrorCode -eq $native) ($name+'-native-code') @{message=$failure.Message;code=$failure.NativeErrorCode}}elseif($message){Check ($failure.Message -like ('*'+$message+'*')) ($name+'-reason') $failure.Message}}
function Owned([string]$leaf){$p=Join-Path $root $leaf;Check ([IO.Path]::GetFullPath($p) -ceq $p -and $p.StartsWith($root+'\',[StringComparison]::Ordinal)) ('owned-target:'+ $leaf);return $p}
function Canonical([string]$s){([Security.AccessControl.RawSecurityDescriptor]::new($s)).GetSddlForm([Security.AccessControl.AccessControlSections]'Owner,Group,Access')}
function Observe([string]$p){[Azurite.Stage.FileSecurity]::Read($p,$false)}
function Same($a,$b){$a.identity -ceq $b.identity -and $a.sddl -ceq $b.sddl -and $a.directory -eq $b.directory -and $a.sha256 -ceq $b.sha256 -and $a.bytes -eq $b.bytes}
function Archive([string]$source,$record,[string]$destination){[Azurite.Stage.FileSecurity]::ArchiveFile($source,$record.identity,$record.sddl,$record.sha256,[long]$record.bytes,$destination)}
try{
 [Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal
 Check ([Diagnostics.Process]::GetCurrentProcess().PriorityClass -eq [Diagnostics.ProcessPriorityClass]::BelowNormal) 'below-normal-priority'
 Check ((Get-FileHash -LiteralPath $HelperPath).Hash.ToLowerInvariant() -ceq $ExpectedHelperSha256) 'pinned-actual-helper'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();$owner=$identity.User.Value
 Check (-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) 'read-only-current-identity-not-elevated'
 Check ($null -eq ('Azurite.Stage.FileSecurity' -as [type])) 'fresh-helper-type-context'
 [Reflection.Assembly]::LoadFrom($HelperPath)|Out-Null
 $delete=[Azurite.Stage.FileSecurity].GetMethod('DeleteEmptyDirectory',[type[]]@([string],[string],[string]));$archive=[Azurite.Stage.FileSecurity].GetMethod('ArchiveFile',[type[]]@([string],[string],[string],[string],[long],[string]))
 $steps.Add([pscustomobject]@{name='DeleteEmptyDirectory-three-string-interface';passed=($null -ne $delete);evidence=$null});$steps.Add([pscustomobject]@{name='ArchiveFile-six-argument-interface';passed=($null -ne $archive);evidence=$null})
 if(-not $delete -or -not $archive){throw 'Required recovery file primitive is missing'}
 $cursor=$artifact;while($cursor){$item=Get-Item -LiteralPath $cursor -Force;Check ($item.PSIsContainer -and -not($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) ('real-C-ancestor:'+ $cursor);$cursor=Split-Path -Parent $cursor}
 Check (-not(Test-Path -LiteralPath $root)) 'fresh-owned-tree'
 $group=(Get-Acl -LiteralPath $artifact).GetGroup([Security.Principal.SecurityIdentifier]).Value
 $ds=Canonical ('O:'+$owner+'G:'+$group+'D:P(A;OICI;FA;;;'+$owner+')(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)');$fs=Canonical ('O:'+$owner+'G:'+$group+'D:P(A;;FA;;;'+$owner+')(A;;FA;;;SY)(A;;FA;;;BA)')
 [Azurite.Stage.FileSecurity]::NewDirectory($root,$ds)
 $hardSource=Owned 'hard-source.bin';[Azurite.Stage.FileSecurity]::NewFile($hardSource,[byte[]]@(97,98,99),$fs);$hs=Observe $hardSource;$hard=Owned 'hardlink';New-Item -ItemType HardLink -Path $hard -Target $hardSource|Out-Null
 $held.Add([Azurite.Stage.FileSecurity]::LockDirectory($root))
 $empty=Owned 'empty';[Azurite.Stage.FileSecurity]::NewDirectory($empty,$ds);$e=Observe $empty
 Refuse 'directory-wrong-identity' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($empty,('0'*32),$e.sddl)} 'identity/descriptor'
 Refuse 'directory-missing-group-sddl' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($empty,$e.identity,$e.ownerAccessSddl)} 'identity/descriptor'
 $wrongOwner=Canonical ('O:SYG:'+$group+'D:P(A;OICI;FA;;;'+$owner+')')
 Refuse 'directory-wrong-owner-sddl' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($empty,$e.identity,$wrongOwner)} 'identity/descriptor'
 $wrongGroup=Canonical ('O:'+$owner+'G:SYD:P(A;OICI;FA;;;'+$owner+')')
 Refuse 'directory-wrong-group-sddl' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($empty,$e.identity,$wrongGroup)} 'identity/descriptor'
 Refuse 'directory-dot-alias' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory(($root+'\.\empty'),$e.identity,$e.sddl)} 'Canonical'
 Refuse 'directory-parent-alias' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory(($root+'\empty\..\empty'),$e.identity,$e.sddl)} 'Canonical'
 Refuse 'directory-wrong-case-alias' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory(($root+'\EMPTY'),$e.identity,$e.sddl)} 'Canonical'
 Refuse 'directory-extended-prefix' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory(('\\?\'+$empty),$e.identity,$e.sddl)} 'Canonical'
 Refuse 'old-DeleteExisting-remains-file-only' {[Azurite.Stage.FileSecurity]::DeleteExisting($empty,$e.identity,$e.sddl,('0'*64))} 'Directory deletion forbidden'
 Check (Same $e (Observe $empty)) 'all-directory-refusals-preserve-original'
 $locked=[Azurite.Stage.FileSecurity]::LockDirectory($empty);try{Refuse 'directory-live-handle-lock' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($empty,$e.identity,$e.sddl)} '' 32}finally{$locked.Dispose()}
 [Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($empty,$e.identity,$e.sddl);Check (-not(Test-Path -LiteralPath $empty)) 'exact-empty-directory-deleted'
 $nonempty=Owned 'nonempty';[Azurite.Stage.FileSecurity]::NewDirectory($nonempty,$ds);$child=Join-Path $nonempty 'keep.bin';[Azurite.Stage.FileSecurity]::NewFile($child,[byte[]]@(1,2,3),$fs);$ne=Observe $nonempty;$ce=Observe $child
 Refuse 'nonempty-directory-native-refusal' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($nonempty,$ne.identity,$ne.sddl)} '' 145
 Check ((Same $ne (Observe $nonempty)) -and (Same $ce (Observe $child))) 'nonempty-directory-and-child-retained'
 $source=Owned 'source.bin';[Azurite.Stage.FileSecurity]::NewFile($source,[byte[]]@(97,98,99),$fs);$s=Observe $source
 Refuse 'file-type-not-directory' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($source,$s.identity,$s.sddl)} 'Directory type'
 $junctionTarget=Owned 'junction-target';[Azurite.Stage.FileSecurity]::NewDirectory($junctionTarget,$ds);$jt=Observe $junctionTarget;$junction=Owned 'junction';New-Item -ItemType Junction -Path $junction -Target $junctionTarget|Out-Null
 Check ([bool]((Get-Item -LiteralPath $junction -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) 'actual-owned-junction-established'
 Refuse 'reparse-directory-refused' {[Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($junction,$jt.identity,$jt.sddl)} 'Reparse'
 Check (Same $jt (Observe $junctionTarget)) 'reparse-target-retained'
 $destination=Owned 'archive.bin';Archive $source $s $destination;$a=Observe $destination
 Check ($a.bytes -eq $s.bytes -and $a.sha256 -ceq $s.sha256 -and $a.owner -ceq $s.owner -and $a.links -eq 1 -and $a.identity -cne $s.identity -and $a.finalPath -ceq $destination -and (Same $s (Observe $source))) 'small-archive-real-bytes-identity-owner-and-source-preserved'
 Refuse 'archive-create-new-no-overwrite' {Archive $source $s $destination} '' 80
 Check (Same $a (Observe $destination)) 'existing-archive-not-overwritten'
 $bad=Owned 'must-remain-absent.bin'
 Refuse 'archive-wrong-identity' {[Azurite.Stage.FileSecurity]::ArchiveFile($source,('0'*32),$s.sddl,$s.sha256,$s.bytes,$bad)} 'identity/descriptor'
 Refuse 'archive-wrong-sddl' {[Azurite.Stage.FileSecurity]::ArchiveFile($source,$s.identity,$s.ownerAccessSddl,$s.sha256,$s.bytes,$bad)} 'identity/descriptor'
 Refuse 'archive-wrong-sha' {[Azurite.Stage.FileSecurity]::ArchiveFile($source,$s.identity,$s.sddl,('0'*64),$s.bytes,$bad)} 'hash'
 Refuse 'archive-invalid-sha' {[Azurite.Stage.FileSecurity]::ArchiveFile($source,$s.identity,$s.sddl,('g'*64),$s.bytes,$bad)} 'hash'
 Refuse 'archive-wrong-length' {[Azurite.Stage.FileSecurity]::ArchiveFile($source,$s.identity,$s.sddl,$s.sha256,($s.bytes+1),$bad)} 'length'
 Refuse 'archive-negative-length' {[Azurite.Stage.FileSecurity]::ArchiveFile($source,$s.identity,$s.sddl,$s.sha256,-1,$bad)} 'length'
 Refuse 'archive-over-64MiB-declaration' {[Azurite.Stage.FileSecurity]::ArchiveFile($source,$s.identity,$s.sddl,$s.sha256,67108865,$bad)} 'length'
 Refuse 'archive-source-dot-alias' {[Azurite.Stage.FileSecurity]::ArchiveFile(($root+'\.\source.bin'),$s.identity,$s.sddl,$s.sha256,$s.bytes,$bad)} 'Canonical'
 Refuse 'archive-destination-dot-alias' {Archive $source $s ($root+'\.\must-remain-absent.bin')} 'Canonical'
 Refuse 'archive-destination-ADS' {Archive $source $s ($bad+':alternate')} 'Canonical'
 Refuse 'archive-source-is-directory' {[Azurite.Stage.FileSecurity]::ArchiveFile($nonempty,$ne.identity,$ne.sddl,('0'*64),0,$bad)} 'file type'
 Check (-not(Test-Path -LiteralPath $bad) -and (Same $s (Observe $source))) 'preflight-refusals-create-no-destination-and-preserve-source'
 $writer=[IO.File]::Open($source,[IO.FileMode]::Open,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite);try{Refuse 'archive-existing-writer-sharing-refused' {Archive $source $s $bad} '' 32}finally{$writer.Dispose()}
 $changed=Owned 'changed.bin';[Azurite.Stage.FileSecurity]::NewFile($changed,[byte[]]@(97,98,99),$fs);$old=Observe $changed;[IO.File]::WriteAllBytes($changed,[byte[]]@(97,98,100));$changedRecord=Observe $changed
 Refuse 'archive-changed-source-bytes' {Archive $changed $old $bad} 'hash'
 Check (Same $changedRecord (Observe $changed)) 'changed-source-not-modified-by-refusal'
 Refuse 'archive-hardlinked-source' {Archive $hardSource $hs $bad} 'Hardlinked'
 $targetFile=Join-Path $junctionTarget 'target.bin';[Azurite.Stage.FileSecurity]::NewFile($targetFile,[byte[]]@(4,5,6),$fs);$tf=Observe $targetFile
 Refuse 'archive-reparse-ancestor-source' {[Azurite.Stage.FileSecurity]::ArchiveFile((Join-Path $junction 'target.bin'),$tf.identity,$tf.sddl,$tf.sha256,$tf.bytes,$bad)} 'Canonical'
 Refuse 'archive-reparse-destination-parent' {Archive $targetFile $tf (Join-Path $junction 'not-created.bin')} 'Reparse'
 Check (-not(Test-Path -LiteralPath (Join-Path $junctionTarget 'not-created.bin'))) 'reparse-parent-no-target-creation'
 $unicodeName=([string][char]0x5F52+[char]0x6863);$unicode=Owned ($unicodeName+'.bin');[Azurite.Stage.FileSecurity]::NewFile($unicode,[byte[]]@(8,9,10),$fs);$u=Observe $unicode;$unicodeOut=Owned ($unicodeName+'-copy.bin');Archive $unicode $u $unicodeOut
 Check ((Observe $unicodeOut).sha256 -ceq $u.sha256 -and (Same $u (Observe $unicode))) 'unicode-source-and-destination-archive'
 $zero=Owned 'empty.bin';[Azurite.Stage.FileSecurity]::NewFile($zero,[byte[]]@(),$fs);$z=Observe $zero;$zeroOut=Owned 'empty-archive.bin';Archive $zero $z $zeroOut
 Check ((Observe $zeroOut).bytes -eq 0 -and (Observe $zeroOut).sha256 -ceq $z.sha256) 'zero-byte-archive'
 $large=Owned 'large.bin';$stream=[IO.File]::Open($large,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$buffer=[byte[]]::new(65536);for($i=0;$i -lt $buffer.Length;$i++){$buffer[$i]=[byte]($i%251)};$left=38561944;while($left -gt 0){$n=[Math]::Min($left,$buffer.Length);$stream.Write($buffer,0,$n);$left-=$n};$stream.Flush($true)}finally{$stream.Dispose()}
 $l=Observe $large;$largeOut=Owned 'large-archive.bin';Archive $large $l $largeOut;$la=Observe $largeOut
 Check ($l.bytes -eq 38561944 -and $la.bytes -eq $l.bytes -and $la.sha256 -ceq $l.sha256 -and (Same $l (Observe $large))) 'real-38561944-byte-streamed-archive-exceeds-old-4MiB-limit' @{bytes=$la.bytes;sha256=$la.sha256;sourceIdentity=$l.identity;destinationIdentity=$la.identity}
 $over=Owned 'over-limit.bin';$stream=[IO.File]::Open($over,[IO.FileMode]::CreateNew);try{$stream.SetLength(67108865)}finally{$stream.Dispose()};$o=Observe $over
 Refuse 'actual-over-64MiB-source-refused' {Archive $over $o $bad} 'length'
 Check (-not(Test-Path -LiteralPath $bad)) 'over-limit-no-destination'
 $result.passed=$true
}catch{$result.error=[pscustomobject]@{message=$_.Exception.ToString();scriptStack=$_.ScriptStackTrace};$result.passed=$false}
finally{
 foreach($lock in $held){try{$lock.Dispose();$steps.Add([pscustomobject]@{name='owned-ancestor-handle-closed';passed=$lock.IsClosed;evidence=$null});if(-not $lock.IsClosed){$result.passed=$false}}catch{$result.passed=$false}}
 $result.endedUtc=[DateTimeOffset]::UtcNow.ToString('o');$result.checks=$steps.ToArray();$result.checkCount=$steps.Count;$result.testSha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant();$result.helperAfterSha256=(Get-FileHash -LiteralPath $HelperPath).Hash.ToLowerInvariant();if($result.helperAfterSha256 -cne $ExpectedHelperSha256){$result.passed=$false}
 [IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
 [ordered]@{passed=$result.passed;checks=$result.checkCount;host=$result.host;result=$ResultPath;root=$root;error=$result.error}|ConvertTo-Json -Depth 5
}
if(-not $result.passed){exit 1}
