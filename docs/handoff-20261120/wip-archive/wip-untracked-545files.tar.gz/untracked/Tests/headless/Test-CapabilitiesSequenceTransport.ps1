param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$modulePath=Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1'
$resultRoot=Join-Path $repo 'artifacts\aa-fr-capabilities-sequence-source-20261113'
if([IO.Path]::GetFullPath($ResultPath) -cne $ResultPath -or -not $ResultPath.StartsWith($resultRoot+'\',[StringComparison]::Ordinal) -or [IO.File]::Exists($ResultPath)){throw 'Transport result must be a fresh scoped C artifact'}
function Save-Transport($value){$b=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 30 -Compress));$f=[IO.FileStream]::new($ResultPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()}}
$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($modulePath,[ref]$tokens,[ref]$errors)
if($errors.Count){Save-Transport ([pscustomobject]@{passed=$false;phase='source-parse';errors=@($errors|ForEach-Object Message);physicalExecution=$false});throw 'Sequence module parse failed'}
$loadedHash=(Get-FileHash -LiteralPath $modulePath).Hash.ToLowerInvariant()
Import-Module $modulePath -Force -DisableNameChecking
$result=& (Get-Module AzuriteCapabilitiesSequence) {
 $cases=@(
  @{name='normal-zero';throws=@();start=$true;wait=$true;exited=$true;code=0;returned=$true;started=$true;streams=$true;exit=$true;complete=$true;dispose=$true;retain=$false;error='';calls='Start,BeginStreams,Wait,HasExited,FinishStreams,ExitCode,Dispose'},
  @{name='normal-nonzero';throws=@();start=$true;wait=$true;exited=$true;code=86;returned=$true;started=$true;streams=$true;exit=$true;complete=$true;dispose=$true;retain=$false;error='';calls='Start,BeginStreams,Wait,HasExited,FinishStreams,ExitCode,Dispose'},
  @{name='start-false';throws=@();start=$false;returned=$true;started=$false;streams=$false;exit=$false;complete=$false;dispose=$true;retain=$false;error='Child did not start';calls='Start,Dispose'},
  @{name='start-throws-unknown';throws=@('Start');start=$true;returned=$false;started=$false;streams=$false;exit=$false;complete=$false;dispose=$false;retain=$true;error='injected-Start';calls='Start,Retain'},
  @{name='start-nonboolean-unknown';throws=@();start=1;returned=$false;started=$false;streams=$false;exit=$false;complete=$false;dispose=$false;retain=$true;error='Child start is unconfirmed';calls='Start,Retain'},
  @{name='begin-streams-throws';throws=@('BeginStreams');start=$true;returned=$true;started=$true;streams=$false;exit=$false;complete=$false;dispose=$false;retain=$true;error='injected-BeginStreams';calls='Start,BeginStreams,Retain'},
  @{name='wait-throws';throws=@('Wait');start=$true;returned=$true;started=$true;streams=$true;exit=$false;complete=$false;dispose=$false;retain=$true;error='injected-Wait';calls='Start,BeginStreams,Wait,Retain'},
  @{name='wait-false';throws=@();start=$true;wait=$false;returned=$true;started=$true;streams=$true;exit=$false;complete=$false;dispose=$false;retain=$true;error='Child wait is unconfirmed';calls='Start,BeginStreams,Wait,Retain'},
  @{name='has-exited-throws';throws=@('HasExited');start=$true;wait=$true;returned=$true;started=$true;streams=$true;exit=$false;complete=$false;dispose=$false;retain=$true;error='injected-HasExited';calls='Start,BeginStreams,Wait,HasExited,Retain'},
  @{name='has-exited-false';throws=@();start=$true;wait=$true;exited=$false;returned=$true;started=$true;streams=$true;exit=$false;complete=$false;dispose=$false;retain=$true;error='Child exit is unconfirmed';calls='Start,BeginStreams,Wait,HasExited,Retain'},
  @{name='finish-streams-throws';throws=@('FinishStreams');start=$true;wait=$true;exited=$true;returned=$true;started=$true;streams=$true;exit=$true;complete=$false;dispose=$false;retain=$true;error='injected-FinishStreams';calls='Start,BeginStreams,Wait,HasExited,FinishStreams,Retain'},
  @{name='dispose-throws';throws=@('Dispose');start=$true;wait=$true;exited=$true;code=0;returned=$true;started=$true;streams=$true;exit=$true;complete=$true;dispose=$false;retain=$true;error='injected-Dispose';calls='Start,BeginStreams,Wait,HasExited,FinishStreams,ExitCode,Dispose,Retain'},
  @{name='first-error-survives-dispose-throw';throws=@('Dispose');start=$false;returned=$true;started=$false;streams=$false;exit=$false;complete=$false;dispose=$false;retain=$true;error='Child did not start';calls='Start,Dispose,Retain'},
  @{name='exit-code-query-throws';throws=@('ExitCode');start=$true;wait=$true;exited=$true;returned=$true;started=$true;streams=$true;exit=$true;complete=$true;dispose=$true;retain=$false;error='injected-ExitCode';calls='Start,BeginStreams,Wait,HasExited,FinishStreams,ExitCode,Dispose'},
  @{name='void-output-does-not-contaminate-success-state';noisy=$true;throws=@();start=$true;wait=$true;exited=$true;code=0;returned=$true;started=$true;streams=$true;exit=$true;complete=$true;dispose=$true;retain=$false;error='';calls='Start,BeginStreams,Wait,HasExited,FinishStreams,ExitCode,Dispose'},
  @{name='void-output-does-not-contaminate-retained-state';noisy=$true;throws=@();start=$true;wait=$false;returned=$true;started=$true;streams=$true;exit=$false;complete=$false;dispose=$false;retain=$true;error='Child wait is unconfirmed';calls='Start,BeginStreams,Wait,Retain'}
 )
 $results=[Collections.Generic.List[object]]::new();$failures=[Collections.Generic.List[string]]::new()
 foreach($case in $cases){
  $state=[pscustomobject]@{startAttempted=$false;startReturned=$false;started=$false;streamsStarted=$false;exitConfirmed=$false;streamsCompleted=$false;disposed=$false;retained=$false;exitCode=$null;primaryError=$null}
  $observed=@{calls=[Collections.Generic.List[string]]::new();disposed=$false;retained=$false}
  $ops={param($action,$s)
   $observed.calls.Add($action)
   if($case.throws -ccontains $action){throw ('injected-'+$action)}
   switch($action){Start {return $case.start};BeginStreams {if($case.ContainsKey('noisy')){return [pscustomobject]@{ignored='begin-streams'}};return};Wait {return $case.wait};HasExited {return $case.exited};FinishStreams {if($case.ContainsKey('noisy')){return [pscustomobject]@{ignored='finish-streams'}};return};ExitCode {return $case.code};Dispose {$observed.disposed=$true;if($case.ContainsKey('noisy')){return [pscustomobject]@{ignored='dispose'}};return};Retain {$observed.retained=$true;if($case.ContainsKey('noisy')){return [pscustomobject]@{ignored='retain'}};return};default {throw ('Unexpected operation (including Kill): '+$action)}}
  }.GetNewClosure()
  $failure=$null
  try{
   $returned=Invoke-SequenceOwnedProcess $state $ops
   Assert-Sequence ($returned.startAttempted -eq $true) 'Start attempt not recorded'
   foreach($pair in @(@('startReturned','returned'),@('started','started'),@('streamsStarted','streams'),@('exitConfirmed','exit'),@('streamsCompleted','complete'),@('disposed','dispose'),@('retained','retain'))){Assert-Sequence ($returned.($pair[0]) -eq $case[$pair[1]]) ('Wrong state '+$pair[0])}
   Assert-Sequence (($observed.calls -join ',') -ceq $case.calls) 'Wrong lifecycle action order or forbidden disposal/kill'
   Assert-Sequence ($observed.disposed -eq $returned.disposed -and $observed.retained -eq $returned.retained) 'Cleanup flags do not match completed operations'
   if($case.error){Assert-Sequence ($returned.primaryError -like ('*'+$case.error+'*')) 'Original failure was lost or overwritten'}else{Assert-Sequence ([string]::IsNullOrEmpty($returned.primaryError)) 'Successful transport invented an error'}
   if($case.name -ceq 'first-error-survives-dispose-throw'){Assert-Sequence ($returned.primaryError -notlike '*injected-Dispose*') 'Cleanup failure replaced the original start refusal'}
   if($case.ContainsKey('code')){Assert-Sequence ($returned.exitCode -is [int] -and $returned.exitCode -eq $case.code) 'Actual zero/nonzero child exit code was changed'}else{Assert-Sequence ($null -eq $returned.exitCode) 'Exit code invented without a successful query'}
   if($case.name -ceq 'normal-nonzero'){Assert-Sequence ($returned.exitCode -ne 0) 'Nonzero child failure was converted to success'}
  }catch{$failure=$_.Exception.ToString();$failures.Add($case.name+': '+$failure)}
  $results.Add([pscustomobject]@{name=$case.name;passed=($null -eq $failure);state=$state;actions=$observed.calls.ToArray();failure=$failure})
 }
 # Additional read-only diagnostic beyond the requested matrix: a failure of
 # Retain itself must not be confused with the primary child-start failure.
 $retainState=[pscustomobject]@{startAttempted=$false;startReturned=$false;started=$false;streamsStarted=$false;exitConfirmed=$false;streamsCompleted=$false;disposed=$false;retained=$false;exitCode=$null;primaryError=$null}
 $retentionException=$null;$retentionObservation=@{attemptFailed=$false}
 $retentionOps={param($a,$s)if($a -ceq 'Start'){throw 'primary-start-unknown'};if($a -ceq 'Retain'){$retentionObservation.attemptFailed=$true;throw 'secondary-retention-failed'};throw ('Unexpected diagnostic action '+$a)}.GetNewClosure()
 try{$null=Invoke-SequenceOwnedProcess $retainState $retentionOps}catch{$retentionException=$_.Exception.ToString()}
 [pscustomobject]@{passed=($failures.Count -eq 0);requiredCases=$cases.Count;passedCases=@($results|Where-Object passed).Count;failures=$failures.ToArray();cases=$results.ToArray();retentionFailureDiagnostic=[pscustomobject]@{returnedWithoutThrow=($null -eq $retentionException);escapingException=$retentionException;state=$retainState;retentionCallFailed=$retentionObservation.attemptFailed;retainedReferenceConfirmed=$false;primaryFailurePreserved=($retainState.primaryError -like '*primary-start-unknown*');reportedRetentionDespiteFailedOperation=($retainState.retained -and $retentionObservation.attemptFailed)};realProcessStartCalled=$false;collectorExecuted=$false;FReadPerformed=$false;FWritePerformed=$false;registryAccessPerformed=$false;nativeExecuted=$false}
}
$result|Add-Member -NotePropertyName loadedModuleSha256 -NotePropertyValue $loadedHash
$result|Add-Member -NotePropertyName moduleSha256After -NotePropertyValue ((Get-FileHash -LiteralPath $modulePath).Hash.ToLowerInvariant())
Save-Transport $result
$result|Select-Object passed,requiredCases,passedCases,loadedModuleSha256,moduleSha256After,@{n='retentionFailureEscaped';e={-not $_.retentionFailureDiagnostic.returnedWithoutThrow}},realProcessStartCalled,collectorExecuted,FReadPerformed,registryAccessPerformed|ConvertTo-Json -Compress
if(-not $result.passed){exit 1}
