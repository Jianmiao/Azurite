param([Parameter(Mandatory)][string]$HelperBuildDirectory,[Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
Import-Module (Join-Path $repo 'tools\headless\FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($helper,$output)
 Assert-RecoveryCPath $output $false;Assert-Recovery (-not [IO.Directory]::Exists($output)) 'Fresh source-test output required';[void][IO.Directory]::CreateDirectory($output)
 $paths=@{};foreach($n in @('FullRestrictedPreparationRecovery.psm1','Recover-AzuriteFullPreparation.ps1','FullRestrictedStageTransition.psm1')){$paths[$n]=Join-Path (Join-Path $script:RecoveryRepo 'tools\headless') $n};foreach($n in @('FullRestrictedStageFileSecurity.cs','FullRestrictedStageFileSecurity.dll','build.json')){$paths[$n]=Join-Path $helper $n};$pins=Get-RecoveryTokenPins;foreach($n in $pins.Keys){$paths[$n]=$pins[$n].path}
 $files=@(foreach($n in @($paths.Keys|Sort-Object -CaseSensitive)){$p=$paths[$n];Assert-RecoveryCPath $p;$b=[IO.File]::ReadAllBytes($p);[pscustomobject]@{name=$n;path=$p;sha256=(Get-RecoveryHash $b);bytes=$b.Length}})
 $manifest=[pscustomobject]@{schema=1;scope='accepted-22bac-prelaunch-recovery-source';runId=$script:RecoveryRun;files=$files}
 $manifestPath=Join-Path $output 'source-manifest.json';Write-RecoveryCRecord $manifestPath $manifest;$manifestHash=Get-RecoveryHash ([IO.File]::ReadAllBytes($manifestPath))
 $bound=Read-RecoverySourceBindings $manifestPath $manifestHash;Assert-Recovery ($bound.files.Count -eq 9) 'Exact new recovery source graph failed'
 foreach($case in @('WrongDigest','WrongToken','ForeignModulePath','WrongHelperBuild')){
  $copy=ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $manifest)));$expectedError=''
  switch($case){
   WrongDigest {$copy.files[0].sha256='0'*64;$expectedError='Pinned C evidence differs:*'}
   WrongToken {($copy.files|Where-Object name -CEQ RestrictedCliNative.dll).sha256='0'*64;$expectedError='Token reader must use*'}
   ForeignModulePath {($copy.files|Where-Object name -CEQ FullRestrictedPreparationRecovery.psm1).path='C:\foreign.psm1';$expectedError='Executing recovery source path differs'}
   WrongHelperBuild {$b=ConvertFrom-RecoveryJson $bound.files['build.json'].bytes;$b.assemblySha256='0'*64;$p=Join-Path $output 'wrong-build.json';Write-RecoveryCRecord $p $b;$f=$copy.files|Where-Object name -CEQ build.json;$f.path=$p;$bytes=[IO.File]::ReadAllBytes($p);$f.sha256=Get-RecoveryHash $bytes;$f.bytes=$bytes.Length;$expectedError='New recovery helper build provenance differs'}
  }
  $p=Join-Path $output ($case+'.json');Write-RecoveryCRecord $p $copy;$rejected=$false;try{$null=Read-RecoverySourceBindings $p (Get-RecoveryHash ([IO.File]::ReadAllBytes($p)))}catch{$rejected=$_.Exception.Message -like $expectedError};Assert-Recovery $rejected ('Source guard failed: '+$case)
 }
 Assert-Recovery (-not ('Azurite.Stage.FileSecurity' -as [type]) -and -not ('Azurite.Restricted.FullBootstrapIdentity' -as [type])) 'Source-only binding unexpectedly loaded native code'
 $result=[pscustomobject]@{passed=$true;negativeCases=4;manifestPath=$manifestPath;manifestSha256=$manifestHash;fileCount=9;FReadPerformed=$false;FWritePerformed=$false;NativeExecuted=$false};Write-RecoveryCRecord (Join-Path $output 'source-test-result.json') $result;$result
} $HelperBuildDirectory $OutputDirectory
