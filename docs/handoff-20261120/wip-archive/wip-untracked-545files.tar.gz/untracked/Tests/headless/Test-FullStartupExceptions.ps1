param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$planner=Import-Module (Join-Path $repo 'tools/headless/FullRestrictedCapabilitiesPlan.psm1') -Force -PassThru -DisableNameChecking
$runtime=Import-Module (Join-Path $repo 'tools/headless/FullRestrictedCapabilitiesRuntime.psm1') -Force -PassThru -DisableNameChecking
$has=& $runtime { [bool](Get-Command Get-AzuriteFullStartupDiagnostic -ErrorAction SilentlyContinue) }
if(-not $has){throw 'Fixed startup exception diagnostic contract missing'}
$count=0;function Check($b,[string]$why){$script:count++;if(-not $b){throw ('Diagnostic test failed: '+$why)}}
function Refuse([scriptblock]$call,[string]$why){$caught=$false;try{& $call}catch{$caught=$true};Check $caught $why}
$run='a'*32
$diagnostic=& $runtime {param($r)Get-AzuriteFullStartupDiagnostic 'startup-exceptions.v1' $r} $run
$planDiagnostic=& $planner {param($r)Get-AzuriteFullStartupDiagnostic 'startup-exceptions.v1' $r} $run
Check (($diagnostic|ConvertTo-Json -Depth 12 -Compress) -ceq ($planDiagnostic|ConvertTo-Json -Depth 12 -Compress)) 'same source-bound diagnostic contract in planner and runtime'
Check ($null -eq (& $runtime {param($r)Get-AzuriteFullStartupDiagnostic $null $r} $run)) 'ordinary capabilities has no diagnostic contract'
foreach($bad in @('','none','other',$true,1,[pscustomobject]@{path='C:\outside'})){Refuse {& $runtime {param($v,$r)Get-AzuriteFullStartupDiagnostic $v $r} $bad $run} 'invalid diagnostic selection'}
Check ($diagnostic.path -ceq ('F:\AzuriteLabs\Editor-20261108-normal\runs\restricted-'+$run+'\output\startup-exceptions.nettrace') -and $diagnostic.fileMask -ceq '0x12019F' -and $diagnostic.outputLimitBytes -eq 4194304) 'unique derived file and unchanged finite output bound'
$psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName='F:\AzuriteLabs\Editor-20261108-normal\install\AzureArchive.exe';$psi.WorkingDirectory='F:\AzuriteLabs\Editor-20261108-normal\install';$beforeEnvironment=[Environment]::GetEnvironmentVariables('Process')
$control=[pscustomobject]@{runId=$run;startupDiagnostic='startup-exceptions.v1'}
& $runtime {param($p,$c)Set-AzuriteFullStartupDiagnosticEnvironment $p $c} $psi $control
foreach($entry in $diagnostic.environment.PSObject.Properties){Check ($psi.EnvironmentVariables[$entry.Name] -ceq $entry.Value) ('exact child-only value '+$entry.Name)}
Check ([Environment]::GetEnvironmentVariable('DOTNET_EventPipeOutputPath','Process') -ceq $beforeEnvironment['DOTNET_EventPipeOutputPath']) 'parent environment unchanged'
Check (-not $psi.EnvironmentVariables.ContainsKey('BEPINEX_PRELOADER_LOG')) 'fallback failure log remains unredirected'
foreach($key in @('DOTNET_EnableEventPipe','COMPlus_EventPipeConfig','DOTNET_DiagnosticPorts','BEPINEX_PRELOADER_LOG','BEPINEX_FAIL_FAST')){Refuse {& $runtime {param($k)Assert-AzuriteFullEnvironment @{$k='1'}} $key} ('ambient override refused '+$key)}
$badPsi=[Diagnostics.ProcessStartInfo]::new();$badPsi.FileName='C:\other.exe';$badPsi.WorkingDirectory=$psi.WorkingDirectory
Refuse {& $runtime {param($p,$c)Set-AzuriteFullStartupDiagnosticEnvironment $p $c} $badPsi $control} 'cannot inject into arbitrary target'
function Clone($v){$p=@{InputObject=($v|ConvertTo-Json -Depth 90 -Compress);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$p.DateKind='String'};ConvertFrom-Json @p}
$legacy=Join-Path $repo 'artifacts/aa-fr-inputs/sequence-9c1fcbc9886641878858bb6424b6e604'
$facts=Get-Content (Join-Path $legacy 'facts.json') -Raw -Encoding UTF8|ConvertFrom-Json;$oldPlan=Get-Content (Join-Path $legacy 'plan.json') -Raw -Encoding UTF8|ConvertFrom-Json
$contract=Read-AzuriteFullCapabilitiesContract;$cache=Get-Content (Join-Path $repo 'artifacts/aa-fr-cache-prerequisites/cache-prerequisites-contract.json') -Raw -Encoding UTF8|ConvertFrom-Json
$ordinary=New-AzuriteFullCapabilitiesPlan -Contract $contract -CachePrerequisites $cache -RunId $facts.runId -Facts $facts
Check ($ordinary.PreparationReady -and $ordinary.PlanSha256 -ceq $oldPlan.PlanSha256 -and -not $ordinary.PSObject.Properties['StartupDiagnostic']) 'default ordinary frozen plan hash unchanged'
$facts|Add-Member startupDiagnostic 'startup-exceptions.v1'
$plan=New-AzuriteFullCapabilitiesPlan -Contract $contract -CachePrerequisites $cache -RunId $facts.runId -Facts $facts
Check ($plan.PreparationReady -and $plan.PlanSha256 -cne $ordinary.PlanSha256 -and $plan.MutableLeaves.Count -eq 7 -and $plan.BeforeImages.Count -eq 7 -and $plan.BeforeImages[-1].absenceProof -and $null -eq $plan.BeforeImages[-1].initialSha256) 'diagnostic binds distinct hash and exactly seventh absent leaf'
$diagControl=[pscustomobject]@{startupDiagnostic='startup-exceptions.v1'}
& $runtime {param($p,$c)Assert-AzuriteFullStartupDiagnosticBinding $p $c} $plan $diagControl;Check $true 'plan and control same diagnostic'
Refuse {& $runtime {param($p)Assert-AzuriteFullStartupDiagnosticBinding $p ([pscustomobject]@{})} $plan} 'diagnostic plan cannot be used with ordinary control'
Refuse {& $runtime {param($p,$c)Assert-AzuriteFullStartupDiagnosticBinding $p $c} $ordinary $diagControl} 'ordinary plan cannot silently enable diagnostic'
$forged=Clone $plan;$forged.StartupDiagnostic.path='C:\outside.nettrace';Refuse {Get-AzuriteFullExpectedRoles $forged $diagControl} 'forged diagnostic absolute path rejected'
$forged=Clone $plan;$forged.MutableLeaves[-1].path='output/other.nettrace';Refuse {Get-AzuriteFullExpectedRoles $forged $diagControl} 'extra arbitrary trace leaf rejected'
$roles=Get-AzuriteFullExpectedRoles $plan $diagControl;$normalRoles=Get-AzuriteFullExpectedRoles $ordinary ([pscustomobject]@{})
Check ($roles.Count -eq $normalRoles.Count+1 -and $roles[$plan.StartupDiagnostic.path][1] -ceq '0x12019F') 'only one additional existing-file Logon grant'
foreach($phase in @('Prepared','BeforeNative','AfterNative','Complete','DiagnosticFailed')){$inventory=Get-AzuriteFullExpectedInventory $plan $diagControl $phase;Check (@($inventory[(Split-Path -Parent $plan.StartupDiagnostic.path)]|Where-Object {$_ -ceq 'startup-exceptions.nettrace'}).Count -eq 1) ('exact trace leaf in '+$phase)}
$invalidFacts=Clone $facts;$invalidFacts.startupDiagnostic='C:\other';$invalid=New-AzuriteFullCapabilitiesPlan -Contract $contract -CachePrerequisites $cache -RunId $facts.runId -Facts $invalidFacts;Check (-not $invalid.PreparationReady) 'planner refuses path as selection'
$stage=Import-Module (Join-Path $repo 'tools/headless/FullRestrictedStageTransition.psm1') -Force -PassThru -DisableNameChecking
$empty='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';$runPath=$plan.LabRoot+'\runs\restricted-'+$plan.RunId;$loader=$plan.LabRoot+'\install\BepInEx\LogOutput.log';$current=@{};foreach($path in @($loader,($runPath+'\output\unity.log'),$plan.StartupDiagnostic.path)){$current[$path]=[pscustomobject]@{identity=('b'*32);bytes=0;sha256=$empty}}
$spec=[pscustomobject]@{RunId=$plan.RunId;Run=$runPath;Loader=$loader;Input=[pscustomobject]@{Plan=$plan}};$baselineBytes=& $stage {param($s,$c)Get-TransitionEvidenceBytes ([pscustomobject]@{kind='log-baselines'}) $s @() $c} $spec $current
$baseline=[Text.UTF8Encoding]::new($false).GetString($baselineBytes)|ConvertFrom-Json
Check ($baseline.logs.Count -eq 3 -and $baseline.logs[-1].path -ceq $plan.StartupDiagnostic.path -and $baseline.logs[-1].identity -ceq ('b'*32) -and $baseline.logs[-1].bytes -eq 0 -and $baseline.logs[-1].sha256 -ceq $empty) 'actual stage projection binds trace precreated identity and empty hash'
$fakeFacts=Clone $facts;$fakeFacts.transition=[pscustomobject]@{unityLogFileIdentity=('c'*32);startupTraceFileIdentity=('b'*32)}
$receipt=[pscustomobject]@{state='precreated-empty';path='output/unity.log';baselineBytes=0;fileIdentity=('c'*32);fileMask='0x12019F';ownerSid=$contract.ownerSid;startupTrace=[pscustomobject]@{path='output/startup-exceptions.nettrace';baselineBytes=0;fileIdentity=('b'*32);fileMask='0x12019F';ownerSid=$contract.ownerSid}}
$fail=& $planner {param($r,$p,$f)$errors=[Collections.Generic.List[string]]::new();Test-ReceiptResult 'unity-log-precreation' $r $p $f '' $null @{} $errors;return ,$errors.ToArray()} $receipt $plan $fakeFacts
Check ($fail.Count -eq 0) 'actual planner accepts typed trace precreation receipt'
$receipt.startupTrace.fileIdentity='wrong';$fail=& $planner {param($r,$p,$f)$errors=[Collections.Generic.List[string]]::new();Test-ReceiptResult 'unity-log-precreation' $r $p $f '' $null @{} $errors;return ,$errors.ToArray()} $receipt $plan $fakeFacts
Check ($fail.Count -gt 0) 'changed trace identity fails admission receipt'
$oldStage=Get-Content (Join-Path $repo 'artifacts/aa-startup-exception-route-20261113/before-source/FullRestrictedStageTransition.psm1') -Raw;$newStage=Get-Content (Join-Path $repo 'tools/headless/FullRestrictedStageTransition.psm1') -Raw
$pattern='(?s)\$script:TransitionNativeSource\s*=\s*@''(.*?)''@';Check ([regex]::Match($oldStage,$pattern).Groups[1].Value.Length -gt 1000 -and [regex]::Match($oldStage,$pattern).Groups[1].Value -ceq [regex]::Match($newStage,$pattern).Groups[1].Value) 'embedded samehandle native security helper unchanged'
$record=[ordered]@{scope='fixed startup EventPipe source-bound route pure tests';passed=$true;checks=$count;synthetic=$true;AALaunched=$false;FModified=$false;host=$PSVersionTable.PSVersion.ToString()}
[IO.Directory]::CreateDirectory($OutputDirectory)|Out-Null
[IO.File]::WriteAllText((Join-Path $OutputDirectory ('result-'+$PSVersionTable.PSVersion.Major+'.json')),($record|ConvertTo-Json),[Text.UTF8Encoding]::new($false));$record|ConvertTo-Json
