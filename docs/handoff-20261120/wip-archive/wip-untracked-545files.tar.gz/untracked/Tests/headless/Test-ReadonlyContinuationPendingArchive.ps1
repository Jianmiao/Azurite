param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));Import-Module (Join-Path $repo 'tools/headless/FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($out)
 Assert-RecoveryCPath $out $false;Assert-Recovery (-not [IO.Directory]::Exists($out)) 'Fresh C test output required';[void][IO.Directory]::CreateDirectory($out)
 $candidate=Join-Path $script:RecoveryRepo 'artifacts/aa-fr-readonly-trace-continuation/candidate';$spec=Get-ReadonlyTraceContinuationPlan (Join-Path $candidate 'continuation-evidence.json') '75266f8a8cd77fa92c9e4fbf6638f4e832ee92289a169ed47b8b1f9019376de6'
 $expected=@($spec.Created|Where-Object path -CEQ $spec.PendingPath)[0];$prepared=@($spec.Prepared|Where-Object path -CEQ $spec.PendingPath)[0];$pendingBytes=[Convert]::FromBase64String($spec.PendingContent)
 $helper=Read-RecoveryPinnedC (Join-Path $script:RecoveryRepo 'artifacts/aa-fr-empty-directory-helper-20261113/helper-build1/FullRestrictedStageFileSecurity.dll') '0d1bbc0541dd7e1b74619b62c1bbdf4cef00a35b21cdf2a7e4d11f4505a1e84b';[void][Reflection.Assembly]::Load($helper)
 $path=Join-Path $out 'pending.json';[IO.File]::WriteAllBytes($path,$pendingBytes);$actual=[Azurite.Stage.FileSecurity]::Read($path,$false)
 # Keep the actual C object identity/descriptor, but consume the exact length/hash
 # derived by the production binder for its current pending creation.
 $archiveExpected=ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $actual)));$archiveExpected.bytes=$expected.bytes;$archiveExpected.sha256=$expected.sha256
 $archive=Join-Path $out 'archive';[void][IO.Directory]::CreateDirectory($archive)
 $state=@{Spec=[pscustomobject]@{PendingPath=$path;OwnerSid=$actual.owner;Continuation=$spec.Continuation};ArchiveDirectory=$archive;EvidenceDirectory=$out;Locks=@{};Physical=(New-RecoveryPhysicalBackend)}
 $passed=$false;$errorText=$null;$saved=$null
 try{$saved=Invoke-RecoveryOp (New-ReadonlyTraceContinuationBackend) $state Archive @{path=$path;expected=$archiveExpected};$savedBytes=[IO.File]::ReadAllBytes($saved.destination);Assert-Recovery ($expected.bytes -eq 459 -and $prepared.bytes -eq $expected.bytes -and $prepared.sha256 -ceq $expected.sha256 -and $savedBytes.Length -eq 459 -and (Get-RecoveryHash $savedBytes) -ceq '45deee4e668d9197282fbe4950795bfb4ba1b59b65d14ebaf92e2a18d91a2abb' -and [IO.File]::ReadAllBytes($path).Length -eq 459) 'Current pending archive bytes differ';$marker=ConvertFrom-RecoveryJson $savedBytes;Assert-Recovery ($marker.state -ceq 'recovery-in-progress' -and $marker.recoveryId -ceq '9f8f2a58d98a468f8144eca3700b6649' -and $marker.automaticRetryAllowed -eq $false) 'Current pending content differs';$passed=$true}catch{$errorText=$_.Exception.ToString()}finally{foreach($handle in $state.Locks.Values){$handle.Dispose()};$state.Locks.Clear()}
 $result=[pscustomobject]@{passed=$passed;expectedCreatedBytes=$expected.bytes;expectedCreatedSha256=$expected.sha256;preparedBytes=$prepared.bytes;actualSourceBytes=$pendingBytes.Length;archive=$saved;error=$errorText;realFileArchive=$true;FReadPerformed=$false;FWritePerformed=$false;globalLeaseAcquired=$false;readonlyHelperLoaded=([bool]('Azurite.Recovery.ArchivedReadonlyTraceDelete' -as [type]))};Write-RecoveryCRecord (Join-Path $out 'result.json') $result;$result|ConvertTo-Json -Depth 4;if(-not $passed){exit 1}
} $OutputDirectory
