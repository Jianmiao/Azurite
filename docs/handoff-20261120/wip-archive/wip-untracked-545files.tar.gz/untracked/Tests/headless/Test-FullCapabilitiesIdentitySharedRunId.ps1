param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$original=Join-Path $repo '.superpowers\sdd\azurite-authoring-20261108\Capture-FullCapabilitiesIdentityShared-963b80c1.ps1'
$candidate=Join-Path $repo 'tools\headless\Capture-AzuriteFullCapabilitiesIdentityShared.ps1'
function Check($value,[string]$message){if(-not $value){throw ('FAIL '+$message)}}
Check ([IO.File]::Exists($candidate)) 'RED: parameterized identity/shared capture wrapper is missing'
Check ((Get-FileHash -LiteralPath $original).Hash.ToLowerInvariant() -ceq '99185a607ef2f564c21781fc498a29c3aec389c74631a424ffeb8878a963899e') 'original wrapper must remain byte-identical'
$before=[IO.File]::ReadAllText($original);$after=[IO.File]::ReadAllText($candidate)
$tokens=$null;$errors=$null;$oldAst=[Management.Automation.Language.Parser]::ParseInput($before,[ref]$tokens,[ref]$errors);Check ($errors.Count -eq 0) 'original parse'
$newAst=[Management.Automation.Language.Parser]::ParseInput($after,[ref]$tokens,[ref]$errors);Check ($errors.Count -eq 0) 'candidate parse'
$run=@($newAst.ParamBlock.Parameters|Where-Object{$_.Name.VariablePath.UserPath -ceq 'RunId'});Check ($run.Count -eq 1) 'exactly one RunId parameter'
Check (@($run[0].Attributes|Where-Object{$_.TypeName.FullName -ceq 'Parameter' -and @($_.NamedArguments|Where-Object ArgumentName -CEQ Mandatory).Count -eq 1}).Count -eq 1) 'RunId remains mandatory'
$versionPredicate=@($newAst.FindAll({param($node)$node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Test-HarmlessReceiptKind'},$true))
Check ($versionPredicate.Count -eq 1) 'one separately behavior-tested version predicate'
$candidateGate=@(($after -split '\r?\n')|Where-Object {$_ -like 'Need ((Test-HarmlessReceiptKind*'})
$originalGate=@(($before -split '\r?\n')|Where-Object {$_ -like 'Need ($receipt.schema*' -or ($_ -like 'foreach($n in*' -and $_.Contains('desktopLeaseAcrossBootstrapExit'))})
Check ($candidateGate.Count -eq 1 -and $originalGate.Count -eq 2) 'explicit receipt version gate replacement only'
$normalized=$after.Replace($versionPredicate[0].Extent.Text+"`n",'').Replace($candidateGate[0],($originalGate -join "`n")).Replace($newAst.ParamBlock.Extent.Text,$oldAst.ParamBlock.Extent.Text).Replace('$run=$RunId',"`$run='963b80c1ea494ed48098f2ee11bb8997'").Replace("`$tooling=`$repo+'\.superpowers\sdd\azurite-authoring-20261108\aa-fr-ftarget-cleanup-build-20261113\tooling'","`$tooling=`$PSScriptRoot+'\aa-fr-ftarget-freeze2-build-20261112\tooling'").Replace('d599e0431f075c5941d55b761307881213035fcaaaf5189c73babe6eb6710892','460694d0abd2771580c4989485cba134ed01a525c310f4c136adc4123970c73f').Replace('498a2e819c83840095a8391adeca691fc48cf120286f11742f6a77b4ceca6f04','55e2971726db57665e45943199d4ce82a03bed9d111b74bfcff1e98535cb3e74')
Check ($normalized.Replace("`r`n","`n") -ceq $before.Replace("`r`n","`n")) 'only RunId parameterization, receipt version gate and reviewed cleanup tooling binding may differ'
# Compile only the actual RunId parameter declaration plus a return expression.
# The capture wrapper, its body, imports, mutex, native and registry calls never run.
$probe=[scriptblock]::Create('param('+$run[0].Extent.Text+') $RunId')
$valid=@('963b80c1ea494ed48098f2ee11bb8997',('1'*32),('a'*32),('0'*31+'1'))
foreach($value in $valid){Check ((& $probe -RunId $value) -ceq $value) 'canonical nonzero RunId is preserved'}
$invalid=@('',('0'*32),('A'*32),('a'*31),('a'*33),('g'*32),(' '+('a'*32)),(('a'*32)+' '),'963b80c1ea494ed48098f2ee11bb899Z',(('a'*32)+"`n"),(('a'*32)+"`r`n"),$null)
foreach($value in $invalid){$rejected=$false;try{$null=& $probe -RunId $value}catch [System.Management.Automation.ParameterBindingException]{$rejected=$true};Check $rejected 'invalid RunId is rejected before wrapper body'}
Check (-not [IO.File]::Exists($ResultPath) -and [IO.Path]::GetFullPath($ResultPath).StartsWith($repo+'\artifacts\',[StringComparison]::Ordinal)) 'result must be a fresh C artifact'
$result=[pscustomobject]@{passed=$true;validCases=$valid.Count;invalidCases=$invalid.Count;originalSha256='99185a607ef2f564c21781fc498a29c3aec389c74631a424ffeb8878a963899e';candidateSha256=(Get-FileHash -LiteralPath $candidate).Hash.ToLowerInvariant();powerShell=$PSVersionTable.PSVersion.ToString();onlyAuthorizedParameterizationAndMonitorBindingDifferences=$true;wrapperExecuted=$false;collectorExecuted=$false;nativeExecuted=$false;registryAccessPerformed=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 5 -Compress),[Text.UTF8Encoding]::new($false));$result|ConvertTo-Json -Compress
