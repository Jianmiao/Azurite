param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$modulePath=Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1'
$root=Join-Path $repo 'artifacts\aa-fr-capabilities-sequence-source-20261113'
if([IO.Path]::GetFullPath($OutputDirectory) -cne $OutputDirectory -or -not $OutputDirectory.StartsWith($root+'\',[StringComparison]::Ordinal) -or [IO.Directory]::Exists($OutputDirectory)){throw 'Smoke output must be a fresh C artifact directory'}
$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($modulePath,[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Sequence source parse failed'}
$moduleHash=(Get-FileHash -LiteralPath $modulePath).Hash.ToLowerInvariant()
Import-Module $modulePath -Force -DisableNameChecking
$module=Get-Module AzuriteCapabilitiesSequence
[void][IO.Directory]::CreateDirectory($OutputDirectory)
function Check($v,[string]$name){if(-not $v){throw ('FAIL '+$name)}}
function Hash([byte[]]$bytes){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function Save([string]$name,$v){$p=Join-Path $OutputDirectory $name;$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 25 -Compress));$s=[IO.FileStream]::new($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()}}
$childPath=Join-Path $OutputDirectory 'owned-output-only-child.ps1'
$child=@'
param([Parameter(Mandatory)][int]$RequestedExit)
$ErrorActionPreference='Stop'
$utf8=[Text.UTF8Encoding]::new($false)
$marker=$utf8.GetString([Convert]::FromBase64String('5rGJ5a2XL8OpL/CfmYI='))
$json='{"marker":"'+$marker+'","payload":"'+('x'*(5*1024*1024+113))+'","code":'+$RequestedExit+'}'
$bytes=$utf8.GetBytes($json)
$out=[Console]::OpenStandardOutput();$out.Write($bytes,0,$bytes.Length);$out.Flush()
$errorBytes=$utf8.GetBytes('stderr:'+ $marker+':'+$RequestedExit)
$err=[Console]::OpenStandardError();$err.Write($errorBytes,0,$errorBytes.Length);$err.Flush()
exit $RequestedExit
'@
[IO.File]::WriteAllText($childPath,$child,[Text.UTF8Encoding]::new($true))
$utf8=[Text.UTF8Encoding]::new($false,$true);$marker=$utf8.GetString([Convert]::FromBase64String('5rGJ5a2XL8OpL/CfmYI='));$payload='x'*(5*1024*1024+113)
$hosts=@(@('PS51',(Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')),@('PS7',(Join-Path $PSHOME 'pwsh.exe')))
$cases=[Collections.Generic.List[object]]::new();$primary=$null;$retention=$null;$transportAttempts=0;$failurePosition=$null;$failureStack=$null
try{
 foreach($hostInfo in $hosts){foreach($code in @(0,7)){
  $label=$hostInfo[0]+'-exit'+$code;$caseDir=Join-Path $OutputDirectory $label;[void][IO.Directory]::CreateDirectory($caseDir)
  $outPath=Join-Path $caseDir 'stdout.json';$errPath=Join-Path $caseDir 'stderr.txt';$replyPath=Join-Path $caseDir 'unused-reply.json';$runId=[guid]::NewGuid().ToString('N')
  $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$hostInfo[1];$psi.Arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$childPath+'" -RequestedExit '+$code;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.WorkingDirectory=$OutputDirectory
  $transportAttempts++;$state=& $module {param($p,$o,$e,$r,$id)Invoke-SequenceProcessTransport $p $o $e $r 'HarmlessTransportSmoke' $id} $psi $outPath $errPath $replyPath $runId
  Save ($label+'-ownership.json') $state
  Check ($state.startAttempted -and $state.startReturned -and $state.started -and $state.exitConfirmed -and $state.streamsStarted -and $state.streamsCompleted -and $state.disposed -and -not $state.retained -and -not $state.retainedReferenceConfirmed -and $null -eq $state.primaryError -and $state.exitCode -eq $code) ($label+' actual process/stream/exit/disposal evidence')
  $expected=$utf8.GetBytes('{"marker":"'+$marker+'","payload":"'+$payload+'","code":'+$code+'}');$actual=[IO.File]::ReadAllBytes($outPath)
  Check ($actual.Length -gt 5*1024*1024 -and $actual.Length -eq $expected.Length -and (Hash $actual) -ceq (Hash $expected)) ($label+' complete exact UTF8 stdout bytes')
  $json=$utf8.GetString($actual)|ConvertFrom-Json
  Check ($json.marker -ceq $marker -and $json.payload -ceq $payload -and $json.code -eq $code -and @($json.PSObject.Properties).Count -eq 3) ($label+' valid complete JSON and nonASCII marker')
  $expectedError=$utf8.GetBytes('stderr:'+ $marker+':'+$code);$actualError=[IO.File]::ReadAllBytes($errPath)
  Check ($actualError.Length -eq $expectedError.Length -and (Hash $actualError) -ceq (Hash $expectedError)) ($label+' exact stderr bytes')
  foreach($p in @($outPath,$errPath)){$exclusive=[IO.File]::Open($p,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$exclusive.Dispose()}
  Check (-not [IO.File]::Exists($replyPath)) ($label+' no fabricated child reply')
  $cases.Add([pscustomobject]@{name=$label;passed=$true;host=$hostInfo[1];hostSha256=(Get-FileHash -LiteralPath $hostInfo[1]).Hash.ToLowerInvariant();state=$state;stdoutBytes=$actual.Length;stdoutSha256=(Hash $actual);stderrBytes=$actualError.Length;stderrSha256=(Hash $actualError);nonAsciiMarker=$json.marker;exclusiveStreamReopenSucceeded=$true;childReplyExists=$false})
 }}
 # Nested retention is pure: no real host is kept alive. The false timed wait
 # belongs to a ScriptMethod test object and the reply/ready pair is C-only.
 $nestedRun=[guid]::NewGuid().ToString('N');$nestedPath=Join-Path $OutputDirectory 'nested-retention-reply.json'
 Save 'nested-retention-reply.json' ([pscustomobject]@{stage='Warm';runId=$nestedRun;controllerHeldForRoot=$true})
 $ready=[IO.FileStream]::new(($nestedPath+'.ready'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);$ready.Dispose()
 $fake=[pscustomobject]@{waitCalls=0;waitMilliseconds=0;killCalled=$false;disposeCalled=$false}
 $fake|Add-Member -MemberType ScriptMethod -Name WaitForExit -Value {param([int]$milliseconds)$this.waitCalls++;$this.waitMilliseconds=$milliseconds;return $false}
 $fake|Add-Member -MemberType ScriptMethod -Name Kill -Value {$this.killCalled=$true;throw 'Fake process must not be killed'}
 $fake|Add-Member -MemberType ScriptMethod -Name Dispose -Value {$this.disposeCalled=$true;throw 'Fake process must not be disposed'}
 $rejected=$false;$errorText=$null
 try{$null=& $module {param($p,$r,$id)Wait-SequenceChildExitOrRetention $p $r 'Warm' $id} $fake $nestedPath $nestedRun}catch{$errorText=$_.Exception.ToString();$rejected=$errorText -like '*Child reports retained inner ownership; keep both controllers alive for root inspection*'}
 Check ($rejected -and $fake.waitCalls -eq 1 -and $fake.waitMilliseconds -eq 500 -and -not $fake.killCalled -and -not $fake.disposeCalled) 'nested retention reply is detected without kill/dispose or a live retained child'
 $retention=[pscustomobject]@{passed=$true;pureFakeProcess=$true;state=$fake;expectedRefusal=$errorText;realRetainedHostCreated=$false}
 Save 'nested-retention-result.json' $retention
}catch{$primary=$_.Exception.ToString();$failurePosition=$_.InvocationInfo.PositionMessage;$failureStack=$_.ScriptStackTrace}
$result=[pscustomobject]@{passed=($null -eq $primary -and $cases.Count -eq 4 -and $retention.passed);scope='owned C PowerShell transport smoke only';primaryError=$primary;failurePosition=$failurePosition;failureStack=$failureStack;loadedModuleSha256=$moduleHash;moduleSha256After=(Get-FileHash -LiteralPath $modulePath).Hash.ToLowerInvariant();childScriptSha256=(Get-FileHash -LiteralPath $childPath).Hash.ToLowerInvariant();transportStartAttempts=$transportAttempts;actualProcessCases=$cases.ToArray();nestedRetention=$retention;verifiedPowerShellChildrenStarted=$cases.Count;collectorExecuted=$false;nativeHelperLoaded=$false;FReadPerformed=$false;FWritePerformed=$false;registryAccessPerformed=$false;aaStarted=$false}
Save 'smoke-result.json' $result
$result|Select-Object passed,primaryError,loadedModuleSha256,moduleSha256After,transportStartAttempts,verifiedPowerShellChildrenStarted,@{n='verifiedProcessCases';e={$_.actualProcessCases.Count}},@{n='nestedRetentionPassed';e={$_.nestedRetention.passed}},collectorExecuted,nativeHelperLoaded,FReadPerformed,registryAccessPerformed,aaStarted|ConvertTo-Json -Compress
if(-not $result.passed){exit 1}
