param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));Import-Module (Join-Path $repo 'tools/headless/FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($out)
 Assert-RecoveryCPath $out $false;Assert-Recovery (-not [IO.Directory]::Exists($out)) 'Fresh C output required';[void][IO.Directory]::CreateDirectory($out)
 $run='85ab00ecf00d4ef5a1a1aa471ef365a8';$path=Join-Path $script:RecoveryRepo ('artifacts/aa-fr-closed-failed-recovery/plan-'+$run+'/evidence-manifest.json');$hash='597e1a6286a1bd0bed7c1266956df2b240ff1e18bcf7c1fb789e2219fe120689';$manifest=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC $path $hash);$checks=@()
 $plan=Get-ClosedFailedRecoveryPlan $run $path $hash;$checks+=,[pscustomobject]@{name='actual diagnostic plan includes source and exact history trace';passed=($plan.Prepared.Count -eq 1272 -and $plan.Created.Count -eq 44 -and @($plan.Created|Where-Object {-not $_.directory}).Count -eq 34 -and $plan.ActionPlan.Count -eq 1267 -and $plan.PayloadRestores.Count -eq 1 -and $plan.DescriptorRestores.Count -eq 1221 -and -not $plan.ApplicationAccepted)}
 foreach($case in @('missing-history-trace','foreign-trace-path')){
  $copy=ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $manifest)));$record=$copy.files|Where-Object name -CEQ important;$value=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC $record.path $record.sha256)
  if($case -ceq 'missing-history-trace'){$value.paths=@($value.paths|Where-Object {-not $_.path.EndsWith('\history\post-run\startup-exceptions.nettrace',[StringComparison]::Ordinal)})}else{($value.paths|Where-Object {$_.path.EndsWith('\history\post-run\startup-exceptions.nettrace',[StringComparison]::Ordinal)}).path='F:\other\trace.nettrace'}
  $record.path=Join-Path $out ($case+'-record.json');Write-RecoveryCRecord $record.path $value;$record.sha256=Get-RecoveryHash ([IO.File]::ReadAllBytes($record.path));$bad=Join-Path $out ($case+'-manifest.json');Write-RecoveryCRecord $bad $copy;$badHash=Get-RecoveryHash ([IO.File]::ReadAllBytes($bad));$denied=$false;try{Get-ClosedFailedRecoveryPlan $run $bad $badHash|Out-Null}catch{$denied=$_.Exception.Message -ceq 'Important path inventory differs'};$checks+=,[pscustomobject]@{name=$case;passed=$denied}
 }
 $result=[pscustomobject]@{passed=(@($checks|Where-Object {-not $_.passed}).Count -eq 0);total=$checks.Count;failed=@($checks|Where-Object {-not $_.passed}).Count;checks=$checks;FReadPerformed=$false;FWritePerformed=$false;recoveryExecuted=$false};Write-RecoveryCRecord (Join-Path $out 'result.json') $result;$result|Select-Object passed,total,failed,FReadPerformed,FWritePerformed|ConvertTo-Json -Compress;if(-not $result.passed){exit 1}
} $OutputDirectory
