[CmdletBinding()]
param([Parameter(Mandatory)][string]$EvidenceDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
. (Join-Path $repo 'tools\headless\New-AzuriteFullCapabilitiesInputs.ps1')
$scriptPath=Join-Path $repo 'tools\headless\New-AzuriteFullCapabilitiesInputs.ps1'
$recordPath=Join-Path $repo 'artifacts\aa-fr-next-capabilities-20261113\complete-input.json'
$recordHash='1d9a29bac18017867f4d52150d094b81d27981a72597b5d2566e746576b5ab2c'
$trustedBaseline='8dd06e45cee91ee6b13b50153025bfb25303f2bfe252bc27834ba40b370d9481'
$recordBytes=[IO.File]::ReadAllBytes($recordPath)
Assert-Inputs ((Get-InputsHash $recordBytes) -ceq $recordHash) 'Reviewed real input changed before regression test'
$record=ConvertFrom-InputsJson $recordBytes
$evidence=[IO.Path]::GetFullPath($EvidenceDirectory);Assert-Inputs ($evidence.StartsWith($repo+'\artifacts\',[StringComparison]::Ordinal) -and -not [IO.Directory]::Exists($evidence)) 'Test evidence must be fresh inside C artifacts';[void][IO.Directory]::CreateDirectory($evidence)
$passed=[Collections.Generic.List[string]]::new()
function Check($condition,[string]$name){if(-not $condition){throw ('FAIL '+$name)};$passed.Add($name)}
function CopyRecord($value){ConvertFrom-InputsJson (ConvertTo-InputsBytes $value)}
function WriteNew([string]$name,$value){$p=Join-Path $evidence $name;$b=ConvertTo-InputsBytes $value;$f=[IO.FileStream]::new($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()};[pscustomobject]@{path=$p;sha256=(Get-InputsHash $b)}}
$never=Join-Path $repo ('artifacts\aa-fr-inputs\worker-reviewed-baseline-never-'+[guid]::NewGuid().ToString('N'))
# RED before the implementation: this exact accepted new-run record cannot
# pass the old hard-coded run gate, even when its trusted digest is supplied.
$validated=New-AzuriteFullCapabilitiesInputs -InputRecord $record -OutputDirectory $never -ExpectedReviewedBaselineSha256 $trustedBaseline
Check ($validated.inputReady -eq $true -and $validated.runId -ceq '963b80c1ea494ed48098f2ee11bb8997') 'new-reviewed-run-accepted-with-independent-digest'
Check (-not [IO.Directory]::Exists($never)) 'validation-alone-writes-no-output'
$missing=New-AzuriteFullCapabilitiesInputs -InputRecord $record -OutputDirectory $never
Check (-not $missing.inputReady -and $missing.failures[0] -like '*externally supplied reviewed baseline digest*') 'new-reviewed-run-without-external-digest-rejected'
foreach($pair in @(@('wrong',('a'*64),'*differs from externally supplied reviewed baseline digest*'),@('zero',('0'*64),'*nonzero canonical lowercase SHA-256*'),@('uppercase',$trustedBaseline.ToUpperInvariant(),'*nonzero canonical lowercase SHA-256*'),@('short','abc','*nonzero canonical lowercase SHA-256*'),@('empty','','*nonzero canonical lowercase SHA-256*'))){$bad=New-AzuriteFullCapabilitiesInputs -InputRecord $record -OutputDirectory $never -ExpectedReviewedBaselineSha256 $pair[1];Check (-not $bad.inputReady -and $bad.failures[0] -like $pair[2]) ('external-digest-'+$pair[0]+'-rejected')}
$changed=CopyRecord $record;$changed.runId='11111111111111111111111111111111';$bad=New-AzuriteFullCapabilitiesInputs -InputRecord $changed -OutputDirectory $never -ExpectedReviewedBaselineSha256 $trustedBaseline
Check (-not $bad.inputReady -and $bad.failures[0] -ceq 'Real completed baseline capture receipt missing or failed') 'different-run-cannot-replay-capture'
$capture=ConvertFrom-InputsJson ([IO.File]::ReadAllBytes($record.baseline.capture.path));$capture.success=$false;$capture.error='injected failed capture';$pin=WriteNew 'failed-capture.json' $capture;$changed=CopyRecord $record;$changed.baseline.capture=$pin;$bad=New-AzuriteFullCapabilitiesInputs -InputRecord $changed -OutputDirectory $never -ExpectedReviewedBaselineSha256 $trustedBaseline
Check (-not $bad.inputReady -and $bad.failures[0] -ceq 'Real completed baseline capture receipt missing or failed') 'failed-capture-with-repinned-record-remains-rejected'
$baseline=ConvertFrom-InputsJson ([IO.File]::ReadAllBytes($record.baseline.identity.path));$baseline.runId='22222222222222222222222222222222';$pin=WriteNew 'different-run-baseline.json' $baseline;$changed=CopyRecord $record;$changed.baseline.identity=$pin;$bad=New-AzuriteFullCapabilitiesInputs -InputRecord $changed -OutputDirectory $never -ExpectedReviewedBaselineSha256 $trustedBaseline
Check (-not $bad.inputReady -and $bad.failures[0] -like '*differs from externally supplied reviewed baseline digest*') 'repinned-input-cannot-change-independent-baseline-authority'
$legacyPath=Join-Path $repo 'artifacts\aa-fr-inputs\real-baseline-awaiting-harmless.input.json';$legacyTemplate=ConvertFrom-InputsJson ([IO.File]::ReadAllBytes($legacyPath));$legacy=CopyRecord $record;$legacy.runId=$legacyTemplate.runId;$legacy.baseline=$legacyTemplate.baseline;$old=New-AzuriteFullCapabilitiesInputs -InputRecord $legacy -OutputDirectory $never
Check (-not $old.inputReady -and $old.failures[0] -ceq 'Fresh preflight target/run/source pins differ') 'exact-old-reviewed-baseline-fallback-reaches-later-preflight-run-guard'
$oldWrong=New-AzuriteFullCapabilitiesInputs -InputRecord $legacy -OutputDirectory $never -ExpectedReviewedBaselineSha256 ('a'*64)
Check (-not $oldWrong.inputReady -and $oldWrong.failures[0] -like '*differs from externally supplied reviewed baseline digest*') 'explicit-wrong-digest-cannot-use-old-tuple-fallback'
$simulated=CopyRecord $record;$simulated.evidenceClass='simulated-fixture';$simulatedPreflight=ConvertFrom-InputsJson ([IO.File]::ReadAllBytes($record.preflight.path));$simulatedPreflight.evidenceClass='simulated-fixture';$simulated.preflight=WriteNew 'SIMULATED-preflight-not-runtime.json' $simulatedPreflight
$simulatedHarmless=ConvertFrom-InputsJson ([IO.File]::ReadAllBytes($record.harmless.path));$simulatedHarmless|Add-Member -NotePropertyName testOnlySimulated -NotePropertyValue $true;$simulated.harmless=WriteNew 'SIMULATED-harmless-not-runtime.json' $simulatedHarmless
$simulation=New-AzuriteFullCapabilitiesInputs -InputRecord $simulated -OutputDirectory $never
Check ($simulation.inputReady -eq $true -and $simulation.evidenceClass -ceq 'simulated-fixture' -and -not $simulation.productionEvidence -and -not $simulation.approvalPresent -and -not $simulation.runtimeAllowed) 'simulated-fixture-path-still-needs-no-real-baseline-authority-and-remains-nonproduction'
$relabel=CopyRecord $simulated;$relabel.evidenceClass='reviewed-real';$relabel.preflight=$record.preflight;$bad=New-AzuriteFullCapabilitiesInputs -InputRecord $relabel -OutputDirectory $never -ExpectedReviewedBaselineSha256 $trustedBaseline
Check (-not $bad.inputReady -and $bad.failures[0] -ceq 'Simulated harmless receipt cannot be promoted to reviewed-real') 'external-baseline-authority-does-not-promote-simulated-native-evidence'
$output=Join-Path $repo ('artifacts\aa-fr-inputs\worker-reviewed-baseline-validation-'+[guid]::NewGuid().ToString('N'))
$text=& (Join-Path $PSHOME 'pwsh.exe') -NoLogo -NoProfile -File $scriptPath -InputRecordPath $recordPath -OutputDirectory $output -ExpectedReviewedBaselineSha256 $trustedBaseline
$exit=$LASTEXITCODE;$text|Set-Content -LiteralPath (Join-Path $evidence 'public-assembler.log') -Encoding UTF8;$public=($text -join [Environment]::NewLine)|ConvertFrom-Json
Check ($exit -eq 0 -and $public.inputReady -eq $true -and $public.runId -ceq $record.runId -and -not $public.approvalPresent -and -not $public.willApply -and -not $public.willLaunch -and -not $public.runtimeAllowed) 'public-cli-completes-C-only-assembly-with-explicit-digest'
Check ((Get-InputsHash ([IO.File]::ReadAllBytes((Join-Path $output 'identity-baseline.json')))) -ceq $trustedBaseline) 'generated-baseline-retains-reviewed-exact-bytes'
Check ((Get-InputsHash ([IO.File]::ReadAllBytes($recordPath))) -ceq $recordHash -and -not [IO.Directory]::Exists($never)) 'original-input-preserved-and-negatives-write-no-output'
$result=[pscustomobject]@{passed=$true;caseCount=$passed.Count;cases=$passed.ToArray();runId=$record.runId;inputSha256=$recordHash;expectedReviewedBaselineSha256=$trustedBaseline;sourceSha256=(Get-InputsHash ([IO.File]::ReadAllBytes($scriptPath)));publicOutput=$public;FReadPerformed=$false;FWritePerformed=$false;approvalGenerated=$false;ApplyExecuted=$false;runtimeExecuted=$false}
$null=WriteNew 'result.json' $result;$result|Select-Object passed,caseCount,sourceSha256,@{n='publicOutputDirectory';e={$_.publicOutput.outputDirectory}},FReadPerformed,FWritePerformed,approvalGenerated,ApplyExecuted,runtimeExecuted|ConvertTo-Json -Compress
