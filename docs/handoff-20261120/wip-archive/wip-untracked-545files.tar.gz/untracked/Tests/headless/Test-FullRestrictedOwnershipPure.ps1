#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($args.Count -ne 0) { throw 'The current-source ownership runner accepts no arguments.' }
if (-not [Environment]::Is64BitProcess) { throw 'Use an x64 PowerShell host.' }
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
if ([IO.Path]::GetPathRoot($repo) -ine 'C:\') { throw 'This pure runner requires the C workspace.' }
$output = Join-Path $repo ('artifacts\full-restricted-ownership-pure\' + [guid]::NewGuid().ToString('N'))
if (Test-Path -LiteralPath $output) { throw 'Preserve existing pure-test evidence.' }
[void][IO.Directory]::CreateDirectory($output)
$utf8 = [Text.UTF8Encoding]::new($false)
$script:OwnedPureProcessStart = { param($StartInfo) [Diagnostics.Process]::Start($StartInfo) }
$script:OwnedPureProcessOwner = $null
$framework = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
$references = @('System.Web.Extensions.dll', 'System.Runtime.Serialization.dll', 'System.Xml.dll') | ForEach-Object { Join-Path $framework $_ }
$suites = @(
    @{ Name='creation'; File='FullRestrictedCreationOwnership.Tests.cs'; Main='CreationOwnershipTests'; Checks=52 },
    @{ Name='acquisitions'; File='FullRestrictedAcquisitionBoundaries.Tests.cs'; Main='AcquisitionBoundariesTests'; Checks=295 },
    @{ Name='ownership'; File='FullRestrictedOwnership.Tests.cs'; Main='FullRestrictedOwnershipTests'; Checks=54 },
    @{ Name='queries'; File='FullRestrictedPreservedQueries.Tests.cs'; Main='PreservedQueriesTests'; Checks=8 }
)
function Pin([string]$Path) {
    $item = Get-Item -LiteralPath $Path
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Ordinary input file required.' }
    [pscustomobject]@{ path=$item.FullName; bytes=$item.Length; sha256=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
}
function Write-NewText([string]$Path, [string]$Value) {
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    try { $bytes=$utf8.GetBytes($Value); $stream.Write($bytes, 0, $bytes.Length) } finally { $stream.Dispose() }
}
function Write-NewJson([string]$Path, $Value) { Write-NewText $Path (ConvertTo-Json -InputObject $Value -Depth 30) }
function Run-OwnedPureProcess([string]$File, [string]$Arguments, [string]$Directory, [string]$Prefix, [int]$TimeoutMilliseconds) {
    if ($null -ne $script:OwnedPureProcessOwner) { throw 'An unresolved owned process blocks any further process start.' }
    $row = [ordered]@{
        path=$File; arguments=$Arguments; pid=$null; exitCode=$null; timedOut=$false; exited=$false; error=$null
        stdoutPath=($Prefix+'.stdout.txt'); stderrPath=($Prefix+'.stderr.txt'); cleanupVerified=$false; disposed=$false; unresolved=$false
        cleanupBudgetMilliseconds=5000; cleanupElapsedMilliseconds=0; terminationAttempts=0; cleanupWaitMilliseconds=0; cleanupWaitReturned=$null
        cleanupErrors=$null; outputErrors=$null; unresolvedEvidencePath=($Prefix+'.unresolved.json')
    }
    $process=$null; $outTask=$null; $errTask=$null; $stdout=''; $stderr=''
    $cleanupErrors=[Collections.Generic.List[string]]::new(); $outputErrors=[Collections.Generic.List[string]]::new()
    try {
        $start=[Diagnostics.ProcessStartInfo]::new($File, $Arguments)
        $start.WorkingDirectory=$Directory; $start.UseShellExecute=$false; $start.CreateNoWindow=$true
        $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
        $process=& $script:OwnedPureProcessStart $start; $row.pid=$process.Id
        try { $process.PriorityClass='BelowNormal' } catch { }
        $outTask=$process.StandardOutput.ReadToEndAsync(); $errTask=$process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit($TimeoutMilliseconds)) {
            $row.timedOut=$true
            throw 'The owned pure-test process exceeded its execution timeout.'
        }
        $row.exited=$process.HasExited
        if (-not $row.exited) { throw 'The owned process wait completed without confirming exit.' }
        if ($row.exited) { $row.exitCode=$process.ExitCode }
        if (-not $outTask.Wait(5000) -or -not $errTask.Wait(5000)) { throw 'The owned process output did not finish within its bound.' }
        $stdout=$outTask.GetAwaiter().GetResult(); $stderr=$errTask.GetAwaiter().GetResult()
    } catch { $row.error=$_.Exception.ToString() }
    finally {
        if ($null -ne $process) {
            $cleanupClock=[Diagnostics.Stopwatch]::StartNew()
            try { $row.exited=[bool]$process.HasExited } catch { $cleanupErrors.Add($_.Exception.ToString()) }
            if (-not $row.exited) {
                if ($cleanupClock.ElapsedMilliseconds -lt $row.cleanupBudgetMilliseconds) {
                    $row.terminationAttempts++
                    try { $process.Kill() } catch { $cleanupErrors.Add($_.Exception.ToString()) }
                }
                $remaining=[int][Math]::Max(0, $row.cleanupBudgetMilliseconds-$cleanupClock.ElapsedMilliseconds)
                if ($remaining -gt 0) {
                    $row.cleanupWaitMilliseconds=$remaining
                    try { $row.cleanupWaitReturned=[bool]$process.WaitForExit($remaining) } catch { $cleanupErrors.Add($_.Exception.ToString()) }
                }
                try { $row.exited=[bool]$process.HasExited } catch { $cleanupErrors.Add($_.Exception.ToString()) }
            }
            $row.cleanupElapsedMilliseconds=$cleanupClock.ElapsedMilliseconds
            if ($row.exited) {
                try { $row.exitCode=$process.ExitCode } catch { $cleanupErrors.Add($_.Exception.ToString()) }
                try { $process.Dispose(); $row.disposed=$true } catch { $cleanupErrors.Add($_.Exception.ToString()) }
            }
            if (-not $row.exited -or -not $row.disposed) {
                $row.unresolved=$true
                # Keep the actual original Process and stream tasks, never a PID lookup.
                $script:OwnedPureProcessOwner=[pscustomobject]@{Process=$process;StdoutTask=$outTask;StderrTask=$errTask;Evidence=$row}
            }
        }
        $row.cleanupVerified=($null -eq $process -or ($row.exited -and $row.disposed))
        try { if ($null -ne $outTask -and $outTask.IsCompleted -and -not $outTask.IsFaulted -and -not $outTask.IsCanceled) { $stdout=$outTask.GetAwaiter().GetResult() } } catch { $outputErrors.Add($_.Exception.ToString()) }
        try { if ($null -ne $errTask -and $errTask.IsCompleted -and -not $errTask.IsFaulted -and -not $errTask.IsCanceled) { $stderr=$errTask.GetAwaiter().GetResult() } } catch { $outputErrors.Add($_.Exception.ToString()) }
        try { Write-NewText $row.stdoutPath $stdout } catch { $outputErrors.Add($_.Exception.ToString()) }
        try { Write-NewText $row.stderrPath $stderr } catch { $outputErrors.Add($_.Exception.ToString()) }
        $row.cleanupErrors=$cleanupErrors.ToArray(); $row.outputErrors=$outputErrors.ToArray()
        if ($null -eq $row.error -and ($cleanupErrors.Count -gt 0 -or $outputErrors.Count -gt 0 -or $row.unresolved)) { $row.error='Owned process cleanup or output preservation was not fully verified.' }
        if ($row.unresolved) {
            try { Write-NewJson $row.unresolvedEvidencePath ([ordered]@{scope='unresolved original owned process; no later suite may start';ownerRetained=$true;hostRetentionRequired=$true;observedUtc=[datetime]::UtcNow.ToString('o');process=$row}) }
            catch { $outputErrors.Add($_.Exception.ToString()); $row.outputErrors=$outputErrors.ToArray() }
        }
    }
    [pscustomobject]$row
}
try {
$inputs=[Collections.Generic.List[object]]::new()
$rows=[Collections.Generic.List[object]]::new()
$guards=[Collections.Generic.List[object]]::new()
$errors=[Collections.Generic.List[string]]::new()
$snapshots=@{}
$record=[ordered]@{
    schema=1; scope='current production Full/Shared source-linked ownership pure regression'; outputDirectory=$output
    startedUtc=[datetime]::UtcNow.ToString('o'); completedUtc=$null; host=$PSVersionTable.PSVersion.ToString(); hostEdition=$PSVersionTable.PSEdition
    nativeImportGuard=$true; nativeAcceptanceClaimed=$false; AAOrCdbExecuted=$false; registryAccessed=$false; targetDriveAccessed=$false
    expectedChecks=409; checks=0; passed=$false; inputsStable=$false; inputsBefore=$null; inputsAfter=$null; guardedSources=$null; suites=$null; errors=$null
    hostHeldForOwnedProcess=$false; unresolvedOwnedProcess=$null
}
try {
    $sourceFiles=@(
        @{Path=(Join-Path $repo 'tools\headless\RestrictedCliFullRestricted.cs'); Leaf='RestrictedCliFullRestricted.cs'},
        @{Path=(Join-Path $repo 'tools\headless\RestrictedCliNative.cs'); Leaf='RestrictedCliNative.cs'},
        @{Path=$PSCommandPath; Leaf='Test-FullRestrictedOwnershipPure.ps1'}
    )
    foreach ($suite in $suites) { $sourceFiles+=@{Path=(Join-Path $PSScriptRoot $suite.File); Leaf=$suite.File} }
    $inputDirectory=Join-Path $output 'inputs'; [void][IO.Directory]::CreateDirectory($inputDirectory)
    foreach ($source in $sourceFiles) {
        $pin=Pin $source.Path; $inputs.Add($pin)
        $snapshot=Join-Path $inputDirectory $source.Leaf
        [IO.File]::WriteAllBytes($snapshot, [IO.File]::ReadAllBytes($source.Path))
        $saved=Pin $snapshot
        if ($saved.sha256 -cne $pin.sha256 -or $saved.bytes -ne $pin.bytes) { throw ('Input changed during snapshot: '+$source.Leaf) }
        $snapshots[$source.Leaf]=$snapshot
    }
    $inputs.Add((Pin $compiler)); foreach ($reference in $references) { $inputs.Add((Pin $reference)) }
    Write-NewJson (Join-Path $output 'input-pins.json') $inputs.ToArray()
    $pattern='(\[DllImport\(\s*)"[^"]+"'
    $replacement='$1"__AzuriteOwnershipPureNoNative_a61f923b.dll"'
    $guardPattern='\[DllImport\(\s*"__AzuriteOwnershipPureNoNative_a61f923b\.dll"'
    foreach ($leaf in @('RestrictedCliFullRestricted.cs','RestrictedCliNative.cs')) {
        $before=[IO.File]::ReadAllText($snapshots[$leaf]); $count=[regex]::Matches($before,$pattern).Count
        $after=[regex]::Replace($before,$pattern,$replacement)
        if ($count -eq 0 -or [regex]::Matches($after,$guardPattern).Count -ne $count -or
            [regex]::Replace($before,$pattern,'$1"*"') -cne [regex]::Replace($after,$pattern,'$1"*"')) {
            throw ('PInvoke guard did not preserve source bodies: '+$leaf)
        }
        $guarded=Join-Path $output ($leaf+'.native-blocked.cs'); Write-NewText $guarded $after
        $guards.Add([pscustomobject]@{source=$snapshots[$leaf]; compiled=Pin $guarded; importsBlocked=$count; sourceBodiesEqual=$true})
        $snapshots[$leaf+'.guarded']=$guarded
    }
    foreach ($suite in $suites) {
        $dir=Join-Path $output $suite.Name; [void][IO.Directory]::CreateDirectory($dir)
        $exe=Join-Path $dir ($suite.Name+'.Tests.exe')
        $row=[ordered]@{name=$suite.Name; main=$suite.Main; expectedChecks=$suite.Checks; passed=$false; compile=$null; process=$null; test=$null; executable=$null; error=$null}
        try {
            $arguments=@('/nologo','/target:exe','/platform:x64','/warn:4','/warnaserror+',('/main:'+$suite.Main))
            $arguments+=@($references | ForEach-Object { '/r:"'+$_+'"' })
            $arguments+=@(('/out:"'+$exe+'"'),('"'+$snapshots['RestrictedCliNative.cs.guarded']+'"'),('"'+$snapshots['RestrictedCliFullRestricted.cs.guarded']+'"'),('"'+$snapshots[$suite.File]+'"'))
            $rsp=Join-Path $dir 'compile.rsp'; Write-NewText $rsp (($arguments -join "`r`n")+"`r`n")
            $row.compile=Run-OwnedPureProcess $compiler ('@"'+$rsp+'"') $dir (Join-Path $dir 'compile') 30000
            if ($row.compile.error -or $row.compile.timedOut -or -not $row.compile.exited -or $row.compile.exitCode -ne 0) { throw 'Pure source compilation failed; preserved compiler output describes the failure.' }
            $row.executable=Pin $exe
            $row.process=Run-OwnedPureProcess $exe '' $dir (Join-Path $dir 'test') 15000
            if ($row.process.error -or $row.process.timedOut -or -not $row.process.exited) { throw 'Pure test process did not complete normally.' }
            $row.test=([IO.File]::ReadAllText($row.process.stdoutPath) | ConvertFrom-Json)
            foreach ($property in @('passed','checks','failures')) { if (-not $row.test.PSObject.Properties[$property]) { throw ('Missing test result property: '+$property) } }
            if ($row.process.exitCode -ne 0 -or $row.test.passed -isnot [bool] -or -not $row.test.passed -or
                $row.test.checks -ne $suite.Checks -or @($row.test.failures).Count -ne 0) { throw 'Unexpected pure-test result or check count.' }
            $row.passed=$true
        } catch { $row.error=$_.Exception.ToString() }
        Write-NewJson (Join-Path $dir 'result.json') $row
        $rows.Add([pscustomobject]$row)
        if ($null -ne $script:OwnedPureProcessOwner) { break }
    }
} catch { $errors.Add($_.Exception.ToString()) }
$afterPins=[Collections.Generic.List[object]]::new(); $stable=$true
foreach ($beforePin in $inputs) {
    try {
        $afterPin=Pin $beforePin.path; $afterPins.Add($afterPin)
        if ($afterPin.sha256 -cne $beforePin.sha256 -or $afterPin.bytes -ne $beforePin.bytes) { $stable=$false; $errors.Add('Input drift after run: '+$beforePin.path) }
    } catch { $stable=$false; $errors.Add($_.Exception.ToString()) }
}
$record.inputsBefore=$inputs.ToArray(); $record.inputsAfter=$afterPins.ToArray(); $record.inputsStable=$stable
$record.guardedSources=$guards.ToArray(); $record.suites=$rows.ToArray(); $record.errors=$errors.ToArray()
foreach ($row in $rows) { if ($null -ne $row.test -and $row.test.PSObject.Properties['checks']) { $record.checks+=[int]$row.test.checks } }
$record.hostHeldForOwnedProcess=($null -ne $script:OwnedPureProcessOwner)
if ($record.hostHeldForOwnedProcess) { $record.unresolvedOwnedProcess=$script:OwnedPureProcessOwner.Evidence }
$record.passed=($errors.Count -eq 0 -and $stable -and -not $record.hostHeldForOwnedProcess -and $rows.Count -eq 4 -and @($rows | Where-Object { -not $_.passed }).Count -eq 0 -and $record.checks -eq 409)
$record.completedUtc=if ($record.hostHeldForOwnedProcess) { $null } else { [datetime]::UtcNow.ToString('o') }
Write-NewJson (Join-Path $output 'result.json') $record
[pscustomobject]@{passed=$record.passed; checks=$record.checks; host=$record.host; inputsStable=$stable; result=(Join-Path $output 'result.json')} | ConvertTo-Json -Compress
if (-not $record.passed) { exit 1 }
} finally {
    if ($null -ne $script:OwnedPureProcessOwner) {
        try { Write-NewJson (Join-Path $output 'unresolved-owner.json') ([ordered]@{scope='runner stopped with original owned Process retained in this host';passed=$false;hostHeld=$true;observedUtc=[datetime]::UtcNow.ToString('o');process=$script:OwnedPureProcessOwner.Evidence}) } catch { }
        try { [Console]::Error.WriteLine('UNRESOLVED OWNED PROCESS: this host remains alive with the original Process object; no later suite will run.') } catch { }
        while ($true) { try { [Threading.Thread]::Sleep(1000) } catch { } }
    }
}
