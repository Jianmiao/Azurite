param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$m=Import-Module (Join-Path $repo 'tools\headless\FullRestrictedStageTransition.psm1') -Force -PassThru -DisableNameChecking
$result=& $m {
 param($repo,$output)
 $ErrorActionPreference='Stop';$count=0;$names=[Collections.Generic.List[string]]::new()
 function Check($v,$why){if(-not $v){throw ('ASSERT '+$why)};$names.Add($why)}
 function Clone($v){Get-TransitionJsonBytes ([Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 20 -Compress)))}
 function Refuse([scriptblock]$f,[string]$why){$denied=$false;try{& $f|Out-Null}catch{$denied=$true};Check $denied $why}
 $dir=Join-Path $repo 'artifacts\aa-fr-inputs\real-307fd6cd72e547d89f03176e2f9c10c5'
 $manifest=Get-TransitionJsonBytes ([IO.File]::ReadAllBytes($dir+'\source-manifest.json'));$control=Get-TransitionJsonBytes ([IO.File]::ReadAllBytes($dir+'\control.json'))
 $sources=Read-TransitionSources $manifest $control
 Check ($sources.Count -eq 18 -and $sources['before.json'].bytes.Length -eq 38561944 -and (Get-TransitionHash $sources['before.json'].bytes) -ceq '8d9662b8f65ce1af0a9135ba8b868066ed63fa703c5038e2fe2d3d9577da0801') 'actual eighteen-role production seam accepts exact38561944-byte shared snapshot'
 $before=Get-TransitionJsonBytes $sources['before.json'].bytes
 Check ($before.files.Count -eq 91 -and $before.phase -ceq 'Before' -and $before.capturedUtc -ceq '2026-11-12T14:45:30.8839552Z') 'actual91file snapshot/timestamp remain unchanged'
 $b=$sources['before.json'].entry
 Refuse {Read-TransitionPinnedCFile $b.path $b.sha256} 'generic reader default remains8MiB'
 foreach($fault in @('unknown','duplicate','missing','extra','declared-over64','declared-length','wrong-leaf','wrong-scope-pair','wrong-control-hash','wrong-digest','other-role-large','wrong-run','wrong-owner','validator-module')){
  $mm=Clone $manifest;$cc=Clone $control;$entry=@($mm.files|Where-Object name -CEQ 'before.json')[0]
  switch($fault){
   'unknown' {$mm.files[0].name='unexpected.json'}
   'duplicate' {$mm.files[0].name=$mm.files[1].name}
   'missing' {$mm.files=@($mm.files|Select-Object -Skip 1)}
   'extra' {$mm.files+=@($mm.files[0])}
   'declared-over64' {$entry.bytes=67108865L}
   'declared-length' {$entry.bytes--}
   'wrong-leaf' {$entry.path=$dir+'\facts.json'}
   'wrong-scope-pair' {(@($mm.files|Where-Object name -CEQ 'scope.json')[0]).path=$repo+'\scope.json'}
   'wrong-control-hash' {$cc.sharedStateBeforeSha256='0'*64}
   'wrong-digest' {$entry.sha256='0'*64;$cc.sharedStateBeforeSha256='0'*64}
   'other-role-large' {$target=@($mm.files|Where-Object name -CEQ 'facts.json')[0];$target.path=$entry.path;$target.sha256=$entry.sha256;$target.bytes=$entry.bytes}
   'wrong-run' {$mm.runId='a'*32}
   'wrong-owner' {$cc.controllerSid='wrong'}
   'validator-module' {$target=@($mm.files|Where-Object name -CEQ 'CurrentAccountCli.psm1')[0];$target.path=$sources['RestrictedCliCore.psm1'].entry.path;$target.sha256=$sources['RestrictedCliCore.psm1'].entry.sha256;$target.bytes=$sources['RestrictedCliCore.psm1'].entry.bytes}
  }
  Refuse {Read-TransitionSources $mm $cc} $fault
 }
 Refuse {Get-TransitionJsonBytes ([byte[]]@(255,254,255))} 'strictUTF8 refuses invalid decoding'
 $fixture=Join-Path (Split-Path -Parent $output) ('bounds-fixture-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($fixture)
 $badPath=Join-Path $fixture 'before.json';$scopePath=Join-Path $fixture 'scope.json';[IO.File]::WriteAllBytes($scopePath,$sources['scope.json'].bytes)
 $payload=[Text.Encoding]::UTF8.GetBytes((' '*(8388608))+'[]');[IO.File]::WriteAllBytes($badPath,$payload)
 $mm=Clone $manifest;$cc=Clone $control;$be=@($mm.files|Where-Object name -CEQ 'before.json')[0];$be.path=$badPath;$be.bytes=$payload.Length;$be.sha256=Get-TransitionHash $payload;$cc.sharedStateBeforeSha256=$be.sha256;(@($mm.files|Where-Object name -CEQ 'scope.json')[0]).path=$scopePath
 Refuse {Read-TransitionSources $mm $cc} 'oversized before label cannot admit nonobject JSON'
 $oversized=Join-Path $fixture 'over-limit.bin';$f=[IO.File]::Open($oversized,[IO.FileMode]::CreateNew);try{$f.SetLength(67108865)}finally{$f.Dispose()}
 Refuse {Read-TransitionPinnedCFile $oversized ('0'*64) 67108864} 'same production bounded reader rejects actual size over64MiB'
 Refuse {Read-TransitionPinnedCFile $fixture ('0'*64)} 'directory type refused'
 $shortPath=Join-Path $fixture 'short.bin';[IO.File]::WriteAllBytes($shortPath,[byte[]]@(1,2,3,4));$sha=Get-TransitionHash ([byte[]]@(1,2,3,4))
 Check ((Read-TransitionPinnedCFile $shortPath $sha 4).Length -eq 4) 'exact stream boundary accepted'
 Refuse {Read-TransitionPinnedCFile $shortPath $sha 3} 'one byte over explicit bound refused'
 return [ordered]@{scope='production source-role and bounded-reader C-only tests';passed=$true;checks=$names.Count;tests=$names.ToArray();host=$PSVersionTable.PSVersion.ToString();nativeCallsExecuted=$false;applyCalled=$false;targetAccess=$false;fixtureDirectory=$fixture;actualBeforeSha256=$b.sha256;actualBeforeBytes=$b.bytes}
} $repo $ResultPath
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
$result|ConvertTo-Json -Depth 6
