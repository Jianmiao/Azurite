param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
Import-Module (Join-Path $repo 'tools\headless\FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($output)
 Assert-RecoveryCPath $output $false;Assert-Recovery (-not [IO.Directory]::Exists($output)) 'Test output must be fresh';[void][IO.Directory]::CreateDirectory($output)
 $passed=[Collections.Generic.List[string]]::new()
 function Check($v,[string]$name){Assert-Recovery $v ('FAIL '+$name);$passed.Add($name)}
 function Clone($v){ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $v)))}
 function Save([string]$name,$v){$p=Join-Path $output $name;Write-RecoveryCRecord $p $v;return [pscustomobject]@{path=$p;sha256=(Get-RecoveryHash ([IO.File]::ReadAllBytes($p)))}}
 $folder=Join-Path $script:RecoveryRepo 'artifacts\aa-fr-transition-preparation\actual-963b-dfedb1f19e5040a5810eae883a1a8cd6'
 $rows=@(
  @('result',(Join-Path $folder 'preparation-result.json'),'beb4e9bf5bf893a9f6c8f8a9cf2319939d2381698d8cefa11339c396c2a104ea'),
  @('observations',(Join-Path $folder 'observations.json'),'b09eafd3544ee9f8d929f105b5fd936dc6600a4a6d02fae2c31f9f9045e5344d'),
  @('before',(Join-Path $folder 'before-images-raw.json'),'c22dbb708fb097116f94b42010b6616ec9dda2129eeb47c6bc58f54bc0b66471'),
  @('receipt',(Join-Path $folder 'receipt-bundle.json'),'71668fd102e234d8b12ff1ed8b34cc24b6e1eb15e976a849e0d948900ccc3626'),
  @('lease',(Join-Path $folder 'lease-release.json'),'efb68b887a5ad95b07f3f1577c2b36d3e38ec5d867f1aaba2da4f90c4f812a4b'),
  @('refusal',(Join-Path $script:RecoveryRepo 'artifacts\aa-fr-capabilities-runtime\5eaeb376e8af4a0c86bba15592dbce80\controller-final.json'),'b6028d3a95b1b6f55197230ce1348d42780b9e1fd7d8cac313a2f286e397e8e8')
 )
 $files=@(foreach($row in $rows){$null=Read-RecoveryPinnedC $row[1] $row[2];[pscustomobject]@{name=$row[0];path=$row[1];sha256=$row[2]}})
 $manifest=[pscustomobject]@{schema=1;scope='fixed-F-prelaunch-preparation-recovery-evidence';files=$files};$pin=Save 'evidence-manifest.json' $manifest
 # RED: the previous public Plan cannot accept independently bound new evidence.
 $plan=Get-AzuritePreparationRecoveryPlan -RecoveryEvidenceManifestPath $pin.path -ExpectedRecoveryEvidenceManifestSha256 $pin.sha256
 Check ($plan.RunId -ceq '963b80c1ea494ed48098f2ee11bb8997' -and $plan.EvidenceManifestSha256 -ceq $pin.sha256 -and $plan.Original.Count -eq 1228 -and $plan.Prepared.Count -eq 1259 -and $plan.Created.Count -eq 31 -and @($plan.Created|Where-Object{-not $_.directory}).Count -eq 21 -and $plan.PayloadRestores.Count -eq 1 -and $plan.DescriptorRestores.Count -eq 1221) 'real-new-run-derives-exact-finite-inverse'
 Check (@($plan.Created|Where-Object path -Like '*pending.json')[0].sha256 -ceq 'a33cf535f7c901fbb6f5a0498dec63be25bfb12874df4a28fa853d7b2cae84e8') 'new-run-uses-final-recorded-pending'
 $old=Get-AzuritePreparationRecoveryPlan;Check ($old.RunId -ceq '2fc0eb21404d4efaaf527c07c295d147' -and $old.EvidenceMode -ceq 'LegacyFixed22bac') 'legacy-default-never-silently-selects-new-run'
 foreach($case in @('MissingSha','MissingPath','WrongManifestSha','MixedRun','WrongRecordSha','FailedPreparation','RuntimeStarted','ScopeDrift','OwnerDrift','VolumeDrift','CountDrift')){
  $copy=Clone $manifest;$parameters=@{};$needle=''
  switch($case){
   MissingSha {$parameters.RecoveryEvidenceManifestPath=$pin.path;$needle='Recovery evidence manifest path and reviewed digest must be supplied together'}
   MissingPath {$parameters.ExpectedRecoveryEvidenceManifestSha256=$pin.sha256;$needle='Recovery evidence manifest path and reviewed digest must be supplied together'}
   WrongManifestSha {$parameters.RecoveryEvidenceManifestPath=$pin.path;$parameters.ExpectedRecoveryEvidenceManifestSha256='a'*64;$needle='Pinned C evidence differs:*'}
   MixedRun {$f=$copy.files|Where-Object name -CEQ lease;$f.path=Join-Path $script:RecoveryRepo 'artifacts\aa-fr-transition-preparation\actual-22bac3419df34c5696dfe8985d1d8367\lease-release.json';$f.sha256='380104b9d2a8ab585e7543d50778c1b43f689c5ef73d83186234bb02ee0b8a24';$needle='Pinned recovery run binding differs'}
   WrongRecordSha {($copy.files|Where-Object name -CEQ before).sha256='a'*64;$needle='Pinned C evidence differs:*'}
   FailedPreparation {$name='result';$value=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC (($copy.files|Where-Object name -CEQ $name).path) (($copy.files|Where-Object name -CEQ $name).sha256));$value.Success=$false;$needle='Preparation was not accepted successful/prelaunch-only'}
   RuntimeStarted {$name='refusal';$value=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC (($copy.files|Where-Object name -CEQ $name).path) (($copy.files|Where-Object name -CEQ $name).sha256));$value.result=[pscustomobject]@{nativeStarted=$true};$needle='Runtime refusal is not the bound prelaunch outcome'}
   ScopeDrift {$name='receipt';$value=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC (($copy.files|Where-Object name -CEQ $name).path) (($copy.files|Where-Object name -CEQ $name).sha256));$value.Plan.LabRoot='F:\ForeignLab';$needle='Recovery fixed lab/owner/volume binding differs'}
   OwnerDrift {$name='observations';$value=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC (($copy.files|Where-Object name -CEQ $name).path) (($copy.files|Where-Object name -CEQ $name).sha256));$value.lease.ownerSid='S-1-5-21-1-2-3-1001';$needle='Recovery fixed lab/owner/volume binding differs'}
   VolumeDrift {$name='observations';$value=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC (($copy.files|Where-Object name -CEQ $name).path) (($copy.files|Where-Object name -CEQ $name).sha256));$value.lease.volume='foreign';$needle='Recovery fixed lab/owner/volume binding differs'}
   CountDrift {$name='observations';$value=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC (($copy.files|Where-Object name -CEQ $name).path) (($copy.files|Where-Object name -CEQ $name).sha256));$value.created=@($value.created|Select-Object -Skip 1);$needle='Finite accepted preparation counts differ'}
  }
  if($case -cin @('FailedPreparation','RuntimeStarted','ScopeDrift','OwnerDrift','VolumeDrift','CountDrift')){$changed=Save ($case+'-record.json') $value;$f=$copy.files|Where-Object name -CEQ $name;$f.path=$changed.path;$f.sha256=$changed.sha256}
  if($case -cnotin @('MissingSha','MissingPath','WrongManifestSha')){$changedManifest=Save ($case+'-manifest.json') $copy;$parameters.RecoveryEvidenceManifestPath=$changedManifest.path;$parameters.ExpectedRecoveryEvidenceManifestSha256=$changedManifest.sha256}
  $rejected=$false;try{$null=Get-AzuritePreparationRecoveryPlan @parameters}catch{$rejected=$_.Exception.Message -like $needle};Check $rejected ('reject-'+$case)
 }
 $helper=Join-Path $script:RecoveryRepo 'artifacts\aa-fr-empty-directory-helper-20261113\helper-build1';$paths=@{};foreach($n in @('FullRestrictedPreparationRecovery.psm1','Recover-AzuriteFullPreparation.ps1','FullRestrictedStageTransition.psm1')){$paths[$n]=Join-Path (Join-Path $script:RecoveryRepo 'tools\headless') $n};foreach($n in @('FullRestrictedStageFileSecurity.cs','FullRestrictedStageFileSecurity.dll','build.json')){$paths[$n]=Join-Path $helper $n};$tokenPins=Get-RecoveryTokenPins;foreach($n in $tokenPins.Keys){$paths[$n]=$tokenPins[$n].path}
 $sourceFiles=@(foreach($n in @($paths.Keys|Sort-Object -CaseSensitive)){$b=[IO.File]::ReadAllBytes($paths[$n]);[pscustomobject]@{name=$n;path=$paths[$n];sha256=(Get-RecoveryHash $b);bytes=$b.Length}})
 $source=[pscustomobject]@{schema=2;scope='fixed-F-prelaunch-preparation-recovery-source';runId=$plan.RunId;evidenceManifestSha256=$pin.sha256;files=$sourceFiles};$sourcePin=Save 'source-manifest.json' $source
 $bound=Read-RecoverySourceBindings $sourcePin.path $sourcePin.sha256 $plan.RunId $pin.sha256;Check ($bound.files.Count -eq 9) 'source-graph-binds-new-run-and-independent-evidence'
 foreach($case in @('SourceWrongRun','SourceWrongEvidence','SourceLegacy')){$copy=Clone $source;switch($case){SourceWrongRun {$copy.runId='2fc0eb21404d4efaaf527c07c295d147'};SourceWrongEvidence {$copy.evidenceManifestSha256='a'*64};SourceLegacy {$copy.schema=1;$copy.scope='accepted-22bac-prelaunch-recovery-source'}};$bad=Save ($case+'.json') $copy;$rejected=$false;try{$null=Read-RecoverySourceBindings $bad.path $bad.sha256 $plan.RunId $pin.sha256}catch{$rejected=$_.Exception.Message -like 'Recovery source manifest differs*'};Check $rejected ('reject-'+$case)}
 $text=& (Join-Path $PSHOME 'pwsh.exe') -NoLogo -NoProfile -File (Join-Path $script:RecoveryRepo 'tools\headless\Recover-AzuriteFullPreparation.ps1') -RecoveryEvidenceManifestPath $pin.path -ExpectedRecoveryEvidenceManifestSha256 $pin.sha256;$exit=$LASTEXITCODE;$text|Set-Content -LiteralPath (Join-Path $output 'public-plan.json') -Encoding UTF8;$public=($text -join [Environment]::NewLine)|ConvertFrom-Json
 Check ($exit -eq 0 -and $public.runId -ceq $plan.RunId -and $public.evidenceManifestSha256 -ceq $pin.sha256 -and -not $public.FReadPerformed -and -not $public.FWritePerformed) 'public-entry-new-plan-is-C-only'
 $wrongSource=Join-Path $output 'SourceWrongEvidence.json';$never=Join-Path $output 'must-not-create';$text=& (Join-Path $PSHOME 'pwsh.exe') -NoLogo -NoProfile -File (Join-Path $script:RecoveryRepo 'tools\headless\Recover-AzuriteFullPreparation.ps1') -Apply -RecoveryEvidenceManifestPath $pin.path -ExpectedRecoveryEvidenceManifestSha256 $pin.sha256 -SourceManifestPath $wrongSource -ExpectedSourceManifestSha256 (Get-RecoveryHash ([IO.File]::ReadAllBytes($wrongSource))) -EvidenceDirectory $never;$exit=$LASTEXITCODE;$text|Set-Content -LiteralPath (Join-Path $output 'public-apply-rejected-before-backend.json') -Encoding UTF8;$refusal=($text -join [Environment]::NewLine)|ConvertFrom-Json
 Check ($exit -eq 1 -and $refusal.Success -eq $false -and $refusal.error -like '*Recovery source manifest differs from bound run/evidence*' -and -not [IO.Directory]::Exists($never)) 'public-apply-forwards-new-evidence-and-refuses-mixed-source-before-native-or-F'
 Check (-not ('Azurite.Stage.FileSecurity' -as [type]) -and -not ('Azurite.Restricted.FullBootstrapIdentity' -as [type])) 'plan-and-source-binding-load-no-native-code'
 $result=[pscustomobject]@{passed=$true;cases=$passed.ToArray();caseCount=$passed.Count;runId=$plan.RunId;evidenceManifest=$pin;sourceManifest=$sourcePin;FReadPerformed=$false;FWritePerformed=$false;registryAccessPerformed=$false;actualRecoveryExecuted=$false};$null=Save 'result.json' $result;$result|Select-Object passed,caseCount,runId,evidenceManifest,sourceManifest,FReadPerformed,FWritePerformed,actualRecoveryExecuted|ConvertTo-Json -Depth 4 -Compress
} $OutputDirectory
