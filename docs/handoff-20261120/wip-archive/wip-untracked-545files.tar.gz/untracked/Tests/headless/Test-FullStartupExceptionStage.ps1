param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
# Reuse the existing source-linked in-memory coordinator/spec/receipt test.
# Only its explicit synthetic selection and exact extra-leaf counts differ.
$path=Join-Path $PSScriptRoot 'Test-FullRestrictedStageTransition.ps1'
$source=[IO.File]::ReadAllText($path)
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$source=$source.Replace('$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot ''..\..''))',('$root='''+$repo.Replace("'","''")+''''))
$changes=@(
 @(' $facts.preTransition|Add-Member'," `$facts|Add-Member startupDiagnostic 'startup-exceptions.v1'`n `$facts.preTransition|Add-Member"),
 @(' Assert-TransitionAclIntent $acl $plan $control $logon'," `$control|Add-Member startupDiagnostic 'startup-exceptions.v1'`n Assert-TransitionAclIntent `$acl `$plan `$control `$logon")
)
foreach($pair in $changes){if(([regex]::Matches($source,[regex]::Escape($pair[0]))).Count -ne 1){throw 'Stage test selection anchor drift'};$source=$source.Replace($pair[0],$pair[1])}
if(([regex]::Matches($source,'-eq 1252')).Count -ne 3){throw 'Stage test expected-role anchor drift'}
$source=$source.Replace('-eq 1252','-eq 1253')
$absence='@($beforeBody.result.items|Where-Object {$_.absentBefore -and $null -eq $_.fileIdentity}).Count -eq 2'
if(-not $source.Contains($absence)){throw 'Absent-leaf assertion anchor drift'}
$source=$source.Replace($absence,$absence.Replace('-eq 2','-eq 3'))
& ([scriptblock]::Create($source)) -ResultPath $ResultPath
$result=Get-Content -LiteralPath $ResultPath -Raw -Encoding UTF8|ConvertFrom-Json
$p=@{InputObject=[IO.File]::ReadAllText($result.evidenceBundlePath);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$p.DateKind='String'};$bundle=ConvertFrom-Json @p
$receipt=(@($bundle.receipts|Where-Object kind -CEQ 'unity-log-precreation')[0].content|ConvertFrom-Json).result
if($receipt.startupTrace.path -cne 'output/startup-exceptions.nettrace' -or $receipt.startupTrace.baselineBytes -ne 0 -or $receipt.startupTrace.fileMask -cne '0x12019F' -or $receipt.startupTrace.fileIdentity -cnotmatch '\A[a-f0-9]{32}\z'){throw 'Diagnostic actual fake-backend receipt identity absent'}
[pscustomobject]@{scope='diagnostic source-linked stage closure with fake objects only';passed=$true;sourceRegressionChecks=$result.passed;diagnosticTraceReceipt=$receipt.startupTrace;noNative=$true;noF=$true;productionAdmission=$false}|ConvertTo-Json -Depth 5
