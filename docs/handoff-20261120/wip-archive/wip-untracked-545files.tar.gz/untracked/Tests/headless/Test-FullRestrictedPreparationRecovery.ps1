param([string]$OutputDirectory)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$modulePath=Join-Path $repo 'tools\headless\FullRestrictedPreparationRecovery.psm1'
if(-not (Test-Path -LiteralPath $modulePath)){throw 'RED: recovery production coordinator is missing'}
Import-Module $modulePath -Force -DisableNameChecking
$module=Get-Module FullRestrictedPreparationRecovery
& $module {
 function Assert($v,[string]$m){if(-not $v){throw ('ASSERT: '+$m)}}
 function Clone-Record($v){ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $v)))}
 function Fixture {
  $root='C:\RecoveryFixture';$run=$root+'\runs\restricted-r';$sid='S-1-5-21-1-2-3-1001';$base='O:'+ $sid+'G:'+ $sid+'D:P(A;OICI;FA;;;'+$sid+')';$grant=$base+'(A;;FR;;;S-1-5-5-1-2)';$seq=0
  $original=@();$prepared=@();$new=@()
  foreach($p in @($root,($root+'\install'),($root+'\install\child'),($root+'\install\child\loader.log'))){$seq++;$dir=-not $p.EndsWith('.log');[byte[]]$bytes=@();if(-not $dir){$bytes=[Text.Encoding]::UTF8.GetBytes('original loader')};$o=[pscustomobject]@{path=$p;finalPath=$p;identity=('{0:x32}' -f $seq);volume='fixture-volume';owner=$sid;directory=$dir;reparse=$false;links=1;sddl=$base;bytes=[long]$bytes.Length;sha256=$(if($dir){$null}else{Get-RecoveryHash $bytes});content=$(if($dir){$null}else{[Convert]::ToBase64String($bytes)})};$original+=,$o;$x=Clone-Record $o;$x.sddl=$grant;if(-not $dir){$x.bytes=0L;$x.sha256=Get-RecoveryHash ([byte[]]@());$x.content=''};$prepared+=,$x}
  foreach($p in @(($root+'\runs'),$run,($run+'\data'),($run+'\data\snapshot.json'),($root+'\runs\full-capabilities.pending.json'))){$seq++;$dir=-not $p.EndsWith('.json');$t=if($p.EndsWith('pending.json')){(ConvertTo-RecoveryJson ([pscustomobject][ordered]@{schema=1;scope='full-capabilities-global-pending';runId='r';planSha256=('b'*64);controllerSid=$sid;runDirectory=$run;state='prepared-awaiting-runtime-lease'}))}else{'archive me'};[byte[]]$bytes=@();if(-not $dir){$bytes=[Text.Encoding]::UTF8.GetBytes($t)};$o=[pscustomobject]@{path=$p;finalPath=$p;identity=('{0:x32}' -f $seq);volume='fixture-volume';owner=$sid;directory=$dir;reparse=$false;links=1;sddl=$grant;bytes=[long]$bytes.Length;sha256=$(if($dir){$null}else{Get-RecoveryHash $bytes});content=$(if($dir){$null}else{[Convert]::ToBase64String($bytes)})};$new+=,$o;$prepared+=,(Clone-Record $o)}
  $spec=[pscustomobject]@{Schema=1;RunId='r';PlanSha256=('b'*64);Root=$root;OwnerSid=$sid;LogonSid='S-1-5-5-1-2';Volume='fixture-volume';PendingPath=$root+'\runs\full-capabilities.pending.json';RunsPath=$root+'\runs';Original=$original;Prepared=$prepared;Created=$new;PayloadRestores=@($original[-1]);DescriptorRestores=@($original);InventoryExceptions=@{};Bindings=@{fixture=$true}}
  $s=@{Spec=$spec;Objects=@{};Records=@{};Events=[Collections.Generic.List[object]]::new();Archive=@{};Operations=0;Mutations=0;Fault='';FailAt=0;FailAfter=$false;Held=$false;Released=$false;Disposed=$false;RecoveryId=('a'*32)}
  foreach($o in $prepared){$s.Objects[$o.path]=Clone-Record $o}
  $s.Backend={param($action,$a,$s)
   $result=$null
   $s.Events.Add([pscustomobject]@{action=$action;path=$a.path;name=$a.name});$s.Operations++
   if($s.FailAt -eq $s.Operations -and -not $s.FailAfter){throw ('injected before '+$action)}
   switch($action){
    'Acquire' {$s.Held=$true;$result=[pscustomobject]@{ownerSid=$s.Spec.OwnerSid;logonSid=$s.Spec.LogonSid;volume=$s.Spec.Volume}}
    'Release' {if($s.Fault -ceq 'release'){throw 'release failed'};$s.Held=$false;$s.Released=$true}
    'Dispose' {if($s.Fault -ceq 'dispose'){throw 'dispose failed'};$s.Disposed=$true}
    'Retain' {$s.Retained=$true}
    'ValidateEnvironment' {if($s.Fault -cin @('aa','probe')){throw 'live process found'};$result=[pscustomobject]@{aaCount=0;probeCount=0;ownerSid=$s.Spec.OwnerSid;logonSid=$s.Spec.LogonSid;unelevated=$true}}
    'Observe' {$result=if($s.Objects.ContainsKey($a.path)){Clone-Record $s.Objects[$a.path]}else{$null}}
    'Inventory' {$result=@($s.Objects.Keys|Where-Object{[IO.Path]::GetDirectoryName($_) -ceq $a.path}|ForEach-Object{[IO.Path]::GetFileName($_)});if($s.Fault -ceq 'extra-child'){$result+=,'foreign.bin'}}
    'Archive' {if($s.Fault -ceq 'archive'){throw 'archive failed'};$o=$s.Objects[$a.path];$s.Archive[$a.path]=Clone-Record $o;$result=[pscustomobject]@{sourcePath=$a.path;sourceIdentity=$o.identity;sha256=$o.sha256;bytes=$o.bytes;destination='C:\archive\'+$o.identity}}
    'Persist' {if($s.Fault -ceq ('persist-'+$a.name)){throw 'persist failed'};$s.Records[$a.name]=Clone-Record $a.value}
    'Journal' {if($s.Fault -ceq ('journal-'+$a.name)){throw 'journal failed'}}
    'WriteBytes' {$s.Mutations++;$o=$s.Objects[$a.path];$o.content=[Convert]::ToBase64String($a.bytes);$o.bytes=[long]$a.bytes.Length;$o.sha256=Get-RecoveryHash $a.bytes}
    'SetDescriptor' {$s.Mutations++;$s.Objects[$a.path].sddl=$a.sddl}
    'DeleteFile' {$s.Mutations++;if($s.Objects[$a.path].directory){throw 'file only'};$s.Objects.Remove($a.path)}
    'DeleteDirectory' {$s.Mutations++;if(@($s.Objects.Keys|Where-Object{[IO.Path]::GetDirectoryName($_) -ceq $a.path}).Count){throw 'not empty'};$s.Objects.Remove($a.path)}
    default {throw ('unknown '+$action)}
   }
   if($s.FailAt -eq $s.Operations -and $s.FailAfter){throw ('injected after '+$action)}
   if(Test-Path variable:result){return $result}
  }
  return $s
 }
 function Run($s){Invoke-RecoveryCoordinator $s.Spec $s.Backend $s}
 $s=Fixture;$r=Run $s
 Assert $r.Success ('inverse succeeds: '+$r.Error)
 Assert ($s.Objects.Count -eq 4 -and $s.Archive.Count -eq 2) 'restores four originals and archives both created files'
 Assert ($r.ReleaseSucceeded -and $r.DisposeSucceeded -and -not $s.Held) 'success includes actual release and disposal'
 foreach($o in $s.Spec.Original){Assert ($s.Objects[$o.path].sddl -ceq $o.sddl -and $s.Objects[$o.path].sha256 -ceq $o.sha256) 'full baseline restored'}
 $events=$s.Events.ToArray();$firstMutation=@($events|Where-Object action -In @('WriteBytes','SetDescriptor','DeleteFile','DeleteDirectory'))[0]
 Assert ($firstMutation.path -ceq $s.Spec.PendingPath) 'pending becomes recovery-in-progress before inverse work'
 $descriptors=@($events|Where-Object action -CEQ SetDescriptor|ForEach-Object path)
 Assert (($descriptors -join '|') -ceq (($s.Spec.Original.path) -join '|')) 'restores parent descriptors before children'
 $deletes=@($events|Where-Object action -In @('DeleteFile','DeleteDirectory'))
 Assert ($deletes[-2].path -ceq $s.Spec.PendingPath -and $deletes[-1].path -ceq $s.Spec.RunsPath) 'pending and its parent are terminal deletions'
 foreach($fault in @('aa','probe','extra-child','archive','persist-archive-manifest','journal-mutation-intent')){$f=Fixture;$f.Fault=$fault;$x=Run $f;Assert (-not $x.Success -and $f.Mutations -eq 0 -and $f.Objects.ContainsKey($f.Spec.PendingPath)) ('no mutation on '+$fault)}
 foreach($field in @('identity','volume','owner','finalPath','sddl','sha256','bytes','reparse','links')){$f=Fixture;$o=$f.Objects[$f.Spec.Original[-1].path];switch($field){'bytes'{$o.bytes=999};'reparse'{$o.reparse=$true};'links'{$o.links=2};default{$o.$field='drift'}};$x=Run $f;Assert (-not $x.Success -and $f.Mutations -eq 0) ('preflight drift '+$field)}
 foreach($fault in @('release','dispose')){$f=Fixture;$f.Fault=$fault;$x=Run $f;Assert (-not $x.Success -and $x.Error) ('cleanup truthful '+$fault)}
 # Every production operation boundary is injected both before and after its effect.
 $boundaryCount=$s.Operations
 for($i=1;$i -le $boundaryCount;$i++){foreach($after in @($false,$true)){$f=Fixture;$f.FailAt=$i;$f.FailAfter=$after;$x=Run $f;Assert (-not $x.Success) ('failure boundary '+$i+' after='+$after);Assert ($x.Error -or $x.EvidenceError) 'failure has evidence'}}
 $entry=Join-Path $script:RecoveryRepo 'tools\headless\Recover-AzuriteFullPreparation.ps1';Assert ([IO.File]::Exists($entry)) 'explicit recovery entry exists';
 $command=Get-Command Invoke-AzuritePreparationRecovery -ErrorAction Stop;Assert ($command.Module.Path -ceq (Join-Path $script:RecoveryRepo 'tools\headless\FullRestrictedPreparationRecovery.psm1')) 'Apply test uses the real exported coordinator';$refused=$false;try{Invoke-AzuritePreparationRecovery -Apply -SourceManifestPath 'C:\missing-recovery.json' -ExpectedSourceManifestSha256 ('0'*64) -EvidenceDirectory 'C:\missing-recovery-output'}catch{$refused=$_.Exception.Message -like 'C recovery path/parent missing:*'};Assert $refused 'Apply refuses unavailable reviewed source before native/F access';Assert (-not ('Azurite.Stage.FileSecurity' -as [type])) 'Rejected Apply has not loaded native helper';
 $plan=Get-AzuritePreparationRecoveryPlan
 Assert ($plan.Original.Count -eq 1228 -and $plan.Prepared.Count -eq 1259 -and $plan.Created.Count -eq 31) 'bound real C evidence yields exact object sets'
 Assert ($plan.PayloadRestores.Count -eq 1 -and $plan.DescriptorRestores.Count -eq 1221 -and @($plan.Created|Where-Object{-not $_.directory}).Count -eq 21) 'bound C plan inverse counts independently match reviewed preparation'
 Assert ($plan.PayloadRestores[0].path -ceq 'F:\AzuriteLabs\Editor-20261108-normal\install\BepInEx\LogOutput.log') 'only original changed loader payload restored'
 $pendingRecord=[pscustomobject][ordered]@{schema=1;scope='full-capabilities-global-pending';runId=$plan.RunId;planSha256=$plan.PlanSha256;controllerSid=$plan.OwnerSid;runDirectory=($plan.RunsPath+'\restricted-'+$plan.RunId);state='prepared-awaiting-runtime-lease'}
 $pendingBytes=[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-RecoveryJson $pendingRecord));Assert ($pendingBytes.Length -eq 392 -and (Get-RecoveryHash $pendingBytes) -ceq '93ab422b74355bf1341d202de9fea5d40bad38c55f9e7b4b550c3d53712d5854') 'real seven-field prepared pending exactly matches pinned final bytes'
 $real=Fixture;$real.Spec=$plan;$real.Objects=@{};foreach($o in $plan.Prepared){$real.Objects[$o.path]=Clone-Record $o};$real.Objects[$plan.PendingPath].content=[Convert]::ToBase64String($pendingBytes)
 # The physical inventory has one untouched, unrecorded phase-0 container.
 $real.Objects[$plan.Root+'\.phase0-staging']=[pscustomobject]@{path=$plan.Root+'\.phase0-staging'}
 $full=Run $real;Assert $full.Success ('full accepted production inverse: '+$full.Error);Assert ($real.Mutations -eq 1254 -and $real.Archive.Count -eq 21) 'full accepted inverse executes exactly 1254 finite mutations and archives 21 files'
 Assert ($real.Records['baseline-readback'].originals.Count -eq 1228 -and $real.Records['baseline-readback'].absent.Count -eq 31) 'full final evidence contains actual baseline/absence observations'
 [pscustomobject]@{passed=$true;boundaryCount=$boundaryCount;boundaryInjections=2*$boundaryCount;fullGraphMutations=$real.Mutations;originalCount=$plan.Original.Count;createdCount=$plan.Created.Count;FReadPerformed=$false;FWritePerformed=$false;NativeExecuted=$false}
}
