param([Parameter(Mandatory)][string]$AssemblyPath,[Parameter(Mandatory)][string]$ExpectedAssemblySha256,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if((Get-FileHash -LiteralPath $AssemblyPath).Hash.ToLowerInvariant() -cne $ExpectedAssemblySha256){throw 'Pinned managed test assembly required'}
if(Test-Path -LiteralPath $ResultPath){throw 'Result must be new'}
$assembly=[Reflection.Assembly]::LoadFrom($AssemblyPath);$bridge=$assembly.GetType('FullMonitorManagedHostTests',$true);$primary=$null;$value=$null
try{$value=$bridge.GetMethod('Run').Invoke($null,[object[]]@())}catch{$errorObject=$_.Exception;while($errorObject.InnerException){$errorObject=$errorObject.InnerException};$primary=[ordered]@{type=$errorObject.GetType().FullName;message=$errorObject.Message;stack=$errorObject.StackTrace}}
$record=[ordered]@{scope='same compiled production monitor with pure API directly executed in host';host=$PSVersionTable.PSVersion.ToString();framework=[Runtime.InteropServices.RuntimeInformation]::FrameworkDescription;assemblyPath=$AssemblyPath;assemblySha256=$ExpectedAssemblySha256;passed=($null -eq $primary -and $value.passed);result=$value;error=$primary;nativeApisCalled=$false;FrameworkChildSubstitution=$false;AAStarted=$false;FRead=$false}
[IO.File]::WriteAllText($ResultPath,($record|ConvertTo-Json -Depth 40),[Text.UTF8Encoding]::new($false));[pscustomobject]@{host=$record.host;passed=$record.passed;checks=$(if($value){$value.checks}else{0});error=$primary;resultPath=$ResultPath}|ConvertTo-Json -Depth 8
if(-not $record.passed){exit 1}
