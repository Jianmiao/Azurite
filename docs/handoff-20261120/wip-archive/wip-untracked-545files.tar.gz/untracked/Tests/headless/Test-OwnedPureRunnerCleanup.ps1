#requires -Version 5.1
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
if($args.Count -ne 0){throw 'This current-runner cleanup regression accepts no arguments.'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
if([IO.Path]::GetPathRoot($repo) -ine 'C:\'){throw 'C workspace required'}
$runner=Join-Path $PSScriptRoot 'Test-FullRestrictedOwnershipPure.ps1'
$testRoot=Join-Path $repo ('artifacts\owned-pure-runner-cleanup\'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($testRoot)
$utf8=[Text.UTF8Encoding]::new($false)
$runnerPin=(Get-FileHash -LiteralPath $runner).Hash.ToLowerInvariant()
$testPin=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant()
$tokens=$null;$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($runner,[ref]$tokens,[ref]$parseErrors)
if(@($parseErrors).Count){throw 'Current runner does not parse'}
$names=@('Write-NewText','Write-NewJson','Run-OwnedPureProcess')
$functions=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -in $names},$true))
if($functions.Count -ne 3){throw 'Expected three exact production function definitions'}
$functionSource=($functions|ForEach-Object{$_.Extent.Text}) -join "`n"
[IO.File]::WriteAllText((Join-Path $testRoot 'executed-functions.ps1'),$functionSource,$utf8)
. ([scriptblock]::Create($functionSource))
$loops=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.ForEachStatementAst] -and $n.Variable.VariablePath.UserPath -ceq 'suite' -and $n.Extent.Text.Contains('Run-OwnedPureProcess')},$true))
if($loops.Count -ne 1){throw 'Expected the actual production suite loop'}
$loopSource=$loops[0].Extent.Text
[IO.File]::WriteAllText((Join-Path $testRoot 'executed-suite-loop.ps1'),$loopSource,$utf8)
$script:OwnedPureProcessOwner=$null
$script:FakeProcesses=[Collections.Generic.Queue[object]]::new()
$script:StartedFiles=[Collections.Generic.List[string]]::new()
$script:OwnedPureProcessStart={param($info)$script:StartedFiles.Add($info.FileName);$script:FakeProcesses.Dequeue()}
$script:CheckCount=0;$script:Failures=[Collections.Generic.List[string]]::new();$cases=[Collections.Generic.List[object]]::new()
function Check([bool]$Value,[string]$Why){$script:CheckCount++;if(-not $Value){$script:Failures.Add($Why)}}
function Flag($Row,[string]$Name){if($Row.PSObject.Properties[$Name]){return [bool]$Row.$Name};return $false}
function New-FakeStream([bool]$Fail,[string]$Text){
    $stream=[pscustomobject]@{Fail=$Fail;Text=$Text}
    $stream|Add-Member -MemberType ScriptMethod -Name ReadToEndAsync -Value {
        if($this.Fail){throw 'fake output initialization failure'}
        $completion=[Threading.Tasks.TaskCompletionSource[string]]::new();$completion.SetResult([string]$this.Text);return $completion.Task
    }
    return $stream
}
function New-FakeProcess([bool]$StdoutFail=$false,[bool]$StderrFail=$false,[bool]$KillThrows=$false,[bool]$KillConfirms=$true,[bool]$Exited=$false,[int]$WaitThrows=0){
    $process=[pscustomobject]@{Id=4321;ExitCode=0;HasExited=$Exited;PriorityClass='Normal';StandardOutput=(New-FakeStream $StdoutFail 'captured output');StandardError=(New-FakeStream $StderrFail '');KillThrows=$KillThrows;KillConfirms=$KillConfirms;WaitThrows=$WaitThrows;KillCalls=0;DisposeCalls=0;DisposedAlive=$false;WaitBudgets=[Collections.Generic.List[int]]::new()}
    $process|Add-Member -MemberType ScriptMethod -Name WaitForExit -Value {param([int]$milliseconds)$this.WaitBudgets.Add($milliseconds);if($this.WaitThrows -gt 0){$this.WaitThrows--;throw 'fake process wait failure'};return [bool]$this.HasExited}
    $process|Add-Member -MemberType ScriptMethod -Name Kill -Value {$this.KillCalls++;if($this.KillThrows){throw 'fake owned Kill failure'};if($this.KillConfirms){$this.HasExited=$true}}
    $process|Add-Member -MemberType ScriptMethod -Name Dispose -Value {$this.DisposeCalls++;if(-not $this.HasExited){$this.DisposedAlive=$true}}
    return $process
}
function Begin-Case($Process){$script:OwnedPureProcessOwner=$null;$script:FakeProcesses.Clear();$script:StartedFiles.Clear();$script:FakeProcesses.Enqueue($Process)}
function Save-Case([string]$Name,$Process,$Row){
    $same=$null -ne $script:OwnedPureProcessOwner -and [object]::ReferenceEquals($script:OwnedPureProcessOwner.Process,$Process)
    $cases.Add([pscustomobject]@{name=$Name;result=$Row;killCalls=$Process.KillCalls;disposeCalls=$Process.DisposeCalls;disposedAlive=$Process.DisposedAlive;waitBudgets=$Process.WaitBudgets.ToArray();sameOwnerRetained=$same;starts=$script:StartedFiles.Count})
}
foreach($which in @('stdout','stderr')){
    $p=New-FakeProcess -StdoutFail ($which -ceq 'stdout') -StderrFail ($which -ceq 'stderr');Begin-Case $p
    $r=Run-OwnedPureProcess 'C:\pure-not-executed.exe' '' $testRoot (Join-Path $testRoot $which) 10
    Check ($r.error -like '*fake output initialization failure*') ($which+': primary initialization error survives')
    Check ($p.KillCalls -eq 1 -and $p.HasExited) ($which+': live owned child is terminated after stream initialization error')
    Check ($r.exited -and (Flag $r 'cleanupVerified')) ($which+': cleanup confirms exit')
    Check ($p.DisposeCalls -eq 1 -and -not $p.DisposedAlive) ($which+': dispose only after confirmed exit')
    Check ($null -eq $script:OwnedPureProcessOwner) ($which+': confirmed cleanup does not retain owner')
    Check ($p.WaitBudgets.Count -eq 1 -and $p.WaitBudgets[0] -gt 0 -and $p.WaitBudgets[0] -le 5000) ($which+': final wait consumes one bounded cleanup allowance')
    Save-Case $which $p $r
}
$p=New-FakeProcess -WaitThrows 1;Begin-Case $p
$r=Run-OwnedPureProcess 'C:\pure-not-executed.exe' '' $testRoot (Join-Path $testRoot 'wait-error') 10
Check ($r.error -like '*fake process wait failure*') 'wait error: original failure survives'
Check ($p.KillCalls -eq 1 -and $r.exited -and $p.DisposeCalls -eq 1 -and -not $p.DisposedAlive) 'wait error: finally closes the actually started child'
Save-Case 'wait-error' $p $r
foreach($which in @('kill-throws','kill-unconfirmed')){
    $p=New-FakeProcess -KillThrows ($which -ceq 'kill-throws') -KillConfirms $false;Begin-Case $p
    $prefix=Join-Path $testRoot $which;$r=Run-OwnedPureProcess 'C:\pure-not-executed.exe' '' $testRoot $prefix 10
    Check ($r.timedOut -and -not $r.exited) ($which+': timeout remains failed with no exit proof')
    Check ((Flag $r 'unresolved') -and -not (Flag $r 'cleanupVerified')) ($which+': unresolved outcome is explicit')
    Check ($p.DisposeCalls -eq 0 -and -not $p.DisposedAlive) ($which+': no dispose substitutes for exit proof')
    Check ($null -ne $script:OwnedPureProcessOwner -and [object]::ReferenceEquals($script:OwnedPureProcessOwner.Process,$p)) ($which+': retains the exact original Process object')
    Check (Test-Path -LiteralPath ($prefix+'.unresolved.json')) ($which+': unresolved evidence is written')
    Check ($p.KillCalls -eq 1 -and $p.WaitBudgets.Count -eq 2 -and $p.WaitBudgets[1] -gt 0 -and $p.WaitBudgets[1] -le 5000) ($which+': Kill failure still reaches bounded wait and final confirmation')
    $next=New-FakeProcess -Exited $true;$script:FakeProcesses.Enqueue($next);$blocked=$false
    try{$null=Run-OwnedPureProcess 'C:\must-not-execute.exe' '' $testRoot (Join-Path $testRoot ($which+'-next')) 10}catch{$blocked=$true}
    Check ($blocked -and $script:StartedFiles.Count -eq 1) ($which+': retained owner prevents any next process start')
    Save-Case $which $p $r
}
$p=New-FakeProcess -StdoutFail $true -Exited $true;Begin-Case $p
$r=Run-OwnedPureProcess 'C:\pure-not-executed.exe' '' $testRoot (Join-Path $testRoot 'already-exited') 10
Check ($p.KillCalls -eq 0 -and $p.DisposeCalls -eq 1 -and $r.exited) 'already exited: IO error does not terminate an exited child'
Check ((Flag $r 'cleanupVerified') -and $null -eq $script:OwnedPureProcessOwner) 'already exited: closure is confirmed independently of IO failure'
Save-Case 'already-exited' $p $r
$p=New-FakeProcess -Exited $true;Begin-Case $p
$r=Run-OwnedPureProcess 'C:\pure-not-executed.exe' '' $testRoot (Join-Path $testRoot 'normal') 10
Check ($null -eq $r.error -and $r.exited -and $r.exitCode -eq 0 -and -not $r.timedOut) 'normal: successful result is unchanged'
Check ($p.KillCalls -eq 0 -and $p.DisposeCalls -eq 1 -and -not $p.DisposedAlive) 'normal: one dispose and no termination'
Check ((Flag $r 'cleanupVerified') -and -not (Flag $r 'unresolved')) 'normal: verified cleanup and no unresolved owner'
Check ([IO.File]::ReadAllText($r.stdoutPath) -ceq 'captured output') 'normal: actual IO helper preserves stdout'
Save-Case 'normal' $p $r
$p=New-FakeProcess -StdoutFail $true -KillThrows $true -KillConfirms $false;Begin-Case $p
$script:FakeProcesses.Enqueue((New-FakeProcess -StdoutFail $true -KillThrows $true -KillConfirms $false))
$output=Join-Path $testRoot 'actual-suite-loop';$compiler='C:\pure-not-executed.exe';$references=@();$rows=[Collections.Generic.List[object]]::new()
$snapshots=@{'RestrictedCliNative.cs.guarded'='C:\not-read-native.cs';'RestrictedCliFullRestricted.cs.guarded'='C:\not-read-full.cs';'unused.cs'='C:\not-read-test.cs'}
$suites=@(@{Name='blocked-first';File='unused.cs';Main='Unused';Checks=1},@{Name='must-not-start';File='unused.cs';Main='Unused';Checks=1})
. ([scriptblock]::Create($loopSource))
Check ($rows.Count -eq 1 -and $script:StartedFiles.Count -eq 1) 'actual suite loop: unresolved first compiler stops later suites'
Check (-not (Test-Path -LiteralPath (Join-Path $output 'must-not-start'))) 'actual suite loop: no later suite directory or IO work'
Check ($p.DisposeCalls -eq 0 -and $null -ne $script:OwnedPureProcessOwner -and [object]::ReferenceEquals($script:OwnedPureProcessOwner.Process,$p)) 'actual suite loop: failed result retains the same owner for the outer host'
Save-Case 'actual-suite-loop' $p @($rows.ToArray())
$stable=((Get-FileHash -LiteralPath $runner).Hash.ToLowerInvariant() -ceq $runnerPin -and (Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant() -ceq $testPin)
Check $stable 'runner and regression input bytes remain unchanged'
$record=[ordered]@{scope='actual current runner process function and suite loop; fake Process and output streams only';host=$PSVersionTable.PSVersion.ToString();runner=$runner;runnerSha256=$runnerPin;testSha256=$testPin;checks=$script:CheckCount;passed=($script:Failures.Count -eq 0);failures=$script:Failures.ToArray();cases=$cases.ToArray();inputsStable=$stable;realProcessStarted=$false;nativeAcquisitionInvoked=$false;AAOrCdbExecuted=$false;registryAccessed=$false}
[IO.File]::WriteAllText((Join-Path $testRoot 'result.json'),($record|ConvertTo-Json -Depth 30),$utf8)
# All retained objects in this test are fakes; the production host-retention loop is not invoked.
$script:OwnedPureProcessOwner=$null
[pscustomobject]@{passed=$record.passed;checks=$record.checks;failures=$script:Failures.Count;host=$record.host;result=(Join-Path $testRoot 'result.json')}|ConvertTo-Json -Compress
if(-not $record.passed){exit 1}
