param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
if(-not [IO.Path]::GetFullPath($ResultPath).StartsWith($repo+'\artifacts\',[StringComparison]::Ordinal) -or (Test-Path -LiteralPath $ResultPath)){throw 'Fresh C result required'}
$sources=@('tools/headless/Capture-AzuriteFullCapabilitiesIdentityShared.ps1','tools/headless/AzuriteCapabilitiesSequence.psm1','tools/headless/New-AzuriteFullCapabilitiesInputs.ps1','tools/headless/FullRestrictedCapabilitiesRuntime.psm1','AcceptanceHarness/FullRestricted.FreshPreflight/Capture-FreshPreflight.ps1')
$checks=[Collections.Generic.List[object]]::new();$failure=$null;$reference=$null
function Check($v,[string]$name){if(-not $v){throw ('FAIL '+$name)};$checks.Add([pscustomobject]@{name=$name;passed=$true})}
function CopyRecord($value){$value|ConvertTo-Json -Depth 8|ConvertFrom-Json}
$old=[pscustomobject]@{schema=1;scope='actual-native-full-restricted-harmless-lifecycle';passed=$true;productionTargetExecuted=$false;actualSuspendedTokenAndJob=$true;pipeHandleListAndEOF=$true;cleanupVerified=$true;desktopLeaseAcrossBootstrapExit=$true}
$next=[pscustomobject]@{schema=2;scope='actual-native-full-restricted-cleanup-lifecycle';passed=$true;productionTargetExecuted=$false;actualSuspendedTokenAndJob=$true;pipeHandleListAndEOF=$true;cleanupVerified=$true;cleanupEvidenceProtocol='cleanup-ordering.v1';outerDesktopHeldUntilJobDrain=$true;bootstrapExitCleanupObserved=$true;cleanupTraceComplete=$true;externalLiveDescendantIntervalClaimed=$false}
try{
 foreach($source in $sources){
  $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $repo $source),[ref]$tokens,[ref]$errors)
  Check ($errors.Count -eq 0) ($source+': parse')
  $fn=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Test-HarmlessReceiptKind'},$true))
  Check ($fn.Count -eq 1) ($source+': actual version predicate exists exactly once')
  $calls=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -ceq 'Test-HarmlessReceiptKind'},$true))
  Check ($calls.Count -eq 1) ($source+': actual admission consumes predicate once')
  if($reference){Check ($reference -ceq $fn[0].Extent.Text) ($source+': same bounded version contract')}else{$reference=$fn[0].Extent.Text}
  $predicate=[scriptblock]::Create('param($Receipt)'+$fn[0].Body.Extent.Text.Substring(1,$fn[0].Body.Extent.Text.Length-2))
  Check ((& $predicate $old) -eq $true) ($source+': unchanged valid v1')
  Check ((& $predicate $next) -eq $true) ($source+': explicit v2 cleanup evidence')
  foreach($field in @('passed','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified','outerDesktopHeldUntilJobDrain','bootstrapExitCleanupObserved','cleanupTraceComplete')){
   foreach($value in @($false,'true',1)){$bad=CopyRecord $next;$bad.$field=$value;Check ((& $predicate $bad) -eq $false) ($source+': rejects invalid '+$field+' '+[string]$value)}
  }
  foreach($field in @('productionTargetExecuted','externalLiveDescendantIntervalClaimed')){
   foreach($value in @($true,'false',0)){$bad=CopyRecord $next;$bad.$field=$value;Check ((& $predicate $bad) -eq $false) ($source+': rejects invalid '+$field+' '+[string]$value)}
  }
  foreach($field in @($next.PSObject.Properties.Name)){$bad=CopyRecord $next;$bad.PSObject.Properties.Remove($field);Check ((& $predicate $bad) -eq $false) ($source+': rejects missing '+$field)}
  foreach($field in @('scope','cleanupEvidenceProtocol')){$bad=CopyRecord $next;$bad.$field='unknown';Check ((& $predicate $bad) -eq $false) ($source+': rejects different '+$field)}
  foreach($value in @(0,1,3,'2')){$bad=CopyRecord $next;$bad.schema=$value;Check ((& $predicate $bad) -eq $false) ($source+': rejects wrong schema '+[string]$value)}
  $bad=CopyRecord $next;$bad|Add-Member desktopLeaseAcrossBootstrapExit $true;Check ((& $predicate $bad) -eq $false) ($source+': v2 cannot promote old interval flag')
  $bad=CopyRecord $old;$bad.desktopLeaseAcrossBootstrapExit=$false;Check ((& $predicate $bad) -eq $false) ($source+': failed v1 interval remains rejected')
  $bad=CopyRecord $old;$bad.schema=2;Check ((& $predicate $bad) -eq $false) ($source+': relabeling old receipt is rejected')
  Check ((& $predicate $null) -eq $false) ($source+': null rejected')
 }
}catch{$failure=$_.Exception.ToString()}
$result=[ordered]@{scope='actual source predicates with synthetic records; no lifecycle qualification';passed=($null -eq $failure);checks=$checks.Count;hosts=$PSVersionTable.PSVersion.ToString();error=$failure;records=$checks.ToArray();wrapperExecuted=$false;nativeExecuted=$false;receiptIssued=$false;FReadPerformed=$false;registryAccessPerformed=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{passed=$result.passed;checks=$result.checks;error=$failure;resultPath=$ResultPath}|ConvertTo-Json -Depth 4
if($failure){exit 1}
