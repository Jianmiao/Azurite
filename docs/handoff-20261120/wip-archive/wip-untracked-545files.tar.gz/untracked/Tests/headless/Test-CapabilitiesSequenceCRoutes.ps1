param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$root=Join-Path $repo ('artifacts\aa-fr-capabilities-sequence-source-20261113\routes-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($root)
$module=Import-Module (Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1') -Force -PassThru -DisableNameChecking
$report=& $module {
 param($repo,$root)
 $tests=[Collections.Generic.List[string]]::new();function Check($v,[string]$n){if(-not $v){throw ('ASSERT '+$n)};$tests.Add($n)}
 $sources=@{};foreach($entry in (Get-SequenceFixedRoles).GetEnumerator()){$p=$entry.Value;$sources[$entry.Key]=[pscustomobject]@{role=$entry.Key;path=$p;sha256=(Get-FileHash $p).Hash.ToLowerInvariant();bytes=(Get-Item $p).Length}}
 $oldInputPath=Join-Path $repo 'artifacts\aa-fr-next-capabilities-20261113\complete-input.json';$oldInputPin=Get-SequencePin $oldInputPath;$old=Read-SequenceJson $oldInputPin.path $oldInputPin.sha256
 $run=$old.runId;$captureRoot=Split-Path -Parent $old.originalIdentity.path;$warmRoot=Split-Path -Parent $old.preflight.path
 $capturePin=Get-SequencePin (Join-Path $captureRoot 'capture-result.json');$warmPin=Get-SequencePin (Join-Path $warmRoot 'capture-result.json')
 $capture=[pscustomobject]@{raw=(Read-SequenceJson $capturePin.path $capturePin.sha256);files=[pscustomobject]@{Identity=(Get-SequencePin $old.originalIdentity.path);Scope=(Get-SequencePin $old.shared.scope.path);Before=(Get-SequencePin $old.shared.before.path)}}
 $warm=[pscustomobject]@{raw=(Read-SequenceJson $warmPin.path $warmPin.sha256);files=[pscustomobject]@{Preflight=(Get-SequencePin $old.preflight.path)}}
 $inputRecord=[pscustomobject]@{runId=$run;baselineCapture=$old.baseline.capture;harmless=$old.harmless;intentValidUntilUtc=$old.intentValidUntilUtc;runtimeTimeoutSeconds=$old.runtimeTimeoutSeconds;sourcesSha256=('1'*64)}
 $request=[pscustomobject]@{stage='Assemble';runId=$run;input=$inputRecord;authorityInput=$oldInputPin;sources=[pscustomobject]$sources;sequenceRoot=$root;baselineIdentity=$old.baseline.identity;prior=[pscustomobject]@{Capture=$capture;Warm=$warm}}
 $transportSpec=[pscustomobject]@{Sources=[pscustomobject]$sources;OutputRoot=$root}
 $parameters=Get-SequenceAssembleParameters $request (Join-Path $root 'complete-input.json')
 Check ($parameters.ExpectedReviewedBaselineSha256 -ceq $old.baseline.identity.sha256 -and (Get-Command $sources.Inputs.path).Parameters.ContainsKey('ExpectedReviewedBaselineSha256')) 'actual assembler external baseline parameter is independently forwarded'
 $assembled=Invoke-SequenceChild $request $transportSpec
 Check ($assembled.raw.inputReady -eq $true -and $assembled.raw.runId -ceq $run -and -not $assembled.raw.willApply -and -not $assembled.raw.willLaunch) 'actual public C assembler route accepted retained real records'
 $null=Write-SequenceJson (Join-Path $parameters.OutputDirectory 'sequence-c-route-test-context.json') ([ordered]@{evidenceClass='historical-C-route-test-only';sourceRunId=$run;actualCapturePerformed=$false;newApprovalProduced=$false;ApplyPermitted=$false})
 $actualInput=Read-SequenceJson $assembled.files.CompleteInput.path $assembled.files.CompleteInput.sha256
 Check ($actualInput.baseline.identity.sha256 -ceq $old.baseline.identity.sha256 -and @($actualInput.baseline.capture.PSObject.Properties).Count -eq 2 -and @($actualInput.harmless.PSObject.Properties).Count -eq 2) 'actual complete-input uses exact two-field baseline and harmless pins'
 $originalGraph=Join-Path $repo 'artifacts\aa-fr-inputs\real-963b-hashcase-20261113';$oldFiles=[ordered]@{};foreach($pair in @(@('Facts','facts.json'),@('Plan','plan.json'),@('SourceManifest','source-manifest.json'),@('Control','control.json'),@('Gate','gate.json'))){$oldFiles[$pair[0]]=Get-SequencePin (Join-Path $originalGraph $pair[1])}
 $approvalPath=Join-Path $repo '.superpowers\sdd\azurite-authoring-20261108\one-capabilities-approval-963b-578ca1b32f9c47729162da6b10071b09.json';$approvalPin=Get-SequencePin $approvalPath
 Check ($approvalPin.sha256 -ceq '960f37fb45c5d97eea6e161991fb06f2d0844b5b9817d06db1c0c07b59b90c30') 'historical approval is read unchanged, never reminted'
 $bundlePin=Get-SequencePin (Join-Path $repo 'artifacts\aa-fr-transition-preparation\actual-963b-dfedb1f19e5040a5810eae883a1a8cd6\receipt-bundle.json')
 $request.prior|Add-Member -NotePropertyName Approval -NotePropertyValue ([pscustomobject]@{files=[pscustomobject]@{Approval=$approvalPin}})
 $request.prior|Add-Member -NotePropertyName Apply -NotePropertyValue ([pscustomobject]@{files=[pscustomobject]@{ReceiptBundle=$bundlePin}})
 $request.stage='Projection';$projected=Invoke-SequenceChild $request $transportSpec
 Check ($projected.raw.Ready -and $projected.raw.PreparationLeaseReleased -and $projected.raw.runId -ceq $run) 'actual receipt projection route retains successful released evidence'
 $bundle=Read-SequenceJson $bundlePin.path $bundlePin.sha256
 Check ($projected.files.EvidenceBundle.sha256 -ceq $bundle.Admission.evidenceBundleSha256 -and $bundle.Facts.preTransition.observedUtc -is [string]) 'real evidence digest and datetime strings are preserved'
 foreach($name in @('Facts','Admission','EvidenceBundle')){$oldProjection=Join-Path $repo ('artifacts\aa-fr-runtime-inputs\from-963b-b2a2888ab1634806bef83b8516f71d29\'+$name+'.json');Check ($projected.files.$name.sha256 -ceq (Get-SequencePin $oldProjection).sha256) ('projection bytes match existing actual '+$name)}
 $request.prior|Add-Member -NotePropertyName Projection -NotePropertyValue $projected
 $plan=Read-SequenceJson $oldFiles.Plan.path $oldFiles.Plan.sha256
 $request.prior|Add-Member -NotePropertyName Assemble -NotePropertyValue ([pscustomobject]@{files=[pscustomobject]$oldFiles;raw=[pscustomobject]@{planSha256=$plan.PlanSha256}})
 $request.stage='RuntimePlan';$runtimeParameters=Get-SequenceRuntimeParameters $request
 Check ($runtimeParameters.FullExpectedApprovalSha256 -ceq $approvalPin.sha256 -and $runtimeParameters.FullExpectedRuntimeGateSha256 -ceq $oldFiles.Gate.sha256 -and $runtimeParameters.FullTransitionSourceManifestPath -ceq $oldFiles.SourceManifest.path) 'runtime route forwards exact approval gate and source pointers'
 # This fixed production route adds PlanOnly before invoking the public script.
 # No Capture, Warm, Apply or Runtime stage is invoked in this test.
 $dry=Invoke-SequenceChild $request $transportSpec
 Check ($dry.raw.Ready -and $dry.raw.RunId -ceq $run -and $dry.raw.WillLaunch -eq $false -and $dry.raw.RuntimeAllowed -eq $false -and @($dry.raw.Failures).Count -eq 0) 'actual public RuntimePlanOnly returns a typed ready nonlaunching object'
 $parameters=Get-SequencePrepareParameters $request
 Check ($parameters.ApprovalPath -ceq $approvalPin.path -and $parameters.ExpectedSourceManifestSha256 -ceq $oldFiles.SourceManifest.sha256 -and -not $parameters.ContainsKey('Apply')) 'preparation parameter route keeps Plan separate from Apply'
 [ordered]@{scope='historical963b C-only production route regression';passed=$true;checks=$tests.Count;tests=$tests.ToArray();root=$root;assembler=$assembled.raw;projection=$projected.raw;runtimePlanReady=$dry.raw.Ready;actualStages=@('Assemble','Projection','RuntimePlan');captureExecuted=$false;warmExecuted=$false;applyExecuted=$false;runtimeExecuted=$false;aaLaunched=$false;stageRead=$false;registryAccess=$false;historicalApprovalUnchanged=$approvalPin.sha256;moduleSha256=(Get-FileHash (Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1')).Hash.ToLowerInvariant()}
} $repo $root
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh result required'}
[IO.File]::WriteAllText($ResultPath,($report|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false));$report|ConvertTo-Json -Depth 7
