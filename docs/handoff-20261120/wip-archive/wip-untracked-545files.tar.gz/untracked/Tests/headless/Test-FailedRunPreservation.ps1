param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$scriptPath=Join-Path $repo 'tools\headless\Preserve-AzuriteFailedCapabilitiesRun.ps1'
if(-not [IO.File]::Exists($scriptPath)){throw 'RED: read-only failed-run preservation script is missing'}
$fixtureOutput=$OutputDirectory
. $scriptPath
$OutputDirectory=$fixtureOutput
function Check($v,[string]$message){if(-not $v){throw ('FAIL '+$message)}}
function CopyObject($v){ConvertFrom-PreservationJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-PreservationJson $v)))}
function NewFixture {
 $root='C:\PreservationVirtual';$run=$root+'\runs\restricted-r';$pending=$root+'\runs\full-capabilities.pending.json';$owner='S-1-5-21-1-2-3-1001';$seq=0;$objects=@{}
 foreach($p in @($root,($root+'\install'),($root+'\install\loader.log'),$run,($run+'\output'),($run+'\output\unity.log'),($run+'\foreign-evidence.txt'),$pending)){$seq++;$dir=$p -cin @($root,($root+'\install'),$run,($run+'\output'));$content=if($p -ceq $pending){'{"schema":1,"scope":"full-capabilities-global-pending","runId":"r","controllerSid":"S-1-5-21-1-2-3-1001","runDirectory":"C:\\PreservationVirtual\\runs\\restricted-r","state":"runtime-pending","planSha256":"a"}'}else{'fixture bytes'};$bytes=[Text.Encoding]::UTF8.GetBytes($content);$objects[$p]=[pscustomobject]@{path=$p;finalPath=$p;identity=('{0:x32}' -f $seq);owner=$owner;volume='fixture-volume';directory=$dir;reparse=$false;links=1;sddl='O:'+ $owner+'G:'+ $owner+'D:P(A;;FA;;;'+$owner+')';bytes=$(if($dir){0L}else{[long]$bytes.Length});sha256=$(if($dir){$null}else{Get-PreservationHash $bytes});content=$(if($dir){$null}else{[Convert]::ToBase64String($bytes)})}}
 $prepared=@($objects.Values|Where-Object path -CNE ($run+'\foreign-evidence.txt')|ForEach-Object{CopyObject $_});$orig=@($prepared|Where-Object{$_.path -ceq $root -or $_.path.StartsWith($root+'\install',[StringComparison]::Ordinal)})
 $expectedPending=CopyObject $objects[$pending];$text=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($expectedPending.content)).Replace('runtime-pending','prepared-awaiting-runtime-lease');$expectedPending.sha256=Get-PreservationHash ([Text.Encoding]::UTF8.GetBytes($text));$expectedPending.bytes=[Text.Encoding]::UTF8.GetByteCount($text);$expectedPending.content=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($text));$prepared=@($prepared|ForEach-Object{if($_.path -ceq $pending){$expectedPending}else{$_}})
 $spec=[pscustomobject]@{RunId='r';LabRoot=$root;RunRoot=$run;PendingPath=$pending;OwnerSid=$owner;Volume='fixture-volume';Original=$orig;Prepared=$prepared;MutableFiles=@($root+'\install\loader.log');ImportantPaths=@(($run+'\output\bootstrap-result.json'),($run+'\request\response.json'));MaxTreeObjects=256;MaxFileBytes=67108864L;MaxArchiveBytes=268435456L;InputBindings=@();OriginalRuntimeCleanupVerified=$false;AaCreationProven=$false;AaCreationExcluded=$false}
 $state=@{Spec=$spec;Objects=$objects;Records=@{};Events=[Collections.Generic.List[string]]::new();Archives=@{};Fault='';Held=$false;Released=$false;Disposed=$false;EvidenceDirectory='C:\evidence'}
 $state.Backend={param($action,$a,$s)
  $s.Events.Add($action)
  switch($action){
   Acquire {$s.Held=$true;return}
   Environment {return [pscustomobject]@{aaCount=0;probeCount=0}}
   Observe {if($s.Objects.ContainsKey($a.path)){return CopyObject $s.Objects[$a.path]};return $null}
   Enumerate {if($s.Fault -ceq 'outside-enumeration'){return @('C:\foreign\escape.txt')};return @($s.Objects.Keys|Where-Object{[IO.Path]::GetDirectoryName($_) -ceq $a.path})}
   Archive {if($s.Fault -ceq 'archive'){throw 'archive stopped'};$s.Archives[$a.path]=CopyObject $s.Objects[$a.path];if($s.Fault -ceq 'read-change'){$s.Objects[$a.path].sha256='a'*64};return [pscustomobject]@{source=$a.path;sourceIdentity=$a.expected.identity;destination='C:\evidence\'+$a.expected.identity+'.bin';bytes=$a.expected.bytes;sha256=$a.expected.sha256}}
   Journal {if($s.Fault -ceq 'journal'){throw 'durable journal failed'};return}
   Persist {if($s.Fault -ceq ('persist-'+$a.name)){throw 'persistence failed'};$s.Records[$a.name]=CopyObject $a.value;return}
   Release {if($s.Fault -ceq 'release'){throw 'release failed'};$s.Held=$false;$s.Released=$true;return}
   Dispose {$s.Disposed=$true;return}
   Retain {$s.Retained=$true;return}
   default {throw ('Unexpected operation: '+$action)}
  }
 }
 return $state
}
$fixture=NewFixture;$before=ConvertTo-PreservationJson $fixture.Objects;$success=Invoke-PreservationCoordinator $fixture.Spec $fixture.Backend $fixture
Check ($success.preserved -and $success.originalObservedCount -eq 3 -and $success.archiveFileCount -eq 4 -and $success.differencesCount -eq 2) ('complete read-only preservation: '+$success.error)
Check ((ConvertTo-PreservationJson $fixture.Objects) -ceq $before) 'preservation does not mutate source objects'
Check ($fixture.Records['object-comparison'].differences.category -ccontains 'extra-run-object') 'unknown ordinary same-owner run evidence is archived and listed'
Check ($fixture.Records['important-path-status'].paths.Count -eq 2 -and @($fixture.Records['important-path-status'].paths|Where-Object exists).Count -eq 0) 'actual important absences are recorded'
Check ($success.originalRuntimeCleanupVerified -eq $false -and $success.aaCreationExcluded -eq $false -and $success.aaCreationProven -eq $false) 'preservation does not promote runtime acceptance or exclude AA creation'
foreach($fault in @('archive','read-change','journal','persist-run-inventory','release')){$s=NewFixture;$s.Fault=$fault;$r=Invoke-PreservationCoordinator $s.Spec $s.Backend $s;Check (-not $r.preserved -and $r.error) ('stop on '+$fault)}
foreach($fault in @('reparse','hardlink','foreign-owner','foreign-volume','canonical','outside-enumeration')){$s=NewFixture;$p=$s.Spec.RunRoot+'\foreign-evidence.txt';switch($fault){reparse {$s.Objects[$p].reparse=$true};hardlink {$s.Objects[$p].links=2};foreign-owner {$s.Objects[$p].owner='foreign'};foreign-volume {$s.Objects[$p].volume='foreign'};canonical {$s.Objects[$p].finalPath='C:\foreign'};outside-enumeration {$s.Fault=$fault}};$r=Invoke-PreservationCoordinator $s.Spec $s.Backend $s;Check (-not $r.preserved -and $s.Archives.Count -eq 0) ('unsafe read refuses archive '+$fault)}
$plan=Get-FailedCapabilitiesPreservationPlan
Check ($plan.RunId -ceq '250c044d62ab4b92ad82a830bb9b47c5' -and $plan.Original.Count -eq 1228 -and $plan.Prepared.Count -eq 1259 -and $plan.MutableFiles.Count -eq 5 -and $plan.OriginalRuntimeCleanupVerified -eq $false) 'C-only accepted 250c input plan remains failed-runtime scope'
Assert-PreservationCPath $OutputDirectory $false;Check (-not [IO.Directory]::Exists($OutputDirectory)) 'fresh physical fixture output';[void][IO.Directory]::CreateDirectory($OutputDirectory)
$dll=Join-Path $repo 'artifacts\aa-fr-empty-directory-helper-20261113\helper-build1\FullRestrictedStageFileSecurity.dll';$bytes=Read-PreservationPinnedC $dll '0d1bbc0541dd7e1b74619b62c1bbdf4cef00a35b21cdf2a7e4d11f4505a1e84b';[void][Reflection.Assembly]::Load([byte[]]$bytes)
$root=Join-Path $OutputDirectory 'source';$run=$root+'\runs\restricted-r';$install=$root+'\install';foreach($p in @($root,$install,($root+'\runs'),$run,($run+'\output'))){[void][IO.Directory]::CreateDirectory($p)}
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;$pending=$root+'\runs\full-capabilities.pending.json';$loader=$install+'\loader.log';$large=$run+'\output\large.json';$extra=$run+'\extra.json'
[IO.File]::WriteAllText($loader,'changed but preserved');[IO.File]::WriteAllText($extra,'{"extra":true}');$stream=[IO.FileStream]::new($large,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$stream.SetLength(6*1024*1024+123);$stream.Flush($true)}finally{$stream.Dispose()}
$pbody=[pscustomobject][ordered]@{schema=1;scope='full-capabilities-global-pending';runId='r';planSha256='a';controllerSid=$sid;runDirectory=$run;state='runtime-pending'};[IO.File]::WriteAllText($pending,(ConvertTo-PreservationJson $pbody),[Text.UTF8Encoding]::new($false))
$live=@(foreach($p in @($root,$install,$loader,$run,($run+'\output'),$large,$pending)){[Azurite.Stage.FileSecurity]::Read($p,$false)});$orig=@($live|Where-Object{$_.path -cin @($root,$install,$loader)});$expectedPending=$live|Where-Object path -CEQ $pending;$pbody.state='prepared-awaiting-runtime-lease';$pb=[Text.Encoding]::UTF8.GetBytes((ConvertTo-PreservationJson $pbody));$expectedPending.sha256=Get-PreservationHash $pb;$expectedPending.bytes=$pb.Length
$spec=[pscustomobject]@{RunId='r';LabRoot=$root;RunRoot=$run;PendingPath=$pending;OwnerSid=$sid;Volume=$orig[0].volume;Original=$orig;Prepared=$live;MutableFiles=@($loader);ImportantPaths=@($run+'\output\bootstrap-result.json');MaxTreeObjects=256;MaxFileBytes=67108864L;MaxArchiveBytes=268435456L;InputBindings=@();OriginalRuntimeCleanupVerified=$false;AaCreationProven=$false;AaCreationExcluded=$false}
$evidence=Join-Path $OutputDirectory 'capture';[void][IO.Directory]::CreateDirectory($evidence);[void][IO.Directory]::CreateDirectory((Join-Path $evidence 'archive'));$state=@{Spec=$spec;EvidenceDirectory=$evidence;ArchiveDirectory=(Join-Path $evidence 'archive');Locks=@{};Mutex=$null;Held=$false;JournalSequence=0;Physical=(New-PreservationPhysicalBackend)}
$backend={param($action,$a,$s)if($action -ceq 'Acquire'){$s.Mutex=[Threading.Mutex]::new($false,('Local\PreserveFixture-'+[guid]::NewGuid().ToString('N')));if(-not $s.Mutex.WaitOne(0)){throw 'fixture lease failed'};$s.Held=$true;return};if($action -ceq 'Environment'){return [pscustomobject]@{aaCount=0;probeCount=0}};& $s.Physical $action $a $s}
$r=Invoke-PreservationCoordinator $spec $backend $state
Check ($r.preserved -and $r.archiveFileCount -eq 4 -and $r.releaseSucceeded -and $r.disposeSucceeded) ('real C preservation completed: '+$r.error)
Check (([Azurite.Stage.FileSecurity]::Read($large,$false)).bytes -eq (6*1024*1024+123) -and [IO.File]::ReadAllText($loader) -ceq 'changed but preserved' -and [IO.File]::Exists($pending) -and [IO.File]::Exists($extra)) 'real source payloads remain unchanged and present'
$result=[pscustomobject]@{passed=$true;pureHazardCases=11;physicalArchiveFiles=$r.archiveFileCount;largeBytes=(6*1024*1024+123);planOriginalCount=$plan.Original.Count;scriptSha256=(Get-FileHash -LiteralPath $scriptPath).Hash.ToLowerInvariant();FReadPerformed=$false;FWritePerformed=$false;registryAccessPerformed=$false;aaStarted=$false;physicalFixture=$r}
Write-PreservationRecord (Join-Path $OutputDirectory 'test-result.json') $result;$result|Select-Object passed,pureHazardCases,physicalArchiveFiles,largeBytes,planOriginalCount,scriptSha256,FReadPerformed,FWritePerformed,registryAccessPerformed,aaStarted|ConvertTo-Json -Compress
