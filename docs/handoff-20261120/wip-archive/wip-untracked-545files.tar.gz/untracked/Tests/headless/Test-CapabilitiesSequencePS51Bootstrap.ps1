param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$root=Join-Path $repo ('artifacts\aa-fr-sequence-ps51-bootstrap-fix-20261113\probe-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($root)
$module=Import-Module (Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1') -Force -PassThru -DisableNameChecking
$result=& $module {
 param($repo,$root)
 $checks=[Collections.Generic.List[string]]::new();function Check($v,[string]$n){if(-not $v){throw ('ASSERT '+$n)};$checks.Add($n)}
 $roles=Get-SequenceFixedRoles;$sources=@{};foreach($entry in $roles.GetEnumerator()){$p=$entry.Value;$sources[$entry.Key]=[pscustomobject]@{role=$entry.Key;path=$p;sha256=(Get-FileHash $p).Hash.ToLowerInvariant();bytes=(Get-Item $p).Length}}
 $captureHash=$sources.Capture.sha256;$modulePathBefore=[Environment]::GetEnvironmentVariable('PSModulePath','Process')
 # Stop at the actual fixed child's complete source gate: it must reach its
 # Get-FileHash-backed source validation, but never enter the Capture producer.
 $sources.Current.sha256='0'*64
 $spec=[pscustomobject]@{Sources=[pscustomobject]$sources;OutputRoot=$root}
 $request=[pscustomobject]@{stage='Capture';runId=('e'*32);sources=[pscustomobject]$sources;input=[pscustomobject]@{};sequenceRoot=$root}
 $reply=Invoke-SequenceChild $request $spec
 Check ($reply.childExitCode -eq 1 -and $reply.stageError -like '*Reviewed source bytes differ: Current*' -and -not $reply.controllerHeldForRoot) 'real production PS51 child reaches exact source gate and exits before Capture'
 Check (-not [IO.File]::Exists((Join-Path $root 'Capture-raw-result.json')) -and $null -eq $reply.raw) 'no producer raw result exists'
 $ownershipPin=Get-SequencePin (Join-Path $root 'Capture-child-ownership.json');$ownership=Read-SequenceJson $ownershipPin.path $ownershipPin.sha256
 Check ($ownership.exitConfirmed -and $ownership.streamsCompleted -and $ownership.disposed -and -not $ownership.retained -and $ownership.exitCode -eq 1) 'preproducer refusal has positively finished streams and no retained owner'
 Check ((Get-FileHash -LiteralPath $roles.Capture).Hash.ToLowerInvariant() -ceq $captureHash) 'fixed Capture producer bytes remain unchanged'
 Check ([Environment]::GetEnvironmentVariable('PSModulePath','Process') -ceq $modulePathBefore) 'parent PSModulePath unchanged'
 # A separate harmless diagnostic uses the same physical transport. Its only
 # public Capture interaction is Get-Command metadata; the script never runs.
 $code=@'
$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$commands=@('Get-FileHash','ConvertTo-Json','ConvertFrom-Json','Get-CimInstance','Get-Item')
$paths=@{};foreach($name in $commands){$paths[$name]=(Get-Command $name -ErrorAction Stop).Module.Path}
$capture=Get-Command 'C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\tools\headless\Capture-AzuriteFullCapabilitiesIdentityShared.ps1'
[Console]::Out.WriteLine(([ordered]@{host=$PSVersionTable.PSVersion.ToString();psModulePath=$env:PSModulePath;commands=$paths;captureRunIdParameter=$capture.Parameters.ContainsKey('RunId');captureExecuted=$false}|ConvertTo-Json -Depth 8 -Compress))
'@
 $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$roles.PS51;$psi.Arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($code));$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.EnvironmentVariables.Remove('PSModulePath');$psi.WorkingDirectory=$root
 $state=Invoke-SequenceProcessTransport $psi (Join-Path $root 'cmdlets-stdout.json') (Join-Path $root 'cmdlets-stderr.log') (Join-Path $root 'cmdlets-no-reply.json') 'PS51CmdletProbe' ('f'*32)
 Check ($state.exitCode -eq 0 -and $state.exitConfirmed -and $state.streamsCompleted -and $state.disposed -and -not $state.retained) 'real PS51 native cmdlet metadata probe exits normally'
 $observed=ConvertFrom-SequenceJson ([IO.File]::ReadAllText((Join-Path $root 'cmdlets-stdout.json')))
 Check ($observed.captureRunIdParameter -and $observed.commands.'Get-FileHash' -like 'C:\Windows\*\WindowsPowerShell\v1.0\Modules\Microsoft.PowerShell.Utility\*' -and $observed.psModulePath -notlike '*codex-primary-runtime*') 'PS51 initializes native module path and real Capture metadata without execution'
 # Real nonzero child with no reply: exact code and original stderr must be
 # reported instead of a subsequent generic missing-path error.
 $code="[Console]::Error.WriteLine('BOOTSTRAP_SENTINEL_NONZERO');exit 23";$psi.Arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($code))
 $failed=Invoke-SequenceProcessTransport $psi (Join-Path $root 'NoReply-stdout.log') (Join-Path $root 'NoReply-stderr.log') (Join-Path $root 'NoReply-child-result.json') 'NoReply' ('f'*32)
 $errorText=$null;try{Complete-SequenceTransportResult $failed ([pscustomobject]@{stage='NoReply'}) ([pscustomobject]@{OutputRoot=$root}) (Join-Path $root 'NoReply-child-result.json')}catch{$errorText=$_.Exception.ToString()}
 Check ($errorText -like '*exited 23*BOOTSTRAP_SENTINEL_NONZERO*' -and $errorText -notlike '*Sequence input missing*') 'real nonzero missing-reply failure preserves original exit and stderr'
 Check ([Environment]::GetEnvironmentVariable('PSModulePath','Process') -ceq $modulePathBefore) 'all diagnostics left global environment unchanged'
 [ordered]@{scope='real fixed PS51 child preproducer gate and C-only bootstrap smoke';passed=$true;checks=$checks.Count;tests=$checks.ToArray();root=$root;actualChildProcesses=3;captureExecuted=$false;warmExecuted=$false;applyExecuted=$false;runtimeExecuted=$false;stageRead=$false;registryAccess=$false;nativeHelperLoaded=$false;producerHashUnchanged=$captureHash;observedNativeCmdlets=$observed;missingReplyError=$errorText;moduleSha256=(Get-FileHash $roles.SequenceModule).Hash.ToLowerInvariant();childSha256=(Get-FileHash $roles.SequenceChild).Hash.ToLowerInvariant()}
} $repo $root
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh result required'};[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false));[pscustomobject]$result|Select-Object passed,checks,actualChildProcesses,moduleSha256,childSha256,captureExecuted,stageRead,registryAccess,nativeHelperLoaded|ConvertTo-Json
