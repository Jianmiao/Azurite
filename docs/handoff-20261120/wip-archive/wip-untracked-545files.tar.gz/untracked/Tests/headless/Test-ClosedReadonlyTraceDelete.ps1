param([Parameter(Mandatory)][string]$OutputDirectory,[ValidateSet('Dispatch','Binding','Load','Preloaded','LegacySource')][string]$Phase='Dispatch')
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$allowed=Join-Path $repo 'artifacts\closed-readonly-trace-integration-20261114'
if(-not [IO.Path]::GetFullPath($OutputDirectory).StartsWith($allowed+'\',[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $OutputDirectory)){throw 'Fresh owned C fixture directory required'}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
Import-Module (Join-Path $repo 'tools\headless\FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($out,$phase,$repo)
 $checks=[Collections.Generic.List[object]]::new()
 function Need($value,[string]$why){if(-not $value){throw $why}}
 function Test([string]$name,[scriptblock]$body){try{& $body;$checks.Add([pscustomobject]@{name=$name;passed=$true;error=$null})}catch{$checks.Add([pscustomobject]@{name=$name;passed=$false;error=$_.Exception.ToString()})}}
 function Clone($v){ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $v)))}
 function Hash([string]$p){Need ($p.StartsWith('C:\',[StringComparison]::OrdinalIgnoreCase)) 'C file required';(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}
 function Save([string]$name,$value){$p=Join-Path $out $name;Write-RecoveryCRecord $p $value;[pscustomobject]@{path=$p;sha256=Hash $p}}
 $helperPath=Join-Path $repo 'artifacts\aa-fr-readonly-trace-continuation\physical-final3\ArchivedReadonlyTraceDelete.dll'
 Need ((Hash $helperPath) -ceq '03c0bb67c23affce8228ee891d2c71a3e57c4f26ec10399d449bac24d92295f0') 'Original readonly helper differs'
 $run='3df9c00b94634b80aec9421b3b592d7b'
 if($phase -eq 'LegacySource'){
  $source=Get-Content -LiteralPath (Join-Path $repo 'artifacts\aa-fr-closed-runtime-recovery-85ab\fresh-0bca162592b8496b9fec0a8048ebf5a6\continuation-source-manifest.json') -Raw|ConvertFrom-Json -DateKind String
  foreach($f in $source.files){$f.sha256=Hash $f.path;$f.bytes=(Get-Item -LiteralPath $f.path).Length}
  $pin=Save 'legacy15-source.json' $source
  Test 'old fixed85ab continuation15 source shape remains compatible' {$bound=Read-RecoverySourceBindings $pin.path $pin.sha256 $source.runId $source.evidenceManifestSha256 'readonly-trace-recovery-continuation';Need ($bound.files.Count -eq 15) 'Legacy continuation source shape changed'}
  Test 'legacy continuation still rejects missing helper source role' {$bad=Clone $source;$bad.files=@($bad.files|Where-Object name -CNE 'readonly-helper-test.json');$p=Save 'legacy-missing-helper.json' $bad;$denied=$false;try{Read-RecoverySourceBindings $p.path $p.sha256 $source.runId $source.evidenceManifestSha256 'readonly-trace-recovery-continuation'|Out-Null}catch{$denied=$true};Need $denied 'Legacy helper proof was weakened'}
  Need (-not ('Azurite.Recovery.ArchivedReadonlyTraceDelete' -as [type]) -and -not ('Azurite.Stage.FileSecurity' -as [type])) 'Legacy source validation loaded native helper'
 }elseif($phase -ne 'Dispatch'){
  $planFolder=Join-Path $repo ('artifacts\aa-fr-closed-failed-recovery\plan-'+$run)
  $evidence=Join-Path $planFolder 'evidence-manifest.json';$eh=Hash $evidence
  Need ($eh -ceq '1032d3772fc438deb5408e778d75504e786dd7a671a8158fe1f953f5960ed487') 'Fixed actual R3df input changed'
  $spec=Get-ClosedFailedRecoveryPlan $run $evidence $eh
  $trace=$null;if($spec.PSObject.Properties['ArchivedReadonlyTrace']){$trace=$spec.ArchivedReadonlyTrace}
  $source=Get-Content -LiteralPath (Join-Path $planFolder 'source-manifest.json') -Raw|ConvertFrom-Json -DateKind String
  foreach($f in $source.files){$f.sha256=Hash $f.path;$f.bytes=(Get-Item -LiteralPath $f.path).Length}
  $base=Clone $source
  $triple=@(@('ArchivedReadonlyTraceDelete.cs',(Join-Path $repo 'tools\headless\ArchivedReadonlyTraceDelete.cs')),@('ArchivedReadonlyTraceDelete.dll',$helperPath),@('readonly-helper-test.json',(Join-Path $repo 'artifacts\aa-fr-readonly-trace-continuation\physical-final3\result.json')))
  foreach($pair in $triple){$source.files+=,[pscustomobject]@{name=$pair[0];path=$pair[1];sha256=Hash $pair[1];bytes=(Get-Item -LiteralPath $pair[1]).Length}}
  $sourcePin=Save 'diagnostic-source-manifest.json' $source;$basePin=Save 'base10-source-manifest.json' $base
  function Bind($pin,$target){$a=@($pin.path,$pin.sha256,$run,$eh,'closed-failed-runtime-recovery');if((Get-Command Read-RecoverySourceBindings).Parameters.ContainsKey('ReadonlyTraceBinding')){Read-RecoverySourceBindings @a -ReadonlyTraceBinding $target}else{Read-RecoverySourceBindings @a}}
  if($phase -eq 'Binding'){
   Test 'actual diagnostic graph derives the unique archived history target without historical attrs' {Need ($null -ne $trace) 'Verified diagnostic target was discarded';Need ($trace.Binding.CopyPath -ceq $trace.Target.path -and $trace.Target.identity -ceq 'd85e8f4100000000000400000005478f' -and $trace.Target.sha256 -ceq 'bc827df2d394c0e10e3ff07ee5f67db3451def24f5f91d6a61ea6b0e01bd3b70' -and $trace.Target.bytes -eq 2071 -and $trace.PreservedArchive.source -ceq $trace.Target.path -and $trace.PreservedArchive.sourceIdentity -ceq $trace.Target.identity) 'Actual history/archive association differs';Need (-not $trace.Target.PSObject.Properties['attributes']) 'Historical attributes were invented';Need ($spec.ActionPlan.Count -eq 1267) 'Inverse action order/count changed'}
   Test 'original10 source shape remains available without diagnostic target' {$b=Bind $basePin $null;Need ($b.files.Count -eq 10) 'Original source shape rejected'}
   Test 'actual diagnostic target requires all13 bound source roles' {$b=Bind $sourcePin $trace;Need ($null -ne $trace -and $b.files.Count -eq 13) 'Readonly helper source closure not bound'}
   Test 'diagnostic target cannot use original10 without helper pins' {$denied=$false;try{Bind $basePin $trace|Out-Null}catch{$denied=$true};Need ($null -ne $trace -and $denied) 'Missing helper closure accepted'}
   Test 'extra helper roles do not activate an unselected diagnostic' {$denied=$false;try{Bind $sourcePin $null|Out-Null}catch{$denied=$true};Need $denied 'Helper closure activated without derived target'}
   foreach($roleName in @('ArchivedReadonlyTraceDelete.cs','ArchivedReadonlyTraceDelete.dll','readonly-helper-test.json')){Test ('changed source binding refuses '+$roleName) {$bad=Clone $source;($bad.files|Where-Object name -CEQ $roleName).sha256='a'*64;$pin=Save ('wrong-'+$roleName.Replace('.','-')+'.json') $bad;$denied=$false;try{Bind $pin $trace|Out-Null}catch{$denied=$true};Need $denied 'Changed pinned helper source accepted'}}
   Test 'source closure cannot bind a foreign run target' {$bad=Clone $trace;$bad.Target.path=$bad.Target.path.Replace($run,('f'*32));$denied=$false;try{Bind $sourcePin $bad|Out-Null}catch{$denied=$true};Need $denied 'Foreign derived target accepted'}
   Need (-not ('Azurite.Recovery.ArchivedReadonlyTraceDelete' -as [type]) -and -not ('Azurite.Stage.FileSecurity' -as [type])) 'Pure source binding loaded native helpers'
  }else{
   $bound=Bind $sourcePin $trace
   if($phase -eq 'Preloaded'){Add-Type -TypeDefinition 'namespace Azurite.Recovery {public static class ArchivedReadonlyTraceDelete { public static void Delete(){} }}';Test 'same-named preloaded type is rejected before qualified bytes load' {$denied=$false;try{Initialize-RecoveryReadonlyTraceHelper $bound|Out-Null}catch{$denied=$true};Need $denied 'Unqualified preloaded type trusted'}}
   else{Test 'qualified bytes load the returned assembly exact executable helper type' {$loaded=Initialize-RecoveryReadonlyTraceHelper $bound;Need ($loaded.Method.DeclaringType.Assembly -eq $loaded.Assembly -and $loaded.Method.DeclaringType.FullName -ceq 'Azurite.Recovery.ArchivedReadonlyTraceDelete' -and $loaded.Method.Name -ceq 'Delete' -and $loaded.Method.GetParameters().Count -eq 7 -and ('Azurite.Recovery.ArchivedReadonlyTraceDelete' -as [type]) -eq $loaded.Method.DeclaringType) 'Executing type does not belong to qualified loaded bytes';$denied=$false;try{Initialize-RecoveryReadonlyTraceHelper $bound|Out-Null}catch{$denied=$true};Need $denied 'Preloaded helper accepted on repeated initialization'}}
  }
 }else{
  $stageHelper=Join-Path $repo 'artifacts\aa-fr-empty-directory-helper-20261113\helper-build1\FullRestrictedStageFileSecurity.dll'
  Need ((Hash $stageHelper) -ceq '0d1bbc0541dd7e1b74619b62c1bbdf4cef00a35b21cdf2a7e4d11f4505a1e84b') 'Original generic helper differs'
  Add-Type -Path $stageHelper
  $qualified=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes($helperPath));$method=$qualified.GetType('Azurite.Recovery.ArchivedReadonlyTraceDelete',$true).GetMethod('Delete')
  function NewFixture {
   $id=[guid]::NewGuid().ToString('N');$root=Join-Path $repo ('artifacts\rtd3\'+[guid]::NewGuid().ToString('N').Substring(0,8));Need (-not (Test-Path -LiteralPath $root)) 'Fresh short C fixture root required';$dir=Join-Path $root ('runs\restricted-'+$id+'\history\post-run');[void][IO.Directory]::CreateDirectory($dir)
   $path=Join-Path $dir 'startup-exceptions.nettrace';[IO.File]::WriteAllText($path,'explicit C recovery handler fixture',[Text.UTF8Encoding]::new($false));[IO.File]::SetAttributes($path,[IO.FileAttributes]33);$object=[Azurite.Stage.FileSecurity]::Read($path,$false)
   $archive=Join-Path $root 'archived-trace.bin';[Azurite.Stage.FileSecurity]::ArchiveFile($path,$object.identity,$object.sddl,$object.sha256,$object.bytes,$archive);$saved=[Azurite.Stage.FileSecurity]::Read($archive,$false)
   $target=[pscustomobject]@{Binding=[pscustomobject]@{CopyPath=$path;SourcePath=(Join-Path $root ('runs\restricted-'+$id+'\output\startup-exceptions.nettrace'));MaximumBytes=4194304;Protocol='startup-exceptions.v1'};Target=$object;PreservedArchive=[pscustomobject]@{source=$path;sourceIdentity=$object.identity;destination=$archive;destinationIdentity=$saved.identity;bytes=$saved.bytes;sha256=$saved.sha256}}
   $state=@{Spec=[pscustomobject]@{Scope='closed-failed-runtime-recovery';RunId=$id;Root=$root;ArchivedReadonlyTrace=$target};RecoveryId=[guid]::NewGuid().ToString('N');ArchiveComplete=$true;EvidenceDirectory=$root;ReadonlyTraceDeleteAssembly=$qualified;ReadonlyTraceDeleteMethod=$method}
   [pscustomobject]@{Root=$root;Path=$path;Object=$object;State=$state;Arguments=@{path=$path;expectedIdentity=$object.identity;expectedSddl=$object.sddl;expectedSha256=$object.sha256};Archive=$archive}
  }
  $backend=New-RecoveryPhysicalBackend
  Test 'actual DeleteFile handler deletes the exact archived readonly history trace' {$f=NewFixture;& $backend DeleteFile $f.Arguments $f.State;Need (-not [IO.File]::Exists($f.Path) -and (Hash $f.Archive) -ceq $f.Object.sha256) 'Actual handler did not preserve archive and delete target'}
  foreach($case in @('wrong-identity','wrong-sha','wrong-sddl','wrong-bytes','wrong-run','wrong-attributes','archive-not-complete')){Test ('actual handler refuses '+$case) {$f=NewFixture;$attrs=33;switch($case){'wrong-identity' {$f.Arguments.expectedIdentity='a'*32};'wrong-sha' {$f.Arguments.expectedSha256='b'*64};'wrong-sddl' {$f.Arguments.expectedSddl='O:SYG:SYD:(A;;FA;;;SY)'};'wrong-bytes' {$f.State.Spec.ArchivedReadonlyTrace.Target.bytes++};'wrong-run' {$f.State.Spec.RunId='f'*32};'wrong-attributes' {$attrs=1;[IO.File]::SetAttributes($f.Path,[IO.FileAttributes]$attrs)};'archive-not-complete' {$f.State.ArchiveComplete=$false}};$denied=$false;try{& $backend DeleteFile $f.Arguments $f.State}catch{$denied=$true};Need ($denied -and [IO.File]::Exists($f.Path) -and [int][IO.File]::GetAttributes($f.Path) -eq $attrs -and (Hash $f.Path) -ceq $f.Object.sha256) 'Invalid target was mutated'}}
  Test 'same-filename output trace still uses the generic handler' {$f=NewFixture;$path=$f.State.Spec.ArchivedReadonlyTrace.Binding.SourcePath;[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path));[IO.File]::WriteAllText($path,'ordinary source trace fixture');$e=[Azurite.Stage.FileSecurity]::Read($path,$false);& $backend DeleteFile @{path=$path;expectedIdentity=$e.identity;expectedSddl=$e.sddl;expectedSha256=$e.sha256} $f.State;Need (-not [IO.File]::Exists($path) -and [IO.File]::Exists($f.Path) -and [int][IO.File]::GetAttributes($f.Path) -eq 33) 'Generic output deletion routing changed'}
  Test 'history filename alone cannot activate readonly clearing' {$f=NewFixture;$f.State.Spec.PSObject.Properties.Remove('ArchivedReadonlyTrace');$denied=$false;try{& $backend DeleteFile $f.Arguments $f.State}catch{$denied=$true};Need ($denied -and [IO.File]::Exists($f.Path) -and [int][IO.File]::GetAttributes($f.Path) -eq 33) 'Filename activated an unselected readonly helper'}
  Test 'missing qualified executable helper refuses before target mutation' {$f=NewFixture;$f.State.Remove('ReadonlyTraceDeleteMethod');$denied=$false;try{& $backend DeleteFile $f.Arguments $f.State}catch{$denied=$true};Need ($denied -and [IO.File]::Exists($f.Path) -and [int][IO.File]::GetAttributes($f.Path) -eq 33) 'Missing helper was bypassed'}
  Test 'mapped-file failure keeps actual cleared attributes and disables retry' {$f=NewFixture;$stream=[IO.FileStream]::new($f.Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete);$mapping=[IO.MemoryMappedFiles.MemoryMappedFile]::CreateFromFile($stream,('Local\ClosedReadonly-'+[guid]::NewGuid().ToString('N')),0,[IO.MemoryMappedFiles.MemoryMappedFileAccess]::Read,[IO.HandleInheritability]::None,$true);$view=$mapping.CreateViewAccessor(0,0,[IO.MemoryMappedFiles.MemoryMappedFileAccess]::Read);try{$denied=$false;try{& $backend DeleteFile $f.Arguments $f.State}catch{$denied=$true};Need ($denied -and $f.State.ContainsKey('ReadonlyTraceFailure')) 'Partial helper failure data was lost';$failure=$f.State.ReadonlyTraceFailure;Need ($failure.attributesCleared -eq $true -and $failure.observedAttributes -eq 32 -and $failure.automaticRetryAllowed -eq $false -and [IO.File]::Exists($f.Path) -and [int][IO.File]::GetAttributes($f.Path) -eq 32 -and (Test-Path -LiteralPath (Join-Path $f.Root 'readonly-trace-failure.json'))) 'Actual partial attribute state or durable failure record differs';$f.State.Spec|Add-Member Prepared @($f.Object);$f.State.Spec|Add-Member Original @();$envelope={param($action,$a,$s)if($action -ceq 'Acquire'){throw 'SOURCE-only stop: physical handler already tested'};if($action -ceq 'Dispose'){return};if($action -ceq 'Persist'){$s.OutcomeRecord=$a.value;return};throw 'Unexpected outcome-only operation'};$outcome=Invoke-RecoveryCoordinator $f.State.Spec $envelope $f.State;Need (-not $outcome.Success -and $outcome.ReadonlyTraceFailure.observedAttributes -eq 32 -and $outcome.ReadonlyTraceFailure.attributesCleared -eq $true -and $outcome.ReadonlyTraceFailure.error -ceq $failure.error -and $outcome.AutomaticRetryAllowed -eq $false) 'Coordinator outcome discarded actual partial helper data'}finally{$view.Dispose();$mapping.Dispose();$stream.Dispose()}}
 }
 $failed=@($checks|Where-Object {-not $_.passed}).Count
 $result=[pscustomobject]@{phase=$phase;passed=($failed -eq 0);checks=$checks.Count;failed=$failed;cases=$checks;FReadPerformed=$false;FWritePerformed=$false;AAExecuted=$false;PublicApplyExecuted=$false;PhysicalCallsOnlySelfCreatedCFixtures=($phase -eq 'Dispatch')}
 Write-RecoveryCRecord (Join-Path $out 'result.json') $result
 $result|Select-Object phase,passed,checks,failed,FReadPerformed,FWritePerformed,AAExecuted,PublicApplyExecuted|ConvertTo-Json
 if($failed){$checks|Where-Object {-not $_.passed}|Select-Object name,error|ConvertTo-Json -Depth 4;exit 1}
} $OutputDirectory $Phase $repo
