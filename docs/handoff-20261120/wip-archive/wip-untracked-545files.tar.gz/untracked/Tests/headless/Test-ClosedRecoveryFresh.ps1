param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));Import-Module (Join-Path $repo 'tools/headless/FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($out)
 Assert-RecoveryCPath $out $false;Assert-Recovery (-not [IO.Directory]::Exists($out)) 'Fresh C test output required';[void][IO.Directory]::CreateDirectory($out)
 $checks=@();$run='9c1fcbc9886641878858bb6424b6e604';$before='14a9246f0fb63d81ff2b6822503c166a2d34f7c4c16bc2b385fc746b7c968553'
 $shared=[pscustomobject]@{scope='TEST FIXTURE ONLY - no live shared capture';utc=[datetime]::UtcNow.ToString('o');beforeSha256=$before;accepted=$true;finalStateUnchanged=$true;registryChanged=$false;deltas=0;unexpected=0;engineMetadata=0;aaAfter=0;registryWrites=$false;sharedWrites=$false;releaseSucceeded=$true;disposeSucceeded=$true}
 $comparison=[pscustomobject]@{schema=1;runId=$run;accepted=$true;userPreferencesUnchanged=$true;registryChanged=$false;finalStateUnchanged=$true;engineMetadata=@();unexpected=@();deltas=@();restorationPerformed=$false}
 function Clone($value){ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $value)))}
 foreach($case in @('valid','shared-user-change','registry-user-change','missing-release','missing-dispose','wrong-before','wrong-run','restoration','missing-offset')){
  $s=Clone $shared;$c=Clone $comparison
  switch($case){'shared-user-change' {$s.deltas=1};'registry-user-change' {$c.registryChanged=$true};'missing-release' {$s.releaseSucceeded=$false};'missing-dispose' {$s.disposeSucceeded=$false};'wrong-before' {$s.beforeSha256='f'*64};'wrong-run' {$c.runId='f'*32};'restoration' {$c.restorationPerformed=$true};'missing-offset' {$s.utc='2026-11-13T00:00:00'}}
  $denied=$false;try{Assert-ClosedFreshSharedResult $s $c $run $before}catch{$denied=$true};$checks+=,[pscustomobject]@{name=$case;passed=($denied -eq ($case -cne 'valid'))}
 }
 $base=ConvertFrom-RecoveryJson ([IO.File]::ReadAllBytes((Join-Path $script:RecoveryRepo 'artifacts\aa-fr-closed-failed-recovery\tests-final\evidence-manifest.json')))
 foreach($pair in @(@('sharedResult',$shared),@('sharedComparison',$comparison))){$path=Join-Path $out ($pair[0]+'.json');Write-RecoveryCRecord $path $pair[1];$base.files+=,[pscustomobject]@{name=$pair[0];path=$path;sha256=(Get-RecoveryHash ([IO.File]::ReadAllBytes($path)))}}
 $manifest=Join-Path $out 'FIXTURE-evidence-manifest.json';Write-RecoveryCRecord $manifest $base;$sha=Get-RecoveryHash ([IO.File]::ReadAllBytes($manifest))
 $plan=Get-ClosedFailedRecoveryPlan $run $manifest $sha;$checks+=,[pscustomobject]@{name='optional-fresh-pair-enters-real-binder';passed=($plan.SharedEvidenceFreshForApply -and -not $plan.SharedRestorationAllowed -and -not $plan.ApplicationAccepted)}
 $failed=@($checks|Where-Object {-not $_.passed}).Count;$result=[pscustomobject]@{passed=($failed -eq 0);total=$checks.Count;failed=$failed;checks=$checks;fixtureOnly=$true;liveSharedCapturePerformed=$false;FReadPerformed=$false;FWritePerformed=$false;registryAccessPerformed=$false};Write-RecoveryCRecord (Join-Path $out 'result.json') $result;$result|Select-Object passed,total,failed,fixtureOnly,liveSharedCapturePerformed,FReadPerformed,FWritePerformed,registryAccessPerformed|ConvertTo-Json -Compress;if($failed){exit 1}
} $OutputDirectory
