param([Parameter(Mandatory)][string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$allowed=Join-Path $repo 'artifacts\aa-fr-capabilities-sequence-source-20261113'
if([IO.Path]::GetFullPath($OutputDirectory) -cne $OutputDirectory -or -not $OutputDirectory.StartsWith($allowed+'\',[StringComparison]::Ordinal) -or (Test-Path -LiteralPath $OutputDirectory)){throw 'Fresh scoped C review output required'}
$modulePath=Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1'
$loadedHash=(Get-FileHash -LiteralPath $modulePath).Hash.ToLowerInvariant()
$module=Import-Module $modulePath -Force -PassThru -DisableNameChecking
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$report=& $module {
 param($repo,$root,$loadedHash)
 $checks=[Collections.Generic.List[string]]::new();$details=[Collections.Generic.List[object]]::new();$primary=$null
 function Check($value,[string]$name){if(-not $value){throw ('Review negative failed: '+$name)};$checks.Add($name)}
 function New-Case([string]$name){$p=Join-Path $root $name;[void][IO.Directory]::CreateDirectory($p);return $p}
 function Occupy([string]$path){$f=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$bytes=[Text.Encoding]::UTF8.GetBytes('preexisting-review-negative');$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}}
 $sources=[ordered]@{};$rows=[Collections.Generic.List[object]]::new()
 foreach($entry in (Get-SequenceFixedRoles).GetEnumerator()){$p=$entry.Value;$row=[pscustomobject]@{role=$entry.Key;path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $p).Length};$sources[$entry.Key]=$row;$rows.Add($row)}
 $runId='ce30141e107a4d61b21d48eb7d3794a2'
 function New-PureSpec([string]$path){return [pscustomobject]@{SourceRows=$rows.ToArray();Sources=[pscustomobject]$sources;Input=[pscustomobject]@{runId=$runId};Baseline=[pscustomobject]@{};BaselineIdentity=[pscustomobject]@{};InputRecordPath=(Join-Path $path 'unused-pure-input.json');InputSha256=('1'*64);OutputRoot=$path}}
 $oldWarm=Get-Variable -Name AzuriteFreshPreflightRetainedOwners -Scope Global -ErrorAction SilentlyContinue
 try{
  $case=New-Case 'step-write';$stepPath=Join-Path $case 'Capture-sequence-step.json';Occupy $stepPath;$beforeHash=(Get-FileHash -LiteralPath $stepPath).Hash.ToLowerInvariant();$spec=New-PureSpec $case
  $seen=@{stages=[Collections.Generic.List[string]]::new()}
  $adapter={param($action,$request,$spec)
   if($action -ceq 'Observe'){return [pscustomobject]@{aaCount=0;probeCount=0}}
   $seen.stages.Add($action)
   return [pscustomobject]@{stage=$action;runId=$spec.Input.runId;childExitCode=0;stageError=$null;files=[pscustomobject]@{};raw=[pscustomobject]@{passed=$true;runId=$spec.Input.runId;leaseStillHeld=$false;cleanupErrors=@();error=$null;aaExecuted=$false;stageWrites=$false;sharedWrites=$false;registryWrites=$false}}
  }.GetNewClosure()
  $result=Invoke-SequenceCore $spec $adapter
  Check (-not $result.passed -and $result.steps.Count -eq 1 -and -not $result.steps[0].passed -and $result.steps[0].error -and $result.primaryError -and $result.runtimeAttemptCount -eq 0 -and ($seen.stages -join ',') -ceq 'Capture') 'step record write failure updates stored row and stops before Warm'
  Check ((Get-FileHash -LiteralPath $stepPath).Hash.ToLowerInvariant() -ceq $beforeHash) 'failed CreateNew preserves preexisting step evidence'
  $details.Add([pscustomobject]@{name='step-write';passed=$true;result=$result;invokedStages=$seen.stages.ToArray()})

  $case=New-Case 'first-error';Occupy (Join-Path $case 'Capture-sequence-step.json');$spec=New-PureSpec $case
  $adapter={param($action,$request,$spec)if($action -ceq 'Observe'){if($request.phase -ceq 'after'){throw 'injected-secondary-observation'};return [pscustomobject]@{aaCount=0;probeCount=0}};throw 'injected-primary-stage-failure'}
  $result=Invoke-SequenceCore $spec $adapter
  Check (-not $result.passed -and $result.primaryError -like '*injected-primary-stage-failure*' -and $result.primaryError -notlike '*injected-secondary-observation*' -and $result.steps.Count -eq 1 -and -not $result.steps[0].passed -and $result.steps[0].error -like '*injected-primary-stage-failure*' -and $result.secondaryErrors.Count -eq 2 -and $result.runtimeAttemptCount -eq 0) 'stage first cause survives observation and step-record failures'
  $details.Add([pscustomobject]@{name='first-error';passed=$true;result=$result})

  $case=New-Case 'retained-journal';Occupy (Join-Path $case 'Warm-child-ownership.json');$spec=New-PureSpec $case
  $state=[pscustomobject]@{retained=$true;retainedReferenceConfirmed=$true;primaryError='injected-child-exit-unknown';exitCode=$null}
  $refusal=$null;$flag=$false
  try{$null=Complete-SequenceTransportResult $state ([pscustomobject]@{stage='Warm';runId=$runId}) $spec (Join-Path $case 'unused-reply.json')}catch{$refusal=$_.Exception.ToString();$flag=[bool]$_.Exception.Data['OwnerRetained']}
  Check ($flag -and $refusal -like '*injected-child-exit-unknown*' -and $state.retained -and -not(Test-Path -LiteralPath (Join-Path $case 'unused-reply.json'))) 'retained owner marker survives ownership-record write failure'
  $details.Add([pscustomobject]@{name='retained-journal';passed=$true;refusal=$refusal;ownerRetainedMarker=$flag;state=$state})

  foreach($failure in @('reply','marker')){
   $case=New-Case ('nested-'+$failure);$reply=Join-Path $case 'reply.json';$packet=[pscustomobject]@{controllerHeldForRoot=$true;stage='Warm';runId=$runId};$holdState=@{count=0};$hold={param($packet,$path)$holdState.count++}.GetNewClosure()
   if($failure -ceq 'reply'){Occupy $reply}else{Occupy ($reply+'.retained')}
   $refusal=$null;try{$null=Complete-SequenceChildPacket $packet $reply $hold}catch{$refusal=$_.Exception.ToString()}
   Check ($holdState.count -eq 1 -and $refusal -and (Test-Path -LiteralPath ($reply+'.retained')) -and -not(Test-Path -LiteralPath ($reply+'.ready'))) ('nested hold executes despite '+$failure+' persistence failure')
   $details.Add([pscustomobject]@{name=('nested-'+$failure);passed=$true;holdCalls=$holdState.count;refusal=$refusal;realRetainedHostCreated=$false})
  }

  $global:AzuriteFreshPreflightRetainedOwners=[Collections.Generic.List[object]]::new();$global:AzuriteFreshPreflightRetainedOwners.Add([pscustomobject]@{pureFakeReference=$true})
  Check (Test-SequenceInnerOwnership 'Warm' $null $true) 'actual global retained collection dominates missing raw packet'
  $global:AzuriteFreshPreflightRetainedOwners.Clear()
  foreach($stage in @('Capture','Warm','Apply','Runtime')){Check (Test-SequenceInnerOwnership $stage $null $true) ($stage+' unknown leaf failure requires retention')}
  Check (-not(Test-SequenceInnerOwnership 'Capture' ([pscustomobject]@{leaseStillHeld=$false}) $false)) 'verified released leaf does not fabricate retention'
 }catch{$primary=$_.Exception.ToString()}
 finally{if($oldWarm){Set-Variable -Name AzuriteFreshPreflightRetainedOwners -Scope Global -Value $oldWarm.Value}else{Remove-Variable -Name AzuriteFreshPreflightRetainedOwners -Scope Global -ErrorAction SilentlyContinue}}
 [pscustomobject]@{schema=1;scope='C-only pure sequence review negatives';passed=($null -eq $primary);primaryError=$primary;checks=$checks.Count;checkNames=$checks.ToArray();cases=$details.ToArray();loadedModuleSha256=$loadedHash;moduleSha256After=(Get-FileHash -LiteralPath (Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1')).Hash.ToLowerInvariant();realProcessStarted=$false;producerInvoked=$false;nativeHelperLoaded=$false;FReadPerformed=$false;FWritePerformed=$false;registryAccessPerformed=$false;aaLaunched=$false;testFunctionMockingUsed=$false}
} $repo $OutputDirectory $loadedHash
$path=Join-Path $OutputDirectory 'review-negatives.json';$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($report|ConvertTo-Json -Depth 35 -Compress));$stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
$report|Select-Object passed,checks,primaryError,loadedModuleSha256,moduleSha256After,realProcessStarted,producerInvoked,FReadPerformed,registryAccessPerformed|ConvertTo-Json -Compress
if(-not $report.passed){exit 1}
