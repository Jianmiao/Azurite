using System;using System.Collections.Generic;using System.Reflection;using System.Web.Script.Serialization;using Azurite.Restricted;
internal static class PreservedQueriesTests {
 static int checks;static readonly List<string> failures=new List<string>();
 static void Expect(string method,object[] args,bool accepted,string label){bool got=true;try{typeof(FullRestrictedToken).GetMethod(method,BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,args);}catch(TargetInvocationException){got=false;}checks++;if(got!=accepted)failures.Add(label);}
 static int Main(){
  Expect("ValidateVariableProbe",new object[]{25,false,122,28u},true,"legitimate FALSE insufficient-buffer size survives");
  Expect("ValidateVariableProbe",new object[]{1,false,122,65536u},true,"bounded variable size survives");
  Expect("ValidateVariableProbe",new object[]{25,false,5,28u},false,"other FALSE errors are not size proof");
  Expect("ValidateVariableProbe",new object[]{25,true,0,28u},false,"unexpected successful null-buffer probe rejected");
  Expect("ValidateVariableProbe",new object[]{25,false,122,0u},false,"empty size rejected");
  Expect("ValidateVariableProbe",new object[]{25,false,122,65537u},false,"unbounded size rejected");
  Expect("ValidateScalarRead",new object[]{27,true,0,4u},true,"exact successful scalar unchanged");
  Expect("ValidateScalarRead",new object[]{27,false,122,4u},false,"scalar failure not reclassified as size query");
  Console.WriteLine(new JavaScriptSerializer().Serialize(new{scope="same unchanged production query validators only",checks,passed=failures.Count==0,failures=failures.ToArray(),nativeAcquisitionInvoked=false,registryAccessed=false,AAOrCdbExecuted=false}));return failures.Count==0?0:1;
 }
}
