param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
Import-Module (Join-Path $repo 'tools\headless\FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
& (Get-Module FullRestrictedPreparationRecovery) {
 param($resultPath)
 $fixed=Get-RecoveryTokenPins
 $bytes=Read-RecoveryPinnedC $fixed['RestrictedCliNative.dll'].path $fixed['RestrictedCliNative.dll'].sha256
 Initialize-RecoveryTokenReader $bytes
 $actual=Get-RecoveryIdentity
 Assert-Recovery ($actual.ownerSid -ceq 'S-1-5-21-222280291-4039000738-1914192245-1001' -and $actual.logonSid -ceq 'S-1-5-5-0-4392691' -and $actual.unelevated -and $actual.tokenType -eq 1 -and -not $actual.isRestricted -and -not $actual.isAppContainer) 'Exact current unelevated original token does not match accepted preparation'
 Write-RecoveryCRecord $resultPath ([pscustomobject]@{passed=$true;identity=$actual;readerSha256=$fixed['RestrictedCliNative.dll'].sha256;registryAccessPerformed=$false;processCreated=$false;FReadPerformed=$false;FWritePerformed=$false})
 [pscustomobject]@{passed=$true;identity=$actual;resultPath=$resultPath}
} $ResultPath
