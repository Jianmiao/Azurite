param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$m=Import-Module (Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1') -Force -PassThru -DisableNameChecking
$result=& $m {
 param($repo)
 $tests=[Collections.Generic.List[string]]::new();function Check($v,[string]$n){if(-not $v){throw ('ASSERT '+$n)};$tests.Add($n)}
 $sources=@{};$rows=@(foreach($e in (Get-SequenceFixedRoles).GetEnumerator()){$p=$e.Value;$row=[pscustomobject]@{role=$e.Key;path=$p;bytes=(Get-Item $p).Length;sha256=(Get-FileHash $p).Hash.ToLowerInvariant()};$sources[$e.Key]=$row;$row})
 $base=Join-Path $repo ('artifacts\aa-fr-capabilities-sequence-source-20261113\core-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($base)
 $run='a'*32;$inputRecord=[pscustomobject]@{runId=$run;intentValidUntilUtc='2030-01-01T02:00:00Z';runtimeTimeoutSeconds=120;sourcesSha256=('1'*64)}
 $spec=[pscustomobject]@{SourceRows=$rows;Sources=[pscustomobject]$sources;Input=$inputRecord;Baseline=[pscustomobject]@{};BaselineIdentity=[pscustomobject]@{path='synthetic';sha256=('2'*64)};OutputRoot=$null;InputRecordPath='synthetic';InputSha256=('3'*64)}
 function Packet([string]$stage,[string]$runId){
  $raw=switch($stage){
   Capture {[pscustomobject]@{passed=$true;runId=$runId;leaseStillHeld=$false;cleanupErrors=@();error=$null;aaExecuted=$false;stageWrites=$false;sharedWrites=$false;registryWrites=$false}}
   Warm {[pscustomobject]@{passed=$true;runId=$runId;primaryError=$null;cleanupErrors=@();leaseStillHeld=$false;ownedReader=[pscustomobject]@{exitConfirmed=$true;streamsCompleted=$true;processDisposed=$true;mutexDisposed=$true;retained=$false}}}
   Assemble {[pscustomobject]@{inputReady=$true;runId=$runId;approvalPresent=$false;willApply=$false;willLaunch=$false;runtimeAllowed=$false;sourceManifestSha256=$script:FixturePin.sha256;controlSha256=$script:FixturePin.sha256;gateSha256=$script:FixturePin.sha256}}
   Approval {[pscustomobject][ordered]@{schema=1;decision='approved-one-capabilities-run';scope='current-account-full-restricted-capabilities-only';runId=$runId;planSha256=('4'*64);contractSha256=('5'*64);ownerSid='S-1-5-21-1';volumeGuid='volume';labRoot='lab';executable='exe';toolingManifestSha256=('6'*64);controlGateSha256=$script:FixturePin.sha256;validFromUtc='2030-01-01T00:00:00Z';issuedUtc='2030-01-01T00:00:01Z';validUntilUtc='2030-01-01T02:00:00Z'}}
   PreparePlan {[pscustomobject]@{mode='planning-only';runId=$runId;approvalPresent=$true;existingObjects=1228;aclTargets=1252;willMutate=$false;willLaunch=$false;runtimeAllowed=$false}}
   Apply {[pscustomobject]@{Success=$true;Prepared=$true;SealRestored=$true;LeaseState='released';Quarantined=$false;Error=$null;RuntimeAllowed=$false;WillLaunch=$false}}
   Projection {[pscustomobject]@{Ready=$true;runId=$runId;approvalSha256=$script:FixturePin.sha256;PreparationLeaseReleased=$true;RequiresFreshRuntimeLease=$true}}
   RuntimePlan {[pscustomobject]@{Ready=$true;RunId=$runId;Failures=@()}}
   Runtime {[pscustomobject]@{passed=$true;runId=$runId;runtimeLeaseReleased=$true;runtimeMutexDisposed=$true;leaseHeld=$false;ownerRetained=$false;pendingCleared=$true;result=[pscustomobject]@{passed=$true;outer=[pscustomobject]@{CleanupVerified=$true};zeroSharedDelta=$true}}}
  }
  [pscustomobject]@{stage=$stage;runId=$runId;childExitCode=0;stageError=$null;raw=$raw;files=[pscustomobject]@{SourceManifest=$script:FixturePin;Control=$script:FixturePin;Gate=$script:FixturePin;Approval=$script:FixturePin}}
 }
 $script:FixturePin=Write-SequenceJson (Join-Path $base 'synthetic-data.json') ([ordered]@{evidenceClass='synthetic-core-only';notProduction=$true})
 $packetFunction=${function:Packet}
 foreach($case in @('success')+@($script:SequenceStages)){
  $dir=Join-Path $base ('case-'+$case);[void][IO.Directory]::CreateDirectory($dir);$spec.OutputRoot=$dir;$calls=[Collections.Generic.List[string]]::new();$fail=$case
  $adapter={param($stage,$request,$s)if($stage -ceq 'Observe'){return [pscustomobject]@{aaCount=0;probeCount=0;synthetic=$true}};$calls.Add($stage);if($stage -ceq $fail){throw ('injected-'+$stage)};& $packetFunction $stage $s.Input.runId}.GetNewClosure()
  $r=Invoke-SequenceCore $spec $adapter
  if($case -ceq 'success'){Check ($r.passed -and $calls.Count -eq 9 -and $r.runtimeAttemptCount -eq 1 -and ($calls -join ',') -ceq ($script:SequenceStages -join ',')) 'synthetic core follows exactly nine stages and one runtime'}else{$index=[Array]::IndexOf($script:SequenceStages,$case);Check (-not $r.passed -and $calls.Count -eq ($index+1) -and $r.primaryError -like ('*injected-'+$case+'*') -and $r.steps[-1].passed -eq $false) ('failure stops at '+$case);Check ($r.runtimeAttemptCount -eq $(if($case -ceq 'Runtime'){1}else{0})) ('no later runtime after '+$case)}
 }
 $dir=Join-Path $base 'nonzero-exit';[void][IO.Directory]::CreateDirectory($dir);$spec.OutputRoot=$dir;$calls=[Collections.Generic.List[string]]::new()
 $adapter={param($stage,$request,$s)if($stage -ceq 'Observe'){return [pscustomobject]@{aaCount=0;probeCount=0}};$calls.Add($stage);$p=& $packetFunction $stage $s.Input.runId;$p.childExitCode=7;return $p}.GetNewClosure()
 $r=Invoke-SequenceCore $spec $adapter;Check (-not $r.passed -and $calls.Count -eq 1 -and $r.runtimeAttemptCount -eq 0) 'nonzero child exit stops despite success-shaped payload'
 $dir=Join-Path $base 'typed-refusal';[void][IO.Directory]::CreateDirectory($dir);$spec.OutputRoot=$dir;$calls=[Collections.Generic.List[string]]::new()
 $adapter={param($stage,$request,$s)if($stage -ceq 'Observe'){return [pscustomobject]@{aaCount=0;probeCount=0}};$calls.Add($stage);$p=& $packetFunction $stage $s.Input.runId;if($stage -ceq 'Assemble'){$p.raw.inputReady=$false};return $p}.GetNewClosure()
 $r=Invoke-SequenceCore $spec $adapter;Check (-not $r.passed -and $calls.Count -eq 3 -and $r.runtimeAttemptCount -eq 0) 'exit-zero assembler refusal prevents approval and Apply'
 $p=[pscustomobject]@{RunId=$run;PlanSha256=('4'*64);ContractSha256=('5'*64);LabRoot='lab';Executable='exe'};$f=[pscustomobject]@{ownerSid='sid';volumeGuid='volume';preTransition=[pscustomobject]@{observedUtc='2030-01-01T00:00:01Z'}};$a=New-SequenceApproval $p $f ('7'*64) ('8'*64) '2030-01-01T00:01:00Z' ([DateTimeOffset]::Parse('2030-01-01T00:00:02.321Z'))
 Check (@($a.PSObject.Properties).Count -eq 15 -and $a.validFromUtc -ceq $f.preTransition.observedUtc -and $a.issuedUtc -ceq '2030-01-01T00:00:02Z') 'approval preserves observed time and uses actual issuance argument'
 $rejected=$false;try{$null=New-SequenceApproval $p $f ('7'*64) ('8'*64) '2030-01-01T00:00:02Z' ([DateTimeOffset]::Parse('2030-01-01T00:00:03Z'))}catch{$rejected=$true};Check $rejected 'expired approval issuance rejected without time rewrite'
 [ordered]@{scope='synthetic fixed sequence core and issuance tests only';passed=$true;checks=$tests.Count;tests=$tests.ToArray();root=$base;actualProcessStarted=$false;actualProducerInvoked=$false;stageRead=$false;registryAccess=$false;moduleSha256=(Get-FileHash (Join-Path $repo 'tools\headless\AzuriteCapabilitiesSequence.psm1')).Hash.ToLowerInvariant()}
} $repo
if(Test-Path -LiteralPath $ResultPath){throw 'Result must be fresh'};[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 15),[Text.UTF8Encoding]::new($false));$result|ConvertTo-Json -Depth 6
