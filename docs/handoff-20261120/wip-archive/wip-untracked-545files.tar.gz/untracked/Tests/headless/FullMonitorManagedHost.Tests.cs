using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.Script.Serialization;
using Azurite.Restricted;

public static class FullMonitorManagedHostTests {
 const string Name="AzuriteFullCli_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
 static readonly IntPtr Handle=new IntPtr(1234);
 static readonly List<string> checks=new List<string>();
 static void Check(bool value,string name){if(!value)throw new InvalidOperationException(name);checks.Add(name);}
 static bool Refused(Action action){try{action();return false;}catch{return true;}}
 static Dictionary<string,object> Row(string name){string hash=name=="user32.dll"?"4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91":"ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4";long rva=name=="user32.dll"?0x2a9a0:0x1610;return FullDesktopImagePolicy.Describe(name,@"C:\Windows\System32\"+name,@"C:\Windows\System32\"+name,hash,hash,"10.0.26100.9818","10.0.26100.9818",rva,rva,false,"raw localized version","raw product","observed language");}
 sealed class Fake:IFullDesktopMonitorApi {
  internal bool Normal,Visible,Foreground,FailPin,FailForeground;internal int Error,Callbacks,JsonCalls,RecordCalls,ListCalls,IdentityCalls;internal uint Needed=1,Capacity=64;internal long First=1;internal bool Guards=true,Tail=true;internal Dictionary<string,object>[] Rows=new[]{Row("user32.dll"),Row("win32u.dll")};
  public FullDesktopEnumeration Enumerate(IntPtr h,int[] ids){return new FullDesktopEnumeration{Returned=Normal,Error=Error,Callbacks=Callbacks,Visible=Visible};}
  public FullDesktopIdentity ReadIdentity(IntPtr h){IdentityCalls++;return new FullDesktopIdentity{Handle=h.ToInt64(),Name=Name,Type="Desktop",Owner="user",CurrentOwner="user",RightsQueryStatus=0,GrantedAccess=0xf01ff,Inherited=false};}
  public string RequirePinnedImages(){foreach(var row in Rows)FullDesktopImagePolicy.Validate(row);if(FailPin)throw new InvalidOperationException("original pin failure");return "same-reviewed-pin-identity";}
  public string ImagePinEvidenceJson(){JsonCalls++;throw new InvalidOperationException("Monitor must not call JSON evidence transport");}
  public object[] ImagePinEvidence(){RecordCalls++;return new object[]{new Dictionary<string,object>(Rows[0]),new Dictionary<string,object>(Rows[1])};}
  public FullDesktopEmptyList ReadEmptyList(IntPtr h){ListCalls++;return new FullDesktopEmptyList{Status=0,LastError=0,Capacity=Capacity,Needed=Needed,First=First,GuardsIntact=Guards,TailIntact=Tail};}
  public bool ForegroundOwned(int[] ids){if(FailForeground)throw new InvalidOperationException("foreground query failure");return Foreground;}
 }
 public static Dictionary<string,object> Run(){
  checks.Clear();var empty=new Fake();var session=new FullDesktopMonitorSession();Check(!FullDesktopMonitor.Run(empty,Handle,new[]{7},Name,session),"production empty path returns no violation");var observed=session.Snapshot();var first=(Dictionary<string,object>)observed["first"];var pins=first["imagePins"] as object[];
  Check(empty.JsonCalls==0&&empty.RecordCalls==1&&empty.ListCalls==1&&empty.IdentityCalls==2,"empty path uses structured evidence with original monitor sequence");
  Check(pins!=null&&pins.Length==2&&((Dictionary<string,object>)pins[0])["name"].Equals("user32.dll")&&((Dictionary<string,object>)pins[1])["name"].Equals("win32u.dll"),"exact bare two-row image array preserved");
  Check(Convert.ToInt64(observed["emptyCount"])==1&&Convert.ToInt64(observed["failedCount"])==0&&first["usedPath"].Equals("pinned-empty"),"successful empty monitor evidence remains qualified");
  var normal=new Fake{Normal=true};var normalSession=new FullDesktopMonitorSession();Check(!FullDesktopMonitor.Run(normal,Handle,new[]{7},Name,normalSession)&&normal.JsonCalls==0&&normal.RecordCalls==0&&normal.ListCalls==0,"normal path never requests image fallback evidence");
  Check(FullDesktopMonitor.Run(new Fake{Normal=true,Visible=true},Handle,new[]{7},Name),"visible window remains violation");
  Check(FullDesktopMonitor.Run(new Fake{Foreground=true},Handle,new[]{7},Name),"foreground owned remains violation");
  foreach(string fault in new[]{"error","callback","list-count","list-sentinel","list-capacity","list-guard","list-tail","pin","foreground"}){
   var fake=new Fake();switch(fault){case "error":fake.Error=6;break;case "callback":fake.Callbacks=1;break;case "list-count":fake.Needed=2;break;case "list-sentinel":fake.First=0;break;case "list-capacity":fake.Capacity=1;break;case "list-guard":fake.Guards=false;break;case "list-tail":fake.Tail=false;break;case "pin":fake.FailPin=true;break;case "foreground":fake.FailForeground=true;break;}
   var state=new FullDesktopMonitorSession();Check(Refused(()=>FullDesktopMonitor.Run(fake,Handle,new[]{7},Name,state)),"production rejects "+fault);Check(Convert.ToInt64(state.Snapshot()["failedCount"])==1&&fake.JsonCalls==0,"failed observation preserved without JSON "+fault);
   if(fault=="pin")Check(((Dictionary<string,object>)state.Snapshot()["last"]).ContainsKey("imagePins")&&fake.ListCalls==0,"pin failure keeps available structured records and never calls list");
  }
  foreach(string field in new[]{"pathMatch","hashMatch","fixedVersionMatch","exportMatch","nonReparseMatch"}){var fake=new Fake();fake.Rows[0][field]=false;Check(Refused(()=>FullDesktopMonitor.Run(fake,Handle,new[]{7},Name)),"unchanged image-policy refusal "+field);Check(fake.ListCalls==0,"image-policy refusal precedes list "+field);}
  // Exercise the real native adapter's managed evidence accessors without any
  // native query. Save and restore the private cache in this fresh test process.
  var nativeType=typeof(NativeFullDesktopMonitor);var cache=nativeType.GetField("pinEvidenceRecords",BindingFlags.NonPublic|BindingFlags.Static);Check(cache!=null,"production structured image cache exists");
  var old=cache.GetValue(null);var oldJson=nativeType.GetField("pinEvidenceJson",BindingFlags.NonPublic|BindingFlags.Static).GetValue(null);
  try{var values=new object[]{Row("user32.dll"),Row("win32u.dll")};cache.SetValue(null,values);var api=new NativeFullDesktopMonitor();var method=nativeType.GetMethod("ImagePinEvidence",BindingFlags.Public|BindingFlags.Instance);var a=(object[])method.Invoke(api,null);((Dictionary<string,object>)a[0])["hashMatch"]=false;a[1]=null;var b=(object[])method.Invoke(api,null);Check((bool)((Dictionary<string,object>)b[0])["hashMatch"]&&b[1]!=null,"real evidence accessor returns independent row snapshots");var json=new JavaScriptSerializer().Serialize(values);nativeType.GetField("pinEvidenceJson",BindingFlags.NonPublic|BindingFlags.Static).SetValue(null,json);Check(api.ImagePinEvidenceJson()==json,"existing JSON accessor preserves same schema bytes");}
  finally{cache.SetValue(null,old);nativeType.GetField("pinEvidenceJson",BindingFlags.NonPublic|BindingFlags.Static).SetValue(null,oldJson);}
  return new Dictionary<string,object>{{"passed",true},{"checks",checks.Count},{"tests",checks.ToArray()},{"imagePins",pins},{"monitor",observed},{"nativeApisCalled",false},{"productionMonitorRun",true}};
 }
}
