param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$root=Join-Path $repo 'artifacts\aa-fr-monitor-managed-host-diagnosis-20261113'
$ResultPath=[IO.Path]::GetFullPath($ResultPath)
if(-not $ResultPath.StartsWith($root+'\',[StringComparison]::Ordinal) -or [IO.File]::Exists($ResultPath)){throw 'Fresh C diagnosis output required'}
$nativePath=Join-Path $repo '.superpowers\sdd\azurite-authoring-20261108\aa-fr-ftarget-hashcase-build-20261113\tooling\RestrictedCliNative.dll'
$webPath=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll'
function Hash([string]$p){$s=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($s.ComputeHash([IO.File]::ReadAllBytes($p)))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
if((Hash $nativePath) -cne '89b6047da7d698fb3f18d1e3abe2a369584bd165723aff9bc1f30b57fadd9b96' -or (Hash $webPath) -cne '6f2545e5ba378f6836ea0fed1067d089181e27dbd3c81e9db418c8bb32e6af51'){throw 'Exact existing native or referenced serializer bytes differ'}
$native=[Reflection.Assembly]::LoadFrom($nativePath)
$web=[Reflection.Assembly]::LoadFrom($webPath)
$type=$web.GetType('System.Web.Script.Serialization.JavaScriptSerializer',$true)
$json=[Activator]::CreateInstance($type)
$serialize=$type.GetMethod('Serialize',[type[]]@([object]));$deserialize=$type.GetMethod('DeserializeObject',[type[]]@([string]))
$describe=$native.GetType('Azurite.Restricted.FullDesktopImagePolicy',$true).GetMethod('Describe',[Reflection.BindingFlags]'NonPublic,Static')
$validate=@($native.GetType('Azurite.Restricted.FullDesktopImagePolicy',$true).GetMethods([Reflection.BindingFlags]'NonPublic,Static')|Where-Object {$_.Name -ceq 'Validate' -and $_.GetParameters().Count -eq 1})[0]
$rows=[Collections.Generic.List[Collections.Generic.Dictionary[string,object]]]::new()
foreach($name in @('user32.dll','win32u.dll')){
 $h=if($name -ceq 'user32.dll'){'4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91'}else{'ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4'}
 $rva=if($name -ceq 'user32.dll'){0x2a9a0L}else{0x1610L};$p='C:\Windows\System32\'+$name
 # Managed Describe only constructs a Dictionary. No image read, DLL export,
 # desktop, token, process monitor or other native method is called.
 $row=$describe.Invoke($null,[object[]]@($name,$p,$p,$h,$h,'10.0.26100.9818','10.0.26100.9818',$rva,$rva,$false,'10.0.26100.9818','10.0.26100.9818','English (United States)'))
 $rows.Add($row)
}
$tests=[Collections.Generic.List[object]]::new()
function Attempt([string]$name,[scriptblock]$body){$ok=$false;$value=$null;$errorInfo=$null;try{$value=& $body;$ok=$true}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};$errorInfo=[ordered]@{type=$e.GetType().FullName;message=$e.Message;stack=$e.StackTrace}};$tests.Add([pscustomobject]@{name=$name;success=$ok;value=$value;error=$errorInfo})}
$script:SerializedImageRows=$null
Attempt 'real-Describe-and-Serialize-image-records' {$script:SerializedImageRows=$serialize.Invoke($json,[object[]]@(,$rows));[pscustomobject]@{json=$script:SerializedImageRows;bytes=[Text.Encoding]::UTF8.GetByteCount($script:SerializedImageRows)}}
$serialized=$script:SerializedImageRows
if($null -eq $serialized){$serialized='[{"name":"user32.dll","path":"C:\\Windows\\System32\\user32.dll","sha256":"4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91","hashMatch":true},{"name":"win32u.dll","hashMatch":true}]'}
Attempt 'actual-Framework-DeserializeObject-image-records' {$value=$deserialize.Invoke($json,[object[]]@($serialized));[pscustomobject]@{type=$value.GetType().FullName;count=@($value).Count;firstName=$value[0]['name']}}
Attempt 'DeserializeObject-minimal-string-key' {$value=$deserialize.Invoke($json,[object[]]@('{"name":"user32.dll"}'));[pscustomobject]@{type=$value.GetType().FullName;name=$value['name']}}
Attempt 'DeserializeObject-number-only-array' {$value=$deserialize.Invoke($json,[object[]]@('[1,2]'));[pscustomobject]@{type=$value.GetType().FullName;count=@($value).Count}}
Attempt 'real-ImagePolicy-Validate-success-managed-only' {$null=$validate.Invoke($null,[object[]]@(,$rows[0]));'accepted'}
Attempt 'real-ImagePolicy-Validate-mismatch-managed-only' {$bad=[Collections.Generic.Dictionary[string,object]]::new($rows[0]);$bad['hashMatch']=$false;$null=$validate.Invoke($null,[object[]]@(,$bad));'unexpected acceptance'}
Attempt 'Serialize-full-monitor-like-nested-graph' {$graph=[ordered]@{normalCount=0L;emptyCount=1L;failedCount=0L;first=[ordered]@{imagePins=$rows.ToArray();identity=[ordered]@{handle=123L;name='AzuriteFullCli_'+('a'*32);grantedAccess=983551;inherited=$false};usedPath='pinned-empty'};boundedStoredObservations=1};$text=$serialize.Invoke($json,[object[]]@(,$graph));[pscustomobject]@{length=$text.Length;json=$text}}
$webAssembly=[Reflection.Assembly]::Load('System.Web, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
$record=[ordered]@{schema=1;scope='same-existing-DLL managed serializer host diagnosis only';host=$PSVersionTable.PSVersion.ToString();framework=[Runtime.InteropServices.RuntimeInformation]::FrameworkDescription;nativePath=$nativePath;nativeSha256=(Hash $nativePath);nativeLoadedLocation=$native.Location;serializerPath=$webPath;serializerSha256=(Hash $webPath);serializerLoadedLocation=$type.Assembly.Location;systemWebLoadedLocation=$webAssembly.Location;utf16StringValidatorPresent=($null -ne $webAssembly.GetType('System.Web.Util.Utf16StringValidator',$false));imageJsonLiteralFallback=($null -eq $script:SerializedImageRows);tests=$tests.ToArray();nativeMethodsInvoked=$false;desktopApisInvoked=$false;tokenApisInvoked=$false;monitorRunInvoked=$false;sourceChanged=$false;FRead=$false;AAStarted=$false;testScriptSha256=(Hash $PSCommandPath)}
[IO.File]::WriteAllText($ResultPath,($record|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{host=$record.host;framework=$record.framework;utf16StringValidatorPresent=$record.utf16StringValidatorPresent;tests=@($tests|Select-Object name,success,@{n='errorType';e={if($_.error){$_.error.type}}});resultPath=$ResultPath}|ConvertTo-Json -Depth 8
