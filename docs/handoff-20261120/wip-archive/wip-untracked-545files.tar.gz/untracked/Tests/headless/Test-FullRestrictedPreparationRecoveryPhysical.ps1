param([Parameter(Mandatory)][string]$HelperAssemblyPath,[Parameter(Mandatory)][string]$ExpectedHelperSha256,[Parameter(Mandatory)][string]$OutputDirectory,[switch]$PostNativeFixture,[switch]$ClosedFailedFixture)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
Import-Module (Join-Path $repo 'tools\headless\FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
$module=Get-Module FullRestrictedPreparationRecovery
& $module {
 param($dll,$hash,$output,$postNative,$closedFailed)
 Assert-Recovery (-not ($postNative -and $closedFailed)) 'Fixture modes are mutually exclusive'
 Assert-RecoveryCPath $output $false;Assert-Recovery (-not [IO.Directory]::Exists($output)) 'Test requires fresh C output'
 $binary=Read-RecoveryPinnedC $dll $hash;[void][Reflection.Assembly]::Load([byte[]]$binary)
 Assert-Recovery ($null -ne [Azurite.Stage.FileSecurity].GetMethod('ArchiveFile')) 'Archive primitive unavailable'
 $token=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$token.User.Value}finally{$token.Dispose()};$logon='S-1-5-5-1-2' # Deliberately synthetic ACL principal; not a token-admission test.
 [void][IO.Directory]::CreateDirectory($output);$root=Join-Path $output 'target';$evidence=Join-Path $output 'evidence';[void][IO.Directory]::CreateDirectory($evidence);$archive=Join-Path $evidence 'archive';[void][IO.Directory]::CreateDirectory($archive)
 $base='O:'+ $sid+'G:'+ $sid+'D:P(A;OICI;FA;;;'+$sid+')(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)'
 $dirs=@($root,($root+'\install'),($root+'\install\child'))
 foreach($p in $dirs){[Azurite.Stage.FileSecurity]::NewDirectory($p,$base)}
 $loader=$dirs[-1]+'\loader.log';[IO.File]::WriteAllBytes($loader,[Text.Encoding]::UTF8.GetBytes('C owned original loader payload'))
 $original=@(foreach($p in $dirs+@($loader)){[Azurite.Stage.FileSecurity]::Read($p,($p -ceq $loader))})
 $originalFile=$original[-1];$originalSd=[Security.AccessControl.RawSecurityDescriptor]::new($originalFile.sddl)
 Assert-Recovery (-not ($originalSd.ControlFlags -band [Security.AccessControl.ControlFlags]::DiscretionaryAclProtected) -and @($originalSd.DiscretionaryAcl|Where-Object{($_.AceFlags -band [Security.AccessControl.AceFlags]::Inherited) -ne 0}).Count -eq 3) 'Fixture must use real unprotected inherited file DACL'
 foreach($o in $original){$grant=if($o.directory){$base+'(A;;FR;;;'+$logon+')'}else{'O:'+ $sid+'G:'+ $sid+'D:P(A;;FA;;;'+$sid+')(A;;FA;;;SY)(A;;FA;;;BA)(A;;FR;;;'+$logon+')'};[Azurite.Stage.FileSecurity]::SetDescriptor($o.path,$o.identity,$o.sddl,$grant)}
 $current=[Azurite.Stage.FileSecurity]::Read($loader,$false);[Azurite.Stage.FileSecurity]::WriteExisting($loader,$current.identity,$current.sddl,$current.sha256,[byte[]]@())
 # Prove the real guard permits WRITE_DAC but denies payload write and rename.
 $current=[Azurite.Stage.FileSecurity]::Read($loader,$false);$guard=[IO.FileStream]::new($loader,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
 try{
  $writeBlocked=$false;try{$w=[IO.FileStream]::new($loader,[IO.FileMode]::Open,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite);$w.Dispose()}catch{$writeBlocked=$true};Assert-Recovery $writeBlocked 'Read guard failed to block data writes'
  $renameBlocked=$false;try{[IO.File]::Move($loader,$loader+'.moved')}catch{$renameBlocked=$true};Assert-Recovery $renameBlocked 'Read guard failed to block replacement/rename'
  [Azurite.Stage.FileSecurity]::SetDescriptor($loader,$current.identity,$current.sddl,$current.sddl)
 }finally{$guard.Dispose()}
 $runs=$root+'\runs';$run=$runs+'\restricted-r';$newDirs=@($runs,$run,($run+'\data'));foreach($p in $newDirs){[Azurite.Stage.FileSecurity]::NewDirectory($p,$base)}
 $pending=$runs+'\full-capabilities.pending.json';$planHash='b'*64;$record=[pscustomobject][ordered]@{schema=1;scope='full-capabilities-global-pending';runId='r';planSha256=$planHash;controllerSid=$sid;runDirectory=$run;state='prepared-awaiting-runtime-lease'}
 if($postNative -or $closedFailed){$record.state='runtime-pending'}
 [IO.File]::WriteAllBytes($pending,[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-RecoveryJson $record)))
 $snapshotBytes=if($closedFailed){65537L}else{38561944L};$snapshot=$run+'\data\snapshot.json';$f=[IO.FileStream]::new($snapshot,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$f.SetLength($snapshotBytes);$f.Flush($true)}finally{$f.Dispose()}
 $created=@(foreach($p in $newDirs+@($pending,$snapshot)){[Azurite.Stage.FileSecurity]::Read($p,$false)})
 $prepared=@(foreach($p in $dirs+@($loader)+$newDirs+@($pending,$snapshot)){[Azurite.Stage.FileSecurity]::Read($p,$false)})
 $spec=[pscustomobject]@{Schema=1;RunId='r';PlanSha256=$planHash;Root=$root;OwnerSid=$sid;LogonSid=$logon;Volume=$original[0].volume;PendingPath=$pending;RunsPath=$runs;Original=$original;Prepared=$prepared;Created=$created;PayloadRestores=@($originalFile);DescriptorRestores=$original;InventoryExceptions=@{};Bindings=@{fixture='C-owned-only'}}
 if($postNative){$spec|Add-Member Scope 'post-native-cleanup-recovery';$spec|Add-Member ExpectedPendingState 'runtime-pending'}
 if($closedFailed){$spec|Add-Member Scope 'closed-failed-runtime-recovery';$spec|Add-Member ExpectedPendingState 'runtime-pending';$spec|Add-Member OriginalRuntimeCleanupVerified $true;$spec|Add-Member AaCreationStatus 'proven';$spec|Add-Member ApplicationAccepted $false}
 $state=@{Spec=$spec;RecoveryId=[guid]::NewGuid().ToString('N');EvidenceDirectory=$evidence;ArchiveDirectory=$archive;Mutex=$null;Locks=@{};Held=$false;JournalStream=[IO.FileStream]::new((Join-Path $evidence 'journal.jsonl'),[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read);Physical=(New-RecoveryPhysicalBackend)}
 $backend={param($action,$a,$s)
  if($action -ceq 'Acquire'){$s.Mutex=[Threading.Mutex]::new($false,('Local\AzuriteRecoveryFixture-'+$s.RecoveryId));Assert-Recovery ($s.Mutex.WaitOne(0)) 'Test lease unavailable';$s.Held=$true;return [pscustomobject]@{ownerSid=$s.Spec.OwnerSid;logonSid=$s.Spec.LogonSid;volume=$s.Spec.Volume}}
  if($action -ceq 'ValidateEnvironment'){return [pscustomobject]@{aaCount=0;probeCount=0;ownerSid=$s.Spec.OwnerSid;logonSid=$s.Spec.LogonSid;unelevated=$true;scope='fixture-no-process-query'}}
  & $s.Physical $action $a $s
 }
 try{$result=Invoke-RecoveryCoordinator $spec $backend $state}finally{if($state.JournalStream){$state.JournalStream.Dispose()}}
 Assert-Recovery $result.Success ('Physical inverse failed: '+$result.Error+' '+$result.EvidenceError)
 foreach($o in $original){Assert-RecoveryObject ([Azurite.Stage.FileSecurity]::Read($o.path,$false)) $o}
 $restored=[Azurite.Stage.FileSecurity]::Read($loader,$false);$sd=[Security.AccessControl.RawSecurityDescriptor]::new($restored.sddl)
 Assert-Recovery ($restored.sddl -ceq $originalFile.sddl -and -not ($sd.ControlFlags -band [Security.AccessControl.ControlFlags]::DiscretionaryAclProtected) -and @($sd.DiscretionaryAcl|Where-Object{($_.AceFlags -band [Security.AccessControl.AceFlags]::Inherited) -ne 0}).Count -eq 3) 'Exact unprotected inherited descriptor restoration failed'
 if($closedFailed){Assert-Recovery ($result.OriginalRuntimeCleanupVerified -and $result.AaCreationStatus -ceq 'proven' -and -not $result.ApplicationAccepted -and -not $result.SharedRestorationPerformed) 'Closed failed physical fixture promoted application/shared outcome'}
 $result|Add-Member -NotePropertyName COnly -NotePropertyValue $true;$result|Add-Member -NotePropertyName ArchivedLargeBytes -NotePropertyValue $snapshotBytes;$result|Add-Member -NotePropertyName InheritedDescriptorExact -NotePropertyValue $true;$result|Add-Member -NotePropertyName GuardBlocksContentAndRename -NotePropertyValue $true
 Write-RecoveryCRecord (Join-Path $output 'physical-test-result.json') $result
 $result
} $HelperAssemblyPath $ExpectedHelperSha256 $OutputDirectory $PostNativeFixture $ClosedFailedFixture
