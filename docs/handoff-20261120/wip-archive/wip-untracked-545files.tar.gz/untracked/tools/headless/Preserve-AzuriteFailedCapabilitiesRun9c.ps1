[CmdletBinding()]
param([switch]$Capture9c,[string]$OutputDirectory9c)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$script:PreservationRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$script:PreservationRetained=[Collections.Generic.List[object]]::new()
$basePath=Join-Path $PSScriptRoot 'Preserve-AzuriteFailedCapabilitiesRun.ps1'
$baseHash='cf5b627dc99f3d97bcbf6773c3bfe2a4e16839e341b126949460749d52c8a4d5'
$baseStream=[IO.FileStream]::new($basePath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
try{
 $reader=[IO.StreamReader]::new($baseStream,[Text.UTF8Encoding]::new($false,$true),$true,4096,$true)
 try{$baseSource=$reader.ReadToEnd()}finally{$reader.Dispose()}
 $baseStream.Position=0;$hasher=[Security.Cryptography.SHA256]::Create();try{$actualHash=([BitConverter]::ToString($hasher.ComputeHash($baseStream))).Replace('-','').ToLowerInvariant()}finally{$hasher.Dispose()}
 if($actualHash -cne $baseHash){throw 'Reviewed 250c preservation implementation changed.'}
 $tokens=$null;$parseErrors=$null;$baseAst=[Management.Automation.Language.Parser]::ParseInput($baseSource,[ref]$tokens,[ref]$parseErrors)
 if($parseErrors.Count){throw 'Reviewed preservation source did not parse.'}
 # Import only function definitions. The old param block and 250c entry point never run.
 foreach($definition in $baseAst.EndBlock.Statements){if($definition -is [Management.Automation.Language.FunctionDefinitionAst] -and $definition.Name -cnotin @('Get-FailedCapabilitiesPreservationPlan','Invoke-FailedCapabilitiesPreservation')){. ([scriptblock]::Create($definition.Extent.Text))}}
}finally{$baseStream.Dispose()}
Assert-PreservationCPath $basePath
function Get-FailedCapabilitiesPreservationPlan9c {
 $run='9c1fcbc9886641878858bb6424b6e604';$lab='F:\AzuriteLabs\Editor-20261108-normal';$folder=Join-Path $script:PreservationRepo ('artifacts\aa-fr-transition-preparation\sequence-'+$run)
 $pins=[ordered]@{
  observations=@((Join-Path $folder 'observations.json'),'541fb1e00ae8241f7abc6c55e44dedc84f8b56547dfcdacbda002083c5b86812')
  preparation=@((Join-Path $folder 'preparation-result.json'),'2ee7ab1b3e31e716b405cb2b830c7b58eaa57e076e73598d3825eb463369cb6e')
  beforeImages=@((Join-Path $folder 'before-images-raw.json'),'42a53231f5c998fef0ce98dfc02e4e36a8cf07f0116e414bdcfdb97ade4c5014')
  journal=@((Join-Path $folder 'journal.jsonl'),'957e852854f4e9c3d180babd9c2f6cf63e1fc3808ab39cbbe7fc65f6d1133654')
  release=@((Join-Path $folder 'lease-release.json'),'09099fb571edf6c03a20a5a4dd23008e9c0b4f9451dd63307ad89553322c9270')
  receipts=@((Join-Path $folder 'receipt-bundle.json'),'7a121806dd57e62f4e1c8b65d2cf5eef668918f6b59c005a57e8feb19e230c2a')
  final=@((Join-Path $script:PreservationRepo 'artifacts\aa-fr-capabilities-runtime\6b1d9c73f1e04bc2b07d2b0b9bff17bb\controller-final.json'),'415a0b23c551c49f078f5594f8236d615e2132553aa2c75b3c0b06e86e928c97')
  bootstrap=@((Join-Path $script:PreservationRepo 'artifacts\aa-fr-actual-aa-9c-failure-20261113\output__bootstrap-result.json'),'d8d081e3a5d696dcb67538065ec6df1513644670f93c1f13add7b00ed7a2f5a6')
 }
 $values=@{};$bindings=@();foreach($key in $pins.Keys){$bytes=Read-PreservationPinnedC $pins[$key][0] $pins[$key][1];if($key -cne 'journal'){$values[$key]=ConvertFrom-PreservationJson $bytes};$bindings+=,[pscustomobject]@{name=$key;path=$pins[$key][0];sha256=$pins[$key][1];bytes=$bytes.Length}}
 $o=$values.observations;$prep=$values.preparation;$raw=$values.beforeImages;$release=$values.release;$receipt=$values.receipts;$f=$values.final;$outer=$f.result.outer;$trace=$outer.FullDesktopMonitorEvidence.outerDrain;$monitor=$outer.FullDesktopMonitorEvidence
 Assert-Preservation ($o.runId -ceq $run -and $prep.Success -eq $true -and $prep.Prepared -eq $true -and $prep.LeaseState -ceq 'released' -and -not $prep.Quarantined -and -not $prep.Error -and $prep.Observations.runId -ceq $run -and @($o.snapshots).Count -eq 1228 -and @($o.objects).Count -eq 1259 -and @($o.created).Count -eq 31) 'Exact run9c preparation differs'
 Assert-Preservation ($o.lease.ownerSid -ceq 'S-1-5-21-222280291-4039000738-1914192245-1001' -and $o.lease.volume -ceq '\\?\Volume{a7c77c39-d000-4faf-bbf8-cc8ca0c743cb}\' -and $raw.runId -ceq $run -and @($raw.objects).Count -eq 1228 -and $release.runId -ceq $run -and $release.leaseId -ceq $o.lease.leaseId -and $release.releaseOutcome -ceq 'success') 'Original baseline/owner/volume/preparation release differs'
 Assert-Preservation ($receipt.Plan.RunId -ceq $run -and $receipt.Plan.PlanSha256 -ceq '626032434d5b2c6cf5f3ebb7774d41a8db700ffaa059ed1cf1cc2e4cd6aa1e9d' -and $receipt.PreparationLeaseReleased -eq $true -and $receipt.RuntimeAllowed -eq $false) 'Preparation receipt binding differs'
 Assert-Preservation ($f.runId -ceq $run -and $f.passed -eq $false -and $f.runtimeAllowed -eq $false -and $f.runtimeLeaseReleased -eq $true -and $f.runtimeMutexDisposed -eq $true -and -not $f.releaseError -and -not $f.disposeError -and -not $f.leaseHeld -and -not $f.ownerRetained -and $f.pendingCleared -eq $false -and $f.result.zeroSharedDelta -eq $true -and $outer.RunId -ceq $run -and $outer.Pid -eq 10956 -and $outer.ExitCode -eq 1 -and $outer.DirectProcessExited -eq $true -and $outer.JobDrained -eq $true -and $outer.RemainingOwnedProcesses -eq 0 -and $outer.StreamCaptureComplete -eq $true -and $outer.DesktopLeaseClosed -eq $true -and -not $outer.DesktopLeaseRetained -and $outer.FullJobObserverClosed -eq $true -and -not $outer.FullJobObserverRetained -and $outer.FullJobObserverCloseError -eq 0 -and $outer.CleanupVerified -eq $true -and -not $outer.TimedOut -and -not $outer.WindowViolation -and -not $outer.OutputLimitExceeded) 'Bound run9c failed runtime exit/drain/closure evidence differs'
 Assert-Preservation ($trace.runId -ceq $run -and $trace.bootstrapPid -eq 10956 -and $trace.complete -eq $true -and $trace.recordCount -eq 7 -and $trace.droppedCount -eq 0 -and -not $trace.recordError -and $monitor.normalCount -eq 0 -and $monitor.emptyCount -eq 29 -and $monitor.failedCount -eq 0) 'Bound cleanup trace or monitor differs'
 $bootstrap=$values.bootstrap;$native=$bootstrap.restrictedNative
 Assert-Preservation ($bootstrap.runId -ceq $run -and $bootstrap.bootstrapPid -eq 10956 -and $bootstrap.planSha256 -ceq $receipt.Plan.PlanSha256 -and $bootstrap.aaPid -eq 32244 -and $bootstrap.aaStartedUtc -ceq '2026-11-12T23:40:36.6997434Z' -and $bootstrap.aaExitCode -eq -532462766 -and $native.Process.Pid -eq 32244 -and $native.Process.ExitCode -eq -532462766 -and $native.Process.NoProcessCreated -eq $false -and $native.Evidence.created -eq $true -and $native.Evidence.createError -eq 0 -and $native.Evidence.actualTokenVerified -eq $true -and $native.Evidence.exactOwnedJobVerified -eq $true -and $native.Evidence.resumeCalls -eq 1 -and $native.Evidence.resumeVerified -eq $true) 'Prior failed AA process creation evidence differs'
 $original=New-PreservationMap $o.snapshots;$prepared=New-PreservationMap $o.objects
 foreach($obj in $raw.objects){Assert-Preservation ($original.ContainsKey($obj.path)) 'Raw baseline path absent from observations';Assert-PreservationStable $obj $original[$obj.path]}
 foreach($obj in $o.objects){Assert-Preservation ($obj.path -ceq 'F:\AzuriteLabs' -or $obj.path -ceq 'F:\AzuriteLabs\.azurite-phase0-parent.json' -or $obj.path -ceq $lab -or $obj.path.StartsWith($lab+'\',[StringComparison]::Ordinal)) 'Prepared object escapes fixed lab scope'}
 $runRoot=$lab+'\runs\restricted-'+$run;$mutable=@(($lab+'\install\BepInEx\LogOutput.log'),($lab+'\install\BepInEx\cache\chainloader_typeloader.dat'),($lab+'\install\BepInEx\config\BepInEx.cfg'),($lab+'\install\profiles\AzuriteAcceptance\configs\halocue.azurite.cfg'),($lab+'\install\BepInEx\cache\mod-the-azure-archive-38F3AC6B852EB58403C65A45_typeloader.dat'));$pending=$lab+'\runs\full-capabilities.pending.json'
 foreach($p in $mutable){Assert-Preservation ($prepared.ContainsKey($p) -and -not $prepared[$p].directory) 'Mutable leaf lacks prepared baseline'}
 [pscustomobject]@{RunId=$run;PlanSha256=$receipt.Plan.PlanSha256;LabRoot=$lab;RunRoot=$runRoot;PendingPath=$pending;OwnerSid=$o.lease.ownerSid;Volume=$o.lease.volume;Original=@($o.snapshots);Prepared=@($o.objects);MutableFiles=$mutable;MutablePayloadPaths=@($mutable)+@($pending,($runRoot+'\output\unity.log'));ImportantPaths=@(($runRoot+'\output\unity.log'),($runRoot+'\output\bootstrap-result.json'),($runRoot+'\output\aa.stdout.log'),($runRoot+'\output\aa.stderr.log'),($runRoot+'\request\response.json'),($runRoot+'\shared-state\after.json'),($runRoot+'\shared-state\delta.json'));MaxTreeObjects=512;MaxFileBytes=67108864L;MaxArchiveBytes=268435456L;InputBindings=$bindings;RuntimeFinalSha256=$pins.final[1];OriginalRuntimeCleanupVerified=$true;AaCreationProven=$true;AaCreationExcluded=$false;PriorAa=[pscustomobject]@{pid=32244;startedUtc=$bootstrap.aaStartedUtc;exitCode=-532462766;bootstrapSha256=$pins.bootstrap[1];applicationAccepted=$false};HelperPath=(Join-Path $script:PreservationRepo 'artifacts\aa-fr-empty-directory-helper-20261113\helper-build1\FullRestrictedStageFileSecurity.dll');HelperSha256='0d1bbc0541dd7e1b74619b62c1bbdf4cef00a35b21cdf2a7e4d11f4505a1e84b';BaseScriptPath=$basePath;BaseScriptSha256=$baseHash;WillWriteF=$false;WillRestore=$false;WillLaunch=$false}
}
function Assert-Preservation9cPending($record,$spec){Assert-Preservation ($record.schema -eq 1 -and $record.scope -ceq 'full-capabilities-global-pending' -and $record.runId -ceq $spec.RunId -and $record.planSha256 -ceq $spec.PlanSha256 -and $record.controllerSid -ceq $spec.OwnerSid -and $record.runDirectory -ceq $spec.RunRoot -and $record.state -ceq 'runtime-pending') 'Archived pending does not match exact failed runtime'}
function New-Preservation9cBackend {
 return {param($action,$a,$state)
  if($action -ceq 'Observe'){
   $actual=& $state.Inner $action $a $state
   if($state.Prepared.ContainsKey($a.path)){
    Assert-Preservation ($null -ne $actual) ('Prepared object disappeared: '+$a.path)
    $expected=$state.Prepared[$a.path]
    foreach($key in @('path','finalPath','identity','owner','volume','directory','reparse','links','sddl')){Assert-Preservation ($actual.$key -ceq $expected.$key) ('Prepared identity/descriptor drift ('+$key+'): '+$a.path)}
    if(-not $actual.directory -and $a.path -cnotin $state.Spec.MutablePayloadPaths){Assert-Preservation ($actual.bytes -eq $expected.bytes -and $actual.sha256 -ceq $expected.sha256) ('Immutable prepared payload drift: '+$a.path)}
   }
   return $actual
  }
  if($action -ceq 'Persist' -and $a.name -ceq 'preservation-result'){
   $a.value.originalRuntimeCleanupVerified=$state.Spec.OriginalRuntimeCleanupVerified
   $a.value.aaCreationProven=$state.Spec.AaCreationProven
   $a.value | Add-Member -NotePropertyName runtimeFinalSha256 -NotePropertyValue $state.Spec.RuntimeFinalSha256
   $a.value | Add-Member -NotePropertyName applicationAccepted -NotePropertyValue $false
   $a.value | Add-Member -NotePropertyName nativeAcceptanceClaimed -NotePropertyValue $false
  }
  $value=& $state.Inner $action $a $state
  if($action -ceq 'Archive' -and $a.path -ceq $state.Spec.PendingPath){
   $pendingBytes=& $state.ArchiveReader $value
   Assert-Preservation ($pendingBytes.Length -eq $value.bytes -and (Get-PreservationHash $pendingBytes) -ceq $value.sha256) 'Archived pending readback changed'
   Assert-Preservation9cPending (ConvertFrom-PreservationJson $pendingBytes) $state.Spec
  }
  return $value
 }
}
function Invoke-FailedCapabilitiesPreservation9c([string]$output){
 Assert-Preservation ($PSVersionTable.PSEdition -ceq 'Core' -and $PSVersionTable.PSVersion.Major -ge 7 -and [Environment]::Is64BitProcess -and -not ('Azurite.Stage.FileSecurity' -as [type])) 'Fresh x64 PowerShell 7 without preloaded helper required'
 $spec=Get-FailedCapabilitiesPreservationPlan9c;Assert-PreservationCPath $output $false;Assert-Preservation (-not [IO.Directory]::Exists($output) -and -not [IO.File]::Exists($output)) 'Preservation evidence directory must be fresh'
 $captureParent=Join-Path $script:PreservationRepo 'artifacts\aa-fr-failed-run-preservation-9c';Assert-Preservation ([IO.Path]::GetDirectoryName($output) -ceq $captureParent) 'Capture output must be a fresh direct child of fixed C run9c evidence root'
 $bytes=Read-PreservationPinnedC $spec.HelperPath $spec.HelperSha256;[void][Reflection.Assembly]::Load([byte[]]$bytes);[Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal
 $state=@{Spec=$spec;Prepared=(New-PreservationMap $spec.Prepared);Inner=(New-PreservationPhysicalBackend);ArchiveReader={param($archive) Read-PreservationPinnedC $archive.destination $archive.sha256 16384};EvidenceDirectory=$output;ArchiveDirectory=(Join-Path $output 'archive');Locks=@{};Mutex=$null;Held=$false;JournalSequence=0}
 Lock-PreservationAncestry $state $output $false
 try{[void][IO.Directory]::CreateDirectory($output);Lock-PreservationAncestry $state $output $true;[void][IO.Directory]::CreateDirectory($state.ArchiveDirectory);Lock-PreservationAncestry $state $state.ArchiveDirectory $true;Invoke-PreservationCoordinator $spec (New-Preservation9cBackend) $state}
 finally{if(-not $state.Held){foreach($h in $state.Locks.Values){$h.Dispose()};$state.Locks.Clear()}}
}
if($MyInvocation.InvocationName -ne '.'){
 $entryExit=0;$result=$null
 try{if($Capture9c){Assert-Preservation (-not [string]::IsNullOrWhiteSpace($OutputDirectory9c)) 'Capture9c requires a fresh C OutputDirectory9c';$result=Invoke-FailedCapabilitiesPreservation9c $OutputDirectory9c;$result|ConvertTo-Json -Depth 8;if(-not $result.preserved){$entryExit=1}}else{$plan=Get-FailedCapabilitiesPreservationPlan9c;[pscustomobject]@{mode='C-only-plan';runId=$plan.RunId;originalObjects=$plan.Original.Count;preparedObjects=$plan.Prepared.Count;archiveScope=@($plan.RunRoot,$plan.PendingPath)+$plan.MutableFiles;importantPathsObservedWithoutPredeterminedAbsence=$plan.ImportantPaths;inputBindings=$plan.InputBindings;helperPath=$plan.HelperPath;helperSha256=$plan.HelperSha256;baseScriptSha256=$plan.BaseScriptSha256;originalRuntimeCleanupVerified=$true;applicationAccepted=$false;aaCreationProven=$plan.AaCreationProven;priorAa=$plan.PriorAa;aaCreationExcluded=$false;willWriteF=$false;willRestore=$false;willLaunch=$false}|ConvertTo-Json -Depth 8}}catch{$entryExit=1;[pscustomobject]@{preserved=$false;error=$_.Exception.ToString();willWriteF=$false;restorationPerformed=$false;registryAccessPerformed=$false;aaCreationExcluded=$false}|ConvertTo-Json -Depth 8}
 finally{if($Capture9c -and ($script:PreservationRetained.Count -gt 0 -or ($result -and $result.leaseHeld))){try{[Console]::Error.WriteLine('Preservation lease release remains unconfirmed; controller retained for root inspection. No retry or target write.')}finally{while($true){[Threading.Thread]::Sleep(30000)}}}}
 if($entryExit -ne 0){exit $entryExit}
}
