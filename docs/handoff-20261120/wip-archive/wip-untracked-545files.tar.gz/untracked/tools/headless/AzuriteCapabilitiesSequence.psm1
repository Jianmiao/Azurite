function Test-HarmlessReceiptKind($Receipt) {
 if($null -eq $Receipt){return $false}
 foreach($name in @('schema','scope','passed','productionTargetExecuted','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified')){if(-not $Receipt.PSObject.Properties[$name]){return $false}}
 if($Receipt.schema -isnot [int] -and $Receipt.schema -isnot [long]){return $false}
 foreach($name in @('passed','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified')){if($Receipt.$name -isnot [bool] -or -not $Receipt.$name){return $false}}
 if($Receipt.productionTargetExecuted -isnot [bool] -or $Receipt.productionTargetExecuted){return $false}
 if($Receipt.schema -eq 1){return ($Receipt.scope -ceq 'actual-native-full-restricted-harmless-lifecycle' -and $Receipt.PSObject.Properties['desktopLeaseAcrossBootstrapExit'] -and $Receipt.desktopLeaseAcrossBootstrapExit -is [bool] -and $Receipt.desktopLeaseAcrossBootstrapExit)}
 if($Receipt.schema -ne 2 -or $Receipt.scope -cne 'actual-native-full-restricted-cleanup-lifecycle' -or $Receipt.PSObject.Properties['desktopLeaseAcrossBootstrapExit']){return $false}
 foreach($name in @('cleanupEvidenceProtocol','outerDesktopHeldUntilJobDrain','bootstrapExitCleanupObserved','cleanupTraceComplete','externalLiveDescendantIntervalClaimed')){if(-not $Receipt.PSObject.Properties[$name]){return $false}}
 if($Receipt.cleanupEvidenceProtocol -cne 'cleanup-ordering.v1'){return $false}
 foreach($name in @('outerDesktopHeldUntilJobDrain','bootstrapExitCleanupObserved','cleanupTraceComplete')){if($Receipt.$name -isnot [bool] -or -not $Receipt.$name){return $false}}
 return ($Receipt.externalLiveDescendantIntervalClaimed -is [bool] -and -not $Receipt.externalLiveDescendantIntervalClaimed)
}
Set-StrictMode -Version Latest
$script:SequenceRepo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$script:SequenceStages=@('Capture','Warm','Assemble','Approval','PreparePlan','Apply','Projection','RuntimePlan','Runtime')
$script:SequenceRoles=[ordered]@{
 SequenceEntry='tools\headless\Invoke-AzuriteCapabilitiesSequence.ps1';SequenceModule='tools\headless\AzuriteCapabilitiesSequence.psm1';SequenceChild='tools\headless\Invoke-AzuriteCapabilitiesSequenceChild.ps1';Capture='tools\headless\Capture-AzuriteFullCapabilitiesIdentityShared.ps1'
 Warm='AcceptanceHarness\FullRestricted.FreshPreflight\Capture-FreshPreflight.ps1';WarmIndex='AcceptanceHarness\FullRestricted.FreshPreflight\source-index.json';WarmManifest='artifacts\aa-fr-fresh-preflight-tooling\build-cf95-qual1\manifest.json'
 Inputs='tools\headless\New-AzuriteFullCapabilitiesInputs.ps1';Prepare='tools\headless\Prepare-AzuriteFullCapabilitiesRun.ps1';Stage='tools\headless\FullRestrictedStageTransition.psm1';Runtime='tools\headless\Invoke-AzuriteRestrictedCli.ps1'
 Headless='tools\headless\HeadlessCore.psm1';Core='tools\headless\RestrictedCliCore.psm1';Current='tools\headless\CurrentAccountCli.psm1';Planner='tools\headless\FullRestrictedCapabilitiesPlan.psm1';RuntimePolicy='tools\headless\FullRestrictedCapabilitiesRuntime.psm1'
 NativeSource='tools\headless\RestrictedCliNative.cs';FullNativeSource='tools\headless\RestrictedCliFullRestricted.cs';Bootstrap='tools\headless\RestrictedCliBootstrap.ps1'
 CaptureNative='.superpowers\sdd\azurite-authoring-20261108\aa-fr-ftarget-cf95-build-20261114\tooling\RestrictedCliNative.dll'
 RuntimeNative='.superpowers\sdd\azurite-authoring-20261108\aa-fr-ftarget-cf95-build-20261114\tooling\RestrictedCliNative.dll';ToolingManifest='.superpowers\sdd\azurite-authoring-20261108\aa-fr-ftarget-cf95-build-20261114\tooling\tooling-manifest.json'
 FileHelper='artifacts\aa-startup-exception-diagnostic-20261113\helper-build1\FullRestrictedStageFileSecurity.dll';FileHelperSource='artifacts\aa-startup-exception-diagnostic-20261113\helper-build1\FullRestrictedStageFileSecurity.cs';FileHelperBuild='artifacts\aa-startup-exception-diagnostic-20261113\helper-build1\build.json'
 PS51='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';PS7='C:\Users\21294\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe';Dotnet='C:\Program Files\dotnet\dotnet.exe'
}
function Assert-Sequence($condition,[string]$message){if(-not $condition){throw $message}}
function Get-SequenceHash([byte[]]$bytes){$s=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($s.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
function ConvertTo-SequenceJson($value){ConvertTo-Json -InputObject $value -Depth 95 -Compress}
function ConvertFrom-SequenceJson([string]$text){$p=@{InputObject=$text};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$p.DateKind='String'};ConvertFrom-Json @p}
function Assert-SequenceCPath([string]$path,[bool]$MustExist=$true){
 $full=[IO.Path]::GetFullPath($path);Assert-Sequence ($path -ceq $full -and $full.StartsWith($script:SequenceRepo+'\',[StringComparison]::Ordinal)) 'Exact C workspace path required'
 $cursor=$full;while($cursor){$item=Get-Item -LiteralPath $cursor -Force -ErrorAction SilentlyContinue;if($item){Assert-Sequence (-not($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'Sequence reparse ancestry refused'}elseif($MustExist -and $cursor -ceq $full){throw 'Sequence input missing'};$cursor=Split-Path -Parent $cursor};return $full
}
function Read-SequenceBytes([string]$path,[string]$sha,[long]$maximum=67108864){
 $null=Assert-SequenceCPath $path;Assert-Sequence ($sha -cmatch '\A[a-f0-9]{64}\z' -and $sha -cne ('0'*64)) 'Trusted digest required'
 $item=Get-Item -LiteralPath $path;Assert-Sequence (-not $item.PSIsContainer -and $item.Length -le $maximum) 'Sequence input size/type differs'
 $bytes=[IO.File]::ReadAllBytes($path);Assert-Sequence ($bytes.Length -le $maximum -and (Get-SequenceHash $bytes) -ceq $sha) 'Sequence pinned bytes differ';return ,$bytes
}
function Read-SequenceJson([string]$path,[string]$sha,[long]$maximum=67108864){ConvertFrom-SequenceJson ([Text.UTF8Encoding]::new($false,$true).GetString((Read-SequenceBytes $path $sha $maximum)))}
function Get-SequencePin([string]$path){$null=Assert-SequenceCPath $path;[pscustomobject]@{path=$path;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $path).Length}}
function Write-SequenceJson([string]$path,$value){
 $null=Assert-SequenceCPath $path $false;$bytes=[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-SequenceJson $value));Assert-Sequence ($bytes.Length -le 67108864) 'Sequence record exceeds 64 MiB'
 $f=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()};Get-SequencePin $path
}
function Assert-SequenceSourcePins($Spec){
 $fixed=Get-SequenceFixedRoles;$seen=@{};Assert-Sequence (@($Spec.SourceRows).Count -eq $fixed.Count) 'Exact sequence source whitelist required'
 foreach($row in $Spec.SourceRows){
  Assert-Sequence ($row.role -cin @($fixed.Keys) -and -not $seen.ContainsKey($row.role) -and $row.path -ceq $fixed[$row.role] -and $row.sha256 -cmatch '\A[a-f0-9]{64}\z') 'Sequence source role/path differs';$seen[$row.role]=$true
  $item=Get-Item -LiteralPath $row.path -Force;Assert-Sequence (-not $item.PSIsContainer -and $item.Length -eq $row.bytes -and $item.Length -le 16777216 -and -not($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -and (Get-FileHash -LiteralPath $row.path).Hash.ToLowerInvariant() -ceq $row.sha256) ('Reviewed source bytes differ: '+$row.role)
 }
}
function Get-SequenceFixedRoles {
 $roles=[ordered]@{};foreach($key in $script:SequenceRoles.Keys){$value=$script:SequenceRoles[$key];$roles[$key]=if([IO.Path]::IsPathRooted($value)){$value}else{Join-Path $script:SequenceRepo $value}}
 return $roles
}
function Read-SequenceSpec([string]$InputRecordPath,[string]$ExpectedInputRecordSha256,[string]$ReviewedSourcesPath,[string]$ExpectedReviewedSourcesSha256){
 $manifest=Read-SequenceJson $ReviewedSourcesPath $ExpectedReviewedSourcesSha256 1048576
 Assert-Sequence ($manifest.schema -eq 1 -and $manifest.scope -ceq 'root-reviewed-fixed-capabilities-sequence-sources') 'Root-reviewed sequence source manifest required'
 $sources=@{};foreach($row in $manifest.files){$sources[$row.role]=$row}
 $spec=[pscustomobject]@{SourceRows=@($manifest.files);Sources=[pscustomobject]$sources;Input=$null;Baseline=$null;BaselineIdentity=$null;OutputRoot=$null;InputRecordPath=$InputRecordPath;InputSha256=$ExpectedInputRecordSha256;ReviewedSourcesPath=$ReviewedSourcesPath;ReviewedSourcesSha256=$ExpectedReviewedSourcesSha256}
 Assert-SequenceSourcePins $spec
 $record=Read-SequenceJson $InputRecordPath $ExpectedInputRecordSha256 131072
 $fields=@('schema','scope','runId','baselineCapture','harmless','intentValidUntilUtc','runtimeTimeoutSeconds','sourcesSha256')
 if($record.PSObject.Properties['startupDiagnostic']){$fields+='startupDiagnostic';Assert-Sequence ($record.startupDiagnostic -is [string] -and $record.startupDiagnostic -ceq 'startup-exceptions.v1') 'Fixed explicit startup diagnostic required'}
 Assert-Sequence (@($record.PSObject.Properties).Count -eq $fields.Count -and @($fields|Where-Object {-not $record.PSObject.Properties[$_]}).Count -eq 0 -and $record.schema -eq 1 -and $record.scope -ceq 'root-authorized-one-capabilities-sequence' -and $record.sourcesSha256 -ceq $ExpectedReviewedSourcesSha256 -and $record.runId -cmatch '\A[a-f0-9]{32}\z' -and $record.runId -cne ('0'*32)) 'Exact authorized sequence input/run/source binding required'
 Assert-Sequence ($record.runtimeTimeoutSeconds -is [int] -or $record.runtimeTimeoutSeconds -is [long]) 'Typed runtime duration required'
 Assert-Sequence ($record.runtimeTimeoutSeconds -ge 10 -and $record.runtimeTimeoutSeconds -le 300 -and $record.intentValidUntilUtc -is [string] -and $record.intentValidUntilUtc -cmatch '\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\z') 'Fixed bounded duration and canonical absolute expiry required'
 $baseline=Read-SequenceJson $record.baselineCapture.path $record.baselineCapture.sha256 1048576
 Assert-Sequence ($baseline.schema -eq 1 -and $baseline.scope -ceq 'read-only-stage-baseline-capture' -and $baseline.runId -ceq $record.runId -and $baseline.success -is [bool] -and $baseline.success -and $baseline.observedObjects -eq 1228 -and $baseline.lease.state -ceq 'released' -and -not $baseline.error -and -not $baseline.willWriteF -and -not $baseline.runtimeAllowed -and -not $baseline.launchPermission) 'Completed same-run baseline is required before sequence capture'
 $identityPath=Join-Path (Split-Path -Parent $record.baselineCapture.path) 'identity-baseline.json';$identity=Read-SequenceJson $identityPath $baseline.baselineSha256 4194304
 Assert-Sequence ($identity.schema -eq 1 -and $identity.scope -ceq 'preapproval-stage-object-identities' -and $identity.runId -ceq $record.runId -and @($identity.objects).Count -eq 1228) 'Baseline identity record differs'
 $harmless=Read-SequenceJson $record.harmless.path $record.harmless.sha256 131072
 Assert-Sequence ((Test-HarmlessReceiptKind $harmless) -and $harmless.nativeSourceSha256 -ceq $sources.FullNativeSource.sha256 -and $harmless.sharedNativeSourceSha256 -ceq $sources.NativeSource.sha256) 'Same-source complete harmless lifecycle version required'
 $warmIndex=Read-SequenceJson $sources.WarmIndex.path $sources.WarmIndex.sha256 1048576
 foreach($f in $warmIndex.files){Assert-Sequence ($f.path -cmatch '\A[A-Za-z0-9_.-]+\z') 'Warm source must be a leaf';$null=Read-SequenceBytes (Join-Path (Split-Path -Parent $sources.WarmIndex.path) $f.path) $f.sha256 16777216}
 $warmBuild=Read-SequenceJson $sources.WarmManifest.path $sources.WarmManifest.sha256 1048576
 Assert-Sequence ($warmBuild.sourceIndexSha256 -ceq $sources.WarmIndex.sha256 -and -not $warmBuild.runtimeExecuted -and -not $warmBuild.stageRead) 'Warm build provenance differs'
 foreach($f in $warmBuild.files){Assert-Sequence ($f.path -cmatch '\A[A-Za-z0-9_.-]+\z') 'Warm build member must be a leaf';$null=Read-SequenceBytes (Join-Path (Split-Path -Parent $sources.WarmManifest.path) $f.path) $f.sha256 16777216}
 $tooling=Read-SequenceJson $sources.ToolingManifest.path $sources.ToolingManifest.sha256 1048576
 $nameRoles=[ordered]@{'RestrictedCliCore.psm1'='Core';'RestrictedCliNative.cs'='NativeSource';'RestrictedCliFullRestricted.cs'='FullNativeSource';'RestrictedCliNative.dll'='RuntimeNative';'RestrictedCliBootstrap.ps1'='Bootstrap';'CurrentAccountCli.psm1'='Current';'HeadlessCore.psm1'='Headless';'FullRestrictedCapabilitiesRuntime.psm1'='RuntimePolicy'}
 $hashes=[ordered]@{};foreach($name in $nameRoles.Keys){$hashes[$name]=$sources[$nameRoles[$name]].sha256}
 $policy=Import-Module $sources.RuntimePolicy.path -PassThru -DisableNameChecking
 & $policy {param($m,$h)Assert-AzuriteFullToolManifest $m ([pscustomobject]@{toolHashes=[pscustomobject]$h})} $tooling $hashes
 $helper=Read-SequenceJson $sources.FileHelperBuild.path $sources.FileHelperBuild.sha256 131072
 Assert-Sequence ($helper.exitCode -eq 0 -and $helper.moduleSha256 -ceq $sources.Stage.sha256 -and $helper.sourceSha256 -ceq $sources.FileHelperSource.sha256 -and $helper.assemblySha256 -ceq $sources.FileHelper.sha256) 'File helper source/build binding differs'
 $spec.Input=$record;$spec.Baseline=$baseline;$spec.BaselineIdentity=[pscustomobject]@{path=$identityPath;sha256=$baseline.baselineSha256}
 $spec.OutputRoot=Join-Path $script:SequenceRepo ('artifacts\aa-fr-capabilities-sequence\run-'+$record.runId)
 return $spec
}
function Get-SequenceStepRequest([string]$Stage,$Spec,$State){
 $request=[ordered]@{stage=$Stage;runId=$Spec.Input.runId;input=$Spec.Input;authorityInput=[pscustomobject]@{path=$Spec.InputRecordPath;sha256=$Spec.InputSha256};sources=$Spec.Sources;sequenceRoot=$Spec.OutputRoot;baseline=$Spec.Baseline;baselineIdentity=$Spec.BaselineIdentity;prior=$State.Outputs}
 return [pscustomobject]$request
}
function Assert-SequenceStepResult([string]$Stage,$Result,$Spec,$State){
 Assert-Sequence ($Result -and $Result.runId -ceq $Spec.Input.runId -and $Result.stage -ceq $Stage) 'Stage/run binding differs'
 Assert-Sequence ($Result.childExitCode -eq 0 -and -not $Result.stageError) ('Child stage failed: '+$Result.stageError)
 foreach($pin in $Result.files.PSObject.Properties.Value){$bytes=Read-SequenceBytes $pin.path $pin.sha256;Assert-Sequence ($bytes.Length -eq $pin.bytes) 'Stage artifact byte count differs'}
 $r=$Result.raw
 switch($Stage){
  Capture {Assert-Sequence ($r.passed -is [bool] -and $r.passed -and $r.runId -ceq $Spec.Input.runId -and -not $r.leaseStillHeld -and @($r.cleanupErrors).Count -eq 0 -and -not $r.error -and -not $r.aaExecuted -and -not $r.stageWrites -and -not $r.sharedWrites -and -not $r.registryWrites) 'Identity/shared capture failed or retained ownership'}
  Warm {Assert-Sequence ($r.passed -is [bool] -and $r.passed -and $r.runId -ceq $Spec.Input.runId -and -not $r.primaryError -and @($r.cleanupErrors).Count -eq 0 -and -not $r.leaseStillHeld -and $r.ownedReader.exitConfirmed -and $r.ownedReader.streamsCompleted -and $r.ownedReader.processDisposed -and $r.ownedReader.mutexDisposed -and -not $r.ownedReader.retained) 'Warm capture failed or retained ownership'}
  Assemble {Assert-Sequence ($r.inputReady -is [bool] -and $r.inputReady -and $r.runId -ceq $Spec.Input.runId -and -not $r.approvalPresent -and -not $r.willApply -and -not $r.willLaunch -and -not $r.runtimeAllowed -and $r.sourceManifestSha256 -ceq $Result.files.SourceManifest.sha256 -and $r.controlSha256 -ceq $Result.files.Control.sha256 -and $r.gateSha256 -ceq $Result.files.Gate.sha256) 'Assembler did not produce the exact unapproved graph'}
  Approval {Assert-Sequence ($r.runId -ceq $Spec.Input.runId -and $r.decision -ceq 'approved-one-capabilities-run' -and $r.controlGateSha256 -ceq $State.Outputs.Assemble.files.Gate.sha256 -and $r.validUntilUtc -ceq $Spec.Input.intentValidUntilUtc -and @($r.PSObject.Properties).Count -eq 15) 'Canonical one-run approval binding differs'}
  PreparePlan {$expectedTargets=1252;if($Spec.Input.PSObject.Properties['startupDiagnostic']){$expectedTargets++};Assert-Sequence ($r.mode -ceq 'planning-only' -and $r.runId -ceq $Spec.Input.runId -and $r.approvalPresent -and $r.existingObjects -eq 1228 -and $r.aclTargets -eq $expectedTargets -and -not $r.willMutate -and -not $r.willLaunch -and -not $r.runtimeAllowed) 'Public preparation Plan refused'}
  Apply {Assert-Sequence ($r.Success -is [bool] -and $r.Success -and $r.Prepared -and $r.SealRestored -and $r.LeaseState -ceq 'released' -and -not $r.Quarantined -and -not $r.Error -and -not $r.RuntimeAllowed -and -not $r.WillLaunch) 'Actual preparation failed or lease incomplete'}
  Projection {Assert-Sequence ($r.Ready -and $r.runId -ceq $Spec.Input.runId -and $r.approvalSha256 -ceq $State.Outputs.Approval.files.Approval.sha256 -and $r.PreparationLeaseReleased -and $r.RequiresFreshRuntimeLease) 'Actual receipt projection failed'}
  RuntimePlan {Assert-Sequence ($r.Ready -is [bool] -and $r.Ready -and $r.RunId -ceq $Spec.Input.runId -and @($r.Failures).Count -eq 0) 'Public runtime Plan refused'}
  Runtime {Assert-Sequence ($r.passed -is [bool] -and $r.passed -and $r.runId -ceq $Spec.Input.runId -and $r.runtimeLeaseReleased -and $r.runtimeMutexDisposed -and -not $r.leaseHeld -and -not $r.ownerRetained -and $r.pendingCleared -and $r.result.passed -and $r.result.outer.CleanupVerified -and $r.result.zeroSharedDelta) 'Full runtime final outcome failed'}
 }
}
function Invoke-SequenceCore($Spec,[scriptblock]$Adapter){
 $state=[pscustomobject]@{Outputs=[ordered]@{};Steps=[Collections.Generic.List[object]]::new();PrimaryError=$null;SecondaryErrors=[Collections.Generic.List[string]]::new();OwnerRetained=$false}
 foreach($stage in $script:SequenceStages){
  $watch=[Diagnostics.Stopwatch]::StartNew();$row=[ordered]@{stage=$stage;startedUtc=[DateTimeOffset]::UtcNow.ToString('o');invoked=$false;passed=$false;error=$null;before=$null;after=$null;result=$null}
  try{
   Assert-SequenceSourcePins $Spec
   $row.before=& $Adapter 'Observe' ([pscustomobject]@{stage=$stage;phase='before'}) $Spec
   Assert-Sequence ($row.before.aaCount -eq 0 -and $row.before.probeCount -eq 0) 'AA/probe present before stage'
   $request=Get-SequenceStepRequest $stage $Spec $state;$row.invoked=$true
   $answer=& $Adapter $stage $request $Spec;$row.result=$answer
   Assert-SequenceStepResult $stage $answer $Spec $state
   $state.Outputs[$stage]=$answer;$row.passed=$true
  }catch{$row.error=$_.Exception.ToString();if(-not $state.PrimaryError){$state.PrimaryError=$row.error};if($_.Exception.Data['OwnerRetained']){$state.OwnerRetained=$true};$retained=Get-Variable -Scope Global -Name AzuriteSequenceRetainedOwners -ErrorAction SilentlyContinue;if($retained -and $retained.Value.Count -gt 0){$state.OwnerRetained=$true}}
  finally{
   try{$row.after=& $Adapter 'Observe' ([pscustomobject]@{stage=$stage;phase='after'}) $Spec;Assert-Sequence ($row.after.aaCount -eq 0 -and $row.after.probeCount -eq 0) 'AA/probe present after stage'}catch{if(-not $state.PrimaryError){$state.PrimaryError=$_.Exception.ToString();$row.error=$state.PrimaryError}else{$state.SecondaryErrors.Add($_.Exception.ToString())};$row.passed=$false}
   try{Assert-SequenceSourcePins $Spec}catch{if(-not $state.PrimaryError){$state.PrimaryError=$_.Exception.ToString();$row.error=$state.PrimaryError}else{$state.SecondaryErrors.Add($_.Exception.ToString())};$row.passed=$false}
   $watch.Stop();$row.elapsedMilliseconds=$watch.ElapsedMilliseconds;$row.completedUtc=[DateTimeOffset]::UtcNow.ToString('o')
   try{$null=Write-SequenceJson (Join-Path $Spec.OutputRoot ($stage+'-sequence-step.json')) $row}catch{if(-not $state.PrimaryError){$state.PrimaryError=$_.Exception.ToString()}else{$state.SecondaryErrors.Add($_.Exception.ToString())};$row.passed=$false;$row.error=$state.PrimaryError}
   $state.Steps.Add([pscustomobject]$row)
  }
  if($state.PrimaryError){break}
 }
 $result=[ordered]@{schema=1;scope='one-fixed-full-capabilities-sequence';runId=$Spec.Input.runId;passed=($null -eq $state.PrimaryError -and $state.Outputs.Contains('Runtime'));primaryError=$state.PrimaryError;secondaryErrors=$state.SecondaryErrors.ToArray();ownerRetained=$state.OwnerRetained;steps=$state.Steps.ToArray();runtimeAttemptCount=@($state.Steps|Where-Object {$_.stage -ceq 'Runtime' -and $_.invoked}).Count;automaticRetry=$false;automaticRecovery=$false;externalControllerQuiescenceProven=$false}
 try{$null=Write-SequenceJson (Join-Path $Spec.OutputRoot 'sequence-result.json') $result}catch{if(-not $result.primaryError){$result.primaryError=$_.Exception.ToString();$result.passed=$false}}
 return [pscustomobject]$result
}
function Get-SequenceObservation {
 $found=@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'" -ErrorAction Stop)
 $rows=@(foreach($p in $found){$parent=$null;$errorText=$null;try{$parent=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$p.ParentProcessId) -ErrorAction Stop}catch{$errorText=$_.Exception.Message};[pscustomobject]@{pid=[int]$p.ProcessId;parentPid=[int]$p.ParentProcessId;name=$p.Name;executable=$p.ExecutablePath;creationTime=$(if($p.CreationDate){([datetime]$p.CreationDate).ToUniversalTime().ToString('o')}else{$null});parentCreationTime=$(if($parent -and $parent.CreationDate){([datetime]$parent.CreationDate).ToUniversalTime().ToString('o')}else{$null});parentExecutable=$(if($parent){$parent.ExecutablePath}else{$null});parentObservationError=$errorText}})
 [pscustomobject]@{observedUtc=[DateTimeOffset]::UtcNow.ToString('o');aaCount=@($found|Where-Object Name -CEQ 'AzureArchive.exe').Count;probeCount=@($found|Where-Object Name -CEQ 'AzuriteLifecycleProbe.exe').Count;processes=$rows;unknownControllerQuiescenceProven=$false;processControlPerformed=$false}
}
function Get-SequenceInputPin($pin){[pscustomobject]@{path=$pin.path;sha256=$pin.sha256}}
function Get-SequenceAssembleParameters($Request,[string]$InputPath){return @{InputRecordPath=$InputPath;OutputDirectory=(Join-Path $script:SequenceRepo ('artifacts\aa-fr-inputs\sequence-'+$Request.runId));ExpectedReviewedBaselineSha256=$Request.baselineIdentity.sha256}}
function Get-SequencePrepareParameters($Request){
 $a=$Request.prior.Assemble;$approval=$Request.prior.Approval
 return @{SourceManifestPath=$a.files.SourceManifest.path;ExpectedSourceManifestSha256=$a.files.SourceManifest.sha256;ControlPath=$a.files.Control.path;ExpectedControlSha256=$a.files.Control.sha256;GatePath=$a.files.Gate.path;ExpectedGateSha256=$a.files.Gate.sha256;ExpectedPlanSha256=$a.raw.planSha256;ApprovalPath=$approval.files.Approval.path;ExpectedApprovalSha256=$approval.files.Approval.sha256}
}
function Get-SequenceRuntimeParameters($Request){
 $a=$Request.prior.Assemble;$p=$Request.prior.Projection;$approval=$Request.prior.Approval
 return @{LabRoot='F:\AzuriteLabs\Editor-20261108-normal';Command='capabilities';UseCurrentAccount=$true;FullRestrictedCapabilities=$true;FullRunId=$Request.runId;TimeoutSeconds=[int]$Request.input.runtimeTimeoutSeconds;FullPlanFactsPath=$p.files.Facts.path;FullAdmissionPath=$p.files.Admission.path;FullEvidenceBundlePath=$p.files.EvidenceBundle.path;FullApprovalPath=$approval.files.Approval.path;FullExpectedApprovalSha256=$approval.files.Approval.sha256;FullRuntimeGatePath=$a.files.Gate.path;FullExpectedRuntimeGateSha256=$a.files.Gate.sha256;FullTransitionSourceManifestPath=$a.files.SourceManifest.path}
}
function New-SequenceApproval($Plan,$Facts,[string]$GateSha,[string]$ToolingSha,[string]$Expiry,[DateTimeOffset]$Now){
 $issued=$Now.UtcDateTime.ToString('yyyy-MM-ddTHH:mm:ssZ');$observed=[string]$Facts.preTransition.observedUtc
 Assert-Sequence ($observed -cmatch '\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\z' -and [DateTimeOffset]::Parse($observed) -le [DateTimeOffset]::Parse($issued) -and [DateTimeOffset]::Parse($issued) -lt [DateTimeOffset]::Parse($Expiry)) 'Actual approval issuance is outside unchanged observation/expiry interval'
 [pscustomobject][ordered]@{schema=1;decision='approved-one-capabilities-run';scope='current-account-full-restricted-capabilities-only';runId=$Plan.RunId;planSha256=$Plan.PlanSha256;contractSha256=$Plan.ContractSha256;ownerSid=$Facts.ownerSid;volumeGuid=$Facts.volumeGuid;labRoot=$Plan.LabRoot;executable=$Plan.Executable;toolingManifestSha256=$ToolingSha;controlGateSha256=$GateSha;validFromUtc=$observed;issuedUtc=$issued;validUntilUtc=$Expiry}
}
function Project-SequenceReceipts($Bundle,[string]$RunId,[string]$ApprovalSha,[string]$Directory){
 Assert-Sequence ($Bundle.Plan.Ready -and $Bundle.Plan.RunId -ceq $RunId -and $Bundle.PreparationLeaseReleased -and $Bundle.RequiresFreshRuntimeLease -and -not $Bundle.WillLaunch -and -not $Bundle.RuntimeAllowed -and $Bundle.Facts.transition.runId -ceq $RunId -and $Bundle.Admission.runId -ceq $RunId -and $Bundle.EvidenceBundle.runId -ceq $RunId -and $Bundle.Admission.approvalSha256 -ceq $ApprovalSha -and @($Bundle.EvidenceBundle.receipts).Count -eq 12) 'Actual same-run released receipt bundle required'
 $content=ConvertTo-SequenceJson $Bundle.EvidenceBundle;Assert-Sequence ((Get-SequenceHash ([Text.UTF8Encoding]::new($false).GetBytes($content))) -ceq $Bundle.Admission.evidenceBundleSha256) 'Actual embedded evidence bundle digest differs'
 Assert-Sequence (-not(Test-Path -LiteralPath $Directory)) 'Projection directory must be fresh';$null=Assert-SequenceCPath $Directory $false;[void][IO.Directory]::CreateDirectory($Directory)
 $files=[ordered]@{};foreach($name in @('Facts','Admission','EvidenceBundle')){$files[$name]=Write-SequenceJson (Join-Path $Directory ($name+'.json')) $Bundle.$name}
 return [pscustomobject]$files
}
function Invoke-SequenceOwnedProcess($State,[scriptblock]$Operations){
 try{
  $State.startAttempted=$true;$start=& $Operations 'Start' $State;Assert-Sequence ($start -is [bool]) 'Child start is unconfirmed';$State.startReturned=$true;$State.started=$start;Assert-Sequence $start 'Child did not start'
  $null=& $Operations 'BeginStreams' $State;$State.streamsStarted=$true
  $wait=& $Operations 'Wait' $State;Assert-Sequence ($wait -is [bool] -and $wait) 'Child wait is unconfirmed'
  $exited=& $Operations 'HasExited' $State;Assert-Sequence ($exited -is [bool] -and $exited) 'Child exit is unconfirmed';$State.exitConfirmed=$true
  $null=& $Operations 'FinishStreams' $State;$State.streamsCompleted=$true;$State.exitCode=& $Operations 'ExitCode' $State
 }catch{$State.primaryError=$_.Exception.ToString()}
 finally{
  $safe=($State.startReturned -and -not $State.started) -or ($State.exitConfirmed -and $State.streamsCompleted)
  if($safe){try{$null=& $Operations 'Dispose' $State;$State.disposed=$true}catch{if(-not $State.primaryError){$State.primaryError=$_.Exception.ToString()}}}
  if(-not $State.disposed){$State.retained=$true;try{$null=& $Operations 'Retain' $State}catch{if(-not $State.primaryError){$State.primaryError=$_.Exception.ToString()}}}
 }
 return $State
}
function Wait-SequenceChildExitOrRetention($Process,[string]$ReplyPath,[string]$Stage,[string]$RunId){
 while($true){
  if([IO.File]::Exists($ReplyPath+'.retained')){throw 'Child announced retained inner ownership; keep both controllers alive for root inspection'}
  if($Process.WaitForExit(500)){return $true}
  # A false timed wait means the same owned process is still running, not a
  # failed observation. Exceptions are propagated once, never retried.
  if([IO.File]::Exists($ReplyPath+'.ready')){
   $pin=Get-SequencePin $ReplyPath;$reply=Read-SequenceJson $pin.path $pin.sha256
   Assert-Sequence ($reply.stage -ceq $Stage -and $reply.runId -ceq $RunId) 'Child retention reply binding differs'
   if($reply.controllerHeldForRoot){throw 'Child reports retained inner ownership; keep both controllers alive for root inspection'}
  }
 }
}
function Invoke-SequenceProcessTransport([Diagnostics.ProcessStartInfo]$Psi,[string]$OutPath,[string]$ErrPath,[string]$ReplyPath,[string]$Stage,[string]$RunId){
 $null=Assert-SequenceCPath $OutPath $false;$null=Assert-SequenceCPath $ErrPath $false;$null=Assert-SequenceCPath $ReplyPath $false
 Assert-Sequence (-not $Psi.UseShellExecute -and $Psi.CreateNoWindow -and $Psi.RedirectStandardOutput -and $Psi.RedirectStandardError -and [string]::IsNullOrEmpty($Psi.UserName)) 'Fixed hidden current-account stream transport required'
 $owner=[pscustomobject]@{process=[Diagnostics.Process]::new();stdout=$null;stderr=$null;stdoutTask=$null;stderrTask=$null;stage=$Stage};$owner.process.StartInfo=$Psi
 if(-not(Get-Variable -Name AzuriteSequenceRetainedOwners -Scope Global -ErrorAction SilentlyContinue)){$global:AzuriteSequenceRetainedOwners=[Collections.Generic.List[object]]::new()}
 Assert-Sequence ($global:AzuriteSequenceRetainedOwners -is [Collections.Generic.List[object]]) 'Controller ownership collection is invalid before child start'
 $global:AzuriteSequenceRetainedOwners.Add($owner)
 $state=[pscustomobject]@{startAttempted=$false;startReturned=$false;started=$false;streamsStarted=$false;exitConfirmed=$false;streamsCompleted=$false;disposed=$false;retained=$false;exitCode=$null;primaryError=$null}
 $waiter=${function:Wait-SequenceChildExitOrRetention};$step=$Stage;$id=$RunId
 $ops={param($action,$s)switch($action){Start {return $owner.process.Start()};BeginStreams {$owner.stdout=[IO.File]::Open($outPath,'CreateNew','Write','Read');$owner.stderr=[IO.File]::Open($errPath,'CreateNew','Write','Read');$owner.stdoutTask=$owner.process.StandardOutput.BaseStream.CopyToAsync($owner.stdout);$owner.stderrTask=$owner.process.StandardError.BaseStream.CopyToAsync($owner.stderr);return};Wait {return (& $waiter $owner.process $replyPath $step $id)};HasExited {return $owner.process.HasExited};FinishStreams {[void]$owner.stdoutTask.GetAwaiter().GetResult();[void]$owner.stderrTask.GetAwaiter().GetResult();$owner.stdout.Flush($true);$owner.stderr.Flush($true);return};ExitCode {return $owner.process.ExitCode};Dispose {if($owner.stdout){$owner.stdout.Dispose()};if($owner.stderr){$owner.stderr.Dispose()};$owner.process.Dispose();return};Retain {return};default {throw 'Unknown fixed child operation'}}}.GetNewClosure()
 $state=Invoke-SequenceOwnedProcess $state $ops
 if($state.disposed){[void]$global:AzuriteSequenceRetainedOwners.Remove($owner)}
 $state|Add-Member -NotePropertyName retainedReferenceConfirmed -NotePropertyValue ($global:AzuriteSequenceRetainedOwners.Contains($owner))
 return $state
}
function Invoke-SequenceChild($Request,$Spec){
 $requestFile=Write-SequenceJson (Join-Path $Spec.OutputRoot ($Request.stage+'-request.json')) $Request
 $replyPath=Join-Path $Spec.OutputRoot ($Request.stage+'-child-result.json')
 $module=$Spec.Sources.SequenceModule;$child=$Spec.Sources.SequenceChild;$quotedChild=$child.path.Replace("'","''");$quotedRequest=$requestFile.path.Replace("'","''");$quotedReply=$replyPath.Replace("'","''")
 $code="`$ErrorActionPreference='Stop';`$b=[IO.File]::ReadAllBytes('$quotedChild');`$s=[Security.Cryptography.SHA256]::Create();try{`$h=([BitConverter]::ToString(`$s.ComputeHash(`$b))).Replace('-','').ToLowerInvariant()}finally{`$s.Dispose()};if(`$h -cne '$($child.sha256)'){throw 'Pinned plain child differs'};& '$quotedChild' -RequestPath '$quotedRequest' -RequestSha '$($requestFile.sha256)' -ReplyPath '$quotedReply' -ExpectedModuleSha256 '$($module.sha256)'"
 $hostPath=if($Request.stage -cin @('Capture','Warm','Apply')){$Spec.Sources.PS51.path}else{$Spec.Sources.PS7.path}
 $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$hostPath;$psi.Arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($code));$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.WorkingDirectory=$script:SequenceRepo
 if($hostPath -ceq $Spec.Sources.PS51.path){$psi.EnvironmentVariables.Remove('PSModulePath')}
 $state=Invoke-SequenceProcessTransport $psi (Join-Path $Spec.OutputRoot ($Request.stage+'-stdout.log')) (Join-Path $Spec.OutputRoot ($Request.stage+'-stderr.log')) $replyPath $Request.stage $Request.runId
 return Complete-SequenceTransportResult $state $Request $Spec $replyPath
}
function Complete-SequenceTransportResult($State,$Request,$Spec,[string]$ReplyPath){
 $state=$State;$replyPath=$ReplyPath
 $recordError=$null;try{$null=Write-SequenceJson (Join-Path $Spec.OutputRoot ($Request.stage+'-child-ownership.json')) $state}catch{$recordError=$_.Exception.ToString()}
 if($state.retained){$error=[InvalidOperationException]::new('Child ownership remains unconfirmed: '+$state.primaryError);$error.Data['OwnerRetained']=$true;throw $error}
 Assert-Sequence (-not $state.primaryError) ('Child transport failed: '+$state.primaryError)
 Assert-Sequence (-not $recordError) ('Child ownership record failed: '+$recordError)
 if(-not [IO.File]::Exists($replyPath)){
  $stderrPath=Join-Path $Spec.OutputRoot ($Request.stage+'-stderr.log');$stderrPin=Get-SequencePin $stderrPath
  $stream=[IO.File]::Open($stderrPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read);try{$buffer=[byte[]]::new(16384);$count=$stream.Read($buffer,0,$buffer.Length);$excerpt=[Text.Encoding]::UTF8.GetString($buffer,0,$count)}finally{$stream.Dispose()}
  throw ('Child '+$Request.stage+' exited '+$state.exitCode+' without a structured reply. Original stderr: '+$stderrPath+'; SHA256='+$stderrPin.sha256+'; excerpt='+$excerpt)
 }
 $replyPin=Get-SequencePin $replyPath;$reply=Read-SequenceJson $replyPin.path $replyPin.sha256
 $reply.childExitCode=$state.exitCode;$reply.files|Add-Member -NotePropertyName ChildResult -NotePropertyValue $replyPin
 return $reply
}
function Test-SequenceInnerOwnership([string]$Stage,$Raw,[bool]$UncertainFailure){
 $warm=Get-Variable -Scope Global -Name AzuriteFreshPreflightRetainedOwners -ErrorAction SilentlyContinue
 if($warm -and $warm.Value.Count -gt 0){return $true}
 foreach($policy in @(Get-Module -All -Name FullRestrictedCapabilitiesRuntime|Where-Object Path -CEQ (Join-Path $script:SequenceRepo 'tools\headless\FullRestrictedCapabilitiesRuntime.psm1'))){try{if((& $policy {$script:RetainedFullRuntimeLeases.Count}) -gt 0){return $true}}catch{return $true}}
 if($Raw){switch($Stage){Capture {return [bool]$Raw.leaseStillHeld};Warm {return ([bool]$Raw.leaseStillHeld -or [bool]$Raw.ownedReader.retained)};Apply {return ($Raw.LeaseState -ceq 'release-failed')};Runtime {return ([bool]$Raw.ownerRetained -or [bool]$Raw.leaseHeld)}}}
 return ($UncertainFailure -and $Stage -cin @('Capture','Warm','Apply','Runtime'))
}
function Complete-SequenceChildPacket($Packet,[string]$ReplyPath,[scriptblock]$Hold){
 $writeError=$null
 try{
  if($Packet.controllerHeldForRoot){$marker=[IO.File]::Open(($ReplyPath+'.retained'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);$marker.Dispose()}
  $null=Write-SequenceJson $ReplyPath $Packet
  $ready=[IO.File]::Open(($ReplyPath+'.ready'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);$ready.Dispose()
 }catch{$writeError=$_.Exception.ToString();try{[Console]::Error.WriteLine('Child response persistence failed: '+$writeError)}catch{}}
 finally{if($Packet.controllerHeldForRoot){$null=& $Hold $Packet $ReplyPath}}
 if($writeError){throw $writeError}
}
function Complete-SequenceChildExecution($r,$packet,[string]$primary,[string[]]$SecondaryErrors,[string]$ReplyPath,[bool]$ProducerStarted=$true){
 $secondary=[Collections.Generic.List[string]]::new();foreach($e in $SecondaryErrors){$secondary.Add($e)}
 if(-not $packet){$packet=[pscustomobject]@{stage=$r.stage;runId=$r.runId;childExitCode=1;stageError=$primary;raw=$null;files=[pscustomobject]@{}}}elseif($primary){if(-not $packet.stageError){$packet.stageError=$primary}else{$secondary.Add($primary)};$packet.childExitCode=1}
 $hold=Test-SequenceInnerOwnership $r.stage $packet.raw ([bool]$primary -and $ProducerStarted)
 $packet|Add-Member -NotePropertyName controllerHeldForRoot -NotePropertyValue $hold;$packet|Add-Member -NotePropertyName secondaryErrors -NotePropertyValue $secondary.ToArray()
 Complete-SequenceChildPacket $packet $ReplyPath {param($p,$path)try{[Console]::Error.WriteLine('Owned stage state remains unconfirmed; controller retained for root inspection: '+$path)}catch{};while($true){[Threading.Thread]::Sleep(30000)}}
 if($packet.childExitCode -ne 0){exit 1}
}
function Invoke-AzuriteCapabilitiesSequence {
 [CmdletBinding()]param([Parameter(Mandatory)][string]$InputRecordPath,[Parameter(Mandatory)][string]$ExpectedInputRecordSha256,[Parameter(Mandatory)][string]$ReviewedSourcesPath,[Parameter(Mandatory)][string]$ExpectedReviewedSourcesSha256,[switch]$Execute)
 $spec=Read-SequenceSpec $InputRecordPath $ExpectedInputRecordSha256 $ReviewedSourcesPath $ExpectedReviewedSourcesSha256
 if(-not $Execute){return [pscustomobject]@{schema=1;mode='planning-only';runId=$spec.Input.runId;stages=$script:SequenceStages;outputRoot=$spec.OutputRoot;willCapture=$false;willApply=$false;willLaunch=$false;sourceManifestSha256=$ExpectedReviewedSourcesSha256}}
 Assert-Sequence ($PSVersionTable.PSVersion.Major -ge 7 -and [Environment]::Is64BitProcess) 'Fresh x64 PS7 controller required'
 Assert-Sequence ([DateTimeOffset]::UtcNow -lt [DateTimeOffset]::Parse($spec.Input.intentValidUntilUtc)) 'Root intent expiry already elapsed'
 Assert-Sequence (-not(Test-Path -LiteralPath $spec.OutputRoot)) 'One-run sequence directory already exists; no retry'
 $null=Assert-SequenceCPath $spec.OutputRoot $false;[void][IO.Directory]::CreateDirectory($spec.OutputRoot)
 $null=Write-SequenceJson (Join-Path $spec.OutputRoot 'sequence-input-pins.json') ([ordered]@{input=$InputRecordPath;inputSha256=$ExpectedInputRecordSha256;sources=$ReviewedSourcesPath;sourcesSha256=$ExpectedReviewedSourcesSha256;runId=$spec.Input.runId;startedUtc=[DateTimeOffset]::UtcNow.ToString('o')})
 [Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal
 $adapter={param($action,$request,$s)if($action -ceq 'Observe'){return Get-SequenceObservation};Invoke-SequenceChild $request $s}
 Invoke-SequenceCore $spec $adapter
}
Export-ModuleMember -Function Invoke-AzuriteCapabilitiesSequence
