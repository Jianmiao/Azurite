#requires -Version 5.1
param([Parameter(Mandatory)][string]$RequestPath,[Parameter(Mandatory)][string]$RequestSha,[Parameter(Mandatory)][string]$ReplyPath,[Parameter(Mandatory)][string]$ExpectedModuleSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
if($PSScriptRoot -cne ($repo+'\tools\headless')){throw 'Fixed plain child directory required'}
$modulePath=$PSScriptRoot+'\AzuriteCapabilitiesSequence.psm1'
$moduleBytes=[IO.File]::ReadAllBytes($modulePath);$hash=[Security.Cryptography.SHA256]::Create();try{$moduleSha=([BitConverter]::ToString($hash.ComputeHash($moduleBytes))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()}
if($ExpectedModuleSha256 -cnotmatch '\A[a-f0-9]{64}\z' -or $moduleSha -cne $ExpectedModuleSha256){throw 'Externally pinned sequence module differs'}
$sequenceModule=Import-Module $modulePath -PassThru -DisableNameChecking
function Assert-Sequence($a,[string]$b){& $sequenceModule {param($a,$b)Assert-Sequence $a $b} $a $b}
function Read-SequenceJson([string]$p,[string]$h,[long]$n=67108864){& $sequenceModule {param($p,$h,$n)Read-SequenceJson $p $h $n} $p $h $n}
function ConvertFrom-SequenceJson([string]$t){& $sequenceModule {param($t)ConvertFrom-SequenceJson $t} $t}
function Get-SequencePin([string]$p){& $sequenceModule {param($p)Get-SequencePin $p} $p}
function Get-SequenceInputPin($p){& $sequenceModule {param($p)Get-SequenceInputPin $p} $p}
function Write-SequenceJson([string]$p,$v){& $sequenceModule {param($p,$v)Write-SequenceJson $p $v} $p $v}
function Get-SequenceAssembleParameters($r,[string]$p){& $sequenceModule {param($r,$p)Get-SequenceAssembleParameters $r $p} $r $p}
function Get-SequencePrepareParameters($r){& $sequenceModule {param($r)Get-SequencePrepareParameters $r} $r}
function Get-SequenceRuntimeParameters($r){& $sequenceModule {param($r)Get-SequenceRuntimeParameters $r} $r}
function New-SequenceApproval($p,$f,$g,$t,$e,$n){& $sequenceModule {param($p,$f,$g,$t,$e,$n)New-SequenceApproval $p $f $g $t $e $n} $p $f $g $t $e $n}
function Project-SequenceReceipts($b,$r,$a,$d){& $sequenceModule {param($b,$r,$a,$d)Project-SequenceReceipts $b $r $a $d} $b $r $a $d}
$r=Read-SequenceJson $RequestPath $RequestSha
$packet=$null;$primary=$null;$secondary=[Collections.Generic.List[string]]::new();$producerStarted=$false
try{
 & $sequenceModule {param($r)Assert-Sequence ($r.stage -cin $script:SequenceStages) 'Fixed child stage required';Assert-SequenceSourcePins ([pscustomobject]@{SourceRows=@($r.sources.PSObject.Properties.Value)})} $r
 [Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal
 # Public producers execute here in a plain script session, not a module scope.
 $script:SequenceRepo=$repo

 $files=[ordered]@{};$raw=$null;$stageError=$null;$exitCode=0;$sources=$r.sources;$runId=$r.runId
 $producerStarted=$true
 switch($r.stage){
  Capture {
   $global:LASTEXITCODE=0;$text=(& $sources.Capture.path -RunId $runId -HarmlessReceiptPath $r.input.harmless.path -HarmlessReceiptSha256 $r.input.harmless.sha256)-join "`n";$exitCode=$LASTEXITCODE;[Console]::Out.WriteLine($text);$summary=ConvertFrom-SequenceJson $text
   if($summary.PSObject.Properties['result']){$files.CaptureResult=$summary.result;$raw=Read-SequenceJson $summary.result.path $summary.result.sha256;foreach($pair in @(@('Identity','originalIdentity'),@('Scope','sharedScope'),@('Before','sharedBefore'))){if($raw.PSObject.Properties[$pair[1]]){$files[$pair[0]]=$raw.($pair[1])}}}else{$raw=$summary}
  }
  Warm {
   $capture=$r.prior.Capture;$parameters=@{Repo=$script:SequenceRepo;RunId=$runId;BaselineCaptureResultPath=$r.input.baselineCapture.path;ExpectedBaselineCaptureResultSha256=$r.input.baselineCapture.sha256;BuildDirectory=(Split-Path -Parent $sources.WarmManifest.path);ReviewedSourceIndexSha256=$sources.WarmIndex.sha256;ReviewedBuildManifestSha256=$sources.WarmManifest.sha256;HarmlessReceiptPath=$r.input.harmless.path;HarmlessReceiptSha256=$r.input.harmless.sha256;SharedBeforePath=$capture.files.Before.path;SharedBeforeSha256=$capture.files.Before.sha256;DotnetPath=$sources.Dotnet.path;DotnetSha256=$sources.Dotnet.sha256;Execute=$true}
   # Isolated child scope makes the existing collector's output local observable
   # without replacing its public workflow or adding an output override.
   $output=$null
   try{. $sources.Warm.path @parameters}catch{$stageError=$_.Exception.ToString();$exitCode=1}
   if($output){foreach($pair in @(@('CaptureResult','capture-result.json'),@('Preflight','preflight-warm-order.json'),@('WarmResult','warm-stamp-result.json'))){$p=Join-Path $output $pair[1];if(Test-Path -LiteralPath $p){$files[$pair[0]]=Get-SequencePin $p}};if($files.Contains('CaptureResult')){$raw=Read-SequenceJson $files.CaptureResult.path $files.CaptureResult.sha256}}
  }
  Assemble {
   $map=[ordered]@{'RestrictedCliCore.psm1'='Core';'RestrictedCliNative.cs'='NativeSource';'RestrictedCliFullRestricted.cs'='FullNativeSource';'RestrictedCliNative.dll'='RuntimeNative';'RestrictedCliBootstrap.ps1'='Bootstrap';'CurrentAccountCli.psm1'='Current';'HeadlessCore.psm1'='Headless';'FullRestrictedCapabilitiesRuntime.psm1'='RuntimePolicy';'FullRestrictedCapabilitiesPlan.psm1'='Planner';'FullRestrictedStageFileSecurity.dll'='FileHelper';'helper-build.json'='FileHelperBuild';'tooling-manifest.json'='ToolingManifest'}
   $sourceRows=@(foreach($name in $map.Keys){$pin=$sources.($map[$name]);[pscustomobject]@{name=$name;path=$pin.path;sha256=$pin.sha256}})
   $complete=[ordered]@{schema=1;scope='fixed-F-capabilities-preapproval-inputs';evidenceClass='reviewed-real';runId=$runId;baseline=[ordered]@{identity=(Get-SequenceInputPin $r.baselineIdentity);capture=(Get-SequenceInputPin $r.input.baselineCapture)};harmless=(Get-SequenceInputPin $r.input.harmless);preflight=(Get-SequenceInputPin $r.prior.Warm.files.Preflight);shared=[ordered]@{scope=(Get-SequenceInputPin $r.prior.Capture.files.Scope);before=(Get-SequenceInputPin $r.prior.Capture.files.Before)};originalIdentity=(Get-SequenceInputPin $r.prior.Capture.files.Identity);helperSource=(Get-SequenceInputPin $sources.FileHelperSource);sources=$sourceRows;intentValidUntilUtc=$r.input.intentValidUntilUtc;runtimeTimeoutSeconds=$r.input.runtimeTimeoutSeconds}
   if($r.input.PSObject.Properties['startupDiagnostic']){$complete.startupDiagnostic=$r.input.startupDiagnostic}
   $inputPin=Write-SequenceJson (Join-Path $r.sequenceRoot 'complete-input.json') $complete
   $assemblyParameters=Get-SequenceAssembleParameters $r $inputPin.path;$graph=$assemblyParameters.OutputDirectory
   $text=(& $sources.Inputs.path @assemblyParameters)-join "`n";[Console]::Out.WriteLine($text);$raw=ConvertFrom-SequenceJson $text
   if($raw.inputReady){foreach($pair in @(@('Facts','facts.json'),@('Plan','plan.json'),@('SourceManifest','source-manifest.json'),@('Control','control.json'),@('Gate','gate.json'))){$files[$pair[0]]=Get-SequencePin (Join-Path $graph $pair[1])}};$files.CompleteInput=$inputPin
  }
  Approval {
   $a=$r.prior.Assemble;$plan=Read-SequenceJson $a.files.Plan.path $a.files.Plan.sha256;$facts=Read-SequenceJson $a.files.Facts.path $a.files.Facts.sha256
   $raw=New-SequenceApproval $plan $facts $a.files.Gate.sha256 $sources.ToolingManifest.sha256 $r.input.intentValidUntilUtc ([DateTimeOffset]::UtcNow)
   $files.Approval=Write-SequenceJson (Join-Path $r.sequenceRoot 'one-capabilities-approval.json') $raw
   $files.Authority=Write-SequenceJson (Join-Path $r.sequenceRoot 'approval-authority.json') ([ordered]@{scope='root-authorized-fixed-sequence-approval-issuance';runId=$runId;trustedInput=$r.authorityInput;reviewedSourcesSha256=$r.input.sourcesSha256;approvalSha256=$files.Approval.sha256;issuedUtc=$raw.issuedUtc;priorObservationsRewritten=$false})
  }
  {$_ -cin @('PreparePlan','Apply')} {
   $parameters=Get-SequencePrepareParameters $r
   if($r.stage -ceq 'Apply'){$parameters.Apply=$true;$parameters.EvidenceDirectory=Join-Path $script:SequenceRepo ('artifacts\aa-fr-transition-preparation\sequence-'+$runId)}
   Import-Module $sources.Stage.path -Force -DisableNameChecking
   $returned=Invoke-AzuriteStageTransitionPreparation @parameters
   if($r.stage -ceq 'Apply'){
    foreach($pair in @(@('PreparationResult','preparation-result.json'),@('ReceiptBundle','receipt-bundle.json'),@('LeaseRelease','lease-release.json'))){$p=Join-Path $parameters.EvidenceDirectory $pair[1];if(Test-Path -LiteralPath $p){$files[$pair[0]]=Get-SequencePin $p}}
    $raw=[pscustomobject]@{Success=$returned.Success;Prepared=$returned.Prepared;SealRestored=$returned.SealRestored;LeaseState=$returned.LeaseState;Quarantined=$returned.Quarantined;Error=$returned.Error;RuntimeAllowed=$returned.RuntimeAllowed;WillLaunch=$returned.WillLaunch}
   }else{$raw=$returned}
  }
  Projection {
   $pin=$r.prior.Apply.files.ReceiptBundle;$bundle=Read-SequenceJson $pin.path $pin.sha256
   $files=Project-SequenceReceipts $bundle $runId $r.prior.Approval.files.Approval.sha256 (Join-Path $r.sequenceRoot 'runtime-inputs')
   $raw=[pscustomobject]@{Ready=$bundle.Plan.Ready;runId=$runId;approvalSha256=$bundle.Admission.approvalSha256;PreparationLeaseReleased=$bundle.PreparationLeaseReleased;RequiresFreshRuntimeLease=$bundle.RequiresFreshRuntimeLease}
  }
  {$_ -cin @('RuntimePlan','Runtime')} {
   $parameters=Get-SequenceRuntimeParameters $r
   if($r.stage -ceq 'RuntimePlan'){$parameters.PlanOnly=$true;$raw=& $sources.Runtime.path @parameters}
   else{
    $evidenceRoot=Join-Path $script:SequenceRepo 'artifacts\aa-fr-capabilities-runtime';$old=@(Get-ChildItem -LiteralPath $evidenceRoot -Directory|ForEach-Object FullName)
    try{$raw=& $sources.Runtime.path @parameters}catch{$stageError=$_.Exception.ToString();$exitCode=1}
    $matches=@(foreach($dir in Get-ChildItem -LiteralPath $evidenceRoot -Directory){if($dir.FullName -cnotin $old){$path=Join-Path $dir.FullName 'controller-final.json';if(Test-Path -LiteralPath $path){$pin=Get-SequencePin $path;$body=Read-SequenceJson $pin.path $pin.sha256;if($body.runId -ceq $runId){[pscustomobject]@{pin=$pin;body=$body}}}}})
    Assert-Sequence ($matches.Count -eq 1) 'Exactly one same-run actual runtime final outcome required';$files.ControllerFinal=$matches[0].pin;$raw=$matches[0].body
   }
  }
  default {throw 'Unknown fixed sequence stage'}
 }
 if($raw -and $r.stage -cne 'Apply'){$rawPin=Write-SequenceJson (Join-Path $r.sequenceRoot ($r.stage+'-raw-result.json')) $raw;if($files -is [Collections.IDictionary]){$files['RawResult']=$rawPin}else{$files|Add-Member -NotePropertyName RawResult -NotePropertyValue $rawPin}}
 $packet=[pscustomobject]@{stage=$r.stage;runId=$runId;childExitCode=$exitCode;stageError=$stageError;raw=$raw;files=[pscustomobject]$files}

}catch{$primary=$_.Exception.ToString()}
finally{try{& $sequenceModule {param($r)Assert-SequenceSourcePins ([pscustomobject]@{SourceRows=@($r.sources.PSObject.Properties.Value)})} $r}catch{if(-not $primary){$primary=$_.Exception.ToString()}else{$secondary.Add($_.Exception.ToString())}}}
& $sequenceModule {param($r,$p,$e,$s,$o,$started)Complete-SequenceChildExecution $r $p $e $s $o $started} $r $packet $primary $secondary.ToArray() $ReplyPath $producerStarted
