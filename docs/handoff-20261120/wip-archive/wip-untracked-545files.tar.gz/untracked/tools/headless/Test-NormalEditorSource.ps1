#requires -Version 7.2
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$AAInstallPath,
    [Parameter(Mandatory)][string]$EvidenceRoot,
    [Parameter(Mandatory)][string]$CFixtureRoot
)

$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))

function Get-CanonicalLocalPath([string]$Path) {
    if (![IO.Path]::IsPathFullyQualified($Path) -or $Path.StartsWith('\\') -or
        $Path.Contains('/') -or $Path.Length -lt 4 -or $Path[1] -ne ':' -or
        $Path.Substring(2).Contains(':') -or
        ![string]::Equals([IO.Path]::GetFullPath($Path), $Path, [StringComparison]::OrdinalIgnoreCase)) {
        throw "An explicit canonical local path is required: $Path"
    }
    foreach ($part in $Path.Substring(3).Split('\')) {
        if (!$part -or $part -in @('.', '..') -or $part.EndsWith(' ') -or $part.EndsWith('.')) {
            throw "Path aliases are not permitted: $Path"
        }
    }
    for ($current = $Path; $current; $current = [IO.Path]::GetDirectoryName($current)) {
        if ((Test-Path -LiteralPath $current) -and
            ((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw "Reparse paths are not permitted: $current"
        }
    }
    return $Path
}

function Test-Within([string]$Child, [string]$Parent) {
    return [string]::Equals($Child, $Parent, [StringComparison]::OrdinalIgnoreCase) -or
        $Child.StartsWith($Parent.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)
}

$aa = Get-CanonicalLocalPath $AAInstallPath
$evidence = Get-CanonicalLocalPath $EvidenceRoot
$cFixtures = Get-CanonicalLocalPath $CFixtureRoot
if (!(Test-Path -LiteralPath $aa -PathType Container)) { throw "Missing explicit AA input directory: $aa" }
if (!$cFixtures.StartsWith('C:\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'The existing journal-consumer archive policy requires a fresh C fixture root.'
}
foreach ($path in @($evidence, $cFixtures)) {
    if ((Test-Path -LiteralPath $path) -or (Test-Within $path $repo) -or (Test-Within $path $aa) -or
        (Test-Within $repo $path) -or (Test-Within $aa $path)) {
        throw "Use a fresh external evidence/fixture directory separate from source and host: $path"
    }
}
if ((Test-Within $evidence $cFixtures) -or (Test-Within $cFixtures $evidence)) {
    throw 'Evidence and C fixtures must be separate fresh directories.'
}

New-Item -ItemType Directory -Path $evidence, $cFixtures | Out-Null
$logs = New-Item -ItemType Directory -Path (Join-Path $evidence 'logs')
$buildRoot = Join-Path $evidence 'build'
$fixtureRoot = New-Item -ItemType Directory -Path (Join-Path $evidence 'fixtures')
$results = [Collections.Generic.List[object]]::new()
$builds = @{}

$sourceDirectories = @('CacheRoot.Core', 'EditorIsolation.Policy') +
    @(Get-ChildItem -LiteralPath (Join-Path $repo 'AcceptanceHarness') -Directory -Filter 'NormalEditor*' | ForEach-Object Name)
$sourceManifest = foreach ($directory in $sourceDirectories) {
    Get-ChildItem -LiteralPath (Join-Path $repo "AcceptanceHarness/$directory") -File -Recurse |
        Where-Object { $_.Extension -in @('.cs', '.csproj', '.json') -and $_.FullName -notmatch '[\\/](bin|obj)[\\/]' } |
        ForEach-Object { [ordered]@{ path = [IO.Path]::GetRelativePath($repo, $_.FullName); bytes = $_.Length; sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() } }
}
$sourceManifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'source-manifest.json') -Encoding utf8

$hostRelativePaths = @(
    'core/0Harmony.dll', 'core/BepInEx.Core.dll', 'core/BepInEx.Preloader.Core.dll', 'core/BepInEx.Unity.IL2CPP.dll',
    'core/Il2CppInterop.Common.dll', 'core/Il2CppInterop.Runtime.dll', 'core/Mono.Cecil.dll', 'core/MonoMod.RuntimeDetour.dll',
    'interop/Assembly-CSharp.dll', 'interop/Il2Cppmscorlib.dll', 'interop/UnityEngine.CoreModule.dll',
    'interop/Unity.Addressables.dll', 'interop/Unity.ResourceManager.dll'
)
$hostInputs = foreach ($relative in $hostRelativePaths) {
    $path = Join-Path $aa "BepInEx/$relative"
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing explicit host input: $path" }
    [ordered]@{ path = $path; bytes = (Get-Item -LiteralPath $path).Length; sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$hostInputs | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $evidence 'host-inputs.json') -Encoding utf8

function Invoke-Dotnet([string]$Name, [string]$Tier, [string[]]$Arguments, [string]$ExpectedFailurePattern = '') {
    $log = Join-Path $logs.FullName "$Name.log"
    $started = [DateTime]::UtcNow
    & dotnet @Arguments *> $log
    $exitCode = $LASTEXITCODE
    $content = Get-Content -LiteralPath $log -Raw
    $passed = $null
    $failed = $null
    if ($content -match 'RESULT passed=(\d+) failed=(\d+)') {
        $passed = [int]$Matches[1]
        $failed = [int]$Matches[2]
    } elseif ($content -match '"checks":(\d+),"failed":(\d+)') {
        $failed = [int]$Matches[2]
        $passed = [int]$Matches[1] - $failed
    }
    $accepted = if ($ExpectedFailurePattern) { $exitCode -ne 0 -and $content -match $ExpectedFailurePattern } else { $exitCode -eq 0 }
    $row = [pscustomobject]@{
        name = $Name; tier = $Tier; command = 'dotnet'; arguments = $Arguments; exitCode = $exitCode
        accepted = $accepted; passed = $passed; failed = $failed; expectedFailurePattern = $ExpectedFailurePattern
        log = $log; elapsedSeconds = ([DateTime]::UtcNow - $started).TotalSeconds
    }
    $results.Add($row)
    $results | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $evidence 'command-results.json') -Encoding utf8
    Write-Host "$Name : exit=$exitCode accepted=$accepted passed=$passed failed=$failed"
    return $row
}

function Get-Project([string]$Name) { Join-Path $repo "AcceptanceHarness/$Name/$Name.csproj" }
function Get-TestDll([string]$Name) { Join-Path $buildRoot "bin/$Name/release/$Name.dll" }
function Get-HostDll([string]$Name) { Join-Path $buildRoot "bin/$Name/release/Azurite.$Name.PreparationOnly.dll" }

$entries = @('NormalEditor.Loader.Tests', 'NormalEditor.Entry.Tests', 'NormalEditor.Entry.Evidence.Tests',
    'NormalEditor.Entry.Shutdown.Tests', 'NormalEditor.Adapter.Tests', 'NormalEditor.Loader',
    'NormalEditor.Loader.Guard', 'NormalEditor.Loader.Routes.Tests', 'NormalEditor.Tests')
foreach ($name in $entries) {
    $builds[$name] = Invoke-Dotnet "build-$name" 'source-build' @('build', (Get-Project $name), '-c', 'Release',
        '--artifacts-path', $buildRoot, '--disable-build-servers', '-m:1', "-p:AAInstallPath=$aa")
}

$controls = @(
    @{ name = 'missing-host-parameter'; project = 'NormalEditor.Loader.Guard'; property = '-p:AAInstallPath='; pattern = 'Supply AAInstallPath explicitly' },
    @{ name = 'missing-host-files'; project = 'NormalEditor.Loader.Guard'; property = "-p:AAInstallPath=$(Join-Path $evidence 'absent-host')"; pattern = 'Missing explicit host input' },
    @{ name = 'missing-metadata-parameter'; project = 'NormalEditor.Entry.Tests'; property = '-p:AAInstallPath='; pattern = 'Supply AAInstallPath explicitly' }
)
foreach ($control in $controls) {
    $null = Invoke-Dotnet $control.name 'missing-prerequisite-negative-control' @('build', (Get-Project $control.project),
        '-c', 'Release', '--artifacts-path', (Join-Path $evidence "controls/$($control.name)"),
        '--disable-build-servers', '-m:1', $control.property) $control.pattern
}

$jobs = @(
    @{ name = 'entry-pure'; project = 'NormalEditor.Entry.Tests'; tier = 'pure-managed'; extra = @() },
    @{ name = 'entry-metadata'; project = 'NormalEditor.Entry.Tests'; tier = 'managed-and-readonly-pe-metadata'; extra = @($aa, (Get-HostDll 'NormalEditor.Entry.Host')); requires = @('NormalEditor.Loader') },
    @{ name = 'entry-evidence'; project = 'NormalEditor.Entry.Evidence.Tests'; tier = 'managed-c-archive-fixtures'; extra = @((Join-Path $cFixtures 'evidence')) },
    @{ name = 'entry-shutdown'; project = 'NormalEditor.Entry.Shutdown.Tests'; tier = 'managed-windows-file-fixtures'; extra = @((Join-Path $cFixtures 'shutdown')) },
    @{ name = 'shutdown-metadata'; project = 'NormalEditor.Entry.Shutdown.Tests'; tier = 'readonly-pe-metadata'; extra = @('--metadata', (Get-HostDll 'NormalEditor.Entry.Host'), (Get-HostDll 'NormalEditor.Adapter.Host')); requires = @('NormalEditor.Loader') },
    @{ name = 'adapter'; project = 'NormalEditor.Adapter.Tests'; tier = 'managed-windows-file-fixtures-and-pe-metadata'; extra = @((Join-Path $fixtureRoot.FullName 'adapter'), $aa, (Get-HostDll 'NormalEditor.Adapter.Host')); requires = @('NormalEditor.Loader') },
    @{ name = 'loader'; project = 'NormalEditor.Loader.Tests'; tier = 'managed-windows-file-fixtures'; extra = @((Join-Path $fixtureRoot.FullName 'loader')) },
    @{ name = 'routes'; project = 'NormalEditor.Loader.Routes.Tests'; tier = 'managed-file-fixtures-and-pe-metadata'; extra = @((Join-Path $fixtureRoot.FullName 'routes'), $aa) },
    @{ name = 'normal-policy'; project = 'NormalEditor.Tests'; tier = 'windows-filesystem-fixtures-with-frozen-policy-gate'; extra = @((Join-Path $fixtureRoot.FullName 'normal-policy')) }
)
foreach ($job in $jobs) {
    $required = @($job.project) + @($job.requires)
    if (@($required | Where-Object { $_ -and !$builds[$_].accepted }).Count) {
        $results.Add([pscustomobject]@{ name = $job.name; tier = $job.tier; accepted = $false; executed = $false; reason = 'Required source build failed; see retained build log.' })
        continue
    }
    $null = Invoke-Dotnet $job.name $job.tier (@((Get-TestDll $job.project)) + $job.extra)
}

$hostUnchanged = $true
foreach ($input in $hostInputs) {
    if ((Get-FileHash -LiteralPath $input.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $input.sha256) { $hostUnchanged = $false }
}
$cFixtureBytes = [long](Get-ChildItem -LiteralPath $cFixtures -File -Recurse | Measure-Object -Property Length -Sum).Sum
$cFixtureBounded = $cFixtureBytes -lt 50MB
$allAccepted = @($results | Where-Object { !$_.accepted }).Count -eq 0 -and $hostUnchanged -and $cFixtureBounded
$summary = [ordered]@{
    schemaVersion = 1; sourceRoot = $repo; evidenceRoot = $evidence; cFixtureRoot = $cFixtures
    cFixtureBytes = $cFixtureBytes; cFixtureLimitBytes = 50MB; cFixtureBounded = $cFixtureBounded
    aaInstallPath = $aa; hostInputBytesUnchanged = $hostUnchanged; sourceOnly = $true
    nativeHostExecuted = $false; releaseEligible = $false; allCommandsAccepted = $allAccepted
    commandCount = $results.Count; commands = @($results)
}
$summary | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $evidence 'summary.json') -Encoding utf8
Write-Host "Summary: $(Join-Path $evidence 'summary.json')"
if (!$allAccepted) { exit 1 }
exit 0
