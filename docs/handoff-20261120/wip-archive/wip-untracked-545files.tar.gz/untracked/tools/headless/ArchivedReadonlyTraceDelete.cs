using System;
using System.IO;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using Microsoft.Win32.SafeHandles;

namespace Azurite.Recovery {
 public static class ArchivedReadonlyTraceDelete {
  [StructLayout(LayoutKind.Sequential)] struct FT { public uint Low,High; }
  [StructLayout(LayoutKind.Sequential)] struct FI { public uint Attributes;public FT Creation,Access,Write;public uint Volume,SizeHigh,SizeLow,Links,IdHigh,IdLow; }
  [StructLayout(LayoutKind.Sequential)] struct Basic {public long Creation,Access,Write,Change;public uint Attributes;}
  [StructLayout(LayoutKind.Sequential)] struct Disposition {[MarshalAs(UnmanagedType.U1)]public bool Delete;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern SafeFileHandle CreateFileW(string p,uint access,uint share,IntPtr sa,uint creation,uint flags,IntPtr template);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(SafeFileHandle h,out FI info);
  [DllImport("kernel32.dll",SetLastError=true,EntryPoint="SetFileInformationByHandle")]static extern bool SetBasic(SafeFileHandle h,int kind,ref Basic info,uint size);
  [DllImport("kernel32.dll",SetLastError=true,EntryPoint="SetFileInformationByHandle")]static extern bool SetDisposition(SafeFileHandle h,int kind,ref Disposition info,uint size);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern uint GetFinalPathNameByHandleW(SafeFileHandle h,StringBuilder b,uint count,uint flags);
  [DllImport("advapi32.dll")]static extern uint GetSecurityInfo(SafeFileHandle h,uint kind,uint sections,out IntPtr owner,out IntPtr group,out IntPtr dacl,out IntPtr sacl,out IntPtr descriptor);
  [DllImport("advapi32.dll")]static extern uint GetSecurityDescriptorLength(IntPtr descriptor);
  [DllImport("kernel32.dll")]static extern IntPtr LocalFree(IntPtr p);
  static void Need(bool value,string why){if(!value)throw new InvalidOperationException(why);}
  static FI Info(SafeFileHandle h){FI i;if(!GetFileInformationByHandle(h,out i))throw new Win32Exception(Marshal.GetLastWin32Error());return i;}
  static string Id(FI i){return i.Volume.ToString("x8")+"00000000"+i.IdHigh.ToString("x8")+i.IdLow.ToString("x8");}
  static string Descriptor(SafeFileHandle h){IntPtr o,g,d,s,p;uint error=GetSecurityInfo(h,1,7,out o,out g,out d,out s,out p);if(error!=0)throw new Win32Exception((int)error);try{byte[] b=new byte[GetSecurityDescriptorLength(p)];Marshal.Copy(p,b,0,b.Length);return new RawSecurityDescriptor(b,0).GetSddlForm(AccessControlSections.Owner|AccessControlSections.Group|AccessControlSections.Access);}finally{LocalFree(p);}}
  static string Final(SafeFileHandle h){var b=new StringBuilder(32768);uint n=GetFinalPathNameByHandleW(h,b,(uint)b.Capacity,1);if(n==0||n>=b.Capacity)throw new Win32Exception(Marshal.GetLastWin32Error());return b.ToString();}
  static string Hash(FileStream stream){stream.Position=0;using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(stream)).Replace("-","").ToLowerInvariant();}
  public static void Delete(string path,string runId,string identity,string sddl,string sha256,long bytes,uint expectedAttributes){
   Need(runId!=null&&System.Text.RegularExpressions.Regex.IsMatch(runId,"\\A[a-f0-9]{32}\\z")&&runId!=new string('0',32),"Explicit canonical run required");
   Need(path!=null&&Path.GetFullPath(path)==path&&path.IndexOf(':',2)<0&&path.EndsWith("\\runs\\restricted-"+runId+"\\history\\post-run\\startup-exceptions.nettrace",StringComparison.Ordinal),"Only exact run startup trace history may clear readonly");
   Need(expectedAttributes==33&&bytes>0&&bytes<=4194304&&sha256!=null&&System.Text.RegularExpressions.Regex.IsMatch(sha256,"\\A[a-f0-9]{64}\\z"),"Exact ReadOnly|Archive and bounded archived payload required");
   using(var handle=CreateFileW(path,0x80030100,1,IntPtr.Zero,3,0x00200000,IntPtr.Zero)){
    if(handle.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());var initial=Info(handle);string final=Final(handle);int end=final.IndexOf("}\\",StringComparison.Ordinal);
    Need(initial.Attributes==expectedAttributes&&initial.Links==1&&Id(initial)==identity&&(((long)initial.SizeHigh<<32)|initial.SizeLow)==bytes&&Descriptor(handle)==sddl,"Readonly trace identity/attributes/descriptor/length drift");
    Need(end>0&&final==final.Substring(0,end+2)+path.Substring(3),"Readonly trace canonical final path differs");
    using(var stream=new FileStream(handle,FileAccess.Read,65536,false)){
     Need(Hash(stream)==sha256,"Readonly trace archived payload differs");var before=Info(handle);Need(before.Attributes==33&&Id(before)==identity&&Descriptor(handle)==sddl,"Readonly trace changed before attribute update");
     bool attributesCleared=false;
     try {
      var basic=new Basic{Attributes=32};if(!SetBasic(handle,0,ref basic,(uint)Marshal.SizeOf(typeof(Basic))))throw new Win32Exception(Marshal.GetLastWin32Error());
      attributesCleared=true;
      var after=Info(handle);Need(after.Attributes==32&&after.Links==1&&Id(after)==identity&&after.SizeHigh==before.SizeHigh&&after.SizeLow==before.SizeLow&&after.Write.High==before.Write.High&&after.Write.Low==before.Write.Low&&Descriptor(handle)==sddl&&Final(handle)==final&&Hash(stream)==sha256,"Readonly-only update readback differs");
      var disposition=new Disposition{Delete=true};if(!SetDisposition(handle,4,ref disposition,(uint)Marshal.SizeOf(typeof(Disposition))))throw new Win32Exception(Marshal.GetLastWin32Error(),"Readonly update was attempted; deletion failed. Inspect ObservedAttributes before any separately reviewed action.");
     } catch(Exception error) {
      error.Data["ReadonlyUpdateAttempted"]=true;
      error.Data["AttributesCleared"]=attributesCleared;
      try {error.Data["ObservedAttributes"]=Info(handle).Attributes;} catch {error.Data["ObservedAttributes"]="unknown";}
      error.Data["AutomaticRetryAllowed"]=false;
      throw;
     }
    }
   }
  }
 }
}
