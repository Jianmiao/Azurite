Set-StrictMode -Version Latest
# Import and Plan read only the six pinned C records. No Stage/runtime import,
# native type loading, process enumeration, registry or F access occurs in Plan.
$script:RecoveryRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$script:RecoveryRoot='F:\AzuriteLabs\Editor-20261108-normal'
$script:RecoveryRun='2fc0eb21404d4efaaf527c07c295d147'
$script:RecoveryOwner='S-1-5-21-222280291-4039000738-1914192245-1001'
$script:RecoveryVolume='\\?\Volume{a7c77c39-d000-4faf-bbf8-cc8ca0c743cb}\'
$script:RecoveryRetained=[Collections.Generic.List[object]]::new()
$script:RecoveryTokenType=$null
function Assert-Recovery($Condition,[string]$Message){if(-not $Condition){throw $Message}}
function Get-RecoveryHash([byte[]]$Bytes){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function ConvertTo-RecoveryJson($Value){ConvertTo-Json -InputObject $Value -Depth 95 -Compress}
function ConvertFrom-RecoveryJson([byte[]]$Bytes){$t=[Text.UTF8Encoding]::new($false,$true).GetString($Bytes);if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){return ($t|ConvertFrom-Json -DateKind String -ErrorAction Stop)};$t|ConvertFrom-Json -ErrorAction Stop}
function Assert-RecoveryCPath([string]$Path,[bool]$MustExist=$true){
 Assert-Recovery ($Path -cmatch '^C:\\' -and [IO.Path]::GetFullPath($Path) -ceq $Path -and $Path.Substring(2) -notmatch ':') 'Recovery input/evidence must use an exact absolute C path'
 $cursor=$Path
 while($cursor){if([IO.File]::Exists($cursor) -or [IO.Directory]::Exists($cursor)){$i=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop;Assert-Recovery (-not ($i.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'C recovery ancestry has a reparse point'}elseif($MustExist -or $cursor -cne $Path){throw ('C recovery path/parent missing: '+$cursor)};$cursor=[IO.Path]::GetDirectoryName($cursor)}
}
function Read-RecoveryPinnedC([string]$Path,[string]$Sha256,[long]$Maximum=8388608){
 Assert-Recovery ($Sha256 -cmatch '^[a-f0-9]{64}$') 'Reviewed C digest required';Assert-RecoveryCPath $Path
 $s=[IO.FileStream]::new($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
 try{Assert-Recovery ($s.Length -le $Maximum) 'Pinned C source exceeds finite bound';$m=[IO.MemoryStream]::new();try{$s.CopyTo($m);$b=$m.ToArray();Assert-Recovery ($b.Length -eq $s.Length -and $b.Length -le $Maximum -and (Get-RecoveryHash $b) -ceq $Sha256) ('Pinned C evidence differs: '+[IO.Path]::GetFileName($Path));return ,$b}finally{$m.Dispose()}}finally{$s.Dispose()}
}
function Assert-RecoveryObject($Object,$Expected){
 Assert-Recovery ($null -ne $Object) ('Missing recorded object: '+$Expected.path)
 foreach($k in @('path','identity','volume','owner','directory','finalPath','sddl')){Assert-Recovery ($Object.$k -ceq $Expected.$k) ('Recovery object drift ('+$k+'): '+$Expected.path)}
 Assert-Recovery (-not $Object.reparse -and $Object.finalPath -ceq $Object.path -and $Object.identity -cmatch '^[a-f0-9]{32}$' -and ($Object.directory -or $Object.links -eq 1)) ('Unsafe recorded object: '+$Expected.path)
 if(-not $Object.directory){Assert-Recovery ($Object.bytes -eq $Expected.bytes -and $Object.sha256 -ceq $Expected.sha256) ('Recovery payload drift: '+$Expected.path)}
}
function Get-RecoveryObjectMap($Objects){$map=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal);$ids=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal);foreach($o in $Objects){Assert-Recovery (-not $map.ContainsKey($o.path) -and $ids.Add($o.identity)) 'Duplicate recovery path/object identity';Assert-RecoveryObject $o $o;$map.Add($o.path,$o)};return ,$map}
function Get-AzuritePreparationRecoveryPlan {
 [CmdletBinding()]param([string]$RecoveryEvidenceManifestPath,[string]$ExpectedRecoveryEvidenceManifestSha256,[switch]$PostNativeCleanupRecovery,[switch]$ClosedFailedRuntimeRecovery,[string]$RunId)
 if($ClosedFailedRuntimeRecovery){Assert-Recovery (-not $PostNativeCleanupRecovery) 'Recovery scopes are mutually exclusive';return Get-ClosedFailedRecoveryPlan $RunId $RecoveryEvidenceManifestPath $ExpectedRecoveryEvidenceManifestSha256}
 Assert-Recovery (-not $PSBoundParameters.ContainsKey('RunId')) 'Explicit RunId requires ClosedFailedRuntimeRecovery'
 $external=$PSBoundParameters.ContainsKey('RecoveryEvidenceManifestPath') -or $PSBoundParameters.ContainsKey('ExpectedRecoveryEvidenceManifestSha256')
 if($PostNativeCleanupRecovery){Assert-Recovery $external 'Post-native cleanup recovery requires separately bound evidence'}
 if($external){Assert-Recovery ($PSBoundParameters.ContainsKey('RecoveryEvidenceManifestPath') -and $PSBoundParameters.ContainsKey('ExpectedRecoveryEvidenceManifestSha256') -and -not [string]::IsNullOrWhiteSpace($RecoveryEvidenceManifestPath) -and -not [string]::IsNullOrWhiteSpace($ExpectedRecoveryEvidenceManifestSha256)) 'Recovery evidence manifest path and reviewed digest must be supplied together';Assert-Recovery ($ExpectedRecoveryEvidenceManifestSha256 -cmatch '^[a-f0-9]{64}$' -and $ExpectedRecoveryEvidenceManifestSha256 -cne ('0'*64)) 'Reviewed recovery evidence digest must be nonzero canonical lowercase SHA-256'}
 $folder=Join-Path $script:RecoveryRepo 'artifacts\aa-fr-transition-preparation\actual-22bac3419df34c5696dfe8985d1d8367'
 $pins=[ordered]@{
  result=@((Join-Path $folder 'preparation-result.json'),'d5924b43429002a0ffe96485426d67603f7959358c31a22e6e4e6a92a85d8ac1');observations=@((Join-Path $folder 'observations.json'),'f1e9ee6bd526c978ba34def8a679920f2ebd2a9e2279b5ce13bdce9171781a8c');before=@((Join-Path $folder 'before-images-raw.json'),'07dc47eb9abf86fee7691369830805e31766a57d6899132d1d0e70e516ce8815');receipt=@((Join-Path $folder 'receipt-bundle.json'),'371ca195f0ba7ab69e1eb5902034d538911bfaa505703ba39a65f9a254c6bbf3');lease=@((Join-Path $folder 'lease-release.json'),'380104b9d2a8ab585e7543d50778c1b43f689c5ef73d83186234bb02ee0b8a24');refusal=@((Join-Path $script:RecoveryRepo 'artifacts\aa-fr-capabilities-runtime\64d26f9a32a6480c8a292624aa3ab023\controller-final.json'),'dae93ebae6f5edbffef6caea32ea51b5aa36bfd7357f04d3682b0693be8cf23b')
 }
 if($external){
  $manifest=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC $RecoveryEvidenceManifestPath $ExpectedRecoveryEvidenceManifestSha256 131072)
  $labels=@('result','observations','before','receipt','lease','refusal');$scope='fixed-F-prelaunch-preparation-recovery-evidence'
  if($PostNativeCleanupRecovery){$labels+=@('preservation','comparison','inventory','archive','important','preservationInputs','sharedResult','sharedComparison');$scope='fixed-250c-post-native-cleanup-recovery-evidence'}
  Assert-Recovery ($manifest.schema -eq 1 -and $manifest.scope -ceq $scope -and @($manifest.files).Count -eq $labels.Count) 'Recovery evidence manifest shape/scope differs'
  $pins=[ordered]@{};foreach($file in $manifest.files){Assert-Recovery ($file.name -cin $labels -and -not $pins.Contains($file.name)) 'Recovery evidence manifest label is unknown or duplicated';$pins[$file.name]=@($file.path,$file.sha256)}
 }
 $v=@{};$bindings=@();foreach($key in $pins.Keys){$v[$key]=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC $pins[$key][0] $pins[$key][1]);$bindings+=,[pscustomobject]@{name=$key;path=$pins[$key][0];sha256=$pins[$key][1]}}
 $r=$v.result;$o=$v.observations;$b=$v.before;$l=$v.lease;$x=$v.refusal;$receipt=$v.receipt
 $run=if($external){$o.runId}else{$script:RecoveryRun}
 Assert-Recovery ($run -cmatch '^[a-f0-9]{32}$' -and $run -cne ('0'*32)) 'Recovery run must be canonical nonzero lowercase 32-hex'
 Assert-Recovery ($r.Success -eq $true -and $r.Prepared -eq $true -and $r.LeaseState -ceq 'released' -and -not $r.Quarantined -and $r.SealRestored -and -not $r.RuntimeAllowed -and -not $r.WillLaunch -and -not $r.Error) 'Preparation was not accepted successful/prelaunch-only'
 Assert-Recovery ($o.runId -ceq $run -and $b.runId -ceq $run -and $l.runId -ceq $run -and $x.runId -ceq $run -and $receipt.Plan.RunId -ceq $run -and $r.Observations.runId -ceq $run -and $r.ReceiptBundle.Plan.RunId -ceq $run) 'Pinned recovery run binding differs'
 Assert-Recovery ($receipt.Plan.LabRoot -ceq $script:RecoveryRoot -and $o.lease.ownerSid -ceq $script:RecoveryOwner -and $o.lease.volume -ceq $script:RecoveryVolume) 'Recovery fixed lab/owner/volume binding differs'
 Assert-Recovery ($l.releaseOutcome -ceq 'success' -and $l.leaseId -ceq $o.lease.leaseId -and $l.globalMutex -ceq 'Global\AzuriteRestrictedCli-AA' -and $receipt.PreparationLeaseReleased -eq $true -and -not $receipt.RuntimeAllowed) 'Original preparation lease is not released'
 if($PostNativeCleanupRecovery){Assert-RecoveryPostNativeDrain $x $run}else{Assert-Recovery ($x.passed -eq $false -and $null -eq $x.result -and $x.pendingCleared -eq $false -and $x.runtimeAllowed -eq $false -and $x.runtimeLeaseReleased -eq $true -and $x.runtimeMutexDisposed -eq $true -and -not $x.leaseHeld -and -not $x.ownerRetained -and -not $x.releaseError -and -not $x.disposeError) 'Runtime refusal is not the bound prelaunch outcome'}
 Assert-Recovery (@($b.objects).Count -eq 1228 -and @($b.absent).Count -eq 31 -and @($o.objects).Count -eq 1259 -and @($o.created).Count -eq 31 -and @($o.snapshots).Count -eq 1228) 'Finite accepted preparation counts differ'
 $original=Get-RecoveryObjectMap $b.objects;$prepared=Get-RecoveryObjectMap $o.objects;$snapshots=Get-RecoveryObjectMap $o.snapshots;$created=Get-RecoveryObjectMap $o.created;$absent=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($p in $b.absent){Assert-Recovery ($absent.Add($p) -and $created.ContainsKey($p) -and -not $original.ContainsKey($p)) 'Created/absent proof sets differ'}
 $payload=@();$descriptors=@();$new=@();$owner=$o.lease.ownerSid;$volume=$o.lease.volume
 foreach($old in $original.Values){Assert-RecoveryObject $snapshots[$old.path] $old;Assert-Recovery ($prepared.ContainsKey($old.path)) 'Original missing from prepared set';$now=$prepared[$old.path];foreach($k in @('identity','volume','owner','directory','finalPath')){Assert-Recovery ($old.$k -ceq $now.$k) 'Preparation replaced an original object'};if(-not $old.directory -and ($old.bytes -ne $now.bytes -or $old.sha256 -cne $now.sha256)){Assert-Recovery ($old.content) 'Changed original has no captured payload';$data=[Convert]::FromBase64String($old.content);Assert-Recovery ($data.Length -eq $old.bytes -and (Get-RecoveryHash $data) -ceq $old.sha256) 'Original payload before-image failed';$payload+=,$old};if($old.sddl -cne $now.sddl){$descriptors+=,$old}}
 foreach($p in $absent){$c=$created[$p];$now=$prepared[$p];Assert-Recovery ($now.identity -ceq $c.identity -and $now.directory -eq $c.directory -and $now.owner -ceq $owner -and $now.volume -ceq $volume) 'Created identity differs from final observation';$new+=,$now}
 foreach($item in $prepared.Values){Assert-Recovery ($item.owner -ceq $owner -and $item.volume -ceq $volume -and ($item.path -ceq 'F:\AzuriteLabs' -or $item.path -ceq 'F:\AzuriteLabs\.azurite-phase0-parent.json' -or $item.path -ceq $script:RecoveryRoot -or $item.path.StartsWith($script:RecoveryRoot+'\',[StringComparison]::Ordinal))) 'Recovery object exceeds fixed recorded scope'}
 Assert-Recovery ($payload.Count -eq 1 -and $payload[0].path -ceq ($script:RecoveryRoot+'\install\BepInEx\LogOutput.log') -and $payload[0].bytes -eq 3629 -and $descriptors.Count -eq 1221 -and @($descriptors|Where-Object directory).Count -eq 159 -and @($new|Where-Object{-not $_.directory}).Count -eq 21) 'Inverse differs from reviewed finite change set'
 $runs=$script:RecoveryRoot+'\runs';$pending=$runs+'\full-capabilities.pending.json'
 $spec=[pscustomobject][ordered]@{Schema=1;Scope='fixed-F-prelaunch-preparation-recovery';RunId=$run;EvidenceMode=$(if($external){'ExternalSixRecords'}else{'LegacyFixed22bac'});EvidenceManifestPath=$(if($external){$RecoveryEvidenceManifestPath}else{$null});EvidenceManifestSha256=$(if($external){$ExpectedRecoveryEvidenceManifestSha256}else{$null});PlanSha256=$receipt.Plan.PlanSha256;Root=$script:RecoveryRoot;OwnerSid=$owner;LogonSid=$o.lease.logonSid;Volume=$volume;PendingPath=$pending;RunsPath=$runs;Original=@($original.Values|Sort-Object path -CaseSensitive);Prepared=@($prepared.Values|Sort-Object path -CaseSensitive);Created=@($new|Sort-Object path -CaseSensitive);PayloadRestores=$payload;DescriptorRestores=@($descriptors|Sort-Object @{Expression={if($_.directory){0}else{1}}},@{Expression={$_.path.Length}},path);InventoryExceptions=@{$script:RecoveryRoot=@('.phase0-staging')};Bindings=$bindings;UnrecordedDirectoryPolicy='Current nonreparse ancestry locks only; no historical identity/inventory claim';WillLaunch=$false;RuntimeAllowed=$false;FReadPerformed=$false;FWritePerformed=$false}
 if($PostNativeCleanupRecovery){return Complete-RecoveryPostNativePlan $spec $v}
 return $spec
}
function Assert-RecoveryPostNativeDrain($final,[string]$run){
 Assert-Recovery ($run -ceq '250c044d62ab4b92ad82a830bb9b47c5' -and $final.runId -ceq $run -and $final.passed -eq $false -and $final.pendingCleared -eq $false -and $final.runtimeAllowed -eq $false -and $final.runtimeLeaseReleased -eq $true -and $final.runtimeMutexDisposed -eq $true -and -not $final.leaseHeld -and -not $final.ownerRetained -and -not $final.releaseError -and -not $final.disposeError -and $final.result.runId -ceq $run -and $final.result.passed -eq $false -and $null -eq $final.result.native) 'Exact post-native failed runtime binding differs'
 $o=$final.result.outer
 Assert-Recovery ($o.RunId -ceq $run -and $o.Pid -eq 45328 -and $o.DirectProcessExited -eq $true -and $o.JobDrained -eq $true -and $o.RemainingOwnedProcesses -eq 0 -and $o.StreamCaptureComplete -eq $true -and $o.DesktopLeaseClosed -eq $true -and -not $o.DesktopLeaseRetained -and $o.FullJobObserverClosed -eq $true -and -not $o.FullJobObserverRetained -and $o.FullJobObserverCloseError -eq 0 -and $o.CleanupVerified -eq $false -and $o.FullDesktopMonitorEvidence.failedCount -eq 2) 'Post-native physical drain/close proof differs; original monitor failure must remain false'
}
function Assert-RecoveryArchivedFile($entry){
 Assert-RecoveryCPath $entry.destination;Assert-Recovery ($entry.bytes -ge 0 -and $entry.bytes -le 67108864 -and $entry.sha256 -cmatch '\A[a-f0-9]{64}\z') 'Preserved payload exceeds fixed archive bounds'
 $f=[IO.FileStream]::new($entry.destination,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read);try{Assert-Recovery ($f.Length -eq $entry.bytes) 'Preserved archive length changed';$h=[Security.Cryptography.SHA256]::Create();try{Assert-Recovery (([BitConverter]::ToString($h.ComputeHash($f))).Replace('-','').ToLowerInvariant() -ceq $entry.sha256) 'Preserved archive payload changed'}finally{$h.Dispose()}}finally{$f.Dispose()}
}
function Complete-RecoveryPostNativePlan($spec,$evidence){
 $p=$evidence.preservation;$c=$evidence.comparison;$inventory=$evidence.inventory;$archive=$evidence.archive;$input=$evidence.preservationInputs;$shared=$evidence.sharedResult;$comparison=$evidence.sharedComparison
 Assert-Recovery ($p.preserved -eq $true -and $p.runId -ceq $spec.RunId -and $p.originalObservedCount -eq 1228 -and $p.runObjectCount -eq 34 -and $p.archiveFileCount -eq 31 -and $p.differencesCount -eq 7 -and $p.missingCount -eq 0 -and $p.releaseSucceeded -and $p.disposeSucceeded -and -not $p.leaseHeld -and -not $p.error -and $p.originalRuntimeCleanupVerified -eq $false -and $p.aaCreationProven -eq $false -and $p.aaCreationExcluded -eq $false) 'Exact complete post-native preservation required'
 Assert-Recovery ($input.RunId -ceq $spec.RunId -and $input.LabRoot -ceq $spec.Root -and $input.OwnerSid -ceq $spec.OwnerSid -and $input.Volume -ceq $spec.Volume -and @($input.Original).Count -eq 1228 -and @($input.Prepared).Count -eq 1259 -and @($input.MutableFiles).Count -eq 5) 'Preservation input scope differs'
 Assert-Recovery ($c.originalsObserved -eq 1228 -and $c.expectedOriginals -eq 1228 -and @($c.currentObjects).Count -eq 1264 -and @($c.differences).Count -eq 7 -and @($c.missing).Count -eq 0 -and @($inventory.objects).Count -eq 34 -and @($inventory.missing).Count -eq 0) 'Preserved object coverage differs'
 $current=Get-RecoveryObjectMap $c.currentObjects;$prepared=Get-RecoveryObjectMap $spec.Prepared;$original=Get-RecoveryObjectMap $spec.Original;$savedOriginal=Get-RecoveryObjectMap $input.Original;$savedPrepared=Get-RecoveryObjectMap $input.Prepared
 foreach($o in $spec.Original){Assert-RecoveryObject $current[$o.path] $prepared[$o.path];Assert-RecoveryObject $savedOriginal[$o.path] $o}
 foreach($o in $spec.Prepared){Assert-RecoveryObject $savedPrepared[$o.path] $o}
 $run=$spec.RunsPath+'\restricted-'+$spec.RunId;$extras=@('bootstrap.stderr.log','bootstrap.stdout.log','controller-result.json','output\identity.json','shared-state\prelaunch-current.json','shared-state\prelaunch-delta.json')|ForEach-Object{$run+'\'+$_}
 $expectedNew=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal);foreach($o in $spec.Created){[void]$expectedNew.Add($o.path)};foreach($extra in $extras){Assert-Recovery ($expectedNew.Add($extra) -and $current.ContainsKey($extra) -and -not $current[$extra].directory) 'Missing exact post-native extra file'}
 foreach($o in $current.Values){Assert-Recovery ($original.ContainsKey($o.path) -or $expectedNew.Contains($o.path)) 'Unknown preserved object cannot be deleted';Assert-Recovery ($o.owner -ceq $spec.OwnerSid -and $o.volume -ceq $spec.Volume) 'Preserved object owner/volume differs'}
 Assert-Recovery (-not $current.ContainsKey($spec.RunsPath)) 'Unexpected runs-parent preservation shape';$current.Add($spec.RunsPath,$prepared[$spec.RunsPath])
 foreach($o in $spec.Created){if($o.path -ceq $spec.PendingPath){$now=$current[$o.path];foreach($key in @('identity','owner','volume','directory','sddl','finalPath')){Assert-Recovery ($now.$key -ceq $o.$key) 'Global pending identity/descriptor changed'}}else{Assert-RecoveryObject $current[$o.path] $o}}
 $extraDiffs=@($c.differences|Where-Object category -CEQ extra-run-object);Assert-Recovery ($extraDiffs.Count -eq 6 -and (@($extraDiffs.path|Sort-Object -CaseSensitive)-join '|') -ceq (@($extras|Sort-Object -CaseSensitive)-join '|')) 'Only the six exact preserved runtime extras are admitted'
 $pendingDiffs=@($c.differences|Where-Object category -CNE extra-run-object);Assert-Recovery ($pendingDiffs.Count -eq 1 -and $pendingDiffs[0].path -ceq $spec.PendingPath -and ($pendingDiffs[0].fields -join ',') -ceq 'bytes,sha256') 'Only exact pending content transition is admitted'
 $inv=Get-RecoveryObjectMap $inventory.objects;foreach($o in $inv.Values){Assert-Recovery ($o.path -ceq $run -or $o.path.StartsWith($run+'\',[StringComparison]::Ordinal)) 'Preserved run inventory escaped scope';Assert-RecoveryObject $o $current[$o.path]}
 foreach($o in $current.Values){if($o.path -ceq $run -or $o.path.StartsWith($run+'\',[StringComparison]::Ordinal)){Assert-Recovery ($inv.ContainsKey($o.path)) 'Preserved run inventory is incomplete'}}
 foreach($o in @($inv.Values|Where-Object directory)){$actual=@($inventory.children.($o.path));$wanted=@($inv.Values|Where-Object{[IO.Path]::GetDirectoryName($_.path) -ceq $o.path}|ForEach-Object path);Assert-Recovery ($actual.Count -eq $wanted.Count -and (@($actual|Sort-Object -CaseSensitive)-join '|') -ceq (@($wanted|Sort-Object -CaseSensitive)-join '|')) 'Preserved exact directory inventory differs'}
 $important=@('output\bootstrap-result.json','output\aa.stdout.log','output\aa.stderr.log','request\response.json','shared-state\after.json','shared-state\delta.json')|ForEach-Object{$run+'\'+$_};$statuses=@($evidence.important.paths)
 Assert-Recovery ($statuses.Count -eq 6 -and (@($statuses.path|Sort-Object -CaseSensitive)-join '|') -ceq (@($important|Sort-Object -CaseSensitive)-join '|') -and @($statuses|Where-Object{$_.exists -ne $false -or $null -ne $_.object}).Count -eq 0) 'Important native result absence evidence differs'
 Assert-Recovery ($archive.complete -eq $true -and $archive.sourceWasNotModified -eq $true -and @($archive.files).Count -eq 31 -and $archive.totalBytes -eq 79797807) 'Complete preserved archive required'
 $archived=@{};$total=0L;foreach($file in $archive.files){Assert-Recovery (-not $archived.ContainsKey($file.source) -and $current.ContainsKey($file.source) -and -not $current[$file.source].directory -and $file.sourceIdentity -ceq $current[$file.source].identity -and $file.bytes -eq $current[$file.source].bytes -and $file.sha256 -ceq $current[$file.source].sha256) 'Preserved archive does not match current object';Assert-RecoveryArchivedFile $file;$archived[$file.source]=$file;$total+=$file.bytes};Assert-Recovery ($total -eq $archive.totalBytes) 'Archive total bytes differs'
 foreach($o in $inv.Values){if(-not $o.directory){Assert-Recovery ($archived.ContainsKey($o.path)) 'Preserved run file missing archive'}};foreach($p in @($spec.PendingPath)+@($input.MutableFiles)){Assert-Recovery ($archived.ContainsKey($p)) 'Pending/mutable archive missing'}
 $pendingBytes=Read-RecoveryPinnedC $archived[$spec.PendingPath].destination $archived[$spec.PendingPath].sha256 16384;$pending=ConvertFrom-RecoveryJson $pendingBytes
 Assert-Recovery ($pending.schema -eq 1 -and $pending.scope -ceq 'full-capabilities-global-pending' -and $pending.runId -ceq $spec.RunId -and $pending.controllerSid -ceq $spec.OwnerSid -and $pending.planSha256 -ceq $spec.PlanSha256 -and $pending.runDirectory -ceq $run -and $pending.state -ceq 'runtime-pending') 'Exact archived runtime-pending marker required'
 Assert-Recovery ($comparison.schema -eq 1 -and $comparison.runId -ceq $spec.RunId -and $comparison.accepted -eq $true -and $comparison.userPreferencesUnchanged -eq $true -and $comparison.finalStateUnchanged -eq $true -and $comparison.registryChanged -eq $false -and @($comparison.deltas).Count -eq 0 -and @($comparison.unexpected).Count -eq 0 -and @($comparison.engineMetadata).Count -eq 0 -and $comparison.restorationPerformed -eq $false -and $shared.accepted -eq $true -and $shared.finalStateUnchanged -eq $true -and $shared.registryChanged -eq $false -and $shared.deltas -eq 0 -and $shared.unexpected -eq 0 -and $shared.engineMetadata -eq 0 -and $shared.aaAfter -eq 0 -and $shared.registryWrites -eq $false -and $shared.sharedWrites -eq $false -and $shared.beforeSha256 -ceq $archived[$run+'\shared-state\before.json'].sha256) 'Independent postfailure shared comparison must have zero delta and no restoration'
 $spec.Scope='post-native-cleanup-recovery';$spec.EvidenceMode='PostNativePreserved250c';$spec.Prepared=@($current.Values|Sort-Object path -CaseSensitive);$spec.Created=@($expectedNew|ForEach-Object{$current[$_]}|Sort-Object path -CaseSensitive)
 $spec|Add-Member ExpectedPendingState 'runtime-pending';$spec|Add-Member OriginalRuntimeCleanupVerified $false;$spec|Add-Member AaCreationStatus 'unknown';$spec|Add-Member PendingContent ([Convert]::ToBase64String($pendingBytes));$spec|Add-Member SharedComparisonUtc ([string]$shared.utc);$spec|Add-Member PreservationUtc ([string]$archive.observedUtc);$spec|Add-Member RunsParentEvidence 'Prepared identity/SDDL retained as expectation; Apply must freshly verify this uncaptured ancestor'
 Assert-Recovery ($spec.Prepared.Count -eq 1265 -and $spec.Created.Count -eq 37 -and @($spec.Created|Where-Object{-not $_.directory}).Count -eq 27) 'Post-native finite inverse counts differ'
 return $spec
}
function Assert-RecoveryPostNativeFresh($spec,[datetimeoffset]$now){
 if($spec.Scope -cnotin @('post-native-cleanup-recovery','closed-failed-runtime-recovery')){return}
 Assert-Recovery (-not [string]::IsNullOrWhiteSpace($spec.SharedComparisonUtc)) 'Fresh independent shared comparison after preservation and within five minutes is required before Apply'
 if($spec.Scope -ceq 'closed-failed-runtime-recovery'){$observed=[datetimeoffset](ConvertTo-ClosedRecoveryUtcInstant $spec.SharedComparisonUtc);$preserved=[datetimeoffset](ConvertTo-ClosedRecoveryUtcInstant $spec.PreservationUtc)}else{$observed=[datetimeoffset]::Parse($spec.SharedComparisonUtc);$preserved=[datetimeoffset]::Parse($spec.PreservationUtc)}
 Assert-Recovery ($observed -ge $preserved -and $observed -le $now -and ($now-$observed).TotalSeconds -le 300) 'Fresh independent shared comparison after preservation and within five minutes is required before Apply'
}
function Invoke-RecoveryOp($Backend,$State,[string]$Action,[hashtable]$Arguments=@{}){if(-not $Arguments.ContainsKey('path')){$Arguments.path=$null};if(-not $Arguments.ContainsKey('name')){$Arguments.name=$null};$value=& $Backend $Action $Arguments $State;if($null -ne $value){return $value}}
function Assert-RecoveryInventories($Spec,$Map,$Backend,$State){
 $inventories=@{};foreach($o in $Map.Values){if($o.directory){$inventories[$o.path]=[Collections.Generic.List[string]]::new()}}
 foreach($o in $Map.Values){$parent=[IO.Path]::GetDirectoryName($o.path);if($inventories.ContainsKey($parent)){$inventories[$parent].Add([IO.Path]::GetFileName($o.path))}}
 foreach($p in $Spec.InventoryExceptions.Keys){foreach($name in $Spec.InventoryExceptions[$p]){$inventories[$p].Add($name)}}
 foreach($p in @($inventories.Keys|Sort-Object -CaseSensitive)){$actual=@(Invoke-RecoveryOp $Backend $State Inventory @{path=$p});$wanted=@($inventories[$p]);Assert-Recovery ($actual.Count -eq $wanted.Count -and (@($actual|Sort-Object -CaseSensitive) -join "`n") -ceq (@($wanted|Sort-Object -CaseSensitive) -join "`n")) ('Exact directory inventory differs: '+$p)}
}
function Assert-RecoveryLive($Spec,$Map,$Backend,$State){foreach($expected in $Map.Values){$actual=Invoke-RecoveryOp $Backend $State Observe @{path=$expected.path;capture=$false};Assert-RecoveryObject $actual $expected};Assert-RecoveryInventories $Spec $Map $Backend $State}
function Invoke-RecoveryMutation($Spec,$Map,$Backend,$State,[string]$Action,[hashtable]$Arguments){
 $p=$Arguments.path;Assert-Recovery ($Map.ContainsKey($p)) 'Mutation lacks a proved finite object';$before=$Map[$p];$actual=Invoke-RecoveryOp $Backend $State Observe @{path=$p;capture=$false};Assert-RecoveryObject $actual $before
 $Arguments.expectedIdentity=$before.identity;$Arguments.expectedSddl=$before.sddl;$Arguments.expectedSha256=$before.sha256
 $intent=[pscustomobject]@{action=$Action;path=$p;before=$before;afterSddl=$(if($Arguments.ContainsKey('sddl')){$Arguments.sddl}else{$null});afterHash=$(if($Arguments.ContainsKey('bytes')){Get-RecoveryHash $Arguments.bytes}else{$null})}
 Invoke-RecoveryOp $Backend $State Journal @{name='mutation-intent';value=$intent}
 Invoke-RecoveryOp $Backend $State $Action $Arguments
 $after=Invoke-RecoveryOp $Backend $State Observe @{path=$p;capture=$false}
 if($Action -cin @('DeleteFile','DeleteDirectory')){Assert-Recovery ($null -eq $after) ('Deleted object still present: '+$p);$null=$Map.Remove($p);if($p -ceq $Spec.PendingPath){$State.PendingCleared=$true};if($p -ceq $Spec.RunsPath){$State.RunsRemoved=$true}}
 else{$expected=ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $before)));if($Action -ceq 'WriteBytes'){$expected.bytes=$Arguments.bytes.Length;$expected.sha256=Get-RecoveryHash $Arguments.bytes;$expected.content=[Convert]::ToBase64String($Arguments.bytes)}else{$expected.sddl=$Arguments.sddl};Assert-RecoveryObject $after $expected;$Map[$p]=$expected;if($p -ceq $Spec.PendingPath){$State.PendingMarked=$true}}
 Invoke-RecoveryOp $Backend $State Journal @{name='mutation-readback';value=[pscustomobject]@{action=$Action;path=$p;object=$after}}
}
function Invoke-RecoveryCoordinator($Spec,[scriptblock]$Backend,$State){
 foreach($pair in @{Held=$false;PendingMarked=$false;PendingCleared=$false;RunsRemoved=$false;ReleaseSucceeded=$false;DisposeSucceeded=$false;Retained=$false;Error=$null;EvidenceError=$null;ArchiveComplete=$false;OriginalsVerified=$false;BaselineVerified=$false;FinalizationStarted=$false;Success=$false}.GetEnumerator()){$State[$pair.Key]=$pair.Value}
 $map=$null
 try{
  $map=Get-RecoveryObjectMap $Spec.Prepared;$original=Get-RecoveryObjectMap $Spec.Original
  $lease=Invoke-RecoveryOp $Backend $State Acquire
  Assert-Recovery ($lease.ownerSid -ceq $Spec.OwnerSid -and $lease.logonSid -ceq $Spec.LogonSid -and $lease.volume -ceq $Spec.Volume) 'Current recovery lease binding differs'
  $State.Held=$true
  $env=Invoke-RecoveryOp $Backend $State ValidateEnvironment
  Assert-Recovery ($env.aaCount -eq 0 -and $env.probeCount -eq 0 -and $env.unelevated -and $env.ownerSid -ceq $Spec.OwnerSid -and $env.logonSid -ceq $Spec.LogonSid) 'Fresh AA/probe/current unelevated identity guard failed'
  Assert-RecoveryLive $Spec $map $Backend $State
  $continuation=[bool]$Spec.PSObject.Properties['Continuation']
  if($continuation){Assert-Recovery ($Spec.Scope -ceq 'closed-failed-runtime-recovery' -and $Spec.Continuation.Schema -eq 1 -and $Spec.Continuation.CompletedSteps -eq 8 -and $Spec.Continuation.ConfirmedDeleted.Count -eq 6 -and $Spec.PayloadRestores.Count -eq 0) 'Invalid explicit continuation state';foreach($gone in $Spec.Continuation.ConfirmedDeleted){Assert-Recovery (-not $map.ContainsKey($gone.path) -and $null -eq (Invoke-RecoveryOp $Backend $State Observe @{path=$gone.path;capture=$false})) 'Previously deleted object reappeared'}}
  $pending=Invoke-RecoveryOp $Backend $State Observe @{path=$Spec.PendingPath;capture=$true};Assert-RecoveryObject $pending $map[$Spec.PendingPath]
  $expectedPendingState='prepared-awaiting-runtime-lease';if($Spec.PSObject.Properties['ExpectedPendingState']){Assert-Recovery ($Spec.Scope -cin @('post-native-cleanup-recovery','closed-failed-runtime-recovery') -and $Spec.ExpectedPendingState -ceq 'runtime-pending') 'Invalid recovery pending policy';$expectedPendingState=$Spec.ExpectedPendingState}
  if($continuation){$expectedPendingState='recovery-in-progress'}
  $record=ConvertFrom-RecoveryJson ([Convert]::FromBase64String($pending.content));Assert-Recovery ($record.schema -eq 1 -and $record.scope -ceq 'full-capabilities-global-pending' -and $record.runId -ceq $Spec.RunId -and $record.planSha256 -ceq $Spec.PlanSha256 -and $record.controllerSid -ceq $Spec.OwnerSid -and $record.runDirectory -ceq ($Spec.RunsPath+'\restricted-'+$Spec.RunId) -and $record.state -ceq $expectedPendingState) 'Preparation has already been used or recovery has started'
  if($continuation){Assert-Recovery ($record.recoveryId -ceq $Spec.Continuation.PriorRecoveryId -and $record.automaticRetryAllowed -eq $false) 'Partial recovery pending identity differs'}
  Invoke-RecoveryOp $Backend $State Persist @{name='recovery-plan';value=$Spec}
  $archives=@();foreach($file in @($Spec.Created|Where-Object{-not $_.directory}|Sort-Object path -CaseSensitive)){$a=Invoke-RecoveryOp $Backend $State Archive @{path=$file.path;expected=$file};Assert-Recovery ($a.sourcePath -ceq $file.path -and $a.sourceIdentity -ceq $file.identity -and $a.sha256 -ceq $file.sha256 -and $a.bytes -eq $file.bytes) 'Archived payload readback differs';$archives+=,$a}
  Invoke-RecoveryOp $Backend $State Persist @{name='archive-manifest';value=[pscustomobject]@{runId=$Spec.RunId;recoveryId=$State.RecoveryId;objects=$Spec.Created;files=$archives;complete=$true}}
  $State.ArchiveComplete=$true
  Assert-RecoveryLive $Spec $map $Backend $State
  $env=Invoke-RecoveryOp $Backend $State ValidateEnvironment;Assert-Recovery ($env.aaCount -eq 0 -and $env.probeCount -eq 0 -and $env.unelevated) 'Process/identity guard changed before mutation'
  if(-not $continuation){$record.state='recovery-in-progress';$record|Add-Member -NotePropertyName recoveryId -NotePropertyValue $State.RecoveryId;$record|Add-Member -NotePropertyName automaticRetryAllowed -NotePropertyValue $false
   Invoke-RecoveryMutation $Spec $map $Backend $State WriteBytes @{path=$Spec.PendingPath;bytes=[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-RecoveryJson $record))}}
  foreach($old in $Spec.PayloadRestores){Invoke-RecoveryMutation $Spec $map $Backend $State WriteBytes @{path=$old.path;bytes=[Convert]::FromBase64String($old.content)}}
  foreach($file in @($Spec.Created|Where-Object{-not $_.directory -and $_.path -cne $Spec.PendingPath}|Sort-Object path -CaseSensitive)){Invoke-RecoveryMutation $Spec $map $Backend $State DeleteFile @{path=$file.path}}
  foreach($dir in @($Spec.Created|Where-Object{$_.directory -and $_.path -cne $Spec.RunsPath}|Sort-Object @{Expression={$_.path.Length};Descending=$true},path)){Invoke-RecoveryMutation $Spec $map $Backend $State DeleteDirectory @{path=$dir.path}}
  # Protected prepared children stay unchanged while ancestors are restored.
  # Restore original directory descriptors first, then exact inherited file DACLs.
  foreach($old in @($Spec.DescriptorRestores|Sort-Object @{Expression={if($_.directory){0}else{1}}},@{Expression={$_.path.Length}},path)){Invoke-RecoveryMutation $Spec $map $Backend $State SetDescriptor @{path=$old.path;sddl=$old.sddl}}
  foreach($old in $Spec.Original){Assert-RecoveryObject (Invoke-RecoveryOp $Backend $State Observe @{path=$old.path;capture=$false}) $old}
  foreach($new in $Spec.Created){if($new.path -cin @($Spec.PendingPath,$Spec.RunsPath)){continue};Assert-Recovery ($null -eq (Invoke-RecoveryOp $Backend $State Observe @{path=$new.path;capture=$false})) 'A recorded creation remains before finalization'}
  Assert-RecoveryInventories $Spec $map $Backend $State;$State.OriginalsVerified=$true
  Invoke-RecoveryOp $Backend $State Persist @{name='finalization-intent';value=[pscustomobject]@{runId=$Spec.RunId;recoveryId=$State.RecoveryId;originalsVerified=$Spec.Original.Count;remaining=@($map.Values|Where-Object{-not $original.ContainsKey($_.path)});pendingMayBeAbsentAfterNextStep=$true;automaticRetryAllowed=$false}}
  $State.FinalizationStarted=$true
  Invoke-RecoveryMutation $Spec $map $Backend $State DeleteFile @{path=$Spec.PendingPath}
  Invoke-RecoveryMutation $Spec $map $Backend $State DeleteDirectory @{path=$Spec.RunsPath}
  $actualFinal=@();foreach($old in $Spec.Original){$actual=Invoke-RecoveryOp $Backend $State Observe @{path=$old.path;capture=$false};Assert-RecoveryObject $actual $old;$actualFinal+=,$actual};Assert-RecoveryInventories $Spec $original $Backend $State
  $allCreated=@($Spec.Created);if($continuation){$allCreated+=@($Spec.Continuation.ConfirmedDeleted)}
  $absentFinal=@();foreach($new in $allCreated){$observed=Invoke-RecoveryOp $Backend $State Observe @{path=$new.path;capture=$false};Assert-Recovery ($null -eq $observed) 'Originally absent target is present after recovery';$absentFinal+=,[pscustomobject]@{path=$new.path;absent=$true}}
  $env=Invoke-RecoveryOp $Backend $State ValidateEnvironment;Assert-Recovery ($env.aaCount -eq 0 -and $env.probeCount -eq 0 -and $env.unelevated) 'Final process/identity guard failed'
  Invoke-RecoveryOp $Backend $State Persist @{name='baseline-readback';value=[pscustomobject]@{originals=$actualFinal;absent=$absentFinal;observedUtc=[datetime]::UtcNow.ToString('o');baselineMatches=$true;leaseStillHeld=$true}};$State.BaselineVerified=$true
  $State.Success=$true
 }catch{$State.Error=$_.Exception.ToString();$State.Success=$false}
 finally{
  if($State.Held){try{Invoke-RecoveryOp $Backend $State Release;$State.Held=$false;$State.ReleaseSucceeded=$true}catch{$State.Success=$false;$State.Error+='; release: '+$_.Exception.ToString();try{Invoke-RecoveryOp $Backend $State Retain;$State.Retained=$true}catch{$State.Error+='; retain: '+$_.Exception.ToString()}}}
  if(-not $State.Held){try{Invoke-RecoveryOp $Backend $State Dispose;$State.DisposeSucceeded=$true}catch{$State.Success=$false;$State.Error+='; dispose: '+$_.Exception.ToString()}}
 }
 $outcome=[pscustomobject][ordered]@{Success=($State.Success -and $State.ReleaseSucceeded -and $State.DisposeSucceeded);RunId=$Spec.RunId;RecoveryId=$State.RecoveryId;ArchiveComplete=$State.ArchiveComplete;OriginalsVerified=$State.OriginalsVerified;BaselineVerified=$State.BaselineVerified;PendingMarked=$State.PendingMarked;FinalizationStarted=$State.FinalizationStarted;PendingCleared=$State.PendingCleared;RunsRemoved=$State.RunsRemoved;ReleaseSucceeded=$State.ReleaseSucceeded;DisposeSucceeded=$State.DisposeSucceeded;LeaseHeld=$State.Held;OwnerRetained=$State.Retained;Error=$State.Error;EvidenceError=$null;RuntimeAllowed=$false;WillLaunch=$false;AutomaticRetryAllowed=$false;TerminalFailureMayHaveNoPendingMarker=$State.FinalizationStarted}
 if($Spec.PSObject.Properties['ExpectedPendingState']){if($Spec.Scope -ceq 'closed-failed-runtime-recovery'){$outcome|Add-Member Scope $Spec.Scope;$outcome|Add-Member OriginalRuntimeCleanupVerified $Spec.OriginalRuntimeCleanupVerified;$outcome|Add-Member AaCreationStatus $Spec.AaCreationStatus;$outcome|Add-Member ApplicationAccepted $false;$outcome|Add-Member SharedRestorationPerformed $false}else{$outcome|Add-Member Scope 'post-native-cleanup-recovery';$outcome|Add-Member OriginalRuntimeCleanupVerified $false;$outcome|Add-Member AaCreationStatus 'unknown'};$outcome|Add-Member RuntimeAcceptanceGranted $false}
 if($Spec.PSObject.Properties['Continuation']){$outcome|Add-Member ContinuationOfRecoveryId $Spec.Continuation.PriorRecoveryId;$outcome|Add-Member HistoricalCompletedSteps $Spec.Continuation.CompletedSteps;$outcome|Add-Member HistoricalPendingMarked $true;$outcome|Add-Member HistoricalFailurePreserved $true}
 if($State.ContainsKey('ReadonlyTraceFailure')){$outcome|Add-Member ReadonlyTraceFailure $State.ReadonlyTraceFailure}
 try{Invoke-RecoveryOp $Backend $State Persist @{name='recovery-outcome';value=$outcome}}catch{$outcome.Success=$false;$outcome.EvidenceError=$_.Exception.ToString()}
 return $outcome
}
function Write-RecoveryCRecord([string]$Path,$Value){
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-RecoveryJson $Value));$f=[IO.FileStream]::new($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read)
 try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true);$f.Position=0;$h=[Security.Cryptography.SHA256]::Create();try{Assert-Recovery (([BitConverter]::ToString($h.ComputeHash($f))).Replace('-','').ToLowerInvariant() -ceq (Get-RecoveryHash $bytes)) 'C durable evidence readback differs'}finally{$h.Dispose()}}finally{$f.Dispose()}
}
function Lock-RecoveryAncestry($State,[string]$Path,[bool]$IncludeLeaf){
 $cursor=if($IncludeLeaf){$Path}else{[IO.Path]::GetDirectoryName($Path)};$paths=[Collections.Generic.List[string]]::new();while($cursor){$paths.Add($cursor);$cursor=[IO.Path]::GetDirectoryName($cursor)}
 for($i=$paths.Count-1;$i -ge 0;$i--){$p=$paths[$i];if(-not $State.Locks.ContainsKey($p)){$State.Locks[$p]=[Azurite.Stage.FileSecurity]::LockDirectory($p)}}
}
function Get-RecoveryPhysicalObject($State,[string]$Path,[bool]$Capture){
 if(-not [IO.File]::Exists($Path) -and -not [IO.Directory]::Exists($Path)){
  $parent=[IO.Path]::GetDirectoryName($Path);while($parent -and -not [IO.Directory]::Exists($parent)){$parent=[IO.Path]::GetDirectoryName($parent)}
  Assert-Recovery ($parent) 'No existing ancestry for absence check';Lock-RecoveryAncestry $State $parent $true
  # Enumeration reports dangling reparse objects too; Exists alone does not.
  if([IO.Path]::GetDirectoryName($Path) -ceq $parent){$name=[IO.Path]::GetFileName($Path);Assert-Recovery (@([IO.Directory]::EnumerateFileSystemEntries($parent)|Where-Object{[IO.Path]::GetFileName($_) -ieq $name}).Count -eq 0) 'Absence check found an inaccessible/reparse/case-alias entry'}
  return $null
 }
 Lock-RecoveryAncestry $State $Path ([IO.Directory]::Exists($Path));[Azurite.Stage.FileSecurity]::Read($Path,$Capture)
}
function Get-RecoveryTokenPins {
 $folder=Join-Path $script:RecoveryRepo '.superpowers\sdd\azurite-authoring-20261108\aa-fr-ftarget-freeze2-build-20261112\tooling'
 $pins=@{};foreach($pair in @(@('RestrictedCliNative.dll','55e2971726db57665e45943199d4ce82a03bed9d111b74bfcff1e98535cb3e74'),@('RestrictedCliNative.cs','f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'),@('RestrictedCliFullRestricted.cs','460694d0abd2771580c4989485cba134ed01a525c310f4c136adc4123970c73f'))){$pins[$pair[0]]=[pscustomobject]@{path=(Join-Path $folder $pair[0]);sha256=$pair[1]}};return $pins
}
function Initialize-RecoveryTokenReader([byte[]]$Bytes){
 Assert-Recovery ($null -eq $script:RecoveryTokenType -and -not ('Azurite.Restricted.FullBootstrapIdentity' -as [type])) 'Fresh recovery process must not preload the token-reader assembly'
 $assembly=[Reflection.Assembly]::Load($Bytes);$script:RecoveryTokenType=$assembly.GetType('Azurite.Restricted.FullRestrictedToken',$true)
 foreach($name in @('Read','ValidateOriginal')){Assert-Recovery ($null -ne $script:RecoveryTokenType.GetMethod($name,[Reflection.BindingFlags]'NonPublic,Static')) ('Pinned token reader lacks '+$name)}
}
function Get-RecoveryIdentity {
 Assert-Recovery ($null -ne $script:RecoveryTokenType) 'Pinned token reader is not initialized'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();$token=$null;$added=$false
 try{
  $principal=[Security.Principal.WindowsPrincipal]::new($identity);Assert-Recovery (-not $identity.IsSystem -and -not $identity.IsAnonymous -and -not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) 'Recovery requires the current unelevated account'
  $token=$identity.AccessToken;$token.DangerousAddRef([ref]$added)
  $read=$script:RecoveryTokenType.GetMethod('Read',[Reflection.BindingFlags]'NonPublic,Static');$validate=$script:RecoveryTokenType.GetMethod('ValidateOriginal',[Reflection.BindingFlags]'NonPublic,Static')
  $actual=$read.Invoke($null,[object[]]@($token.DangerousGetHandle(),[Collections.Generic.Dictionary[string,object]]::new()));$null=$validate.Invoke($null,[object[]]@($actual))
  Assert-Recovery ($actual['user_sid'] -ceq $identity.User.Value -and $actual['logon_sid'] -cmatch '^S-1-5-5-\d+-\d+$') 'Token identity/logon evidence differs'
  [pscustomobject]@{ownerSid=$actual['user_sid'];logonSid=$actual['logon_sid'];unelevated=(-not $actual['elevated']);tokenType=$actual['token_type'];isRestricted=$actual['is_restricted'];isAppContainer=$actual['is_app_container'];sessionId=$actual['session_id'];source='pinned-token-query-only-no-hive-read'}
 }finally{if($added){$token.DangerousRelease()};$identity.Dispose()}
}
function Assert-RecoveryPhysicalEnvironment($State){
 if($State.Spec.PSObject.Properties['ExpectedPendingState']){Assert-RecoveryPostNativeFresh $State.Spec ([datetimeoffset]::UtcNow)}
 $identity=Get-RecoveryIdentity;Assert-Recovery ($identity.ownerSid -ceq $State.Spec.OwnerSid -and $identity.logonSid -ceq $State.Spec.LogonSid) 'Current account/logon changed since preparation'
 $p=@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'" -ErrorAction Stop);Assert-Recovery ($p.Count -eq 0) 'Fresh AA/probe absence guard failed'
 [pscustomobject]@{ownerSid=$identity.ownerSid;logonSid=$identity.logonSid;unelevated=$true;aaCount=0;probeCount=0;utc=[datetime]::UtcNow.ToString('o')}
}
function New-RecoveryPhysicalBackend {
 return {param($Action,$A,$State)
  switch($Action){
   'Acquire' {
    $State.Mutex=[Threading.Mutex]::new($false,'Global\AzuriteRestrictedCli-AA')
    try{$held=$State.Mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{
     # WaitOne grants ownership on abandonment; this is not admission.
     $State.Held=$true;throw 'Abandoned global lease refuses automatic recovery'
    }
    Assert-Recovery $held 'Another controller holds the global AA lease';$State.Held=$true
    $e=Assert-RecoveryPhysicalEnvironment $State
    [pscustomobject]@{ownerSid=$e.ownerSid;logonSid=$e.logonSid;volume=$State.Spec.Volume;globalMutex='Global\AzuriteRestrictedCli-AA';acquiredUtc=[datetime]::UtcNow.ToString('o')};return
   }
   'ValidateEnvironment' {return Assert-RecoveryPhysicalEnvironment $State}
   'Observe' {return Get-RecoveryPhysicalObject $State $A.path $A.capture}
   'Inventory' {Lock-RecoveryAncestry $State $A.path $true;return @([IO.Directory]::EnumerateFileSystemEntries($A.path)|ForEach-Object{[IO.Path]::GetFileName($_)})}
   'Archive' {
    $e=$A.expected;$destination=Join-Path $State.ArchiveDirectory ($e.identity+'.bin')
    Lock-RecoveryAncestry $State $A.path $false;Lock-RecoveryAncestry $State $destination $false
    [Azurite.Stage.FileSecurity]::ArchiveFile($A.path,$e.identity,$e.sddl,$e.sha256,[long]$e.bytes,$destination)
    $d=[Azurite.Stage.FileSecurity]::Read($destination,$false);Assert-Recovery (-not $d.directory -and $d.links -eq 1 -and $d.owner -ceq $State.Spec.OwnerSid -and $d.bytes -eq $e.bytes -and $d.sha256 -ceq $e.sha256) 'C archive destination readback differs'
    return [pscustomobject]@{sourcePath=$A.path;sourceIdentity=$e.identity;sha256=$d.sha256;bytes=$d.bytes;destination=$destination;destinationIdentity=$d.identity;destinationSddl=$d.sddl}
   }
   'Persist' {Write-RecoveryCRecord (Join-Path $State.EvidenceDirectory ($A.name+'.json')) $A.value;return}
   'Journal' {
    $b=[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-RecoveryJson ([pscustomobject]@{utc=[datetime]::UtcNow.ToString('o');kind=$A.name;value=$A.value}))+"`n")
    $f=$State.JournalStream;[void]$f.Seek(0,[IO.SeekOrigin]::End);$offset=$f.Position;$f.Write($b,0,$b.Length);$f.Flush($true);$f.Position=$offset;$read=[byte[]]::new($b.Length);$n=0;while($n -lt $read.Length){$k=$f.Read($read,$n,$read.Length-$n);Assert-Recovery ($k -gt 0) 'Journal readback truncated';$n+=$k};Assert-Recovery ((Get-RecoveryHash $read) -ceq (Get-RecoveryHash $b)) 'Journal durable readback differs';return
   }
   'WriteBytes' {[Azurite.Stage.FileSecurity]::WriteExisting($A.path,$A.expectedIdentity,$A.expectedSddl,$A.expectedSha256,$A.bytes);return}
   'SetDescriptor' {
    $expected=@($State.Spec.Prepared|Where-Object path -CEQ $A.path)[0]
    if($expected.directory){[Azurite.Stage.FileSecurity]::SetDescriptor($A.path,$A.expectedIdentity,$A.expectedSddl,$A.sddl);return}
    # FileShare.Read prevents content writes and replacement while existing
    # FileSecurity.SetDescriptor performs its same-handle identity/SDDL check.
    $guard=[IO.FileStream]::new($A.path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    try{$read=[Azurite.Stage.FileSecurity]::Read($A.path,$false);Assert-Recovery ($read.identity -ceq $A.expectedIdentity -and $read.sddl -ceq $A.expectedSddl -and $read.sha256 -ceq $A.expectedSha256) 'Guarded descriptor payload changed';[Azurite.Stage.FileSecurity]::SetDescriptor($A.path,$A.expectedIdentity,$A.expectedSddl,$A.sddl);$read=[Azurite.Stage.FileSecurity]::Read($A.path,$false);Assert-Recovery ($read.identity -ceq $A.expectedIdentity -and $read.sddl -ceq $A.sddl -and $read.sha256 -ceq $A.expectedSha256) 'Guarded descriptor readback differs'}finally{$guard.Dispose()};return
   }
   'DeleteFile' {
    $target=$null;if($State.Spec.PSObject.Properties['ArchivedReadonlyTrace']){$target=$State.Spec.ArchivedReadonlyTrace}
    if($null -ne $target -and $A.path -ceq $target.Target.path){
     Assert-Recovery ($State.Spec.Scope -ceq 'closed-failed-runtime-recovery' -and $State.ArchiveComplete) 'Readonly trace deletion requires the completed existing recovery archive'
     Assert-RecoveryReadonlyTraceBinding $target $State.Spec.RunId $State.Spec.Root
     Assert-Recovery ($A.expectedIdentity -ceq $target.Target.identity -and $A.expectedSddl -ceq $target.Target.sddl -and $A.expectedSha256 -ceq $target.Target.sha256) 'Readonly trace mutation differs from its bound current object'
     Assert-Recovery ($State.ContainsKey('ReadonlyTraceDeleteMethod') -and $State.ContainsKey('ReadonlyTraceDeleteAssembly') -and $State.ReadonlyTraceDeleteMethod.DeclaringType.Assembly -eq $State.ReadonlyTraceDeleteAssembly -and $State.ReadonlyTraceDeleteMethod.DeclaringType.FullName -ceq 'Azurite.Recovery.ArchivedReadonlyTraceDelete') 'Qualified readonly trace helper was not loaded'
     try{$null=$State.ReadonlyTraceDeleteMethod.Invoke($null,[object[]]@([string]$A.path,[string]$State.Spec.RunId,[string]$A.expectedIdentity,[string]$A.expectedSddl,[string]$A.expectedSha256,[long]$target.Target.bytes,[uint32]33))}catch{
      $errorObject=$_.Exception;while($errorObject.InnerException){$errorObject=$errorObject.InnerException};$attributes='unknown';$attempted=$false;$cleared='unknown';if($errorObject.Data.Contains('ObservedAttributes')){$attributes=$errorObject.Data['ObservedAttributes']};if($errorObject.Data.Contains('ReadonlyUpdateAttempted')){$attempted=$errorObject.Data['ReadonlyUpdateAttempted']};if($errorObject.Data.Contains('AttributesCleared')){$cleared=$errorObject.Data['AttributesCleared']}
      $State.ReadonlyTraceFailure=[pscustomobject]@{path=$A.path;identity=$A.expectedIdentity;sha256=$A.expectedSha256;readonlyUpdateAttempted=$attempted;attributesCleared=$cleared;observedAttributes=$attributes;attributesMayAlreadyBe32=$true;automaticRetryAllowed=$false;error=$errorObject.ToString()}
      Invoke-RecoveryOp (New-RecoveryPhysicalBackend) $State Persist @{name='readonly-trace-failure';value=$State.ReadonlyTraceFailure};throw
     };return
    }
    [Azurite.Stage.FileSecurity]::DeleteExisting($A.path,$A.expectedIdentity,$A.expectedSddl,$A.expectedSha256);return
   }
   'DeleteDirectory' {
    # Our own leaf lock denies deletion. Drop only that exact leaf handle;
    # all ancestor locks remain, and the helper validates identity/SDDL/empty.
    if($State.Locks.ContainsKey($A.path)){$State.Locks[$A.path].Dispose();$State.Locks.Remove($A.path)}
    [Azurite.Stage.FileSecurity]::DeleteEmptyDirectory($A.path,$A.expectedIdentity,$A.expectedSddl);return
   }
   'Release' {
    foreach($p in @($State.Locks.Keys|Sort-Object Length -Descending)){$State.Locks[$p].Dispose();$State.Locks.Remove($p)}
    $State.Mutex.ReleaseMutex();$State.Held=$false;return
   }
   'Dispose' {if($State.JournalStream){$State.JournalStream.Flush($true);$State.JournalStream.Dispose();$State.JournalStream=$null};if($State.Mutex){$State.Mutex.Dispose()};return}
   'Retain' {$script:RecoveryRetained.Add($State);return}
   default {throw ('Unknown recovery operation: '+$Action)}
  }
 }
}
function Assert-RecoveryReadonlyTraceBinding($Trace,[string]$RunId,[string]$Root=$script:RecoveryRoot){
 Assert-Recovery ($null -ne $Trace -and $RunId -cmatch '\A[a-f0-9]{32}\z' -and $RunId -cne ('0'*32)) 'Readonly trace binding lacks exact run data'
 $copy=$Root+'\runs\restricted-'+$RunId+'\history\post-run\startup-exceptions.nettrace';$source=$Root+'\runs\restricted-'+$RunId+'\output\startup-exceptions.nettrace';$t=$Trace.Target;$a=$Trace.PreservedArchive
 Assert-Recovery ($Trace.Binding.Protocol -ceq 'startup-exceptions.v1' -and $Trace.Binding.CopyPath -ceq $copy -and $Trace.Binding.SourcePath -ceq $source -and $Trace.Binding.MaximumBytes -eq 4194304 -and $t.path -ceq $copy -and -not $t.directory -and -not $t.reparse -and $t.links -eq 1 -and $t.bytes -gt 0 -and $t.bytes -le 4194304) 'Readonly trace is not the selected bounded diagnostic history object'
 Assert-Recovery ($a.source -ceq $t.path -and $a.sourceIdentity -ceq $t.identity -and $a.sha256 -ceq $t.sha256 -and $a.bytes -eq $t.bytes) 'Readonly trace current/archive identity or payload differs'
 Assert-RecoveryArchivedFile $a
}
function Get-RecoveryReadonlyTracePins {
 $dir=Join-Path $script:RecoveryRepo 'artifacts\aa-fr-readonly-trace-continuation\physical-final3'
 return @{'ArchivedReadonlyTraceDelete.cs'=[pscustomobject]@{path=(Join-Path $PSScriptRoot 'ArchivedReadonlyTraceDelete.cs');sha256='57e67e9d30d7f07406fdcefb99caf89ade5d164dec855e93805e7d59eb4b4f48'};'ArchivedReadonlyTraceDelete.dll'=[pscustomobject]@{path=(Join-Path $dir 'ArchivedReadonlyTraceDelete.dll');sha256='03c0bb67c23affce8228ee891d2c71a3e57c4f26ec10399d449bac24d92295f0'};'readonly-helper-test.json'=[pscustomobject]@{path=(Join-Path $dir 'result.json');sha256='1ece3a7528a3e531f9b2f719d2250c8cfc0ebe00fb0508b3a9c17d9f5f078527'}}
}
function Initialize-RecoveryReadonlyTraceHelper($Bindings){
 Assert-Recovery (-not ('Azurite.Recovery.ArchivedReadonlyTraceDelete' -as [type])) 'Readonly trace helper must not be preloaded'
 $pins=Get-RecoveryReadonlyTracePins
 foreach($name in $pins.Keys){Assert-Recovery ($Bindings.files.ContainsKey($name) -and $Bindings.files[$name].entry.path -ceq $pins[$name].path -and $Bindings.files[$name].entry.sha256 -ceq $pins[$name].sha256 -and (Get-RecoveryHash $Bindings.files[$name].bytes) -ceq $pins[$name].sha256) 'Readonly helper bytes lack their fixed source binding'}
 $assembly=[Reflection.Assembly]::Load([byte[]]$Bindings.files['ArchivedReadonlyTraceDelete.dll'].bytes);$type=$assembly.GetType('Azurite.Recovery.ArchivedReadonlyTraceDelete',$true)
 $method=$type.GetMethod('Delete',[Reflection.BindingFlags]'Public,Static')
 Assert-Recovery ($null -ne $method -and $method.DeclaringType.Assembly -eq $assembly -and ('Azurite.Recovery.ArchivedReadonlyTraceDelete' -as [type]) -eq $type -and (@($method.GetParameters()|ForEach-Object {$_.ParameterType.FullName}) -join ',') -ceq 'System.String,System.String,System.String,System.String,System.String,System.Int64,System.UInt32') 'Loaded readonly helper executable type/signature differs'
 return [pscustomobject]@{Assembly=$assembly;Method=$method}
}
function Read-RecoverySourceBindings([string]$Path,[string]$ExpectedSha256,[string]$RunId=$script:RecoveryRun,[string]$EvidenceManifestSha256,[string]$RecoveryScope='fixed-F-prelaunch-preparation-recovery',$ReadonlyTraceBinding=$null){
 $manifest=ConvertFrom-RecoveryJson (Read-RecoveryPinnedC $Path $ExpectedSha256)
 $readonlyRequired=$null -ne $ReadonlyTraceBinding
 if($readonlyRequired){Assert-Recovery ($RecoveryScope -ceq 'closed-failed-runtime-recovery') 'Readonly helper binding is only for verified closed diagnostic recovery';Assert-RecoveryReadonlyTraceBinding $ReadonlyTraceBinding $RunId}
 if($RecoveryScope -ceq 'readonly-trace-recovery-continuation'){Assert-Recovery ($RunId -ceq '85ab00ecf00d4ef5a1a1aa471ef365a8' -and $manifest.schema -eq 5 -and $manifest.scope -ceq 'readonly-trace-recovery-continuation-source' -and $manifest.runId -ceq $RunId -and $manifest.evidenceManifestSha256 -ceq $EvidenceManifestSha256 -and @($manifest.files).Count -eq 15) 'Readonly trace continuation source manifest differs'}
 elseif($RecoveryScope -ceq 'closed-failed-runtime-recovery'){$requiredCount=10;if($readonlyRequired){$requiredCount=13};Assert-Recovery ($RunId -cmatch '\A[a-f0-9]{32}\z' -and $RunId -cne ('0'*32) -and $manifest.schema -eq 4 -and $manifest.scope -ceq 'closed-failed-runtime-recovery-source' -and $manifest.runId -ceq $RunId -and $manifest.evidenceManifestSha256 -ceq $EvidenceManifestSha256 -and @($manifest.files).Count -eq $requiredCount) 'Closed failed recovery source manifest differs from explicit mode/run/evidence'}
 elseif($RecoveryScope -ceq 'post-native-cleanup-recovery'){Assert-Recovery ($RunId -ceq '250c044d62ab4b92ad82a830bb9b47c5' -and $manifest.schema -eq 3 -and $manifest.scope -ceq 'fixed-250c-post-native-cleanup-recovery-source' -and $manifest.runId -ceq $RunId -and $manifest.evidenceManifestSha256 -ceq $EvidenceManifestSha256 -and @($manifest.files).Count -eq 9) 'Post-native recovery source manifest differs from explicit mode/run/evidence'}
 elseif([string]::IsNullOrEmpty($EvidenceManifestSha256)){Assert-Recovery ($RunId -ceq $script:RecoveryRun -and $manifest.schema -eq 1 -and $manifest.scope -ceq 'accepted-22bac-prelaunch-recovery-source' -and $manifest.runId -ceq $script:RecoveryRun -and @($manifest.files).Count -eq 9) 'Recovery source manifest differs'}
 else{Assert-Recovery ($EvidenceManifestSha256 -cmatch '^[a-f0-9]{64}$' -and $manifest.schema -eq 2 -and $manifest.scope -ceq 'fixed-F-prelaunch-preparation-recovery-source' -and $manifest.runId -ceq $RunId -and $manifest.evidenceManifestSha256 -ceq $EvidenceManifestSha256 -and @($manifest.files).Count -eq 9) 'Recovery source manifest differs from bound run/evidence'}
 $expected=@{'FullRestrictedPreparationRecovery.psm1'=(Join-Path $PSScriptRoot 'FullRestrictedPreparationRecovery.psm1');'Recover-AzuriteFullPreparation.ps1'=(Join-Path $PSScriptRoot 'Recover-AzuriteFullPreparation.ps1');'FullRestrictedStageTransition.psm1'=(Join-Path $PSScriptRoot 'FullRestrictedStageTransition.psm1')}
 if($RecoveryScope -cin @('closed-failed-runtime-recovery','readonly-trace-recovery-continuation')){$expected['FullRestrictedClosedFailedRecovery.ps1']=Join-Path $PSScriptRoot 'FullRestrictedClosedFailedRecovery.ps1';$expected['FullRestrictedStageTransition.psm1']=Join-Path $script:RecoveryRepo 'artifacts\aa-fr-empty-directory-helper-20261113\final-FullRestrictedStageTransition.psm1'}
 if($RecoveryScope -ceq 'readonly-trace-recovery-continuation'){foreach($name in @('FullRestrictedReadonlyTraceContinuation.ps1','Resume-AzuriteReadonlyTraceRecovery.ps1','ArchivedReadonlyTraceDelete.cs')){$expected[$name]=Join-Path $PSScriptRoot $name}}
 $tokenPins=Get-RecoveryTokenPins
 $allowedSourceNames=@('FullRestrictedPreparationRecovery.psm1','Recover-AzuriteFullPreparation.ps1','FullRestrictedStageTransition.psm1','FullRestrictedStageFileSecurity.cs','FullRestrictedStageFileSecurity.dll','build.json','RestrictedCliNative.dll','RestrictedCliNative.cs','RestrictedCliFullRestricted.cs');if($RecoveryScope -cin @('closed-failed-runtime-recovery','readonly-trace-recovery-continuation')){$allowedSourceNames+=,'FullRestrictedClosedFailedRecovery.ps1'};if($RecoveryScope -ceq 'readonly-trace-recovery-continuation'){$allowedSourceNames+=@('FullRestrictedReadonlyTraceContinuation.ps1','Resume-AzuriteReadonlyTraceRecovery.ps1','ArchivedReadonlyTraceDelete.cs','ArchivedReadonlyTraceDelete.dll','readonly-helper-test.json')}
 if($readonlyRequired){$readonlyPins=Get-RecoveryReadonlyTracePins;$allowedSourceNames+=@($readonlyPins.Keys);foreach($name in $readonlyPins.Keys){$expected[$name]=$readonlyPins[$name].path}}
 $files=@{};foreach($f in $manifest.files){Assert-Recovery (-not $files.ContainsKey($f.name) -and $f.name -cin $allowedSourceNames) 'Unknown/duplicate recovery source';if($expected.ContainsKey($f.name)){Assert-Recovery ($f.path -ceq $expected[$f.name]) 'Executing recovery source path differs'};if($tokenPins.ContainsKey($f.name)){Assert-Recovery ($f.path -ceq $tokenPins[$f.name].path -and $f.sha256 -ceq $tokenPins[$f.name].sha256) 'Token reader must use the exact already-qualified frozen C build'};$b=Read-RecoveryPinnedC $f.path $f.sha256;Assert-Recovery ($b.Length -eq $f.bytes) 'Recovery source length differs';$files[$f.name]=[pscustomobject]@{entry=$f;bytes=$b}}
 $build=ConvertFrom-RecoveryJson $files['build.json'].bytes
 if($readonlyRequired){foreach($name in $readonlyPins.Keys){Assert-Recovery ($files.ContainsKey($name) -and $files[$name].entry.sha256 -ceq $readonlyPins[$name].sha256) 'Readonly helper is not the fixed qualified artifact'}}
 if($readonlyRequired -or $RecoveryScope -ceq 'readonly-trace-recovery-continuation'){$readonlyBuild=ConvertFrom-RecoveryJson $files['readonly-helper-test.json'].bytes;Assert-Recovery ($readonlyBuild.passed -eq $true -and $readonlyBuild.failed -eq 0 -and $readonlyBuild.sourceSha256 -ceq $files['ArchivedReadonlyTraceDelete.cs'].entry.sha256 -and $readonlyBuild.assemblySha256 -ceq $files['ArchivedReadonlyTraceDelete.dll'].entry.sha256 -and $readonlyBuild.assemblyPath -ceq $files['ArchivedReadonlyTraceDelete.dll'].entry.path -and $readonlyBuild.FWritePerformed -eq $false) 'Readonly helper source/build/test binding differs'}
 Assert-Recovery ($build.scope -ceq 'controller-file-security-helper-build' -and $build.target -ceq 'library' -and $build.platform -ceq 'x64' -and $build.exitCode -eq 0 -and $build.sourceSha256 -ceq $files['FullRestrictedStageFileSecurity.cs'].entry.sha256 -and $build.assemblySha256 -ceq $files['FullRestrictedStageFileSecurity.dll'].entry.sha256 -and $build.moduleSha256 -ceq $files['FullRestrictedStageTransition.psm1'].entry.sha256) 'New recovery helper build provenance differs'
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput([Text.Encoding]::UTF8.GetString($files['FullRestrictedStageTransition.psm1'].bytes),[ref]$tokens,[ref]$errors);Assert-Recovery (@($errors).Count -eq 0) 'Stage source parse failed'
 $assign=@($ast.FindAll({param($node)$node -is [Management.Automation.Language.AssignmentStatementAst] -and $node.Left.Extent.Text -ceq '$script:TransitionNativeSource'},$false));Assert-Recovery ($assign.Count -eq 1) 'Stage helper source assignment not unique';$literal=@($assign[0].Right.FindAll({param($node)$node -is [Management.Automation.Language.StringConstantExpressionAst] -and $node.StringConstantType -eq [Management.Automation.Language.StringConstantType]::SingleQuotedHereString},$false));Assert-Recovery ($literal.Count -eq 1) 'Stage helper must be one literal here-string';$embedded=$literal[0].Value;Assert-Recovery ((Get-RecoveryHash ([Text.UTF8Encoding]::new($false).GetBytes($embedded))) -ceq $files['FullRestrictedStageFileSecurity.cs'].entry.sha256) 'Helper source is not the pinned embedded source'
 return [pscustomobject]@{manifest=$manifest;files=$files;manifestSha256=$ExpectedSha256}
}
function Invoke-AzuritePreparationRecovery {
 [CmdletBinding()]param([switch]$Apply,[string]$SourceManifestPath,[string]$ExpectedSourceManifestSha256,[string]$EvidenceDirectory,[string]$RecoveryEvidenceManifestPath,[string]$ExpectedRecoveryEvidenceManifestSha256,[switch]$PostNativeCleanupRecovery,[switch]$ClosedFailedRuntimeRecovery,[string]$RunId)
 $evidenceParameters=@{};foreach($name in @('RecoveryEvidenceManifestPath','ExpectedRecoveryEvidenceManifestSha256','PostNativeCleanupRecovery','ClosedFailedRuntimeRecovery','RunId')){if($PSBoundParameters.ContainsKey($name)){$evidenceParameters[$name]=$PSBoundParameters[$name]}}
 if(-not $Apply){return Get-AzuritePreparationRecoveryPlan @evidenceParameters}
 Assert-Recovery ($PSVersionTable.PSEdition -ceq 'Core' -and $PSVersionTable.PSVersion.Major -ge 7 -and [Environment]::Is64BitProcess) 'Apply requires fresh x64 PowerShell 7'
 Assert-Recovery (-not ('Azurite.Stage.FileSecurity' -as [type])) 'Apply requires a fresh process without a preloaded file-security type'
 $spec=Get-AzuritePreparationRecoveryPlan @evidenceParameters
 if($PostNativeCleanupRecovery -or $ClosedFailedRuntimeRecovery){Assert-RecoveryPostNativeFresh $spec ([datetimeoffset]::UtcNow)}
 $readonlyTrace=$null;if($spec.PSObject.Properties['ArchivedReadonlyTrace']){$readonlyTrace=$spec.ArchivedReadonlyTrace;Assert-Recovery (-not ('Azurite.Recovery.ArchivedReadonlyTraceDelete' -as [type])) 'Apply requires a fresh process without a preloaded readonly trace type'}
 $bindings=Read-RecoverySourceBindings $SourceManifestPath $ExpectedSourceManifestSha256 $spec.RunId $spec.EvidenceManifestSha256 $spec.Scope -ReadonlyTraceBinding $readonlyTrace
 Assert-RecoveryCPath $EvidenceDirectory $false;Assert-Recovery (-not [IO.Directory]::Exists($EvidenceDirectory) -and -not [IO.File]::Exists($EvidenceDirectory)) 'Recovery evidence directory must be fresh'
 Initialize-RecoveryTokenReader $bindings.files['RestrictedCliNative.dll'].bytes
 $identity=Get-RecoveryIdentity;Assert-Recovery ($identity.ownerSid -ceq $spec.OwnerSid -and $identity.logonSid -ceq $spec.LogonSid) 'Current account/logon differs from accepted preparation'
 [Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal
 [void][Reflection.Assembly]::Load([byte[]]$bindings.files['FullRestrictedStageFileSecurity.dll'].bytes)
 Assert-Recovery ($null -ne [Azurite.Stage.FileSecurity].GetMethod('DeleteEmptyDirectory') -and $null -ne [Azurite.Stage.FileSecurity].GetMethod('ArchiveFile')) 'Pinned helper lacks required recovery primitives'
 $state=@{Spec=$spec;RecoveryId=[guid]::NewGuid().ToString('N');EvidenceDirectory=$EvidenceDirectory;ArchiveDirectory=(Join-Path $EvidenceDirectory 'archive');Mutex=$null;Locks=@{};Held=$false;JournalStream=$null}
 if($null -ne $readonlyTrace){$qualified=Initialize-RecoveryReadonlyTraceHelper $bindings;$state.ReadonlyTraceDeleteAssembly=$qualified.Assembly;$state.ReadonlyTraceDeleteMethod=$qualified.Method}
 Lock-RecoveryAncestry $state $EvidenceDirectory $false
 try{
  [void][IO.Directory]::CreateDirectory($EvidenceDirectory);Lock-RecoveryAncestry $state $EvidenceDirectory $true
  [void][IO.Directory]::CreateDirectory($state.ArchiveDirectory);Lock-RecoveryAncestry $state $state.ArchiveDirectory $true
  $state.JournalStream=[IO.FileStream]::new((Join-Path $EvidenceDirectory 'journal.jsonl'),[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read)
  Write-RecoveryCRecord (Join-Path $EvidenceDirectory 'source-bindings.json') ([pscustomobject]@{manifest=$bindings.manifest;manifestSha256=$bindings.manifestSha256;runId=$spec.RunId;recoveryId=$state.RecoveryId;newRecoveryAuthority=$true;oldRuntimeApprovalReused=$false})
  $outcome=Invoke-RecoveryCoordinator $spec (New-RecoveryPhysicalBackend) $state
  return $outcome
 }finally{
  if($state.JournalStream){$state.JournalStream.Dispose()}
  if(-not $state.Held){foreach($h in $state.Locks.Values){$h.Dispose()};$state.Locks.Clear()}
 }
}
. (Join-Path $PSScriptRoot 'FullRestrictedClosedFailedRecovery.ps1')
. (Join-Path $PSScriptRoot 'FullRestrictedReadonlyTraceContinuation.ps1')
Export-ModuleMember -Function Get-AzuritePreparationRecoveryPlan,Invoke-AzuritePreparationRecovery,Invoke-AzuriteReadonlyTraceContinuation
