[CmdletBinding(DefaultParameterSetName='Plan')]
param(
 [Parameter(Mandatory,ParameterSetName='Apply')][switch]$Apply,
 [Parameter(Mandatory,ParameterSetName='Apply')][string]$SourceManifestPath,
 [Parameter(Mandatory,ParameterSetName='Apply')][string]$ExpectedSourceManifestSha256,
 [Parameter(Mandatory,ParameterSetName='Apply')][string]$EvidenceDirectory,
 [string]$RecoveryEvidenceManifestPath,
 [string]$ExpectedRecoveryEvidenceManifestSha256,
 [switch]$PostNativeCleanupRecovery,
 [switch]$ClosedFailedRuntimeRecovery,
 [string]$RunId
)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'FullRestrictedPreparationRecovery.psm1') -Force -DisableNameChecking
$entryExit=0;$result=$null
try{
 $result=Invoke-AzuritePreparationRecovery @PSBoundParameters
 if($Apply){$result|ConvertTo-Json -Depth 12;if(-not $result.Success){$entryExit=1}}
 else{$summary=[pscustomobject]@{mode='Plan';recoveryScope=$result.Scope;runId=$result.RunId;evidenceMode=$result.EvidenceMode;evidenceManifestSha256=$result.EvidenceManifestSha256;originalCount=$result.Original.Count;preparedCount=$result.Prepared.Count;createdCount=$result.Created.Count;archiveFileCount=@($result.Created|Where-Object{-not $_.directory}).Count;payloadRestoreCount=$result.PayloadRestores.Count;descriptorRestoreCount=$result.DescriptorRestores.Count;bindings=$result.Bindings;FReadPerformed=$false;FWritePerformed=$false;WillLaunch=$false;RuntimeAllowed=$false;runtimeAcceptanceGranted=$false};if($ClosedFailedRuntimeRecovery){$summary|Add-Member originalRuntimeCleanupVerified $result.OriginalRuntimeCleanupVerified;$summary|Add-Member aaCreationStatus $result.AaCreationStatus;$summary|Add-Member applicationAccepted $false;$summary|Add-Member sharedRestorationAllowed $false;$summary|Add-Member sharedEvidenceFreshForApply $result.SharedEvidenceFreshForApply;$summary|Add-Member actionPlan $result.ActionPlan};$summary|ConvertTo-Json -Depth 8}
}catch{$entryExit=1;[pscustomobject]@{Success=$false;error=$_.Exception.ToString();WillLaunch=$false;RuntimeAllowed=$false;automaticRetryAllowed=$false}|ConvertTo-Json -Depth 8}
finally{if($Apply){$retained=& (Get-Module FullRestrictedPreparationRecovery) {$script:RecoveryRetained.Count -gt 0};if($retained -or ($result -and $result.LeaseHeld)){try{[Console]::Error.WriteLine('Recovery lease ownership remains unconfirmed; retaining this controller for root inspection.')}finally{while($true){[Threading.Thread]::Sleep(30000)}}}}}
exit $entryExit
