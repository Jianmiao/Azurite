#requires -Version 7.0
[CmdletBinding()]
param(
 [Parameter(Mandatory)][string]$InputRecordPath,
 [Parameter(Mandatory)][string]$ExpectedInputRecordSha256,
 [Parameter(Mandatory)][string]$ReviewedSourcesPath,
 [Parameter(Mandatory)][string]$ExpectedReviewedSourcesSha256,
 [switch]$Execute
)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
if($PSScriptRoot -cne ($repo+'\tools\headless')){throw 'Fixed sequence entry directory required'}
$full=[IO.Path]::GetFullPath($ReviewedSourcesPath)
if($full -cne $ReviewedSourcesPath -or -not $full.StartsWith($repo+'\',[StringComparison]::Ordinal) -or $ExpectedReviewedSourcesSha256 -cnotmatch '\A[a-f0-9]{64}\z'){throw 'External root-reviewed C source manifest digest required'}
$cursor=$full;while($cursor){$i=Get-Item -LiteralPath $cursor -Force;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Source manifest reparse ancestry refused'};$cursor=Split-Path -Parent $cursor}
$bytes=[IO.File]::ReadAllBytes($full)
$sha=[Security.Cryptography.SHA256]::Create();try{$digest=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
if($bytes.Length -gt 1048576 -or $digest -cne $ExpectedReviewedSourcesSha256){throw 'Root-reviewed source manifest differs'}
$manifest=[Text.UTF8Encoding]::new($false,$true).GetString($bytes)|ConvertFrom-Json -DateKind String
foreach($role in @('SequenceEntry','SequenceModule')){
 $rows=@($manifest.files|Where-Object role -CEQ $role);$path=if($role -ceq 'SequenceEntry'){$PSCommandPath}else{Join-Path $PSScriptRoot 'AzuriteCapabilitiesSequence.psm1'}
 if($rows.Count -ne 1 -or $rows[0].path -cne $path -or (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -cne $rows[0].sha256){throw ('Sequence bootstrap source mismatch: '+$role)}
}
Import-Module (Join-Path $PSScriptRoot 'AzuriteCapabilitiesSequence.psm1') -Force -DisableNameChecking
$result=$null
try{
 $result=Invoke-AzuriteCapabilitiesSequence -InputRecordPath $InputRecordPath -ExpectedInputRecordSha256 $ExpectedInputRecordSha256 -ReviewedSourcesPath $ReviewedSourcesPath -ExpectedReviewedSourcesSha256 $ExpectedReviewedSourcesSha256 -Execute:$Execute
 if($Execute){[pscustomobject]@{runId=$result.runId;passed=$result.passed;primaryError=$result.primaryError;ownerRetained=$result.ownerRetained;completedStageCount=$result.steps.Count;resultPath=(Join-Path $repo ('artifacts\aa-fr-capabilities-sequence\run-'+$result.runId+'\sequence-result.json'))}|ConvertTo-Json -Depth 8}else{$result|ConvertTo-Json -Depth 20}
}finally{
 $owners=Get-Variable -Name AzuriteSequenceRetainedOwners -Scope Global -ErrorAction SilentlyContinue
 if(($result -and $result.PSObject.Properties['ownerRetained'] -and $result.ownerRetained) -or ($owners -and $owners.Value.Count -gt 0)){
  try{Write-Warning 'Child exit or output ownership remains unconfirmed. This controller stays alive for root inspection; no retry, kill or next stage will run.'}catch{}
  while($true){Start-Sleep -Seconds 30}
 }
}
if($Execute -and -not $result.passed){exit 1}
