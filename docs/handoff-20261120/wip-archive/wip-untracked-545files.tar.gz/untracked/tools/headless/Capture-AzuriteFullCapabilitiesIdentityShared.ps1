#requires -Version 5.1
param([Parameter(Mandatory)][ValidateScript({$_ -cmatch '\A[a-f0-9]{32}\z' -and $_ -cne ('0'*32)})][string]$RunId,[Parameter(Mandatory)][string]$HarmlessReceiptPath,[Parameter(Mandatory)][string]$HarmlessReceiptSha256)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$run=$RunId
$tooling=$repo+'\.superpowers\sdd\azurite-authoring-20261108\aa-fr-ftarget-cf95-build-20261114\tooling'
$pins=[ordered]@{'HeadlessCore.psm1'='75f2dccc4015059fe41a476c87117b315f2d38f27569629c5f2192d4792b757f';'RestrictedCliCore.psm1'='452a4255fd950c9b6d1e3e35c537fdb93bd4b40874fb4536dfcc44c754ab1f59';'CurrentAccountCli.psm1'='495efe99ea5f32330d7a1b25148d9cd637a508a83fac93b5037a0db1dcb45ea9'}
function Test-HarmlessReceiptKind($Receipt) {
 if($null -eq $Receipt){return $false}
 foreach($name in @('schema','scope','passed','productionTargetExecuted','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified')){if(-not $Receipt.PSObject.Properties[$name]){return $false}}
 if($Receipt.schema -isnot [int] -and $Receipt.schema -isnot [long]){return $false}
 foreach($name in @('passed','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified')){if($Receipt.$name -isnot [bool] -or -not $Receipt.$name){return $false}}
 if($Receipt.productionTargetExecuted -isnot [bool] -or $Receipt.productionTargetExecuted){return $false}
 if($Receipt.schema -eq 1){return ($Receipt.scope -ceq 'actual-native-full-restricted-harmless-lifecycle' -and $Receipt.PSObject.Properties['desktopLeaseAcrossBootstrapExit'] -and $Receipt.desktopLeaseAcrossBootstrapExit -is [bool] -and $Receipt.desktopLeaseAcrossBootstrapExit)}
 if($Receipt.schema -ne 2 -or $Receipt.scope -cne 'actual-native-full-restricted-cleanup-lifecycle' -or $Receipt.PSObject.Properties['desktopLeaseAcrossBootstrapExit']){return $false}
 foreach($name in @('cleanupEvidenceProtocol','outerDesktopHeldUntilJobDrain','bootstrapExitCleanupObserved','cleanupTraceComplete','externalLiveDescendantIntervalClaimed')){if(-not $Receipt.PSObject.Properties[$name]){return $false}}
 if($Receipt.cleanupEvidenceProtocol -cne 'cleanup-ordering.v1'){return $false}
 foreach($name in @('outerDesktopHeldUntilJobDrain','bootstrapExitCleanupObserved','cleanupTraceComplete')){if($Receipt.$name -isnot [bool] -or -not $Receipt.$name){return $false}}
 return ($Receipt.externalLiveDescendantIntervalClaimed -is [bool] -and -not $Receipt.externalLiveDescendantIntervalClaimed)
}
function Need($value,[string]$message){if(-not $value){throw $message}}
function HashBytes([byte[]]$bytes){$s=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($s.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
function Ordinary([string]$path){$p=[IO.Path]::GetFullPath($path);Need ($p -ceq $path) 'Canonical path required';while($p){$i=Get-Item -LiteralPath $p -Force;Need (-not($i.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'Reparse ancestry refused';$p=Split-Path -Parent $p}}
function Pin([string]$path,[string]$sha){Ordinary $path;Need ((Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -ceq $sha) ('Source/artifact drift: '+[IO.Path]::GetFileName($path))}
function NoAA(){ $p=@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'" -ErrorAction Stop);Need ($p.Count -eq 0) 'AA/probe active; read capture deferred';return [datetime]::UtcNow.ToString('o') }
function Save([string]$name,$value){$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 90));Need ($bytes.Length -le 67108864) 'Capture exceeds bounded output';$p=Join-Path $output $name;$s=[IO.File]::Open($p,'CreateNew','Write','Read');try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()};return [pscustomobject]@{path=$p;sha256=HashBytes $bytes;bytes=$bytes.Length}}
Need ([Environment]::Is64BitProcess -and $PSVersionTable.PSVersion.Major -eq 5) 'Use fresh system x64 PS5.1'
Need ($HarmlessReceiptPath.StartsWith($repo+'\',[StringComparison]::Ordinal) -and $HarmlessReceiptSha256 -cmatch '^[a-f0-9]{64}$') 'Exact C reviewed harmless receipt required'
Ordinary $HarmlessReceiptPath
$bytes=[IO.File]::ReadAllBytes($HarmlessReceiptPath);Need ($bytes.Length -le 131072 -and (HashBytes $bytes) -ceq $HarmlessReceiptSha256) 'Bounded receipt bytes drift'
$receipt=([Text.UTF8Encoding]::new($false,$true).GetString($bytes))|ConvertFrom-Json
Need ((Test-HarmlessReceiptKind $receipt) -and $receipt.nativeSourceSha256 -ceq 'cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533' -and $receipt.sharedNativeSourceSha256 -ceq 'f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921') 'Harmless receipt version/scope/lineage differs'
foreach($n in $pins.Keys){Pin ($repo+'\tools\headless\'+$n) $pins[$n]}
Pin ($tooling+'\RestrictedCliNative.dll') 'af4b1a7e0e18721824e2d64f6e47eec148b2553f437a6f4390f6cf08df165343'
Pin ($repo+'\tools\headless\RestrictedCliFullRestricted.cs') 'cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533'
Pin ($repo+'\tools\headless\RestrictedCliNative.cs') 'f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'
$mutex=[Threading.Mutex]::new($false,'Global\AzuriteRestrictedCli-AA');$held=$false;$output=$null;$errorText=$null;$cleanup=@();$passed=$false
$record=[ordered]@{schema=1;scope='actual current-account identity and bounded shared Before read capture';runId=$run;harmlessReceiptSha256=$HarmlessReceiptSha256;aaExecuted=$false;stageWrites=$false;sharedWrites=$false;registryWrites=$false;passed=$false}
try{
 try{$held=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$held=$true;throw 'Abandoned test mutex requires inspection'}
 Need $held 'Another test owns the shared capture lease'
 $record.aaBefore=NoAA
 $parent=$repo+'\artifacts\aa-fr-live-inputs';Ordinary ($repo+'\artifacts');if(-not(Test-Path -LiteralPath $parent)){[void][IO.Directory]::CreateDirectory($parent)};Ordinary $parent
 $output=$parent+'\capture-'+[guid]::NewGuid().ToString('N');Need (-not(Test-Path -LiteralPath $output)) 'Fresh output required';[void][IO.Directory]::CreateDirectory($output);Ordinary $output
 foreach($n in $pins.Keys){Import-Module ($repo+'\tools\headless\'+$n) -Force -DisableNameChecking}
 Add-Type -Path ($tooling+'\RestrictedCliNative.dll')
 $raw=[Azurite.Restricted.FullBootstrapIdentity]::Read($run)
 Need ($raw.status -ceq 'passed' -and -not $raw.isAdministrator -and $raw.unexpectedPrivileges.Count -eq 0) 'Original unelevated identity required'
 $environment=[ordered]@{};foreach($n in @('localAppData','environmentProfile','environmentLocalAppData','environmentAppData','environmentTemp','environmentTmp')){$environment[$n]=$raw[$n]}
 $proof=Assert-AzuriteCurrentIdentity ([pscustomobject]$raw) $raw.identitySid $raw.userProfile $raw.localLow ([pscustomobject]$environment)
 $identity=[ordered]@{};foreach($key in $raw.Keys){$identity[$key]=$raw[$key]};$identity.controllerProfile=$raw.userProfile;$identity.currentLocalLow=$raw.localLow;$identity.currentEnvironment=[pscustomobject]$environment;$identity.profileIdentity=$raw;$identity.profileProof=$proof
 $record.originalIdentity=Save 'original-identity.json' $identity
 $scope=New-AzuriteSharedStateSpec $raw.localLow 'F:\AzureArchive_101' $raw.identitySid
 $registry=Read-AzuritePlayerPrefsSnapshot
 $before=New-AzuriteSharedSnapshot $scope $registry $run Before
 Assert-AzuriteSharedSnapshot $before $scope $run Before
 $record.sharedScope=Save 'scope.json' $scope
 $record.sharedBefore=Save 'before.json' $before
 $record.sharedFileCount=$before.files.Count;$record.sharedDirectoryCount=$before.directories.Count;$record.dailyProfile=$scope.dailyProfileName
 $record.aaAfter=NoAA
 $passed=$true
}catch{$errorText=$_.Exception.ToString()}
finally{
 if($held){try{$mutex.ReleaseMutex();$held=$false}catch{$cleanup+=@($_.Exception.ToString())}}
 if(-not $held){try{$mutex.Dispose()}catch{$cleanup+=@($_.Exception.ToString())}}
 $record.passed=$passed -and $null -eq $errorText -and $cleanup.Count -eq 0;$record.error=$errorText;$record.cleanupErrors=$cleanup;$record.leaseStillHeld=$held;$record.completedUtc=[datetime]::UtcNow.ToString('o')
 if($output){$saved=Save 'capture-result.json' $record;[pscustomobject]@{result=$saved;passed=$record.passed;error=$errorText;sharedFileCount=$record['sharedFileCount'];dailyProfile=$record['dailyProfile']}|ConvertTo-Json -Depth 5}else{[pscustomobject]$record|ConvertTo-Json -Depth 5}
}
if(-not $record.passed){exit 1}
