using Azurite.EditorIsolation;
using Azurite.NormalEditor;
using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Entry;
using Azurite.NormalEditor.Loader;
using System.Text.Json;

if(args.Length!=1||!Path.IsPathFullyQualified(args[0]))throw new ArgumentException("Supply one explicit fresh fixture output directory.");
var output=Path.GetFullPath(args[0]);
if(!RunPaths.Same(output,args[0])||Directory.Exists(output)||File.Exists(output))throw new ArgumentException("A canonical fresh fixture output directory is required.");
RunPaths.RequireSafeExisting(Path.GetDirectoryName(output)!);
Directory.CreateDirectory(output);
var results=new List<object>();
void Need(bool value,string reason){if(!value)throw new Exception(reason);}
void Test(string name,Action action){try{action();results.Add(new{name,passed=true,error=(string?)null});}catch(Exception e){results.Add(new{name,passed=false,error=e.Message});}}
void Reject(AdmissionFixture f,Action action){bool rejected=false;try{action();}catch(InvalidOperationException){rejected=true;}Need(rejected&&f.Admission.Failure is not null,"refusal did not retain failure");}

Test("strict actual admission permits installation with matching immutable observations",()=>{var f=new AdmissionFixture();f.Admission.RequireInstallation(f.Binding);Need(f.Admission.Failure is null&&f.Environment.Observations>0&&f.Environment.IntegrityChecks>0,"no real context checks");});
Test("native callbacks require actual guard completion but registration does not",()=>{var f=new AdmissionFixture(completed:false);f.Admission.RequireInstallation(f.Binding);Reject(f,()=>f.Admission.RequireCallback(f.Binding,CallbackKind.Awake,100));});
Test("same-value cloned AdapterBinding is not the registered object",()=>{var f=new AdmissionFixture();Reject(f,()=>f.Admission.RequireInstallation(f.Binding with{}));});
Test("owner publication waits for verified actual Awake route after",()=>{
 var f=new AdmissionFixture();f.Awake();Need(f.Admission.BoundSettingsOwner==0,"candidate Awake owner published before routing");var intent=f.Intent();
 f.Admission.RequireRouting(f.Binding,intent);Need(f.Admission.BoundSettingsOwner==0,"intent published owner");f.Admission.RecordRouting(intent);Need(f.Admission.BoundSettingsOwner==0,"audit intent published owner");
 f.Admission.RecordRouting(f.After(intent));Need(f.Admission.BoundSettingsOwner==100&&f.Audit.Count==2,"matching actual after did not publish owner");
});
Test("both permitted fields and native default-path reroute have real positive paths",()=>{
 var f=new AdmissionFixture();f.Awake();foreach(var intent in new[]{f.Intent(),f.Intent(field:"_cachedWorkspacePath"),f.Intent(stage:RouteStage.InitReadYield,before:f.Before with{SettingsPath=f.Binding.ExpectedNativeSettingsPath})}){f.Admission.RequireRouting(f.Binding,intent);f.Admission.RecordRouting(intent);f.Admission.RecordRouting(f.After(intent));}
 Need(f.Audit.Count==6&&f.Admission.BoundSettingsOwner==100&&f.Admission.Failure is null,"valid routing refused");
});
Test("resource entry before isReady delegates the same actual binding and settings",()=>{var f=new AdmissionFixture();f.Publish();var s=f.Before with{Data=200,Ready=false,SettingsPath=f.Paths.Settings,CachedWorkspace=f.Paths.Workspace,DataWorkspace=f.Paths.Workspace,DataCache=f.Paths.Cache};f.Admission.RequireResources(f.Binding,500,s);Need(f.Routes.ResourceCalls==1&&!f.Routes.LastSettings!.Ready&&ReferenceEquals(f.Routes.LastBinding,f.Binding),"ResourceStart incorrectly required readiness or cloned binding");});
Test("frozen policy observations retain native init timing without a second FSM",()=>{var f=new AdmissionFixture();f.Publish();var observation=new SettingsObservation(f.Binding.Policy.RunId,1,f.Owner.ProcessId,7,1,100,200,false,f.Paths.Settings,f.Paths.Workspace,f.Paths.Workspace,f.Paths.Cache);f.Admission.AssertPermitted(f.Binding.Policy,NormalStep.ResourceStart,observation);Need(f.Admission.Failure is null,"valid false-ready policy observation refused");});
foreach(string change in new[]{"process","creation","managed","native","executable","loader"})Test("actual context drift rejects "+change,()=>{
 var f=new AdmissionFixture();var i=f.Owner;i=change switch{"process"=>i with{ProcessId=i.ProcessId+1},"creation"=>i with{ProcessCreationFileTime=i.ProcessCreationFileTime+1},"managed"=>i with{ManagedThreadId=i.ManagedThreadId+1},"native"=>i with{NativeThreadId=8},"executable"=>i with{ExecutablePath=@"C:\other\AzureArchive.exe"},_=>i with{LoaderAssemblyPath=@"C:\other\loader.dll"}};f.Environment.Current=f.Environment.Current with{Identity=i};Reject(f,()=>f.Admission.RequireInstallation(f.Binding));
});
foreach(string flag in new[]{"cli","transport","batch","graphics","sound","log","offline","extra"})Test("launch observation rejects "+flag,()=>{
 var f=new AdmissionFixture();var o=f.Environment.Current;var a=o.Arguments.ToList();switch(flag){case "cli":o=o with{CliActive=true};break;case "transport":o=o with{CliTransportPresent=true};break;case "batch":a.Remove("-batchmode");break;case "graphics":a.Remove("-nographics");break;case "sound":a.Remove("-disableaudio");break;case "log":a[4]=@"C:\daily\unity.log";break;case "offline":a[6]=@"C:\daily\cache";break;default:a.Add("--unbound");break;}f.Environment.Current=o with{Arguments=a};Reject(f,()=>f.Admission.RequireInstallation(f.Binding));
});
Test("changed prepared inputs revoke admission before callbacks",()=>{var f=new AdmissionFixture();f.Environment.IntegrityFailure=true;Reject(f,()=>f.Admission.RequireInstallation(f.Binding));});
Test("actual foreign managed thread is refused without observation or audit",()=>{var f=new AdmissionFixture();bool refused=Task.Run(()=>{try{f.Admission.RequireInstallation(f.Binding);return false;}catch(InvalidOperationException){return true;}}).GetAwaiter().GetResult();Need(refused&&f.Admission.Failure is not null&&f.Environment.Observations==0&&f.Audit.Count==0,"foreign invocation entered owner observers");});
foreach(string fault in new[]{"field","target","owner","stage","early-after","cli","data","ready"})Test("routing intent refuses "+fault,()=>{
 var f=new AdmissionFixture();f.Awake();var i=f.Intent();i=fault switch{"field"=>i with{Field="data"},"target"=>i with{Target=@"C:\daily\settings.json"},"owner"=>i with{Before=i.Before with{Owner=101}},"stage"=>i with{Stage=RouteStage.InitReadYield,Field="_cachedWorkspacePath",Target=f.Paths.Workspace},"early-after"=>f.After(i),"cli"=>i with{Before=i.Before with{CliActive=true}},"data"=>i with{Before=i.Before with{Data=200}},_=>i with{Before=i.Before with{Ready=true}}};Reject(f,()=>f.Admission.RequireRouting(f.Binding,i));Need(f.Audit.Count==0&&f.Admission.BoundSettingsOwner==0,"invalid intent mutated evidence/owner");
});
Test("after without matching audited intent is refused",()=>{var f=new AdmissionFixture();f.Awake();Reject(f,()=>f.Admission.RecordRouting(f.After(f.Intent())));});
Test("after cannot change data dirty owner or other routed field",()=>{foreach(string field in new[]{"data","dirty","owner","workspace"}){var f=new AdmissionFixture();f.Awake();var i=f.Intent();f.Admission.RequireRouting(f.Binding,i);f.Admission.RecordRouting(i);var a=f.After(i);a=a with{After=field switch{"data"=>a.After! with{Data=200},"dirty"=>a.After! with{Dirty=true},"owner"=>a.After! with{Owner=101},_=>a.After! with{CachedWorkspace="changed"}}};Reject(f,()=>f.Admission.RecordRouting(a));Need(f.Admission.BoundSettingsOwner==0,"bad after published owner");}});
Test("duplicate audit after is refused instead of replayed",()=>{var f=new AdmissionFixture();f.Publish();Reject(f,()=>f.Admission.RecordRouting(f.After(f.Intent())));Need(f.Audit.Count==2,"duplicate audit written");});
Test("audit sink reentry is latched even if sink swallows its refusal",()=>{var f=new AdmissionFixture();f.Awake();f.OnAudit=()=>{try{f.Admission.RequireInstallation(f.Binding);}catch{}};var i=f.Intent();f.Admission.RequireRouting(f.Binding,i);Reject(f,()=>f.Admission.RecordRouting(i));Need(f.Admission.BoundSettingsOwner==0,"reentrant audit published owner");});
Test("audit sink failure cannot publish owner",()=>{var f=new AdmissionFixture();f.Awake();f.OnAudit=()=>throw new IOException("audit failed");var i=f.Intent();f.Admission.RequireRouting(f.Binding,i);Reject(f,()=>f.Admission.RecordRouting(i));Need(f.Admission.BoundSettingsOwner==0,"failed audit published owner");});
Test("resource failure propagates without manufacturing readiness",()=>{var f=new AdmissionFixture();f.Publish();f.Routes.FailEntry=true;Reject(f,()=>f.Admission.RequireResources(f.Binding,500,f.Before with{Data=200,Ready=false}));});
Test("revocation is permanent and preserves first failure",()=>{var f=new AdmissionFixture();f.Admission.Revoke("first");f.Admission.Revoke("second");Reject(f,()=>f.Admission.RequireInstallation(f.Binding));Need(f.Admission.Failure=="first","original failure overwritten");});

LifetimeCases.Run(output,Test,Need);
PreparationCases.Run(output,Test,Need);
StartupWindowCases.Run(Test,Need);
DeploymentCases.Run(Test,Need);
Test("SOURCE checks never load target host or generated interop assemblies",()=>Need(!AppDomain.CurrentDomain.GetAssemblies().Any(a=>a.GetName().Name is "Assembly-CSharp" or "UnityEngine.CoreModule" or "Unity.Addressables" or "Il2CppInterop.Runtime" or "Azurite.NormalEditor.Adapter.Host.PreparationOnly" or "Azurite.NormalEditor.Entry.Host.PreparationOnly" or "Azurite.NormalEditor.Loader.PreparationOnly" or "Azurite.NormalEditor.Loader.Guard.PreparationOnly"),"A target Host/interop assembly was loaded"));
Console.WriteLine(JsonSerializer.Serialize(results));int failed=results.Count(x=>!(bool)x.GetType().GetProperty("passed")!.GetValue(x)!);Console.WriteLine($"RESULT passed={results.Count-failed} failed={failed}; sourceOnly=true; nativeExecuted=false; hostExecuted=false; observationsAreFixtures=true");return failed==0?0:1;

sealed class AdmissionFixture
{
 internal readonly RunPaths Paths;internal readonly AdapterBinding Binding;internal readonly NormalOwnerIdentity Owner;internal readonly TestEnvironment Environment;internal readonly TestRoutes Routes=new();internal readonly TestGuard Guard;
 internal readonly List<RouteRecord> Audit=new();internal readonly NormalEntryAdmission Admission;internal Action? OnAudit;
 internal const string ManifestHash="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
 internal AdmissionFixture(bool completed=true){var id=Guid.NewGuid().ToString("D");string lab=@"C:\explicit-loader-observation-fixture";Paths=new(lab,Path.Combine(lab,"runs",id),Path.Combine(lab,"install"));Binding=new(new(id,1,System.Environment.ProcessId,7,Paths,new('a',64),new('b',64),"lab-read-"+id),"controller-bound-native-default-string"){HostAssemblySha256=new('c',64),CoreAssemblySha256=new('d',64)};Owner=new(System.Environment.ProcessId,1,System.Environment.CurrentManagedThreadId,7,Path.Combine(Paths.Install,"AzureArchive.exe"),Path.Combine(Paths.Install,InstallationAuthority.AdapterSubdirectory,"Azurite.NormalEditor.Loader.PreparationOnly.dll"));var resources=new NormalResourcePreparation(Path.Combine(lab,"contract.json"),new('a',64),Path.Combine(Paths.Install,"catalog.json"),Path.Combine(lab,"offline","catalog.json"),new('b',64),Path.Combine(Paths.Install,"settings.json"),new('c',64),Path.Combine(lab,"offline"),Path.Combine(lab,"offline","catalog.hash"),new('d',64),Path.Combine(lab,"bundle-manifest.json"),new('e',64),Path.Combine(lab,"offline","complete.json"),new('f',64),1,16);Environment=new(new(Owner,new[]{"-batchmode","-nographics","-disableaudio","-logFile",Path.Combine(Paths.Output,"unity.log"),"--aap-offline-resources",resources.OfflineRoot},false,false));Guard=new(ManifestHash,completed);Admission=new(Binding,ManifestHash,new('e',64),Owner,resources,Environment,Routes,Guard,r=>{Audit.Add(r);OnAudit?.Invoke();});}
 internal NativeSettings Before=>new(100,0,false,false,"native-before-awake","native-workspace",null,null,null,false,false);
 internal void Awake()=>Admission.RequireCallback(Binding,CallbackKind.Awake,100);
 internal RouteRecord Intent(string field="settingFilePath",RouteStage stage=RouteStage.Awake,NativeSettings? before=null)=>new(stage,field,field=="settingFilePath"?Paths.Settings:Paths.Workspace,before??Before,null);
 internal RouteRecord After(RouteRecord i)=>i with{After=i.Field=="settingFilePath"?i.Before with{SettingsPath=i.Target}:i.Before with{CachedWorkspace=i.Target}};
 internal void Publish(){Awake();var i=Intent();Admission.RequireRouting(Binding,i);Admission.RecordRouting(i);Admission.RecordRouting(After(i));}
}
sealed class TestEnvironment : INormalAdmissionEnvironment
{
 internal NormalHostObservation Current;internal bool IntegrityFailure;internal int Observations,IntegrityChecks;internal Action? OnObserve;
 internal TestEnvironment(NormalHostObservation observation)=>Current=observation;
 public NormalHostObservation Observe(){Observations++;OnObserve?.Invoke();return Current;}
 public NormalProcessObservation ObserveProcess()=>new(Current.Identity,Current.Arguments,Current.CliTransportPresent);
 public void RequireUnchanged(){IntegrityChecks++;if(IntegrityFailure)throw new InvalidOperationException("prepared inputs changed");}
}
sealed class TestGuard : INormalGuardLink
{
 private readonly StartupGuardState state=new();
 internal TestGuard(string hash,bool completed){state.Arm(hash);if(completed){state.RoutesReady(hash,StartupGuardState.RequiredRoutes);state.Complete(null);}}
 public void RequireArmed(string hash)=>state.RequireArmed(hash);
 public void RequireCompleted(string hash)=>state.RequireCompleted(hash);
 public void RequireStartupWindow(string hash)=>state.RequireArmed(hash);
 public void RoutesReady(string hash,IReadOnlyCollection<string> routes)=>state.RoutesReady(hash,routes);
}
sealed class TestRoutes : INormalRoutes
{
 public IReadOnlyCollection<string> InstalledRoutes=>new[]{"cache","workspace","discovery","offline","addressSet","addressClear","addressEvaluate"};
 internal bool FailEntry;internal int ResourceCalls;internal NativeSettings? LastSettings;internal AdapterBinding? LastBinding;
 public void Register(NormalRouteContext context){ }
 public void RequireResourceEntry(AdapterBinding binding,long resource,NativeSettings settings){ResourceCalls++;LastBinding=binding;LastSettings=settings;if(FailEntry)throw new InvalidOperationException("native route entry fact absent");}
 public void RequireCatalogClosure(AdapterBinding binding,CatalogEvidence observation){ }
 public void RequireShutdownSafe(AdapterBinding binding){ }
}
