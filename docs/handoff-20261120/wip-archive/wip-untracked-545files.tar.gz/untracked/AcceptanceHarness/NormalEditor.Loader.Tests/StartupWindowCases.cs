using Azurite.EditorIsolation;
using Azurite.NormalEditor.Loader;

static class StartupWindowCases
{
    private static readonly string Hash=new('a',64);
    private static NormalStartupWindow New(Func<uint>? native=null)=>new(Hash,new(Environment.ProcessId,1,Environment.CurrentManagedThreadId,7,@"C:\source-fixture\AzureArchive.exe",@"C:\source-fixture\loader.dll"),native??(()=>7));
    internal static void Run(Action<string,Action> test,Action<bool,string> need)
    {
        void Deny(Action a){bool denied=false;try{a();}catch(InvalidOperationException){denied=true;}need(denied,"startup continuation unexpectedly allowed");}
        test("startup positive path enters held Execute then completes exact12 routes",()=>{var w=New();w.RequireArmed(Hash);w.EnterExecute();w.RequireStartupWindow(Hash);w.RoutesReady(Hash,StartupGuardState.RequiredRoutes);w.RequireStartupWindow(Hash);w.Complete(null);w.RequireCompleted(Hash);w.Complete(null);});
        test("armed-only startup cannot pretend Execute continuation is held",()=>{var w=New();w.RequireArmed(Hash);Deny(()=>w.RequireStartupWindow(Hash));Deny(()=>w.EnterExecute());});
        test("missing or incomplete loader cannot release native startup",()=>{foreach(var routes in new[]{Array.Empty<string>(),new[]{"awake"}}){var w=New();w.EnterExecute();if(routes.Length>0)Deny(()=>w.RoutesReady(Hash,routes));Deny(()=>w.Complete(null));Deny(()=>w.RequireCompleted(Hash));}});
        test("completed startup cannot be reused as cache pre-use window",()=>{var w=New();w.EnterExecute();w.RoutesReady(Hash,StartupGuardState.RequiredRoutes);w.Complete(null);Deny(()=>w.RequireStartupWindow(Hash));});
        test("swallowed chainloader exception permanently revokes continuation",()=>{var w=New();w.EnterExecute();w.RoutesReady(Hash,StartupGuardState.RequiredRoutes);Deny(()=>w.Complete(new InvalidOperationException("plugin exception")));Deny(()=>w.Complete(null));Deny(()=>w.RequireCompleted(Hash));});
        test("foreign real managed thread never reaches native observer",()=>{int samples=0;var w=New(()=>{samples++;return 7;});int before=samples;Task.Run(()=>Deny(()=>w.EnterExecute())).GetAwaiter().GetResult();need(samples==before,"foreign guard touched native observer");Deny(()=>w.EnterExecute());});
        test("changed actual native owner refuses continuation",()=>{uint thread=7;var w=New(()=>thread);w.EnterExecute();thread=8;Deny(()=>w.RequireStartupWindow(Hash));});
        test("wrong manifest cannot install routes or complete",()=>{var w=New();w.EnterExecute();Deny(()=>w.RoutesReady(new('b',64),StartupGuardState.RequiredRoutes));Deny(()=>w.Complete(null));});
        test("reentrant Execute refuses a second continuation",()=>{var w=New();w.EnterExecute();Deny(()=>w.EnterExecute());Deny(()=>w.RequireStartupWindow(Hash));});
    }
}
