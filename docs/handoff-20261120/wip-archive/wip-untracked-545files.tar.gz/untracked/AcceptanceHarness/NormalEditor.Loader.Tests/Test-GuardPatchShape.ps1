param([Parameter(Mandatory)][string]$Source,[Parameter(Mandatory)][string]$Report)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
foreach($path in @($Source,$Report)){if(-not [IO.Path]::GetFullPath($path).StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'C worktree-only SOURCE paths required'}}
if(Test-Path -LiteralPath $Report){throw 'Fresh predicate report required'}
$text=[IO.File]::ReadAllText($Source)
$start=$text.IndexOf('    private static void Verify()',[StringComparison]::Ordinal)
$end=$text.IndexOf('    private static void BeforeExecute()',$start,[StringComparison]::Ordinal)
if($start -lt 0 -or $end -le $start){throw 'Cannot extract the unique actual Verify function'}
$predicate=$text.Substring($start,$end-$start)
# Executes the unchanged extracted production predicate over BCL-only stand-ins.
# It does not load the target Guard/Harmony assemblies or perform any patching.
$prefix=@'
#nullable enable
using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
namespace GuardPatchShapeChecks {
 public sealed class Patch { public string owner; public MethodInfo PatchMethod; public Patch(string o,MethodInfo m){owner=o;PatchMethod=m;} }
 public sealed class Patches { public Patch[] Prefixes=Array.Empty<Patch>(),Postfixes=Array.Empty<Patch>(),Transpilers=Array.Empty<Patch>(),Finalizers=Array.Empty<Patch>(),ILManipulators=Array.Empty<Patch>(); }
 public sealed class Harmony { public string Id="lab.azurite.normal-editor.guard"; public static Patches Current=new(); public static Patches GetPatchInfo(MethodInfo method)=>Current; }
 public static class NormalStartupGuard {
  private static readonly Harmony harmony=new();
  private static readonly MethodInfo execute=typeof(NormalStartupGuard).GetMethod(nameof(BeforeExecute),BindingFlags.NonPublic|BindingFlags.Static)!;
  private static void BeforeExecute(){} private static void AfterExecute(){} private static void AfterExecuteFinalizer(){}
'@
$suffix=@'
  private static Patch Own(string name)=>new(harmony.Id,typeof(NormalStartupGuard).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Static)!);
  private static bool Accepted(){try{Verify();return true;}catch(InvalidOperationException){return false;}}
  public static object[] Run(){
   var rows=new List<object>();
   foreach(string name in new[]{"baseline","foreign-prefix","foreign-transpiler","foreign-ilmanipulator","same-owner-ilmanipulator"}){
    var p=new Patches{Prefixes=new[]{Own(nameof(BeforeExecute))},Postfixes=new[]{Own(nameof(AfterExecute))},Finalizers=new[]{Own(nameof(AfterExecuteFinalizer))}};
    var foreign=new Patch("foreign.source.owner",execute);
    if(name=="foreign-prefix")p.Prefixes=p.Prefixes.Concat(new[]{foreign}).ToArray();
    if(name=="foreign-transpiler")p.Transpilers=new[]{foreign};
    if(name=="foreign-ilmanipulator")p.ILManipulators=new[]{foreign};
    if(name=="same-owner-ilmanipulator")p.ILManipulators=new[]{Own(nameof(BeforeExecute))};
    Harmony.Current=p;bool accepted=Accepted(),expected=name=="baseline";
    rows.Add(new Dictionary<string,object>{{"case",name},{"expectedAccept",expected},{"actualAccepts",accepted},{"passed",accepted==expected}});
   }
   return rows.ToArray();
  }
 }
}
'@
Add-Type -TypeDefinition ($prefix+"`n"+$predicate+"`n"+$suffix)
$cases=[GuardPatchShapeChecks.NormalStartupGuard]::Run()
$loaded=@([AppDomain]::CurrentDomain.GetAssemblies()|Where-Object {$_.GetName().Name -eq '0Harmony' -or $_.GetName().Name -like 'Azurite.*'}|ForEach-Object {$_.GetName().Name})
if($loaded.Count -ne 0){throw 'A target component was loaded'}
$result=[ordered]@{scope='Actual source-extracted Guard Verify predicate over explicit managed stand-ins';source=[IO.Path]::GetFullPath($Source);sourceSha256=(Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash.ToLowerInvariant();predicate=$predicate;checks=$cases.Count;failed=@($cases|Where-Object {-not $_.passed}).Count;cases=$cases;actualGuardDllExecuted=$false;targetAssembliesLoaded=$loaded;nativeExecuted=$false;patchOperations=0}
[IO.File]::WriteAllText($Report,($result|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
$result|ConvertTo-Json -Depth 8
if($result.failed -ne 0){exit 1}
