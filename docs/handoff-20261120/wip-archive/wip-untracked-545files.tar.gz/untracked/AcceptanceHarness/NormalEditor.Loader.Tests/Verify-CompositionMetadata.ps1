param([Parameter(Mandatory)][string]$Core,[Parameter(Mandatory)][string]$Guard,[Parameter(Mandatory)][string]$Plugin,[Parameter(Mandatory)][string]$Report)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$cecil=Join-Path $root 'artifacts\normal-entry-deployment-pin-20261114\reader\Mono.Cecil.dll'
if((Get-FileHash -LiteralPath $cecil -Algorithm SHA256).Hash.ToLowerInvariant() -ne '769a59793d4b8885bbbfbc5aee8f57a0d4e34d275c56c60c03994309b87f67e9'){throw 'Reader identity differs'}
foreach($p in @($Core,$Guard,$Plugin,$Report)){if(-not [IO.Path]::GetFullPath($p).StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'C worktree-only metadata paths required'}}
if(Test-Path -LiteralPath $Report){throw 'Fresh metadata report required'}
Add-Type -Path $cecil
function AllTypes($types){foreach($t in $types){$t;if($t.HasNestedTypes){AllTypes $t.NestedTypes}}}
function Need([bool]$value,[string]$message){if(-not $value){throw $message}}
function Calls($m){if($m.HasBody){@($m.Body.Instructions|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]}|ForEach-Object Operand)}}
$assemblies=@{};foreach($pair in @(@('Core',$Core),@('Guard',$Guard),@('Plugin',$Plugin))){$assemblies[$pair[0]]=[Mono.Cecil.AssemblyDefinition]::ReadAssembly($pair[1])}
$checks=[Collections.Generic.List[object]]::new()
function Test([string]$name,[scriptblock]$body){try{& $body;$checks.Add([pscustomobject]@{name=$name;passed=$true;error=$null})}catch{$checks.Add([pscustomobject]@{name=$name;passed=$false;error=$_.Exception.Message})}}
try{
 $g=$assemblies.Guard;$c=$assemblies.Core;$p=$assemblies.Plugin
 $gt=@(AllTypes $g.MainModule.Types);$ct=@(AllTypes $c.MainModule.Types);$pt=@(AllTypes $p.MainModule.Types)
 $gm=@($gt|ForEach-Object Methods);$cm=@($ct|ForEach-Object Methods);$pm=@($pt|ForEach-Object Methods)
 Test 'guard has zero Policy Core or interop assembly references before bootstrap' {Need (@($g.MainModule.AssemblyReferences|Where-Object {$_.Name -like 'Azurite.*' -or $_.Name -eq 'Assembly-CSharp' -or $_.Name -like 'Il2Cpp*'}).Count -eq 0) 'Guard has a pre-bootstrap managed dependency'}
 Test 'guard field and method signatures contain no early Policy or Loader Core types' {
  $types=@($gt|ForEach-Object Fields|ForEach-Object {$_.FieldType.FullName})+@($gm|ForEach-Object {$_.ReturnType.FullName;foreach($a in $_.Parameters){$a.ParameterType.FullName}})
  Need (@($types|Where-Object {$_ -match 'NormalPreparation|NormalGuardSession|StartupGuardState|RunManifest|RunPaths'}).Count -eq 0) 'Early Core signature found'
 }
 Test 'bootstrap pins inputs before default context load and never uses LoadFile bytes or new context' {
  $method=($gt|Where-Object Name -eq 'GuardBootstrap').Methods|Where-Object Name -eq 'Prepare';$il=@($method.Body.Instructions)
  $pin=@(0..($il.Count-1)|Where-Object {$il[$_].Operand -is [Mono.Cecil.MethodReference] -and $il[$_].Operand.Name -eq 'Pin'})
  $load=@(0..($il.Count-1)|Where-Object {$il[$_].Operand -is [Mono.Cecil.MethodReference] -and $il[$_].Operand.Name -eq 'LoadFromAssemblyPath'})
  Need ($pin.Count -ge 3 -and $load.Count -eq 1 -and $pin[-1] -lt $load[0]) 'Pinned loading order missing'
  $all=@($gm|ForEach-Object {Calls $_});Need (@($all|Where-Object {$_.Name -eq 'LoadFile' -or ($_.DeclaringType.FullName -eq 'System.Reflection.Assembly' -and $_.Name -eq 'Load') -or ($_.DeclaringType.FullName -eq 'System.Runtime.Loader.AssemblyLoadContext' -and $_.Name -eq '.ctor')}).Count -eq 0) 'Non-default or byte load found'
  Need (@($all|Where-Object {$_.DeclaringType.FullName -eq 'System.Runtime.Loader.AssemblyLoadContext' -and $_.Name -eq 'get_Default'}).Count -ge 1) 'Default ALC absent'
 }
 Test 'guard installs actual Execute prefix postfix and finalizer and verifies each' {
  $install=($gt|Where-Object Name -eq 'NormalStartupGuard').Methods|Where-Object Name -eq 'InstallExecuteHooks';$calls=@(Calls $install)
  Need (@($calls|Where-Object {$_.DeclaringType.FullName -eq 'HarmonyLib.Harmony' -and $_.Name -eq 'Patch'}).Count -eq 1) 'Actual patch call absent'
  $strings=@($install.Body.Instructions|Where-Object {$_.OpCode.Code.ToString() -eq 'Ldstr'}|ForEach-Object Operand)
  foreach($name in @('Execute','BeforeExecute','AfterExecute','AfterExecuteFinalizer')){Need ($strings -contains $name) ('Required seam absent '+$name)}
  Need (@($calls|Where-Object Name -eq 'Verify').Count -eq 1) 'Installed patch verification absent'
 }
 Test 'loader delegates actual Adapter Register Entry Register and Entry Close' {
  $calls=@($pm|ForEach-Object {Calls $_})
  foreach($wanted in @(@('Azurite.NormalEditor.Adapter.Host.NativeAdapterHost','Register'),@('Azurite.NormalEditor.Entry.Host.CatalogEntryHost','Register'),@('Azurite.NormalEditor.Entry.Host.CatalogEntryHost','Close'))){Need (@($calls|Where-Object {$_.DeclaringType.FullName -eq $wanted[0] -and $_.Name -eq $wanted[1]}).Count -eq 1) ('Actual host delegate missing '+$wanted)}
  Need (@($calls|Where-Object {$_.DeclaringType.FullName -eq 'Azurite.NormalEditor.Adapter.Host.NativeAdapterHost' -and $_.Name -eq 'Close'}).Count -eq 0) 'Loader bypasses Entry Close'
 }
 Test 'Guard recheck rejects the actual Harmony ILManipulators array before return' {
  $verify=($gt|Where-Object Name -eq 'NormalStartupGuard').Methods|Where-Object Name -eq 'Verify';$il=@($verify.Body.Instructions)
  $indices=@(0..($il.Count-1)|Where-Object {$il[$_].OpCode.Code.ToString() -eq 'Ldfld' -and $il[$_].Operand -is [Mono.Cecil.FieldReference] -and $il[$_].Operand.DeclaringType.FullName -eq 'HarmonyLib.Patches' -and $il[$_].Operand.Name -eq 'ILManipulators'})
  Need ($indices.Count -eq 1) 'Actual Guard Verify does not consume Harmony ILManipulators'
  $at=$indices[0];$any=$il[$at+1];$branch=$il[$at+2]
  Need ($any.OpCode.Code.ToString() -eq 'Call' -and $any.Operand -is [Mono.Cecil.GenericInstanceMethod] -and $any.Operand.DeclaringType.FullName -eq 'System.Linq.Enumerable' -and $any.Operand.Name -eq 'Any' -and $any.Operand.GenericArguments[0].FullName -eq 'HarmonyLib.Patch') 'ILManipulators is not the actual Any predicate input'
  Need ($branch.OpCode.Code.ToString() -in @('Brfalse','Brfalse_S') -and $branch.Operand.OpCode.Code.ToString() -eq 'Ret') 'Only an empty ILManipulator array may return successfully'
  Need ($il[$at+3].OpCode.Code.ToString() -eq 'Ldstr' -and $il[$at+4].OpCode.Code.ToString() -eq 'Newobj' -and $il[$at+4].Operand.DeclaringType.FullName -eq 'System.InvalidOperationException' -and $il[$at+5].OpCode.Code.ToString() -eq 'Throw') 'A nonempty ILManipulator array does not reach the refusal'
 }
 Test 'loader captures one actual clock and creates existing writer before lifetime registration' {
  $load=($pt|Where-Object Name -eq 'NormalLoaderPlugin').Methods|Where-Object Name -eq 'Load';$calls=@(Calls $load)
  foreach($wanted in @(@('Azurite.NormalEditor.Entry.CatalogClockAnchor','Capture'),@('Azurite.NormalEditor.Entry.Evidence.CatalogEvidenceWriter','CreateNew'),@('Azurite.NormalEditor.Loader.NormalLoaderLifetime','Register'))){Need (@($calls|Where-Object {$_.DeclaringType.FullName -eq $wanted[0] -and $_.Name -eq $wanted[1]}).Count -eq 1) ('Unique integration call missing '+$wanted)}
 }
 Test 'live environment uses actual process creation threads argv and native CLI backing field' {
  $observe=@(($pt|Where-Object Name -eq 'LiveEnvironment').Methods|Where-Object Name -in @('Observe','ObserveProcess'));$calls=@($observe|ForEach-Object {Calls $_})
  foreach($name in @('GetCurrentProcess','get_StartTime','get_CurrentManagedThreadId','NativeThreadId','GetCommandLineArgs','get__IsActive_k__BackingField','GetEnvironmentVariable')){Need (@($calls|Where-Object Name -eq $name).Count -ge 1) ('Actual observation missing '+$name)}
 }
 Test 'pre-native process observation invokes no generated native field and does not invent CLI false' {
  $process=($pt|Where-Object Name -eq 'LiveEnvironment').Methods|Where-Object Name -eq 'ObserveProcess';$calls=@(Calls $process)
  Need ($process.ReturnType.FullName -eq 'Azurite.NormalEditor.Loader.NormalProcessObservation') 'Pre-native result can misrepresent native CLI state'
  Need (@($calls|Where-Object {$_.DeclaringType.Scope.Name -eq 'Assembly-CSharp' -or $_.DeclaringType.FullName -like 'AzureArchive.*'}).Count -eq 0) 'Pre-native phase calls target class init/field'
 }
 Test 'catalog record contains closure verification and writer only no Close Seal Quit or Begin' {
  $record=($ct|Where-Object Name -eq 'NormalLoaderLifetime').Methods|Where-Object Name -eq 'Record';$calls=@(Calls $record)
  Need (@($calls|Where-Object Name -eq 'RequireCatalogClosure').Count -eq 1 -and @($calls|Where-Object {$_.DeclaringType.FullName -eq 'Azurite.NormalEditor.Entry.Evidence.CatalogEvidenceWriter' -and $_.Name -eq 'Record'}).Count -eq 1) 'Original record wrapper missing'
  Need (@($calls|Where-Object {$_.Name -in @('Close','Seal','Quit','Begin')}).Count -eq 0) 'Ready records mutate lifetime'
 }
 Test 'only explicit lifetime Close seals and disposes the writer' {
  $close=($ct|Where-Object Name -eq 'NormalLoaderLifetime').Methods|Where-Object Name -eq 'Close';$calls=@(Calls $close)
  foreach($name in @('RequireShutdownSafe','Invoke','Seal','Dispose')){Need (@($calls|Where-Object Name -eq $name).Count -ge 1) ('Shutdown integration missing '+$name)}
  $others=@($cm|Where-Object {$_.FullName -ne $close.FullName}|ForEach-Object {Calls $_}|Where-Object {$_.DeclaringType.FullName -eq 'Azurite.NormalEditor.Entry.Evidence.CatalogEvidenceWriter' -and $_.Name -eq 'Seal'});Need ($others.Count -eq 0) 'Another path can seal evidence'
 }
 Test 'composition has no manual session Begin Current assignment or native Quit' {
  $calls=@($pm+$cm|ForEach-Object {Calls $_});Need (@($calls|Where-Object {$_.Name -eq 'Quit' -or ($_.DeclaringType.FullName -like '*AuthoringEditorSession*' -and $_.Name -match 'Begin|set_.*Current')}).Count -eq 0) 'Manual native lifecycle mutation found'
 }
 Test 'metadata review did not load any target component or native interop' {
  $names=@([AppDomain]::CurrentDomain.GetAssemblies()|ForEach-Object {$_.GetName().Name}|Where-Object {$_ -like 'Azurite.*' -or $_ -eq 'Assembly-CSharp' -or $_ -like 'Unity*'});Need ($names.Count -eq 0) 'Target assembly was loaded by metadata reader'
 }
 $result=[ordered]@{sourceOnly=$true;targetMethodsInvoked=0;nativeExecuted=$false;readerSha256=(Get-FileHash $cecil -Algorithm SHA256).Hash.ToLowerInvariant();inputs=@(@{path=$Core;sha256=(Get-FileHash $Core -Algorithm SHA256).Hash.ToLowerInvariant()},@{path=$Guard;sha256=(Get-FileHash $Guard -Algorithm SHA256).Hash.ToLowerInvariant()},@{path=$Plugin;sha256=(Get-FileHash $Plugin -Algorithm SHA256).Hash.ToLowerInvariant()});checks=$checks.Count;failed=@($checks|Where-Object {-not $_.passed}).Count;cases=$checks}
 [IO.File]::WriteAllText($Report,($result|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));$result|ConvertTo-Json -Depth 8
 if($result.failed -gt 0){exit 1}
}finally{foreach($assembly in $assemblies.Values){$assembly.Dispose()}}
