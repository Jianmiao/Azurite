using Azurite.NormalEditor.Loader;
using System.Reflection;

static class DeploymentCases
{
    internal static void Run(Action<string,Action> test,Action<bool,string> need)
    {
        // Byte validation is exercised by the real preparation reader; here the
        // exact consumer-to-immutable-binary association must reject drift.
        test("complete normal deployment map permits original immutable component pins",()=>{var files=NormalDeployment.RequiredFiles.Select(p=>new NormalPreparedFile(p.Key,1,p.Value??new('a',64))).ToArray();NormalDeployment.RequireMap(files);});
        test("normal cache decoder is admitted only as the selected original plugin dependency",()=>{
            const string relative=@"BepInEx\plugins\AzuriteNormalEditorPreparation\Azurite.CacheRoot.Core.LabOnly.dll";
            var rows=NormalDeployment.RequiredFiles.Where(p=>p.Key!=relative).Select(p=>new NormalPreparedFile(p.Key,1,p.Value??new('a',64))).Append(new(relative,66560,"32ac8c188e676779c371d628c96c493ec8f7866da04e17e014a92f97895c8ed7")).ToArray();
            NormalDeployment.RequireMap(rows);rows[^1]=rows[^1] with{Sha256=new('e',64)};bool denied=false;try{NormalDeployment.RequireMap(rows);}catch(InvalidOperationException){denied=true;}need(denied,"unselected cache decoder accepted");
        });
        foreach(string fault in new[]{"missing","extra","duplicate","swapped-adapter","old-entry","legacy-policy"})test("deployment map refuses "+fault,()=>{var files=NormalDeployment.RequiredFiles.Select(p=>new NormalPreparedFile(p.Key,1,p.Value??new('a',64))).ToList();switch(fault){case "missing":files.RemoveAt(0);break;case "extra":files.Add(new("other.dll",1,new('a',64)));break;case "duplicate":files.Add(files[0]);break;case "swapped-adapter":{int a=files.FindIndex(f=>f.RelativePath.EndsWith("Adapter.Core.PreparationOnly.dll")),b=files.FindIndex(f=>f.RelativePath.EndsWith("Adapter.Host.PreparationOnly.dll"));string h=files[a].Sha256;files[a]=files[a] with{Sha256=files[b].Sha256};files[b]=files[b] with{Sha256=h};break;}case "old-entry":{int i=files.FindIndex(f=>f.RelativePath.EndsWith("Entry.Host.PreparationOnly.dll"));files[i]=files[i] with{Sha256="c9ce6a782f3269a0f31bd5aa89a626c01a140299f57eab2f1cb7acdfbdeae622"};break;}default:{int i=files.FindIndex(f=>f.RelativePath.EndsWith("EditorIsolation.Policy.LabOnly.dll"));files[i]=files[i] with{Sha256=new('b',64)};break;}}bool denied=false;try{NormalDeployment.RequireMap(files);}catch(InvalidOperationException){denied=true;}need(denied,"foreign deployment accepted");});
        test("actual loaded assembly cannot be relabeled as installed plugin",()=>{bool denied=false;try{NormalDeployment.RequireLoaded(@"C:\wrong-install",new[]{typeof(NormalPreparation).Assembly.GetName().Name!});}catch(InvalidOperationException){denied=true;}need(denied,"wrong actual assembly location admitted");});
    }
}
