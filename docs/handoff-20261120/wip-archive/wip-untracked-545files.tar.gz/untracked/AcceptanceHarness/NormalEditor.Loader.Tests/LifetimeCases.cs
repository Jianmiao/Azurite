using Azurite.EditorIsolation;
using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Entry;
using Azurite.NormalEditor.Entry.Evidence;
using Azurite.NormalEditor.Loader;

static class LifetimeCases
{
    internal static void Run(string output,Action<string,Action> test,Action<bool,string> need)
    {
        test("lifetime registers actual boundaries with one binding admission and clock",()=>{using var f=new Fixture(output);f.Lifetime.Register();need(f.Lifetime.Registered&&f.Order.SequenceEqual(new[]{"routes","adapter","catalog","ready"})&&f.JournalLines==1,"registration order or identity differs");});
        test("real native CLI observation follows route first-use guard installation",()=>{using var f=new Fixture(output);f.Environment.OnObserve=()=>{if(!f.Order.Contains("routes"))throw new InvalidOperationException("native observation preceded first-use guards");};f.Lifetime.Register();need(f.Environment.Observations>0&&f.Lifetime.Registered,"actual non-CLI validation omitted");});
        test("catalog-ready only verifies resource closure and writes original evidence",()=>{using var f=new Fixture(output);f.Start();f.Lifetime.Record(f.Event("catalog-ready"));need(f.Routes.Closures==1&&f.JournalLines==2&&f.CloseCalls==0&&!f.Lifetime.Closed&&!f.Text.Contains("\"sealed\""),"ready caused lifetime mutation or omitted closure");});
        test("owner explicit close checks route shutdown then entry and seals real writer",()=>{using var f=new Fixture(output);f.Start();f.Lifetime.Record(f.Event("catalog-ready"));need(f.Lifetime.Close()&&f.Lifetime.Closed&&f.Order.TakeLast(2).SequenceEqual(new[]{"shutdown","close"})&&f.Text.Contains("\"sealed\""),"normal close did not seal after entry approval");});
        test("entry false close never seals evidence",()=>{using var f=new Fixture(output);f.Start();f.CloseResult=false;need(!f.Lifetime.Close()&&!f.Lifetime.Closed&&!f.Text.Contains("\"sealed\"")&&f.Lifetime.Failure is not null,"false close reached terminal");});
        test("route close refusal occurs before entry close and never seals",()=>{using var f=new Fixture(output);f.Start();f.Routes.OnShutdown=()=>throw new InvalidOperationException("unfinished callback");need(!f.Lifetime.Close()&&f.CloseCalls==0&&!f.Text.Contains("\"sealed\""),"route safety refusal bypassed");});
        test("foreign close does not call owner observers or entry",()=>{using var f=new Fixture(output);f.Start();int before=f.Environment.Observations;bool result=Task.Run(()=>f.Lifetime.Close()).GetAwaiter().GetResult();need(!result&&f.CloseCalls==0&&f.Environment.Observations==before&&!f.Lifetime.Closed,"foreign close crossed owner boundary");});
        test("foreign record latches refusal without touching real writer",()=>{using var f=new Fixture(output);f.Start();int before=f.Environment.Observations;try{Task.Run(()=>f.Lifetime.Record(f.Event("catalog-start-enter"))).GetAwaiter().GetResult();}catch(InvalidOperationException){}need(f.Lifetime.Failure is not null&&f.JournalLines==1&&f.Environment.Observations==before&&!f.Lifetime.Close(),"foreign writer path was admitted");});
        test("late callbacks after successful close are inert and preserve seal",()=>{using var f=new Fixture(output);f.Start();need(f.Lifetime.Close(),"setup close failed");string before=f.Text;Task.Run(()=>f.Lifetime.Record(f.Event("catalog-ready"))).GetAwaiter().GetResult();need(f.Text==before&&f.Lifetime.Closed&&!f.Lifetime.Close(),"late callback poisoned completed journal");});
        test("record reentry into close invalidates callback before writer",()=>{using var f=new Fixture(output);f.Start();f.Routes.OnClosure=()=>f.Lifetime.Close();bool rejected=false;try{f.Lifetime.Record(f.Event("catalog-ready"));}catch(InvalidOperationException){rejected=true;}need(rejected&&f.JournalLines==1&&f.CloseCalls==0&&f.Lifetime.Failure is not null,"reentrant close reached writer or native close");});
        test("close delegate reentry refuses seal even if delegate returns true",()=>{using var f=new Fixture(output);f.Start();f.OnClose=()=>f.Lifetime.Record(f.Event("catalog-ready"));need(!f.Lifetime.Close()&&!f.Text.Contains("\"sealed\"")&&f.Lifetime.Failure is not null,"reentrant record did not invalidate close");});
        test("missing route registration cannot announce guard readiness",()=>{using var f=new Fixture(output);f.Routes.Categories=new[]{"cache"};bool denied=false;try{f.Lifetime.Register();}catch(InvalidOperationException){denied=true;}need(denied&&!f.Lifetime.Registered&&!f.Order.Contains("ready")&&f.Fatal.Count==1,"partial routes were treated as complete");});
        test("swallowed foreign binding window refusal permanently invalidates registration",()=>{using var f=new Fixture(output);f.Routes.OnRegister=c=>{try{c.RequireStartupWindow(c.Binding with{});}catch(InvalidOperationException){}};bool denied=false;try{f.Lifetime.Register();}catch(InvalidOperationException){denied=true;}need(denied&&!f.Lifetime.Registered&&!f.Order.Contains("ready"),"swallowed wrong-binding refusal allowed startup");});
        test("adapter register failure retains unsealed original journal and aborts",()=>{using var f=new Fixture(output);f.AdapterFailure=true;bool denied=false;try{f.Lifetime.Register();}catch(InvalidOperationException){denied=true;}need(denied&&!f.Order.Contains("catalog")&&!f.Order.Contains("ready")&&f.JournalLines==1&&f.Fatal.Count==1,"failed adapter setup resumed registration");});
        test("catalog register callback cannot emit before registration completes",()=>{using var f=new Fixture(output);f.EarlyCatalogRecord=true;bool denied=false;try{f.Lifetime.Register();}catch(InvalidOperationException){denied=true;}need(denied&&f.Order.Contains("catalog")&&f.JournalLines==1&&!f.Order.Contains("ready"),"registration callback reached journal or catalog boundary was absent");});
        test("duplicate registration fails and cannot replace real producers",()=>{using var f=new Fixture(output);f.Start();bool denied=false;try{f.Lifetime.Register();}catch(InvalidOperationException){denied=true;}need(denied&&f.Order.Count(x=>x=="adapter")==1&&f.Lifetime.Failure is not null,"repeated registration replaced producers");});
        test("record requires completed chainloader and exact original identity",()=>{foreach(bool incomplete in new[]{false,true}){using var f=new Fixture(output);f.Lifetime.Register();if(!incomplete)f.Guard.Complete();var e=f.Event("catalog-start-enter");if(!incomplete)e=e with{RunId=Guid.NewGuid().ToString("D")};bool denied=false;try{f.Lifetime.Record(e);}catch(InvalidOperationException){denied=true;}need(denied&&f.JournalLines==1,"uncompleted or foreign record written");}});
        test("resource closure rejection never writes a ready claim",()=>{using var f=new Fixture(output);f.Start();f.Routes.OnClosure=()=>throw new InvalidOperationException("provider fact absent");bool denied=false;try{f.Lifetime.Record(f.Event("catalog-ready"));}catch(InvalidOperationException){denied=true;}need(denied&&f.JournalLines==1&&f.Lifetime.Failure is not null,"false ready escaped closure");});
        test("foreign record racing entry close prevents writer seal",()=>{using var f=new Fixture(output);f.Start();f.OnClose=()=>{try{Task.Run(()=>f.Lifetime.Record(f.Event("catalog-ready"))).GetAwaiter().GetResult();}catch(InvalidOperationException){}};need(!f.Lifetime.Close()&&!f.Text.Contains("\"sealed\""),"foreign race lost before close commit");});
        test("writer failure is propagated and normal close cannot certify it",()=>{using var f=new Fixture(output);f.Start();f.Writer.Dispose();bool denied=false;try{f.Lifetime.Record(f.Event("catalog-start-enter"));}catch(InvalidOperationException){denied=true;}need(denied&&f.Lifetime.Failure is not null&&!f.Lifetime.Close(),"writer failure did not invalidate lifecycle");});
    }
    private sealed class Fixture : IDisposable
    {
        internal readonly List<string> Order=new();internal readonly NormalLoaderLifetime Lifetime;internal readonly CatalogEvidenceWriter Writer;internal readonly TestEnvironment Environment;internal readonly Routes Routes;internal readonly Guard Guard;internal readonly Fatal Fatal=new();internal readonly AdapterBinding Binding;internal readonly NormalOwnerIdentity Owner;internal readonly string FilePath;internal int CloseCalls;internal bool CloseResult=true,AdapterFailure,EarlyCatalogRecord;internal Action? OnClose;
        internal Fixture(string output)
        {
            string id=Guid.NewGuid().ToString("D"),lab=Path.GetFullPath(Path.Combine(output,"lifetime-fixtures",Guid.NewGuid().ToString("N")));
            var paths=new RunPaths(lab,Path.Combine(lab,"runs",id),Path.Combine(lab,"install"));Directory.CreateDirectory(paths.Output);FilePath=Path.Combine(paths.Output,"source-catalog-evidence.jsonl");
            Binding=new(new(id,1,System.Environment.ProcessId,7,paths,new('a',64),new('b',64),"lab-read-"+id),"controller-bound-native-default-string"){HostAssemblySha256=new('c',64),CoreAssemblySha256=new('d',64)};
            Owner=new(System.Environment.ProcessId,DateTime.UtcNow.AddMinutes(-1).ToFileTimeUtc(),System.Environment.CurrentManagedThreadId,7,Path.Combine(paths.Install,"AzureArchive.exe"),Path.Combine(paths.Install,InstallationAuthority.AdapterSubdirectory,"Azurite.NormalEditor.Loader.PreparationOnly.dll"));
            var resource=new NormalResourcePreparation(Path.Combine(lab,"contract.json"),new('a',64),Path.Combine(paths.Install,"catalog.json"),Path.Combine(lab,"offline","catalog.json"),new('b',64),Path.Combine(paths.Install,"settings.json"),new('c',64),Path.Combine(lab,"offline"),Path.Combine(lab,"offline","catalog.hash"),new('d',64),Path.Combine(lab,"bundle-manifest.json"),new('e',64),Path.Combine(lab,"offline","complete.json"),new('f',64),1,16);
            Environment=new(new(Owner,new[]{"-batchmode","-nographics","-disableaudio","-logFile",Path.Combine(paths.Output,"unity.log"),"--aap-offline-resources",resource.OfflineRoot},false,false));
            Routes=new(Order);Guard=new(Order);var admission=new NormalEntryAdmission(Binding,new('a',64),new('e',64),Owner,resource,Environment,Routes,Guard,_=>{});var clock=CatalogClockAnchor.Capture();
            Writer=CatalogEvidenceWriter.CreateNew(FilePath,new(new(id,Owner.ProcessId,Owner.ManagedThreadId,7,120000),new DateTimeOffset(DateTime.FromFileTimeUtc(Owner.ProcessCreationFileTime)),clock.ObserverStartedUtc),Binding.Policy);
            Lifetime=new(Binding,admission,Owner,resource,Routes,Guard,Fatal,new('a',64),clock,Writer,(b,a)=>{if(!ReferenceEquals(b,Binding)||!ReferenceEquals(a,admission))throw new Exception("adapter identity changed");Order.Add("adapter");if(AdapterFailure)throw new InvalidOperationException("adapter registration failed");},(b,a,record,c)=>{if(!ReferenceEquals(b,Binding)||!ReferenceEquals(a,admission)||!ReferenceEquals(c,clock))throw new Exception("entry identity changed");Order.Add("catalog");if(EarlyCatalogRecord)record(Event("catalog-ready"));},()=>{Order.Add("close");CloseCalls++;OnClose?.Invoke();return CloseResult;});
        }
        internal CatalogEvidence Event(string kind)=>new(1,kind,Binding.Policy.RunId,new(Binding.Policy.RunId,Owner.ProcessId,Owner.ManagedThreadId,7,1,1,900),null,null);
        internal void Start(){Lifetime.Register();Guard.Complete();}
        internal string Text {get{using var stream=new FileStream(FilePath,FileMode.Open,FileAccess.Read,FileShare.ReadWrite);using var reader=new StreamReader(stream);return reader.ReadToEnd();}}
        internal int JournalLines=>Text.Split('\n',StringSplitOptions.RemoveEmptyEntries).Length;
        public void Dispose()=>Writer.Dispose();
    }
    private sealed class Routes : INormalRoutes
    {
        private readonly List<string> order;internal Routes(List<string> order)=>this.order=order;
        internal string[] Categories={"cache","workspace","discovery","offline","addressSet","addressClear","addressEvaluate"};internal int Closures;internal Action? OnClosure,OnShutdown;internal Action<NormalRouteContext>? OnRegister;
        public IReadOnlyCollection<string> InstalledRoutes=>Categories;
        public void Register(NormalRouteContext c){if(c.BoundSettingsOwner()!=0)throw new Exception("unvalidated owner exposed");c.RequireStartupWindow(c.Binding);order.Add("routes");OnRegister?.Invoke(c);}
        public void RequireResourceEntry(AdapterBinding b,long r,NativeSettings s){}
        public void RequireCatalogClosure(AdapterBinding b,CatalogEvidence e){Closures++;OnClosure?.Invoke();}
        public void RequireShutdownSafe(AdapterBinding b){order.Add("shutdown");OnShutdown?.Invoke();}
    }
    private sealed class Guard : INormalGuardLink
    {
        private readonly StartupGuardState state=new();private readonly List<string> order;
        internal Guard(List<string> order){this.order=order;state.Arm(new('a',64));}
        public void RequireArmed(string hash)=>state.RequireArmed(hash);public void RequireCompleted(string hash)=>state.RequireCompleted(hash);
        public void RequireStartupWindow(string hash)=>state.RequireArmed(hash);
        public void RoutesReady(string hash,IReadOnlyCollection<string> routes){state.RoutesReady(hash,routes);order.Add("ready");}
        internal void Complete()=>state.Complete(null);
    }
    private sealed class Fatal : IFatalSink {internal int Count;public void Terminate(string reason)=>Count++;}
}
