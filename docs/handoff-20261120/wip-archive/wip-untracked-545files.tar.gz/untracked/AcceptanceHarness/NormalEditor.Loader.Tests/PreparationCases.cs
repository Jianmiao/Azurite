using Azurite.EditorIsolation;
using Azurite.NormalEditor.Loader;
using System.Security.Cryptography;
using System.Text.Json;

static class PreparationCases
{
    internal static void Run(string output,Action<string,Action> test,Action<bool,string> need)
    {
        test("real preparation reader admits complete staged facts without native-success flags",()=>{var f=new Fixture(output);using var p=f.Read();need(p.Manifest.Mode=="normalObserverCatalogOnly"&&p.Facts.Resources.Preparation.BundleBytes==4&&p.EvidenceSha256==f.Hash(f.PreparationPath),"matching original bytes not bound");p.RequireUnchanged();});
        test("live immutable preparation handles block mutation while run settings stay writable",()=>{var f=new Fixture(output);using var p=f.Read();bool blocked=false;try{File.WriteAllText(f.PreparationPath,"{}");}catch(IOException){blocked=true;}File.WriteAllText(f.Paths.Settings,"legitimate later native save");p.RequireUnchanged();need(blocked,"immutable preparation could change after admission");});
        test("wrong external preparation hash rejects before parsing foreign contents",()=>{var f=new Fixture(output);bool denied=false;try{using var p=NormalPreparation.ReadAt(f.Lab,f.ManifestPath,new('a',64));}catch(Exception){denied=true;}need(denied,"unbound preparation accepted");});
        foreach(string fault in new[]{"run","manifest","native-default","duplicate","unknown","nested-unknown","manifest-unknown","seed","catalog","contract","journal","incomplete","accepted","wronglab","count","bundlebytes","payload","payloadpath","deployment","receiptflag"})test("real input reader rejects "+fault,()=>{var f=new Fixture(output);f.Change(fault);bool denied=false;try{using var p=f.Read();}catch(Exception){denied=true;}need(denied,"invalid actual prepared input accepted: "+fault);});
        test("reader disposal releases only its own immutable handles",()=>{var f=new Fixture(output);var p=f.Read();p.Dispose();bool denied=false;try{p.RequireUnchanged();}catch(ObjectDisposedException){denied=true;}File.WriteAllText(f.PreparationPath,"after-disposal");need(denied,"disposed proof remained usable");});
    }
    private sealed class Fixture
    {
        internal readonly string Lab,ManifestPath,PreparationPath;internal readonly RunPaths Paths;private NormalPreparationFacts facts;private readonly string contract,manifest,complete,journal,bundle,installedCatalog;
        internal Fixture(string output)
        {
            Lab=Path.GetFullPath(Path.Combine(output,"preparation-fixtures",Guid.NewGuid().ToString("N")));string id=Guid.NewGuid().ToString("D");Paths=new(Lab,Path.Combine(Lab,"runs",id),Path.Combine(Lab,"install"));
            foreach(var d in new[]{Paths.Install,Path.GetDirectoryName(Paths.Settings)!,Paths.Workspace,Paths.Cache,Paths.Persistent,Paths.Discovery,Paths.Output,Path.Combine(Lab,"preparation"),Path.Combine(Lab,"offline-resources48f8",".azurite-staging"),Path.Combine(Paths.Install,"AzureArchive_Data","StreamingAssets","aa")})Directory.CreateDirectory(d);
            Seed(Paths.Settings,"lab-read-"+id);Seed(Paths.Control,"miss-control-"+id);ManifestPath=Path.Combine(Paths.Run,"manifest.json");Json(ManifestPath,new{Version=1,RunId=id,Mode="normalObserverCatalogOnly",LabRoot=Lab,RunRoot=Paths.Run,InstallRoot=Paths.Install,SeedSha256=Hash(Paths.Settings),ControlSha256=Hash(Paths.Control)});
            string offline=Path.Combine(Lab,"offline-resources48f8"),catalog=Path.Combine(offline,"catalog.json"),hashfile=Path.Combine(offline,"catalog.hash"),settings=Path.Combine(Paths.Install,"AzureArchive_Data","StreamingAssets","aa","settings.json");installedCatalog=Path.Combine(Paths.Install,"AzureArchive_Data","StreamingAssets","aa","catalog.json");
            bundle=Path.Combine(offline,"one.bundle");File.WriteAllBytes(bundle,new byte[]{1,2,3,4});File.WriteAllText(catalog,"{\"sourceFixture\":true}");File.Copy(catalog,installedCatalog);File.WriteAllText(hashfile,"catalog-fixture-hash");File.WriteAllText(settings,"{}");
            manifest=Path.Combine(Lab,"preparation","bundles.json");Json(manifest,new[]{new{relative_path="one.bundle",bytes=4,sha256=Hash(bundle),status="full_payload_sha256_match"}});
            contract=Path.Combine(Lab,"preparation","contract.json");Json(contract,new{status="PROPOSED_NOT_MATERIALIZED_NOT_NATIVE_ACCEPTED",contract_id="source-only-fixture",isolated_lab_root=Lab,catalog_sha256=Hash(catalog),catalog_hash_file_sha256=Hash(hashfile),catalog_hash_text="catalog-fixture-hash",required_bundle_count=1,bundle_bytes=4,bundle_payload_manifest_sha256=Hash(manifest),unchanged_executable_and_settings_files=new[]{new{RelativePath="AzureArchive_Data\\StreamingAssets\\aa\\settings.json",Bytes=2,SHA256=Hash(settings)}}});
            journal=Path.Combine(offline,".azurite-staging","files.jsonl");using(var writer=new StreamWriter(journal)){int seq=0;foreach(var p in new[]{bundle,catalog,hashfile})writer.WriteLine(JsonSerializer.Serialize(new{sequence=++seq,path=Path.GetFileName(p),bytes=new FileInfo(p).Length,source_sha256=Hash(p),destination_sha256=Hash(p)}));}
            complete=Path.Combine(offline,".azurite-staging","complete.json");long total=new[]{bundle,catalog,hashfile}.Sum(p=>new FileInfo(p).Length);Json(complete,new{schema=1,contract_id="source-only-fixture",destination=offline,identity=new{contract_id="source-only-fixture",lab_root=Lab,manifest_sha256=Hash(manifest),proposal_sha256=Hash(contract),staged_catalog_sha256=Hash(catalog),staged_catalog_hash_file_sha256=Hash(hashfile)},required_files=3,payload_bytes=total,resource_set_complete=true,resource_contract_activated=false,normal_runtime_accepted=false,runtimeAllowed=false,status="staged_not_activated_not_native_accepted",verified_files=3,verified_bytes=total,files_journal_sha256=Hash(journal),files_journal_bytes=new FileInfo(journal).Length,preservation_before=new{sourceFixture=true},preservation_after=new{sourceFixture=true},errors=Array.Empty<string>()});
            string deploy=Path.Combine(Paths.Install,"fixture.dll");File.WriteAllText(deploy,"explicit source fixture - never load");facts=new(1,id,Hash(ManifestPath),@"C:\controller-verified-native-default-string",new[]{new NormalPreparedFile("fixture.dll",new FileInfo(deploy).Length,Hash(deploy))},new(new(contract,Hash(contract),installedCatalog,catalog,Hash(catalog),settings,Hash(settings),offline,hashfile,Hash(hashfile),manifest,Hash(manifest),complete,Hash(complete),1,4),journal,Hash(journal)));PreparationPath=Path.Combine(Paths.Run,"normal-preparation.json");Save();
        }
        internal string Hash(string p)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))).ToLowerInvariant();
        internal NormalPreparation Read()=>NormalPreparation.ReadAt(Lab,ManifestPath,Hash(PreparationPath));
        private void Save()=>Json(PreparationPath,facts);
        private static void Json(string path,object value)=>File.WriteAllText(path,JsonSerializer.Serialize(value));
        internal void Change(string fault)
        {
            switch(fault){
                case "run":facts=facts with{RunId=Guid.NewGuid().ToString("D")};break;
                case "manifest":facts=facts with{ManifestSha256=new('b',64)};break;
                case "native-default":facts=facts with{ExpectedNativeSettingsPath=""};break;
                case "duplicate":File.WriteAllText(PreparationPath,File.ReadAllText(PreparationPath).Replace("\"Version\":1","\"Version\":1,\"Version\":1"));return;
                case "unknown":File.WriteAllText(PreparationPath,File.ReadAllText(PreparationPath).Replace("\"Version\":1","\"Version\":1,\"allow\":true"));return;
                case "nested-unknown":File.WriteAllText(PreparationPath,File.ReadAllText(PreparationPath).Replace("\"Resources\":{","\"Resources\":{\"allow\":true,"));return;
                case "manifest-unknown":Rewrite(ManifestPath,"\"Version\":1","\"Version\":1,\"allow\":true");facts=facts with{ManifestSha256=Hash(ManifestPath)};break;
                case "seed":File.WriteAllText(Paths.Settings,"{}");break;
                case "catalog":File.WriteAllText(installedCatalog,"old catalog");break;
                case "contract":Rewrite(contract,"\"required_bundle_count\":1","\"required_bundle_count\":2");facts=facts with{Resources=facts.Resources with{Preparation=facts.Resources.Preparation with{ContractSha256=Hash(contract)}}};break;
                case "journal":Rewrite(journal,"\"sequence\":2","\"sequence\":1");facts=facts with{Resources=facts.Resources with{FilesJournalSha256=Hash(journal)}};break;
                case "incomplete":Rewrite(complete,"\"resource_set_complete\":true","\"resource_set_complete\":false");Receipt();break;
                case "accepted":Rewrite(complete,"staged_not_activated_not_native_accepted","native_accepted");Receipt();break;
                case "wronglab":Rewrite(complete,"\"lab_root\":"+JsonSerializer.Serialize(Lab),"\"lab_root\":\"F:\\\\daily\"");Receipt();break;
                case "count":Rewrite(complete,"\"verified_files\":3","\"verified_files\":2");Receipt();break;
                case "bundlebytes":facts=facts with{Resources=facts.Resources with{Preparation=facts.Resources.Preparation with{BundleBytes=5}}};break;
                case "payload":File.WriteAllBytes(bundle,new byte[]{1,2,3,5});break;
                case "payloadpath":Rewrite(manifest,"one.bundle","../outside.bundle");facts=facts with{Resources=facts.Resources with{Preparation=facts.Resources.Preparation with{BundleManifestSha256=Hash(manifest)}}};break;
                case "deployment":facts=facts with{Files=new[]{new NormalPreparedFile("..\\outside.dll",1,new('c',64))}};break;
                case "receiptflag":Rewrite(complete,"\"runtimeAllowed\":false","\"runtimeAllowed\":true");Receipt();break;
            }Save();
        }
        private void Receipt()=>facts=facts with{Resources=facts.Resources with{Preparation=facts.Resources.Preparation with{MaterializationSha256=Hash(complete)}}};
        private static void Rewrite(string p,string a,string b)=>File.WriteAllText(p,File.ReadAllText(p).Replace(a,b));
        private static void Seed(string path,string marker)
        {
            var s=new Dictionary<string,object>();foreach(var k in new[]{"stEnabled","autoSave","autoCompile","lobbyBgmEnabled","checkForUpdate","isAutoPlay"})s.Add(k,false);foreach(var k in new[]{"masterVolume","voiceVolume","bgmVolume","soundEffectVolume"})s.Add(k,1);foreach(var k in new[]{"lastProfileIndex","autoDelay","fpsTier","fontIndex","completeResStructVer"})s.Add(k,0);foreach(var k in new[]{"visitedFiles","favoriteBgmIds","favoriteSoundNames"})s.Add(k,Array.Empty<string>());foreach(var k in new[]{"catalogUrlOverride","username","goldText","diamondText","staminaText","customSource","cachePath","workspacePath"})s.Add(k,"");s["username"]=marker;string run=Path.GetDirectoryName(Path.GetDirectoryName(path))!;s["workspacePath"]=Path.Combine(run,"workspace");s["cachePath"]=Path.Combine(run,"cache");Json(path,s);
        }
    }
}
