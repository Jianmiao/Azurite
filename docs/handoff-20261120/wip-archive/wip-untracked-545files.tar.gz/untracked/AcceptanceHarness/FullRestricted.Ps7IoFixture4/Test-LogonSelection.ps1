param([Parameter(Mandatory)][ValidateSet('Legacy','Corrected')][string]$Mode,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh pure test result required'}
$rows=[Collections.Generic.List[object]]::new()
function New-FixtureRawGroup([string]$Sid,$Attributes){$row=[Collections.Generic.Dictionary[string,object]]::new();$row.Add('sid',$Sid);$row.Add('attributes',$Attributes);return $row}
function Check([bool]$Condition,[string]$Message){if(-not $Condition){throw $Message}}
function Case([string]$Name,[scriptblock]$Body){try{& $Body;$rows.Add([pscustomobject]@{name=$Name;passed=$true;error=$null})}catch{$rows.Add([pscustomobject]@{name=$Name;passed=$false;error=$_.Exception.ToString()})}}
function Refuses([scriptblock]$Body,[string]$Expected){$refused=$false;try{& $Body|Out-Null}catch{Check ($_.Exception.Message -clike $Expected) ('Wrong refusal cause: '+$_.Exception.Message);$refused=$true};Check $refused 'Invalid logon selection was accepted'}
if($Mode -ceq 'Legacy'){
 $repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$runner=Join-Path $repo 'artifacts\aa-handoff-ps7-io-compatibility-20261114\candidate3\source\Invoke-RootCOnlyAclFixture.ps1'
 if((Get-FileHash -LiteralPath $runner -Algorithm SHA256).Hash.ToLowerInvariant() -cne '1717b87915e9c6eb38fd850332881ece054eec8f9322c33f15b817a33ed4f2be'){throw 'Frozen legacy runner differs'}
 $source=[IO.File]::ReadAllText($runner);$start=$source.IndexOf(' $owner=$identity.User.Value;',[StringComparison]::Ordinal);$end=$source.IndexOf(' $assembly=[Reflection.Assembly]::LoadFrom',$start,[StringComparison]::Ordinal);if($start -lt 0 -or $end -le $start){throw 'Exact frozen selector section not found'}
 $block=[scriptblock]::Create($source.Substring($start,$end-$start))
 function Need($Condition,[string]$Message){Check ([bool]$Condition) $Message}
 Case 'raw marked logon SID remains selectable when managed Groups omits it' {
  $identity=[pscustomobject]@{User=[pscustomobject]@{Value='S-1-5-21-1-2-3-1001'};Groups=@([pscustomobject]@{Value='S-1-5-32-545'})}
  $rawGroups=@((New-FixtureRawGroup 'S-1-5-32-545' ([uint32]7)),(New-FixtureRawGroup 'S-1-5-5-11-22' ([uint32]3221225479)))
  . $block;Check ($logon -ceq 'S-1-5-5-11-22') 'Actual raw LOGON_ID group was not selected'
 }
}else{
 . (Join-Path $PSScriptRoot 'Select-CurrentLogonSid.ps1')
 Case 'exact List of Dictionary return shape binds without losing raw rows' {$groups=[Collections.Generic.List[Collections.Generic.Dictionary[string,object]]]::new();$groups.Add((New-FixtureRawGroup 'S-1-5-32-545' ([uint32]7)));$groups.Add((New-FixtureRawGroup 'S-1-5-5-11-22' ([uint32]3221225479)));$groups.Add((New-FixtureRawGroup 'S-1-1-0' ([uint32]7)));$actual=Select-AzuriteFixtureCurrentLogon -Groups $groups;Check ($actual.sid -ceq 'S-1-5-5-11-22' -and $actual.rawGroupCount -eq 3) 'Actual return collection shape lost or coerced group rows'}
 Case 'one marked raw group is selected without relying on managed Groups' {$actual=Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup 'S-1-5-32-545' ([uint32]7)),(New-FixtureRawGroup 'S-1-5-5-11-22' ([uint32]3221225479)));Check ($actual.sid -ceq 'S-1-5-5-11-22' -and $actual.attributes -eq [uint32]3221225479 -and $actual.rawGroupCount -eq 2) 'Wrong actual group selected'}
 Case 'LOGON_ID mask without other flags remains sufficient' {$actual=Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup 'S-1-5-5-0-22' ([uint32]3221225472)));Check ($actual.sid -ceq 'S-1-5-5-0-22') 'Required mask was not recognized'}
 Case 'logon-looking SID without LOGON_ID attributes is refused' {Refuses {Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup 'S-1-5-5-11-22' ([uint32]7)))} 'Exactly one actual raw group*'}
 Case 'either single LOGON_ID bit is insufficient' {foreach($flag in @([uint32]2147483648,[uint32]1073741824)){Refuses {Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup 'S-1-5-5-11-22' $flag))} 'Exactly one actual raw group*'}}
 Case 'multiple fully marked groups are refused even with duplicate SIDs' {Refuses {Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup 'S-1-5-5-11-22' ([uint32]3221225479)),(New-FixtureRawGroup 'S-1-5-5-11-22' ([uint32]3221225479)))} 'Exactly one actual raw group*'}
 Case 'marked group with wrong SID authority or shape is refused' {foreach($sid in @('S-1-5-32-545','S-1-5-5-11','S-1-5-5-11-22-33','prefix-S-1-5-5-11-22')){Refuses {Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup $sid ([uint32]3221225479)))} 'Actual LOGON_ID group has an invalid canonical logon SID shape'}}
 Case 'noncanonical or overflowing SID components are refused' {foreach($sid in @('S-1-5-5-01-22','S-1-5-5-1-4294967296','S-1-5-5--1-22')){Refuses {Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup $sid ([uint32]3221225479)))} 'Actual LOGON_ID*'}}
 Case 'maximum UInt32 SID components remain selectable' {$actual=Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup 'S-1-5-5-4294967295-4294967295' ([uint32]3221225479)));Check ($actual.sid -ceq 'S-1-5-5-4294967295-4294967295') 'Valid boundary SID rejected'}
 Case 'signed string or widened attributes are not coerced' {foreach($attr in @([int]-1073741817,'3221225479',[uint64]3221225479)){Refuses {Select-AzuriteFixtureCurrentLogon @((New-FixtureRawGroup 'S-1-5-5-11-22' $attr))} 'Exact raw token group*'}}
 Case 'missing or empty raw group collection is refused' {Refuses {Select-AzuriteFixtureCurrentLogon $null} 'Bounded actual raw token groups*';Refuses {Select-AzuriteFixtureCurrentLogon @()} 'Exactly one actual raw group*'}
 Case 'malformed actual group row is refused' {Refuses {Select-AzuriteFixtureCurrentLogon @(@{sid='S-1-5-5-11-22'})} 'Exact raw token group*'}
 Case 'original raw group count bound is preserved' {$groups=@((New-FixtureRawGroup 'S-1-5-5-11-22' ([uint32]3221225479)));for($i=1;$i -lt 256;$i++){$groups+=,(New-FixtureRawGroup 'S-1-5-32-545' ([uint32]7))};Refuses {Select-AzuriteFixtureCurrentLogon $groups} 'Bounded actual raw token groups*'}
}
$result=[ordered]@{scope='pure current-logon selection controls; no current identity or token is queried';mode=$Mode;powerShell=$PSVersionTable.PSVersion.ToString();passed=(@($rows.ToArray()|Where-Object {-not $_.passed}).Count -eq 0);tests=@($rows.ToArray());readOnlyCurrentTokenQueryPerformed=$false;tokenCreatedOrModified=$false;fixtureInvoked=$false;filesystemAclOperationsPerformed=$false;aaExecuted=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false));$result|ConvertTo-Json -Depth 10
if(-not $result.passed){exit 1}
