"""Fixture-only C source derivation; never invoke token query or real IO fixture."""
import pathlib,hashlib,json,difflib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114/candidate3'
OUT=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114/io-fixture4'
old=BASE/'source/Invoke-RootCOnlyAclFixture.ps1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sha(old)!='1717b87915e9c6eb38fd850332881ece054eec8f9322c33f15b817a33ed4f2be':raise RuntimeError('Frozen original fixture source differs')
if sha(BASE/'source-checkpoint.json')!='e0a77596152bb6d76fd15df3ad59500d288c86eaeb804bb0448f83ee8e825fad':raise RuntimeError('Frozen native candidate checkpoint differs')
source=old.read_text(encoding='utf-8-sig').replace('\r\n','\n');s=source;changes=[]
def rep(before,after,label):
 global s
 if s.count(before)!=1:raise RuntimeError('Exact delta anchor differs: '+label)
 s=s.replace(before,after);changes.append(dict(label=label,before=before,after=after,count=1))
start=s.index('$candidate=[IO.Path]::GetFullPath');end=s.index('if(($HostVariant',start)
rep(s[start:end],'''$addon=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$repo='C:\\Users\\21294\\.codex\\worktrees\\azurite-authoring-20261108\\Azurite-github-publish-1.0.38'
$expectedAddon=Join-Path $repo 'artifacts\\aa-handoff-ps7-io-compatibility-20261114\\io-fixture4'
$candidate=Join-Path $repo 'artifacts\\aa-handoff-ps7-io-compatibility-20261114\\candidate3'
if($addon -cne $expectedAddon){throw 'Only the reviewed fixed io-fixture4/source addon copy may execute'}
$manifestPath=Join-Path $addon 'fixture-manifest.json'
if((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ReviewedManifestSha256){throw 'Reviewed fixture4 addon manifest differs'}
$manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
if($manifest.scope -cne 'root-only-c-io-fixture4-addon' -or $manifest.candidate3CheckpointSha256 -cne 'e0a77596152bb6d76fd15df3ad59500d288c86eaeb804bb0448f83ee8e825fad'){throw 'Exact frozen candidate3 binding required'}
foreach($name in @('source/Invoke-RootCOnlyAclFixture4.ps1','source/Select-CurrentLogonSid.ps1')){
 $rows=@($manifest.files|Where-Object path -CEQ $name);$path=Join-Path $addon $name
 if($rows.Count -ne 1 -or (Get-Item -LiteralPath $path).Length -ne $rows[0].bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $rows[0].sha256){throw 'Reviewed fixture4 source differs'}
}
$requiredCandidateFiles=@('source-checkpoint.json','components/PortableAclIo.cs','components/RestrictedCliFullRestricted.cs','overlay/RestrictedCliFullRestricted.cs','overlay/RestrictedCliNative.dll')
if(@($manifest.candidate3Files).Count -ne $requiredCandidateFiles.Count){throw 'Exact candidate3 source/DLL reference set differs'}
foreach($name in $requiredCandidateFiles){
 $rows=@($manifest.candidate3Files|Where-Object path -CEQ $name);$path=Join-Path $candidate $name
 if($rows.Count -ne 1 -or (Get-Item -LiteralPath $path).Length -ne $rows[0].bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $rows[0].sha256){throw 'Frozen candidate3 source/checkpoint/DLL differs'}
}
. (Join-Path $addon 'source\\Select-CurrentLogonSid.ps1')
''','independent addon manifest binds new scripts and frozen candidate3 inputs')
rep("$fixture=Join-Path $candidate ('root-io-fixture-'+$HostVariant);$resultPath=Join-Path $candidate ('root-io-'+$HostVariant+'-result.json')","$fixture=Join-Path $addon ('root-io-fixture4-'+$HostVariant);$resultPath=Join-Path $addon ('root-io-fixture4-'+$HostVariant+'-result.json')",'fresh independent fixture4 and result paths')
rep("$cursor=$candidate\nwhile($cursor){if(([IO.File]::GetAttributes($cursor) -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Fixture ancestor is a reparse point'};$cursor=[IO.Path]::GetDirectoryName($cursor)}","foreach($origin in @($candidate,$addon)){$cursor=$origin;while($cursor){if(([IO.File]::GetAttributes($cursor) -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Fixture ancestor is a reparse point'};$cursor=[IO.Path]::GetDirectoryName($cursor)}}",'preserve candidate ancestry check and include addon ancestry')
rep("scope='Root actual C-only portable ACL creation fixture'","scope='Root actual C-only portable ACL creation fixture4 addon'",'distinct evidence scope')
rep("tokensDesktopsJobsInvoked=$false;existingObjectAclChanges=$false","readOnlyCurrentTokenQueryAttempted=$false;readOnlyCurrentTokenQuerySucceeded=$false;rawCurrentTokenGroupCount=$null;logonSelection=$null;tokenCreatedOrModified=$false;desktopsJobsInvoked=$false;registryTouched=$false;existingObjectAclChanges=$false",'truthful read-only current-token query and unchanged forbidden-operation diagnostics')
start=s.index(' $owner=$identity.User.Value;');end=s.index(" $io=$type.GetField('Current'",start)
rep(s[start:end],''' $owner=$identity.User.Value
 $assembly=[Reflection.Assembly]::LoadFrom((Join-Path $candidate 'overlay\\RestrictedCliNative.dll'))
 $tokenType=$assembly.GetType('Azurite.Restricted.FullRestrictedToken',$true);$groupFlags=[Reflection.BindingFlags]'NonPublic,Static,DeclaredOnly'
 $groupMethod=$tokenType.GetMethod('Groups',$groupFlags,$null,[Type[]]@([IntPtr],[int]),$null)
 if($null -eq $groupMethod){throw 'Pinned original current-token group reader missing'}
 $parameters=$groupMethod.GetParameters()
 Need ($groupMethod.DeclaringType -eq $tokenType -and $groupMethod.IsStatic -and $parameters.Count -eq 2 -and $parameters[0].ParameterType -eq [IntPtr] -and $parameters[1].ParameterType -eq [int] -and $groupMethod.ReturnType -eq [Collections.Generic.List[Collections.Generic.Dictionary[string,object]]]) 'Exact pinned original Groups(IntPtr,int) query member is bound'
 Budget;$r.readOnlyCurrentTokenQueryAttempted=$true
 # Borrow the token of this same already-held identity. Groups only queries it;
 # do not duplicate, derive, modify or independently close this borrowed token.
 $rawGroups=$groupMethod.Invoke($null,[object[]]@($identity.Token,[int]2));$r.readOnlyCurrentTokenQuerySucceeded=$true;$r.rawCurrentTokenGroupCount=$rawGroups.Count
 $selection=Select-AzuriteFixtureCurrentLogon -Groups $rawGroups;$logon=$selection.sid;$r.logonSelection=$selection
 Need ($null -ne $selection) 'Exactly one actual LOGON_ID-marked raw group has a canonical logon SID';Budget
 $type=$assembly.GetType('Azurite.Restricted.PortableAclIo',$true);$flags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
''','select original raw token LOGON_ID attributes on the same held identity')
inverse=s
for delta in reversed(changes):inverse=inverse.replace(delta['after'],delta['before'])
if inverse!=source:raise RuntimeError('Fixture inverse delta does not recover original source')
dest=OUT/'source';dest.mkdir()
(dest/'Invoke-RootCOnlyAclFixture4.ps1').write_text(s,encoding='utf-8')
for p in HERE.iterdir():
 if p.is_file():shutil.copy2(p,dest/p.name)
shutil.copy2(BASE/'source/Test-RootRunnerSyntax.ps1',dest/'Test-RootRunnerSyntax.ps1')
patch=list(difflib.unified_diff(source.splitlines(True),s.splitlines(True),fromfile='candidate3/source/Invoke-RootCOnlyAclFixture.ps1',tofile='io-fixture4/source/Invoke-RootCOnlyAclFixture4.ps1'))
helper=(HERE/'Select-CurrentLogonSid.ps1').read_text(encoding='utf-8');patch+=list(difflib.unified_diff([],helper.splitlines(True),fromfile='/dev/null',tofile='io-fixture4/source/Select-CurrentLogonSid.ps1'))
(OUT/'candidate3-to-fixture4.diff').write_text(''.join(patch),encoding='utf-8')
(OUT/'fixture4-deltas.json').write_text(json.dumps(dict(scope='fixture-only exact anchored delta',baseSourceSha256=sha(old),newSourceSha256=sha(dest/'Invoke-RootCOnlyAclFixture4.ps1'),inverseNormalizedEqual=True,changes=changes),indent=2),encoding='utf-8')
print(json.dumps(dict(fixtureSource=str(dest/'Invoke-RootCOnlyAclFixture4.ps1'),sourceSha256=sha(dest/'Invoke-RootCOnlyAclFixture4.ps1'),deltas=len(changes),nativeCandidateRecompiled=False,fixtureInvoked=False)))
