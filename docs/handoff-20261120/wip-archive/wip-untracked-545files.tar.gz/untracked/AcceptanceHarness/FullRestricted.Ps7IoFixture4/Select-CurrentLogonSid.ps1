# Pure selector for the exact dictionaries returned by the pinned Groups(token,2).
# This file does not obtain an identity, token, group list, or any native handle.
function Select-AzuriteFixtureCurrentLogon {
 param([Parameter(Mandatory)][AllowNull()][AllowEmptyCollection()][object[]]$Groups)
 if($null -eq $Groups -or $Groups.Count -ge 256){throw 'Bounded actual raw token groups are required'}
 $marked=[Collections.Generic.List[object]]::new();$mask=[uint32]3221225472
 foreach($group in $Groups){
  if($group -isnot [Collections.Generic.Dictionary[string,object]] -or $group.Count -ne 2 -or -not $group.ContainsKey('sid') -or -not $group.ContainsKey('attributes') -or $group['sid'] -isnot [string] -or $group['attributes'] -isnot [uint32]){throw 'Exact raw token group sid/UInt32 attributes shape is required'}
  if(($group['attributes'] -band $mask) -eq $mask){$marked.Add($group)}
 }
 if($marked.Count -ne 1){throw 'Exactly one actual raw group with LOGON_ID attributes is required'}
 $selected=$marked[0];$sid=$selected['sid']
 if($sid -cnotmatch '\AS-1-5-5-(0|[1-9][0-9]*)-(0|[1-9][0-9]*)\z'){throw 'Actual LOGON_ID group has an invalid canonical logon SID shape'}
 [uint32]$first=0;[uint32]$second=0
 if(-not [uint32]::TryParse($matches[1],[ref]$first) -or -not [uint32]::TryParse($matches[2],[ref]$second)){throw 'Actual LOGON_ID SID components exceed UInt32'}
 return [pscustomobject][ordered]@{sid=$sid;attributes=$selected['attributes'];rawGroupCount=$Groups.Count}
}
