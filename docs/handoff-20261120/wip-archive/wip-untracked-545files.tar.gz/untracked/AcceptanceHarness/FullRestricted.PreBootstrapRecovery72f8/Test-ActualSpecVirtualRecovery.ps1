$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$out=Join-Path $repo 'artifacts\aa-prebootstrap-recovery-72f8-20261114\source1\virtual-coordinator2'
if(Test-Path $out){throw 'Fresh virtual evidence directory required'};[void][IO.Directory]::CreateDirectory($out)
$arguments=Get-Content (Join-Path $repo 'artifacts\aa-prebootstrap-recovery-72f8-20261114\source1\plan-parameters.json') -Raw|ConvertFrom-Json -DateKind String
# Execute the real public Plan and its real Get-ExactPreBootstrapRecoverySpec.
# This loads no native helper. Its actual evidence files are never modified.
$null=. $arguments.EntryPath -AdapterManifestPath $arguments.AdapterManifestPath -ExpectedAdapterManifestSha256 $arguments.ExpectedAdapterManifestSha256 -RecoveryEvidencePath $arguments.RecoveryEvidencePath -ExpectedRecoveryEvidenceSha256 $arguments.ExpectedRecoveryEvidenceSha256
function CloneVirtual($value){return ConvertFrom-RecoveryJson ([Text.Encoding]::UTF8.GetBytes((ConvertTo-RecoveryJson $value)))}
function NeedVirtual($value,[string]$why){if(-not $value){throw $why}}
$actualSpec=$recoverySpec
NeedVirtual ($actualSpec.Original.Count -eq 1228 -and $actualSpec.Prepared.Count -eq 1262 -and $actualSpec.Created.Count -eq 34 -and $actualSpec.SharedEvidenceFreshForApply -eq $false) 'Actual source-derived Plan differs'
$virtualNow=([datetimeoffset](ConvertTo-ClosedRecoveryUtcInstant $actualSpec.PreservationUtc)).AddSeconds(600)
$freshnessChecks=0
foreach($case in @(
 [pscustomobject]@{name='missing';utc=$null;accepted=$false},
 [pscustomobject]@{name='before-preservation';utc=$virtualNow.AddSeconds(-601).ToString('o');accepted=$false},
 [pscustomobject]@{name='older-than-five-minutes';utc=$virtualNow.AddSeconds(-301).ToString('o');accepted=$false},
 [pscustomobject]@{name='future';utc=$virtualNow.AddSeconds(1).ToString('o');accepted=$false},
 [pscustomobject]@{name='exact-five-minute-boundary';utc=$virtualNow.AddSeconds(-300).ToString('o');accepted=$true}
)){$copy=CloneVirtual $actualSpec;$copy.SharedComparisonUtc=$case.utc;$accepted=$true;try{Assert-RecoveryPostNativeFresh $copy $virtualNow}catch{$accepted=$false};NeedVirtual ($accepted -eq $case.accepted) ('Original pure freshness guard differs: '+$case.name);$freshnessChecks++}
NeedVirtual ($actualSpec.NoAttemptEvidence.actualHandoffSnapshot.leaseClosed -eq $false -and $actualSpec.NoAttemptEvidence.actualRuntimeStageAttemptCount -eq 1 -and $actualSpec.NoAttemptEvidence.nativeCountersCaptured -eq $false) 'Actual refusal proof was upgraded'
function NewVirtualState {
 $spec=CloneVirtual $actualSpec
 $spec.InventoryExceptions=@{};foreach($key in $actualSpec.InventoryExceptions.Keys){$spec.InventoryExceptions[$key]=[string[]]@($actualSpec.InventoryExceptions[$key])}
 # Simulated freshness exists only in this in-memory copy. No fresh result,
 # comparison, after snapshot or usable Apply manifest is written by this test.
 $spec.SharedComparisonUtc=[datetime]::UtcNow.ToString('o')
 $objects=@{};foreach($object in (CloneVirtual $spec.Prepared)){$objects[$object.path]=$object}
 $objects[$spec.PendingPath].content=$spec.PendingContent
 $objects[$spec.Root+'\.phase0-staging']=[pscustomobject]@{path=$spec.Root+'\.phase0-staging'}
 return @{Spec=$spec;Objects=$objects;Events=[Collections.Generic.List[object]]::new();Records=@{};Archives=@{};Mutations=0;RecoveryId=('a'*32);Held=$false;TestOnlySimulated=$true}
}
$backend={param($action,$a,$state)
 $state.Events.Add([pscustomobject]@{action=$action;path=$a.path;name=$a.name})
 switch($action){
  Acquire {$state.Held=$true;return [pscustomobject]@{ownerSid=$state.Spec.OwnerSid;logonSid=$state.Spec.LogonSid;volume=$state.Spec.Volume}}
  ValidateEnvironment {Assert-RecoveryPostNativeFresh $state.Spec ([datetimeoffset]::UtcNow);return [pscustomobject]@{aaCount=0;probeCount=0;unelevated=$true;ownerSid=$state.Spec.OwnerSid;logonSid=$state.Spec.LogonSid}}
  Observe {if($state.Objects.ContainsKey($a.path)){return CloneVirtual $state.Objects[$a.path]};return $null}
  Inventory {return @($state.Objects.Keys|Where-Object {[IO.Path]::GetDirectoryName($_) -ceq $a.path}|ForEach-Object {[IO.Path]::GetFileName($_)})}
  Archive {$object=$state.Objects[$a.path];$state.Archives[$a.path]=CloneVirtual $object;return [pscustomobject]@{sourcePath=$a.path;sourceIdentity=$object.identity;sha256=$object.sha256;bytes=$object.bytes;destination='C:\SIMULATED-NO-FILES\'+$object.identity}}
  Persist {$state.Records[$a.name]=$a.value;return}
  Journal {return}
  WriteBytes {$state.Mutations++;$object=$state.Objects[$a.path];$object.content=[Convert]::ToBase64String($a.bytes);$object.bytes=[long]$a.bytes.Length;$object.sha256=Get-RecoveryHash $a.bytes;return}
  SetDescriptor {$state.Mutations++;$state.Objects[$a.path].sddl=$a.sddl;return}
  DeleteFile {NeedVirtual (-not $state.Objects[$a.path].directory) 'Virtual DeleteFile received directory';$state.Mutations++;$state.Objects.Remove($a.path);return}
  DeleteDirectory {NeedVirtual (@($state.Objects.Keys|Where-Object {[IO.Path]::GetDirectoryName($_) -ceq $a.path}).Count -eq 0) 'Virtual directory is not empty';$state.Mutations++;$state.Objects.Remove($a.path);return}
  Release {$state.Held=$false;return}
  Dispose {return}
  Retain {$state.Retained=$true;return}
  default {throw ('Unexpected original coordinator action '+$action)}
 }
}
$state=NewVirtualState;$result=Invoke-RecoveryCoordinator $state.Spec $backend $state
NeedVirtual $result.Success ('Actual Spec through original virtual coordinator failed: '+$result.Error)
NeedVirtual ($result.PendingCleared -and $result.RunsRemoved -and $result.BaselineVerified -and $result.OriginalsVerified -and $result.ReleaseSucceeded -and $result.DisposeSucceeded) 'Virtual terminal baseline/ownership incomplete'
foreach($original in $state.Spec.Original){Assert-RecoveryObject $state.Objects[$original.path] $original}
foreach($created in $state.Spec.Created){NeedVirtual (-not $state.Objects.ContainsKey($created.path)) 'Virtual created object remains'}
$mutations=@($state.Events|Where-Object action -In @('WriteBytes','SetDescriptor','DeleteFile','DeleteDirectory'))
NeedVirtual ($mutations[0].path -ceq $state.Spec.PendingPath -and @($mutations|Where-Object action -CEQ WriteBytes).Count -eq 2 -and @($mutations|Where-Object action -CEQ SetDescriptor).Count -eq 1221) 'Original mark/payload/descriptor sequence differs'
$deleted=@($mutations|Where-Object action -In @('DeleteFile','DeleteDirectory'));NeedVirtual ($deleted.Count -eq 34 -and $deleted[-2].path -ceq $state.Spec.PendingPath -and $deleted[-1].path -ceq $state.Spec.RunsPath -and $state.Mutations -eq 1257) 'Actual finite inverse deletion/finalization differs'
NeedVirtual ($state.Archives.Count -eq @($state.Spec.Created|Where-Object {-not $_.directory}).Count) 'Virtual created-file archive coverage differs'
$drift=NewVirtualState;$drift.Objects[$drift.Spec.RunsPath].identity='e'*32;$rejected=Invoke-RecoveryCoordinator $drift.Spec $backend $drift
NeedVirtual (-not $rejected.Success -and $drift.Mutations -eq 0 -and $drift.Archives.Count -eq 0 -and $rejected.ReleaseSucceeded -and $rejected.DisposeSucceeded -and $drift.Objects.ContainsKey($drift.Spec.PendingPath)) 'Runs-parent identity drift reached a write or lost closure'
NeedVirtual (-not ('Azurite.Stage.FileSecurity' -as [type]) -and -not ('Azurite.Restricted.FullBootstrapIdentity' -as [type])) 'Native helper unexpectedly loaded'
$summary=[ordered]@{scope='actual-spec-original-coordinator-virtual-only';testOnlySimulated=$true;actualSpecConstructorUsed=$true;originalCoordinatorUsed=$true;sourceManifestSha256=$arguments.ExpectedAdapterManifestSha256;actualEvidenceSha256=$arguments.ExpectedRecoveryEvidenceSha256;originalCount=1228;actualCapturedCurrentCount=1261;expectedWithRunsParent=1262;createdCount=34;payloadRestores=1;descriptorRestores=1221;virtualMutations=$state.Mutations;virtualOriginalsMatch=$true;virtualAllCreatedAbsent=$true;virtualPendingCleared=$result.PendingCleared;virtualRunsRemoved=$result.RunsRemoved;virtualArchiveFiles=$state.Archives.Count;parentDriftRefusedBeforeArchiveAndWrite=$true;parentDriftError=$rejected.Error;pureFreshnessGuardChecks=$freshnessChecks;ApplyInvoked=$false;fakeFreshnessInMemoryOnly=$true;fakeFreshFilesWritten=$false;nativeHelpersLoaded=$false;FReadPerformed=$false;FWritePerformed=$false;nativeExecuted=$false;passed=2+$freshnessChecks;failed=0}
[IO.File]::WriteAllText((Join-Path $out 'result.json'),($summary|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$summary|ConvertTo-Json -Depth 6 -Compress
