using Azurite.CacheRootLab;
using Azurite.EditorIsolation;
using Azurite.NormalEditor;
using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Loader.Routes;

static class CacheBindingChecks
{
    internal static void Run(Action<string,Action> test,Action<bool,string> need,Action<Action> refuse)
    {
        // F paths are synthetic text only: these predicates perform no file,
        // process, memory or host operations. Metadata uses existing C copies.
        var lab=InstallationAuthority.ApprovedLabRoot;var id="8e0237ea-e97c-4273-9847-4d9db27f9a20";
        var paths=new RunPaths(lab,Path.Combine(lab,"runs",id),Path.Combine(lab,"install"));
        var binding=new AdapterBinding(new NormalBinding(id,1,123,456,paths,new string('1',64),new string('2',64),"lab-read-"+id),@"C:\source-native-settings.json");var exe=Path.Combine(paths.Install,"AzureArchive.exe");
        test("raw cache binding scope accepts exact synthetic F child identity",()=>CacheBindingRules.RequireHost(binding,exe,123,456));
        test("raw cache binding refuses another executable",()=>refuse(()=>CacheBindingRules.RequireHost(binding,exe+".old",123,456)));
        test("raw cache binding refuses foreign process",()=>refuse(()=>CacheBindingRules.RequireHost(binding,exe,124,456)));
        test("raw cache binding refuses foreign native thread",()=>refuse(()=>CacheBindingRules.RequireHost(binding,exe,123,457)));
        test("raw cache binding cannot repurpose old E path",()=>refuse(()=>CacheBindingRules.RequireHost(binding with{Policy=binding.Policy with{Paths=new RunPaths(@"E:\old",@"E:\old\runs\"+id,@"E:\old\install")}},exe,123,456)));
        var pristine=new PreUseState(2,4096,0,true,456);
        test("cache pristine values are accepted only as observations",()=>CacheBindingRules.RequirePristineObservation(pristine,456));
        test("cache observed manager is not empty",()=>refuse(()=>CacheBindingRules.RequirePristineObservation(pristine with{Manager=1},456)));
        test("cache observed allocator unavailable",()=>refuse(()=>CacheBindingRules.RequirePristineObservation(pristine with{Allocator=0},456)));
        test("cache observed CRT not initialized",()=>refuse(()=>CacheBindingRules.RequirePristineObservation(pristine with{CrtState=1},456)));
        test("cache observed root differs from original bytes",()=>refuse(()=>CacheBindingRules.RequirePristineObservation(pristine with{ExactInitialRoot=false},456)));
        test("cache observation native thread differs",()=>refuse(()=>CacheBindingRules.RequirePristineObservation(pristine with{NativeThreadId=457},456)));
        NativeStringValue Value(string text)=>new(text.Replace('\\','/'),NativeStringKind.Owned,0x5f,9,8192,System.Text.Encoding.UTF8.GetByteCount(text));
        test("native cache consumer accepts exact selected resource cache",()=>CacheBindingRules.RequireCachePath(Value(paths.Cache),paths));
        test("native cache consumer accepts separate owned default cache",()=>CacheBindingRules.RequireCachePath(Value(CacheBindingRules.DefaultCachePath(paths)),paths));
        test("native cache consumer rejects ordinary external cache",()=>refuse(()=>CacheBindingRules.RequireCachePath(Value(@"C:\Users\Public\Unity\daily"),paths)));
        test("native cache consumer rejects sibling prefix",()=>refuse(()=>CacheBindingRules.RequireCachePath(Value(paths.Cache+"-daily"),paths)));
        test("native cache consumer rejects borrowed representation",()=>refuse(()=>CacheBindingRules.RequireCachePath(Value(paths.Cache) with{Kind=NativeStringKind.Borrowed,Tag=0x80},paths)));
        test("native cache consumer rejects wrong allocator label",()=>refuse(()=>CacheBindingRules.RequireCachePath(Value(paths.Cache) with{Label=1},paths)));
        test("reused native decoder assembly is the fixed C binary",()=>need(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(NativeStringReader).Assembly.Location))).ToLowerInvariant()==CacheBindingRules.CoreSha256,"CacheRoot.Core copy differs."));
        test("F raw binding scopes before any target validation and never mutates root",()=>{
            using var assembly=Mono.Cecil.AssemblyDefinition.ReadAssembly(typeof(RoutePathRules).Assembly.Location);
            var type=assembly.MainModule.GetType("Azurite.NormalEditor.Loader.Routes.NormalCacheBindings");need(type is not null,"F-specific raw binding is absent.");
            var bind=type!.Methods.Single(m=>m.Name=="Bind");var calls=bind.Body.Instructions.Select(i=>i.Operand).OfType<Mono.Cecil.MethodReference>().ToArray();
            var host=Array.FindIndex(calls,m=>m.Name=="RequireHost");var window=Array.FindIndex(calls,m=>m.Name=="get_RequireStartupWindow");var target=Array.FindIndex(calls,m=>m.Name=="VerifyFilesAndMetadata");
            need(host>=0&&window>host&&target>window,"Target observation precedes exact host/window checks.");
            var all=type.Methods.Where(m=>m.HasBody).SelectMany(m=>m.Body.Instructions).Select(i=>i.Operand).OfType<Mono.Cecil.MethodReference>();
            need(!all.Any(m=>m.Name.StartsWith("Write",StringComparison.Ordinal)||m.Name=="GetDelegateForFunctionPointer"||m.Name=="RunClassConstructor"||m.Name=="Prepare"),"Read-only binding introduced mutation, target initialization or old CLI Prepare.");
        });
        test("native initializer guard uses exact byte ABI and verifies before forwarding",()=>{
            using var assembly=Mono.Cecil.AssemblyDefinition.ReadAssembly(typeof(RoutePathRules).Assembly.Location);
            var type=assembly.MainModule.GetType("Azurite.NormalEditor.Loader.Routes.NativeCacheInitializerGuard");need(type is not null,"Native initializer guard is absent.");
            var abi=type!.NestedTypes.Single(t=>t.Name=="Initializer");var invoke=abi.Methods.Single(m=>m.Name=="Invoke");
            need(invoke.ReturnType.FullName=="System.Byte"&&invoke.Parameters.Select(p=>p.ParameterType.FullName).SequenceEqual(new[]{"System.IntPtr","System.Byte"}),"Initializer ABI was coerced or gained MethodInfo.");
            var body=type.Methods.Single(m=>m.Name=="Callback").Body.Instructions.Select(i=>i.Operand).OfType<Mono.Cecil.MethodReference>().ToArray();
            var verify=Array.FindIndex(body,m=>m.Name=="VerifyOwnership");var inspect=Array.FindIndex(body,m=>m.Name=="InspectInitializer");var original=Array.FindIndex(body,m=>m.Name=="Invoke"&&m.DeclaringType.Name=="Initializer");
            need(verify>=0&&inspect>verify&&original>inspect,"Original native initializer precedes verified containment.");
            var all=type.Methods.Where(m=>m.HasBody).SelectMany(m=>m.Body.Instructions).Select(i=>i.Operand).OfType<Mono.Cecil.MethodReference>();
            need(!all.Any(m=>m.Name is "get_IsApplied" or "Undo" or "Dispose"||m.Name.StartsWith("Write",StringComparison.Ordinal)),"Guard trusts IsApplied or weakens containment/mutates root.");
        });
        test("global root sentinel identifies exact object",()=>need(RootDestinationPolicy.OverlapsGlobal((IntPtr)0x1000,0x1000),"Exact root escaped."));
        test("global root sentinel identifies interior alias",()=>need(RootDestinationPolicy.OverlapsGlobal((IntPtr)0x1010,0x1000),"Interior root alias escaped."));
        test("global root sentinel identifies prior overlapping slot",()=>need(RootDestinationPolicy.OverlapsGlobal((IntPtr)0xff0,0x1000),"Prior overlap escaped."));
        test("global root sentinel leaves unrelated local object untouched",()=>need(!RootDestinationPolicy.OverlapsGlobal((IntPtr)0x2000,0x1000),"Unrelated destination was claimed."));
        test("global root sentinel refuses null destination",()=>refuse(()=>RootDestinationPolicy.OverlapsGlobal(IntPtr.Zero,0x1000)));
        test("global root sentinel refuses overflowing range",()=>refuse(()=>RootDestinationPolicy.OverlapsGlobal((IntPtr)(-4),0x1000)));
    }
}
