using Mono.Cecil;
using Mono.Cecil.Cil;
using System.Security.Cryptography;
using Azurite.NormalEditor.Loader.Routes;

static class MetadataChecks
{
    internal static void Run(string metadataInput,Action<string,Action> test,Action<bool,string> need)
    {
        string Hash(string p)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p))).ToLowerInvariant();
        var old=Path.Combine(metadataInput,"BepInEx");
        var extra=Path.Combine(old,"interop");
        var files=new[]{
            ("Assembly-CSharp",Path.Combine(old,"interop","Assembly-CSharp.dll"),"d95062f3a49fba645986dc7fe0cee749197c9d0c84ff381fc3ca2d9d2823c013"),
            ("UnityEngine.CoreModule",Path.Combine(old,"interop","UnityEngine.CoreModule.dll"),"fd65570bc81061e45fd9ce3bd162cd5839e0efb8f4d76f6902ead8232cd69e69"),
            ("Unity.Addressables",Path.Combine(extra,"Unity.Addressables.dll"),"06c6cd741d28c5b19c8d22620d16b10d30122abf4f7fff7ec5a21eda92102b5e"),
            ("Unity.ResourceManager",Path.Combine(extra,"Unity.ResourceManager.dll"),"deb4598e5eb03b0dae8f165016fff8ded4445542f8926330b249e969e40608f6")};
        var modules=new Dictionary<string,AssemblyDefinition>();
        try
        {
            need(Hash(typeof(AssemblyDefinition).Assembly.Location)=="769a59793d4b8885bbbfbc5aee8f57a0d4e34d275c56c60c03994309b87f67e9","Fixed Cecil reader changed.");
            foreach(var (name,path,sha) in files)
            {
                test("C metadata input "+name,()=>need(Hash(path)==sha,"Fixed C interop changed."));
                modules.Add(name,AssemblyDefinition.ReadAssembly(path,new ReaderParameters{ReadingMode=ReadingMode.Deferred,ReadSymbols=false}));
            }
            test("route table includes actual getter and consumer seams",()=>{
                var required=new[]{"cache","workspace","discovery","offline","addressSet","addressClear","addressEvaluate","discoveryCtor","discoveryDispose","resolve","providerTransform","providerDetermine","providerLoaded","cacheDefault","cacheLookup","cacheAdd","cacheSelect","cacheMove"};
                need(RouteBindingCatalog.Methods.Count==required.Length&&required.ToHashSet(StringComparer.Ordinal).SetEquals(RouteBindingCatalog.Methods.Select(x=>x.Id)),"Exact 18 required managed bindings are absent or duplicated.");
            });
            foreach(var spec in RouteBindingCatalog.Methods)
            {
                test("actual generated metadata binding "+spec.Id,()=>{
                    var type=modules[spec.Assembly].MainModule.GetType(spec.Type.Replace('+','/'))??throw new Exception("Type absent: "+spec.Type);
                    var pointer=type.Fields.Single(x=>x.Name==spec.PointerField);
                    need(pointer.IsStatic&&pointer.IsInitOnly&&pointer.FieldType.FullName=="System.IntPtr","Pointer field shape differs.");
                    var method=type.Methods.Single(x=>x.Name==spec.Method&&x.IsStatic==spec.Static&&x.ReturnType.FullName==spec.ReturnType&&x.Parameters.Select(p=>p.ParameterType.FullName).SequenceEqual(spec.Parameters));
                    need(method.HasBody&&method.Body.Instructions.Any(i=>i.OpCode.Code==Code.Ldsfld&&i.Operand is FieldReference f&&f.Name==spec.PointerField),"Selected wrapper does not use exact pointer field.");
                    var il=type.Methods.Single(x=>x.IsConstructor&&x.IsStatic).Body.Instructions;
                    var at=Enumerable.Range(0,il.Count).Single(i=>il[i].OpCode.Code==Code.Stsfld&&il[i].Operand is FieldReference f&&f.Name==spec.PointerField);
                    need(at>=2&&il[at-1].Operand is MethodReference call&&call.Name=="GetIl2CppMethodByToken"&&il[at-2].OpCode.Code==Code.Ldc_I4&&(int)il[at-2].Operand==spec.Token,"Generated native token initializer differs.");
                    need(spec.Rva>0,"Native RVA must be explicit, not guessed from CLR metadata.");
                });
            }
            foreach(var (assembly,typeName,property,field,native) in new[]{
                ("Assembly-CSharp","AzureArchive.Automation.AuthoringControlServer","metadataPath","NativeFieldInfoPtr_metadataPath","metadataPath"),
                ("Unity.Addressables","UnityEngine.AddressableAssets.ResourceProviders.ContentCatalogProvider/InternalOp","m_LocalDataPath","NativeFieldInfoPtr_m_LocalDataPath","m_LocalDataPath")})
            {
                test("actual consumer path field "+property,()=>{
                    var type=modules[assembly].MainModule.GetType(typeName)??throw new Exception("Consumer type missing.");
                    var p=type.Properties.Single(x=>x.Name==property);need(p.PropertyType.FullName=="System.String"&&!p.GetMethod.IsStatic,"Consumer field type differs.");
                    need(p.GetMethod.Body.Instructions.Any(i=>i.OpCode.Code==Code.Ldsfld&&i.Operand is FieldReference f&&f.Name==field),"Consumer accessor lacks exact field.");
                    var il=type.Methods.Single(x=>x.IsConstructor&&x.IsStatic).Body.Instructions;var at=Enumerable.Range(0,il.Count).Single(i=>il[i].OpCode.Code==Code.Stsfld&&il[i].Operand is FieldReference f&&f.Name==field);
                    need(at>=2&&il[at-1].Operand is MethodReference c&&c.Name=="GetIl2CppField"&&il[at-2].Operand is string text&&text==native,"Native field lookup name differs.");
                });
            }
            test("typed consumer adapter exists without automatic registration",()=>{
                using var assembly=AssemblyDefinition.ReadAssembly(typeof(RoutePathRules).Assembly.Location);
                var bridge=assembly.MainModule.GetType("Azurite.NormalEditor.Loader.Routes.TypedRouteConsumers");
                need(bridge is not null,"Typed consumer adapter is not implemented.");
                need(!assembly.MainModule.Types.SelectMany(t=>t.CustomAttributes).Any(a=>a.AttributeType.FullName.Contains("BepInPlugin")),"Routes must not load itself as a second plugin.");
                need(bridge!.Methods.Single(m=>m.Name=="ProviderDecisionReturned").Parameters.Any(p=>p.ParameterType.FullName=="UnityEngine.AddressableAssets.ResourceProviders.ContentCatalogProvider/InternalOp"),"Actual provider type is not compiled.");
                need(bridge.Methods.Single(m=>m.Name=="CatalogEffectsEntered").Body.Instructions.Any(i=>i.Operand is MethodReference m&&m.Name=="get_m_LocalDataPath"),"Actual cache destination must be read before original effects.");
                need(bridge.Methods.Single(m=>m.Name=="DiscoveryReturned").Body.Instructions.Any(i=>i.Operand is MethodReference m&&m.Name=="get_metadataPath"),"Actual discovery path must be read back.");
                var calls=bridge.Methods.Where(m=>m.HasBody).SelectMany(m=>m.Body.Instructions).Select(i=>i.Operand).OfType<MethodReference>();
                need(!calls.Any(m=>m.Name is "Initialize" or "OpenProject" or "Begin" or "CreateAndApply" or "il2cpp_object_new"),"Typed consumer adapter cannot drive native lifecycle or claim hook installation.");
            });
            foreach(var (name,getter) in new[]{("DiscoveryReturned","get_metadataPath"),("ProviderDecisionReturned","get_m_LocalDataPath")})
                test("typed owner check precedes native field read "+name,()=>{
                    using var assembly=AssemblyDefinition.ReadAssembly(typeof(RoutePathRules).Assembly.Location);
                    var method=assembly.MainModule.GetType("Azurite.NormalEditor.Loader.Routes.TypedRouteConsumers")!.Methods.Single(m=>m.Name==name);
                    var calls=method.Body.Instructions.Select(i=>i.Operand).OfType<MethodReference>().ToList();
                    var bound=calls.FindIndex(m=>m.Name=="AssertBoundCallback");var read=calls.FindIndex(m=>m.Name==getter);
                    need(bound>=0&&read>bound,"Foreign callback can read a native field before its owner check.");
                });
            test("managed route binding requires native guards before target class init",()=>{
                using var assembly=AssemblyDefinition.ReadAssembly(typeof(RoutePathRules).Assembly.Location);
                var type=assembly.MainModule.GetType("Azurite.NormalEditor.Loader.Routes.ManagedRouteBindings");need(type is not null,"Managed route binding is absent.");
                var calls=type!.Methods.Single(m=>m.Name=="Bind").Body.Instructions.Select(i=>i.Operand).OfType<MethodReference>().ToArray();
                var native=Array.FindIndex(calls,m=>m.Name=="RequireRegisteredForInterop");var initialize=Array.FindIndex(calls,m=>m.Name=="RunClassConstructor");
                need(native>=0&&initialize>native,"Target class initializer precedes real native guards.");
                need(calls.Any(m=>m.Name=="GetConstructors")&&calls.Any(m=>m.Name=="GetIl2CppMethodByToken"),"Constructor overload and native token binding is missing.");
            });
            test("public normal route provider composes real guarded registration",()=>{
                using var assembly=AssemblyDefinition.ReadAssembly(typeof(RoutePathRules).Assembly.Location);
                var type=assembly.MainModule.GetType("Azurite.NormalEditor.Loader.Routes.NormalRoutes");need(type is not null&&type.IsPublic,"Public NormalRoutes is absent.");
                need(type!.Interfaces.Any(i=>i.InterfaceType.FullName=="Azurite.NormalEditor.Loader.INormalRoutes"),"Provider does not implement the shared interface.");
                var ctor=type.Methods.Single(m=>m.IsConstructor&&!m.IsStatic&&m.IsPublic);need(ctor.Parameters.Count==0,"Loader factory requires the exact public no-argument constructor.");
                need(!ctor.Body.Instructions.Any(i=>i.Operand is MethodReference m&&(m.Name is "Bind" or "Install" or "RunClassConstructor")),"Constructor touches native work before supplied context.");
                var calls=type.Methods.Single(m=>m.Name=="Register").Body.Instructions.Select(i=>i.Operand).OfType<MethodReference>().ToArray();
                need(calls.Any(m=>m.DeclaringType.Name=="NormalCacheBindings"&&m.Name=="Bind")&&calls.Any(m=>m.DeclaringType.Name=="GlobalRootWriteSentinel"&&m.Name=="Install")&&calls.Any(m=>m.DeclaringType.Name=="NativeCacheInitializerGuard"&&m.Name=="Install")&&calls.Any(m=>m.DeclaringType.Name=="ManagedRouteHooks"&&m.Name=="Install"),"Real registration composition is missing.");
            });
        }
        finally{foreach(var module in modules.Values)module.Dispose();}
    }
}
