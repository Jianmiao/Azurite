#requires -Version 7.0
param([Parameter(Mandatory)][ValidatePattern('^[a-z][a-z0-9-]{0,40}$')][string]$Stage,[Parameter(Mandatory)][string]$LoaderCorePath,[Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$LoaderCoreSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$root=Join-Path $repo 'artifacts/normal-loader-routes-source-20261114';$out=Join-Path $root $Stage
if(Test-Path -LiteralPath $out){throw 'Preserve prior SOURCE evidence; choose a new stage'}
if(!$LoaderCorePath.StartsWith($repo+'\',[StringComparison]::OrdinalIgnoreCase) -or (Get-FileHash -LiteralPath $LoaderCorePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $LoaderCoreSha256){throw 'Fixed author-supplied C Core output is required'}
$dotnet='C:\Program Files\dotnet\dotnet.exe'
if((Get-FileHash -LiteralPath $dotnet -Algorithm SHA256).Hash.ToLowerInvariant() -cne 'ab1b71fd3dd71062e074c9fab8312081a81b7f2b3e0327c48c4d249c8d1a3135'){throw 'Pinned compiler host changed'}
Import-Module (Join-Path $repo 'AcceptanceHarness/FullRestricted.CdbOwnedWaitFixture/SourceProcess.psm1') -Force -DisableNameChecking
[void][IO.Directory]::CreateDirectory($out)
$config=Join-Path $out 'NuGet.Config';[IO.File]::WriteAllText($config,'<?xml version="1.0" encoding="utf-8"?><configuration><packageSources><clear /></packageSources></configuration>',[Text.UTF8Encoding]::new($false))
$pins=@(foreach($dir in @('NormalEditor.Loader.Routes','NormalEditor.Loader.Routes.Tests')){foreach($f in Get-ChildItem -LiteralPath (Join-Path $repo ('AcceptanceHarness/'+$dir)) -File){$copy=Join-Path $out ('source/'+$dir+'/'+$f.Name);[void][IO.Directory]::CreateDirectory((Split-Path -Parent $copy));[IO.File]::Copy($f.FullName,$copy,$false);[ordered]@{source=$f.FullName;copy=$copy;bytes=$f.Length;sha256=(Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}}})
[IO.File]::WriteAllText((Join-Path $out 'source-pins.json'),($pins|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
$buildArgs=@('build',(Join-Path $PSScriptRoot 'NormalEditor.Loader.Routes.Tests.csproj'),'-c','Release','--nologo','--configfile',$config,'-m:1','-p:UseSharedCompilation=false','-p:UseAppHost=false','-p:NuGetAudit=false','-nodeReuse:false',('-p:LoaderCorePath='+$LoaderCorePath))
$build=Invoke-FixtureSourceProcess -File $dotnet -Arguments $buildArgs -Record (Join-Path $out 'build-process.json') -Directory $repo -BoundMs 120000
if($build.exitCode -ne 0){Write-Output ($build.stdout -split "`r?`n"|Select-Object -Last 14);Write-Output $build.stderr;exit 1}
$test=Join-Path $PSScriptRoot 'bin/Release/net6.0/NormalEditor.Loader.Routes.Tests.dll'
$result=Invoke-FixtureSourceProcess -File $dotnet -Arguments @($test,(Join-Path $out 'cases')) -Record (Join-Path $out 'test-process.json') -Directory $repo -BoundMs 30000
foreach($p in $pins){if((Get-FileHash -LiteralPath $p.source -Algorithm SHA256).Hash.ToLowerInvariant() -cne $p.sha256){throw 'Source changed during this bounded check'}}
if((Get-FileHash -LiteralPath $LoaderCorePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $LoaderCoreSha256){throw 'Core changed during this bounded check'}
[pscustomobject]@{stage=$Stage;coreSha256=$LoaderCoreSha256;buildPid=$build.pid;buildExit=$build.exitCode;testPid=$result.pid;testExit=$result.exitCode;stdout=$result.stdout;stderr=$result.stderr;sourceOnly=$true;nativeHostExecuted=$false}|ConvertTo-Json -Depth 4
exit $result.exitCode
