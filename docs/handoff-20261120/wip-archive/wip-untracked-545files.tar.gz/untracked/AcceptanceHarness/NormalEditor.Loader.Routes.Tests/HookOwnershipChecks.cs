using System.Reflection;
using Azurite.NormalEditor.Loader.Routes;

static class HookOwnershipChecks
{
    public static void Prefix(){}public static void Postfix(){}public static void Finalizer(){}public static void Other(){}
    internal static void Run(Action<string,Action> test,Action<Action> refuse)
    {
        MethodInfo Method(string name)=>typeof(HookOwnershipChecks).GetMethod(name)!;
        var p=Method(nameof(Prefix));var q=Method(nameof(Postfix));var f=Method(nameof(Finalizer));var other=Method(nameof(Other));const string owner="SOURCE-owned";
        OwnedPatch Row(MethodInfo m,string? who=null)=>new(who??owner,m);
        HookSnapshot Good()=>new(new[]{Row(p)},new[]{Row(q)},new[]{Row(f)},Array.Empty<OwnedPatch>(),Array.Empty<OwnedPatch>(),new[]{owner});
        void Require(HookSnapshot s)=>HookOwnership.Require(s,owner,p,q,f);
        test("five-category ownership accepts only exact owned methods",()=>Require(Good()));
        test("five-category ownership refuses missing prefix",()=>refuse(()=>Require(Good() with{Prefixes=Array.Empty<OwnedPatch>()})));
        test("five-category ownership refuses duplicate same-owner prefix",()=>refuse(()=>Require(Good() with{Prefixes=new[]{Row(p),Row(p)}})));
        test("five-category ownership refuses foreign prefix owner",()=>refuse(()=>Require(Good() with{Prefixes=new[]{Row(p,"foreign")}})));
        test("five-category ownership refuses different prefix method",()=>refuse(()=>Require(Good() with{Prefixes=new[]{Row(other)}})));
        test("five-category ownership refuses different postfix method",()=>refuse(()=>Require(Good() with{Postfixes=new[]{Row(other)}})));
        test("five-category ownership refuses different finalizer method",()=>refuse(()=>Require(Good() with{Finalizers=new[]{Row(other)}})));
        test("five-category ownership refuses extra reported owner",()=>refuse(()=>Require(Good() with{Owners=new[]{owner,"foreign"}})));
        test("five-category ownership refuses same-owner transpiler",()=>refuse(()=>Require(Good() with{Transpilers=new[]{Row(other)}})));
        test("five-category ownership refuses same-owner ILManipulator",()=>refuse(()=>Require(Good() with{ILManipulators=new[]{Row(other)}})));
        test("five-category ownership refuses foreign ILManipulator",()=>refuse(()=>Require(Good() with{ILManipulators=new[]{Row(other,"foreign")}})));
    }
}
