using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Entry;
using Azurite.NormalEditor.Loader;
using Azurite.NormalEditor.Loader.Routes;

static class ConsumerChecks
{
    private sealed class Fatal:IFatalSink{public void Terminate(string reason)=>throw new Exception("SOURCE fake fatal: "+reason);}
    internal static void Run(AdapterBinding binding,NormalResourcePreparation resource,string cached,Action<string,Action> test,Action<bool,string> need,Action<Action> refuse)
    {
        const long owner=12345,provider=789,server=456;var p=binding.Policy.Paths;
        RouteConsumerFacts New(Func<long>? actualOwner=null)=>new(new NormalRouteContext(binding,new string('1',64),resource,_=>{},new Fatal(),actualOwner??(()=>owner)),()=>binding.Policy.NativeThreadId);
        void Offline(RouteConsumerFacts f){var call=f.OfflineEntered(resource.OfflineRoot,resource.InstalledCatalogPath,resource.InstalledSettingsPath,p.Persistent);f.OriginalReturned(call,true);f.OriginalFinalized(call,null);}
        RouteCall Decision(RouteConsumerFacts f){var call=f.ProviderDecisionEntered(provider);f.ProviderDecisionReturned(call,true,resource.OfflineCatalogPath,cached);f.OriginalFinalized(call,null);return call;}
        void Discovery(RouteConsumerFacts f){var call=f.DiscoveryEntered(server,p.Discovery);f.DiscoveryReturned(call,true,Path.Combine(p.Discovery,"owned.json"));f.OriginalFinalized(call,null);}
        CatalogEvidence Evidence()=>new(1,"catalog-ready",binding.Policy.RunId,new(binding.Policy.RunId,binding.Policy.ProcessId,Environment.CurrentManagedThreadId,binding.Policy.NativeThreadId,10,1000,321),new(new(binding.Policy.RunId,binding.Policy.ProcessId,Environment.CurrentManagedThreadId,binding.Policy.NativeThreadId,10,1000,321),654,owner,987,"CatalogScene",false,false,true,true,false,0,0,false),null);
        void Facts(RouteConsumerFacts f){f.Getter("cache",owner);Offline(f);Discovery(f);f.Resolved("{UnityEngine.Application.persistentDataPath}/com.unity.addressables/"+Path.GetFileName(cached),cached);Decision(f);var c=f.CatalogEffectsEntered(provider,cached);f.OriginalReturned(c,true,true);f.OriginalFinalized(c,null);}
        test("consumer getter uses admission owner before Resource entry",()=>need(New().Getter("workspace",owner)==p.Workspace,"Early bound workspace failed."));
        test("consumer getter cannot claim its first arbitrary owner",()=>refuse(()=>New(()=>0).Getter("workspace",owner)));
        test("consumer records positive original offline return and finalizer",()=>{var f=New();Offline(f);f.RequireQuiescent();});
        test("consumer rejects original suppressed offline call",()=>{var f=New();var c=f.OfflineEntered(resource.OfflineRoot,resource.InstalledCatalogPath,resource.InstalledSettingsPath,p.Persistent);refuse(()=>f.OriginalReturned(c,false));});
        test("consumer finalizer cannot precede actual original return",()=>{var f=New();var c=f.OfflineEntered(resource.OfflineRoot,resource.InstalledCatalogPath,resource.InstalledSettingsPath,p.Persistent);refuse(()=>f.OriginalFinalized(c,null));});
        test("consumer original exception cannot turn into completed fact",()=>{var f=New();var c=f.OfflineEntered(resource.OfflineRoot,resource.InstalledCatalogPath,resource.InstalledSettingsPath,p.Persistent);f.OriginalReturned(c,true);refuse(()=>f.OriginalFinalized(c,new Exception("native failure")));});
        test("consumer rejects foreign audit token",()=>{var a=New();var b=New();var c=a.ProviderDecisionEntered(provider);refuse(()=>b.OriginalReturned(c,true));});
        test("consumer refuses duplicate finalizer",()=>{var f=New();var c=Decision(f);refuse(()=>f.OriginalFinalized(c,null));});
        test("consumer allows owned provider effects after exact decision",()=>{var f=New();Decision(f);var c=f.CatalogEffectsEntered(provider,cached);f.OriginalReturned(c,true,true);f.OriginalFinalized(c,null);f.RequireQuiescent();});
        test("consumer refuses effect before a native decision",()=>refuse(()=>New().CatalogEffectsEntered(provider,cached)));
        test("consumer refuses effect path drift before original writes",()=>{var f=New();Decision(f);refuse(()=>f.CatalogEffectsEntered(provider,resource.OfflineCatalogPath));});
        test("consumer refuses foreign provider receiver",()=>{var f=New();Decision(f);refuse(()=>f.CatalogEffectsEntered(provider+1,cached));});
        test("consumer guards transformed ID during original decision",()=>{var f=New();var c=f.ProviderDecisionEntered(provider);f.Transformed(provider,resource.OfflineCatalogPath);f.ProviderDecisionReturned(c,true,resource.OfflineCatalogPath,cached);f.OriginalFinalized(c,null);});
        test("consumer guards transformed ID during later retry",()=>{var f=New();Decision(f);f.Transformed(provider,cached);});
        test("consumer rejects remote transformed ID before provider consumes it",()=>{var f=New();f.ProviderDecisionEntered(provider);refuse(()=>f.Transformed(provider,"https://example.invalid/catalog.json"));});
        test("consumer rejects transformed ID from unbound provider",()=>refuse(()=>New().Transformed(provider,resource.OfflineCatalogPath)));
        test("consumer preserves original failure/retry effect path checks",()=>{var f=New();Decision(f);var c=f.CatalogEffectsEntered(provider,cached);f.OriginalReturned(c,true,false);f.OriginalFinalized(c,null);f.RequireQuiescent();});
        test("consumer permits original owned discovery disposal",()=>{var f=New();Discovery(f);var c=f.DiscoveryDisposeEntered(server,Path.Combine(p.Discovery,"owned.json"));f.OriginalReturned(c,true);f.OriginalFinalized(c,null);});
        test("consumer refuses discovery deletion for foreign server",()=>{var f=New();Discovery(f);refuse(()=>f.DiscoveryDisposeEntered(server+1,Path.Combine(p.Discovery,"owned.json")));});
        test("consumer refuses discovery metadata drift before deletion",()=>{var f=New();Discovery(f);refuse(()=>f.DiscoveryDisposeEntered(server,Path.Combine(p.Discovery,"other.json")));});
        test("consumer closure accepts recorded facts without new native calls",()=>{var f=New();Facts(f);f.RequireRecordedCatalogFacts(Evidence());});
        test("consumer closure refuses missing prior facts",()=>refuse(()=>New().RequireRecordedCatalogFacts(Evidence())));
        test("consumer closure refuses foreign Catalog run",()=>{var f=New();Facts(f);refuse(()=>f.RequireRecordedCatalogFacts(Evidence() with{RunId="foreign"}));});
        test("consumer close refuses an active original callback",()=>{var f=New();f.ProviderDecisionEntered(provider);refuse(f.RequireQuiescent);});
        test("foreign route callback refuses without owner-held sink lock",()=>{
            var sync=new object();using var started=new ManualResetEventSlim();using var returned=new ManualResetEventSlim();var rejected=false;
            var f=new RouteConsumerFacts(new NormalRouteContext(binding,new string('1',64),resource,_=>{lock(sync){}},new Fatal(),()=>owner),()=>binding.Policy.NativeThreadId);
            var thread=new Thread(()=>{started.Set();try{f.Getter("cache",owner);}catch(InvalidOperationException){rejected=true;}finally{returned.Set();}}){IsBackground=true};
            bool completed;lock(sync){thread.Start();need(started.Wait(3000),"SOURCE worker never started.");completed=returned.Wait(300);}
            need(returned.Wait(3000),"SOURCE worker did not finish after lock release.");thread.Join();need(completed&&rejected,"Foreign callback waited on the owner's sink lock.");
        });
    }
}
