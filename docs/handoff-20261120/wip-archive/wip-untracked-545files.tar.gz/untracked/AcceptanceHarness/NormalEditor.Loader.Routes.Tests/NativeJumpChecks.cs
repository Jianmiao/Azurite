using Azurite.CacheRootLab;
using Azurite.NormalEditor.Loader.Routes;

static class NativeJumpChecks
{
    private sealed class Memory:IBoundedMemory
    {
        internal readonly Dictionary<ulong,byte[]> Windows=new();
        public byte[] Read(ulong address,int count)
        {var rows=Windows.Where(x=>address>=x.Key&&address-x.Key<=(ulong)x.Value.Length&&(ulong)count<=(ulong)x.Value.Length-(address-x.Key)).ToArray();return rows.Length==1?rows[0].Value.Skip(checked((int)(address-rows[0].Key))).Take(count).ToArray():throw new InvalidOperationException("Unmapped SOURCE byte window.");}
    }
    private static byte[] Absolute(ulong target){var b=new byte[14];b[0]=0xff;b[1]=0x25;BitConverter.GetBytes(target).CopyTo(b,6);return b;}
    private static byte[] Relative(ulong from,ulong target){var b=new byte[14];b[0]=0xe9;BitConverter.GetBytes(checked((int)((long)target-(long)from-5))).CopyTo(b,1);return b;}
    internal static void Run(Action<string,Action> test,Action<Action> refuse)
    {
        const ulong entry=0x1000,target=0x5000,relay=0x3000;
        Memory Map(byte[] b){var m=new Memory();m.Windows.Add(entry,b);return m;}
        test("native patch verifier accepts exact RIP-indirect destination",()=>NativeJumpVerification.RequireTarget(Map(Absolute(target)),entry,target));
        test("native patch verifier accepts exact relative destination",()=>NativeJumpVerification.RequireTarget(Map(Relative(entry,target)),entry,target));
        test("native patch verifier accepts one exact bounded relay",()=>{var m=Map(Relative(entry,relay));m.Windows.Add(relay,Absolute(target));NativeJumpVerification.RequireTarget(m,entry,target);});
        test("native patch verifier accepts MOV RAX jump form",()=>{var b=new byte[14];b[0]=0x48;b[1]=0xb8;BitConverter.GetBytes(target).CopyTo(b,2);b[10]=0xff;b[11]=0xe0;NativeJumpVerification.RequireTarget(Map(b),entry,target);});
        test("native patch verifier accepts MOV R11 jump form",()=>{var b=new byte[14];b[0]=0x49;b[1]=0xbb;BitConverter.GetBytes(target).CopyTo(b,2);b[10]=0x41;b[11]=0xff;b[12]=0xe3;NativeJumpVerification.RequireTarget(Map(b),entry,target);});
        test("native patch verifier rejects another hook destination",()=>refuse(()=>NativeJumpVerification.RequireTarget(Map(Absolute(target+1)),entry,target)));
        test("native patch verifier rejects cycle",()=>{var m=Map(Relative(entry,relay));m.Windows.Add(relay,Relative(relay,entry));refuse(()=>NativeJumpVerification.RequireTarget(m,entry,target));});
        test("native patch verifier rejects unbounded relay chain",()=>{var m=Map(Relative(entry,relay));m.Windows.Add(relay,Relative(relay,0x4000));m.Windows.Add(0x4000,Absolute(target));refuse(()=>NativeJumpVerification.RequireTarget(m,entry,target));});
        test("native patch verifier rejects unrecognized original bytes",()=>refuse(()=>NativeJumpVerification.RequireTarget(Map(new byte[14]),entry,target)));
        test("native patch verifier rejects truncated window",()=>refuse(()=>NativeJumpVerification.RequireTarget(Map(new byte[5]),entry,target)));
        test("native patch verifier rejects zero destination",()=>refuse(()=>NativeJumpVerification.RequireTarget(Map(Absolute(0)),entry,0)));
        test("native patch verifier rejects original pointer as detour",()=>refuse(()=>NativeJumpVerification.RequireTarget(Map(Absolute(entry)),entry,entry)));
        var prefix=Convert.FromHexString("48895c2420564883ec30488bf10fb6da33c9");var bounds=new[]{5,6,10,13,16,18};const ulong trampoline=0x8000;
        Memory Trampoline(byte[] patch,int length,ulong returnTo){var m=Map(patch);var code=new byte[64];prefix.Take(length).ToArray().CopyTo(code,0);Absolute(returnTo).CopyTo(code,length);m.Windows.Add(trampoline,code);return m;}
        test("native trampoline accepts five-byte stolen prefix with exact return",()=>NativeJumpVerification.RequireTrampoline(Trampoline(Relative(entry,target),5,entry+5),entry,prefix,trampoline,bounds));
        test("native trampoline accepts sixteen-byte prefix for absolute patch",()=>NativeJumpVerification.RequireTrampoline(Trampoline(Absolute(target),16,entry+16),entry,prefix,trampoline,bounds));
        test("native trampoline rejects correct prefix returning elsewhere",()=>refuse(()=>NativeJumpVerification.RequireTrampoline(Trampoline(Relative(entry,target),5,target),entry,prefix,trampoline,bounds)));
        test("native trampoline rejects insufficient stolen prefix",()=>refuse(()=>NativeJumpVerification.RequireTrampoline(Trampoline(Absolute(target),5,entry+5),entry,prefix,trampoline,bounds)));
        test("native trampoline rejects modified original instructions",()=>{var m=Trampoline(Relative(entry,target),5,entry+5);m.Windows[trampoline][0]^=1;refuse(()=>NativeJumpVerification.RequireTrampoline(m,entry,prefix,trampoline,bounds));});
    }
}
