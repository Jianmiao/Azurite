"""Fixture-only source casts and fresh addon bindings; never execute the fixture."""
import pathlib,hashlib,json,difflib,shutil
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114/io-fixture4'
OUT=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114/io-fixture5'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=BASE/'source/Invoke-RootCOnlyAclFixture4.ps1'
if sha(old)!='d8a4939c2374df39b9876df853b65eee25dd0ee99568102a6216b5cd3b1feb88':raise RuntimeError('Frozen fixture4 runner differs')
if sha(BASE/'fixture-manifest.json')!='a098cc16079049477c58fe2743ca01ed6e5382482e2ae98d3062f10a51962ca4':raise RuntimeError('Frozen fixture4 addon differs')
source=old.read_text(encoding='utf-8-sig').replace('\r\n','\n');s=source;changes=[]
def rep(before,after,label,count=1):
 global s
 if s.count(before)!=count:raise RuntimeError('Exact delta anchor differs '+label)
 s=s.replace(before,after);changes.append(dict(label=label,before=before,after=after,count=count))
rep('fixture4','fixture5','new addon scope and fresh 5 output paths',s.count('fixture4'))
rep('Fixture4','Fixture5','new fixed runner source filename',s.count('Fixture4'))
rep('@($fixture,$directoryAcl)','@([string]$fixture,$directoryAcl)','exact String at actual directory reflection call')
rep('@($minimum,[byte[]](123,125),$fileAcl)','@([string]$minimum,[byte[]](123,125),$fileAcl)','exact String at actual minimum-record reflection call')
rep('@($minimum,[byte[]](9,9),$fileAcl)','@([string]$minimum,[byte[]](9,9),$fileAcl)','exact String at actual duplicate-record reflection call')
rep('@($maximum,$bytes,$fileAcl)','@([string]$maximum,$bytes,$fileAcl)','exact String at actual maximum-record reflection call')
rep('@($path,$bad[1],$fileAcl)','@([string]$path,$bad[1],$fileAcl)','exact String at every invalid-record reflection call')
rep('if($recordBcl -is [Reflection.ConstructorInfo]){$rightsPath}else','if($recordBcl -is [Reflection.ConstructorInfo]){[string]$rightsPath}else','exact String for actual direct legacy BCL constructor')
inverse=s
for d in reversed(changes):inverse=inverse.replace(d['after'],d['before'])
if inverse!=source:raise RuntimeError('Exact inverse differs')
dest=OUT/'source';dest.mkdir()
(dest/'Invoke-RootCOnlyAclFixture5.ps1').write_text(s,encoding='utf-8')
for p in HERE.iterdir():
 if p.is_file():shutil.copy2(p,dest/p.name)
for name in ['Select-CurrentLogonSid.ps1','Test-RootRunnerSyntax.ps1']:shutil.copy2(BASE/'source'/name,dest/name)
(OUT/'fixture4-to-fixture5.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),s.splitlines(True),fromfile='io-fixture4/source/Invoke-RootCOnlyAclFixture4.ps1',tofile='io-fixture5/source/Invoke-RootCOnlyAclFixture5.ps1')),encoding='utf-8')
(OUT/'fixture5-deltas.json').write_text(json.dumps(dict(scope='explicit path String casts and independent fixture5 bindings only',baseSourceSha256=sha(old),newSourceSha256=sha(dest/'Invoke-RootCOnlyAclFixture5.ps1'),inverseNormalizedEqual=True,changes=changes),indent=2),encoding='utf-8')
print(json.dumps(dict(runnerSha256=sha(dest/'Invoke-RootCOnlyAclFixture5.ps1'),selectorSha256=sha(dest/'Select-CurrentLogonSid.ps1'),deltas=len(changes),nativeCandidateCopiedOrRecompiled=False,fixtureInvoked=False)))
