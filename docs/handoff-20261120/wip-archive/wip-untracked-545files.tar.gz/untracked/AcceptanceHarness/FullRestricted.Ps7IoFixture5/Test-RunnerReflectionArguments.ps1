param([Parameter(Mandatory)][string]$RunnerPath,[Parameter(Mandatory)][string]$ExpectedRunnerSha256,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh argument-shape evidence required'}
if((Get-FileHash -LiteralPath $RunnerPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ExpectedRunnerSha256){throw 'Reviewed fixture source differs'}
Add-Type -Path (Join-Path $PSScriptRoot 'TypedReflectionFakes.cs')
$source=[IO.File]::ReadAllText($RunnerPath);$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Runner parse errors'}
$helper=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Invoke-Exact'},$false));if($helper.Count -ne 1){throw 'One actual Invoke-Exact definition required'}
. ([scriptblock]::Create($helper[0].Extent.Text))
$calls=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -ceq 'Invoke-Exact'},$true));if($calls.Count -ne 5){throw 'Actual portable call-site set changed'}
$assignments=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.AssignmentStatementAst]},$true))
function Assignment([string]$Name){$found=@($assignments|Where-Object {$_.Left.Extent.Text -ceq ('$'+$Name)});if($found.Count -ne 1){throw ('One actual '+$Name+' assignment required')};return $found[0].Extent.Text}
$firstCode=Assignment 'first';$argumentsCode=Assignment 'arguments';$groupsCode=Assignment 'rawGroups'
$bclIf=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.Contains('$stream=$recordBcl.Invoke(')},$true));if($bclIf.Count -ne 1){throw 'One actual direct BCL invocation branch required'}
$rows=[Collections.Generic.List[object]]::new()
function Check([bool]$Condition,[string]$Message){if(-not $Condition){throw $Message}}
function Observation {
 $seen=[Azurite.Fixture5Pure.Capture]::Last;if($null -eq $seen){return $null};$values=@()
 foreach($value in $seen.Arguments){if($null -eq $value){$values+=,$null}elseif($value -is [IO.FileInfo]){$values+=,$value.FullName}elseif($value -is [byte[]]){$values+=,('byte['+$value.Length+']')}elseif($value -is [Security.AccessControl.ObjectSecurity]){$values+=,$value.GetType().FullName}else{$values+=,([string]$value)}}
 return [pscustomobject]@{kind=$seen.Kind;path=$seen.Path;argumentTypes=$seen.ArgumentTypes;argumentValues=$values;byteCount=$(if($null -eq $seen.Bytes){$null}else{$seen.Bytes.Length})}
}
function Case([string]$Name,[scriptblock]$Body){[Azurite.Fixture5Pure.Capture]::Reset();$passed=$false;$errorText=$null;try{& $Body;$passed=$true}catch{$errorText=$_.Exception.ToString()};$rows.Add([pscustomobject]@{name=$Name;passed=$passed;error=$errorText;observed=(Observation)});[Console]::WriteLine('CASE '+$Name+' passed='+$passed)}
function CheckRecord([string]$ExpectedPath,[byte[]]$ExpectedBytes){
 $seen=[Azurite.Fixture5Pure.Capture]::Last;Check ([Azurite.Fixture5Pure.Capture]::Count -eq 1 -and $seen.Kind -ceq 'record') 'Typed record method was not invoked exactly once'
 Check ($seen.Path -ceq $ExpectedPath -and [object]::ReferenceEquals($seen.Security,$fileAcl)) 'Record path or exact FileSecurity instance changed'
 if($null -eq $ExpectedBytes){Check ($null -eq $seen.Bytes) 'Null payload changed'}else{Check ($seen.Bytes -is [byte[]] -and [BitConverter]::ToString($seen.Bytes) -ceq [BitConverter]::ToString($ExpectedBytes)) 'Byte-array payload changed'}
 Check ($seen.ArgumentTypes[0] -ceq 'System.String' -and $seen.ArgumentTypes[2] -ceq 'System.Security.AccessControl.FileSecurity') 'Record argument types changed'
}
function CheckBcl([string]$Kind,[string]$FirstType){
 $seen=[Azurite.Fixture5Pure.Capture]::Last;Check ([Azurite.Fixture5Pure.Capture]::Count -eq 1 -and $seen.Kind -ceq $Kind) 'Wrong typed BCL branch'
 Check ($seen.Path -ceq [string]$rightsPath -and [object]::ReferenceEquals($seen.Security,$fileAcl)) 'BCL path or FileSecurity instance changed'
 $want=@($FirstType,'System.IO.FileMode','System.Security.AccessControl.FileSystemRights','System.IO.FileShare','System.Int32','System.IO.FileOptions','System.Security.AccessControl.FileSecurity')
 Check (($seen.ArgumentTypes -join '|') -ceq ($want -join '|')) 'BCL argument types changed'
 $a=$seen.Arguments;Check ([int]$a[1] -eq 1 -and [int]$a[2] -eq 2 -and [int]$a[3] -eq 1 -and $a[4] -eq 4096 -and [int]$a[5] -eq [int]::MinValue) 'CreateNew/WriteData/Read/4096/WriteThrough values changed'
}
# Real provider output, deliberately left untyped just like the actual runner.
# Join-Path constructs strings only; this nonexistent fixture path is never opened.
$fixture=Join-Path 'C:\' 'Azurite-Fixture5-Pure-NeverCreated';$minimum=Join-Path $fixture 'record-min.json';$maximum=Join-Path $fixture 'record-max.bin';$rightsPath=Join-Path $fixture 'rights-probe.bin'
$directoryAcl=[Security.AccessControl.DirectorySecurity]::new();$fileAcl=[Security.AccessControl.FileSecurity]::new();$bytes=[byte[]]::new(4096);$bytes[4095]=200
$io=[Azurite.Fixture5Pure.FakeAclIo]::new();$directoryMethod=$io.GetType().GetMethod('CreateDirectory');$recordMethod=$io.GetType().GetMethod('CreateRecord')
Case 'actual Invoke-Exact directory call receives String and identical DirectorySecurity' {. ([scriptblock]::Create($calls[0].Extent.Text));$seen=[Azurite.Fixture5Pure.Capture]::Last;Check ([Azurite.Fixture5Pure.Capture]::Count -eq 1 -and $seen.Kind -ceq 'directory' -and $seen.Path -ceq [string]$fixture -and [object]::ReferenceEquals($seen.Security,$directoryAcl)) 'Directory transfer differs';Check (($seen.ArgumentTypes -join '|') -ceq 'System.String|System.Security.AccessControl.DirectorySecurity') 'Directory parameter types differ'}
Case 'actual minimum record call preserves typed bytes and FileSecurity' {. ([scriptblock]::Create($calls[1].Extent.Text));CheckRecord ([string]$minimum) ([byte[]](123,125))}
Case 'actual duplicate record call preserves its attempted replacement bytes' {. ([scriptblock]::Create($calls[2].Extent.Text));CheckRecord ([string]$minimum) ([byte[]](9,9))}
Case 'actual maximum record call preserves all 4096 bytes' {. ([scriptblock]::Create($calls[3].Extent.Text));CheckRecord ([string]$maximum) $bytes}
foreach($bad in @(@('null',$null),@('zero',[byte[]]::new(0)),@('one',[byte[]]::new(1)),@('large',[byte[]]::new(4097)))){
 $path=Join-Path $fixture ('bad-'+$bad[0]+'.bin')
 Case ('actual invalid-record argument transfer: '+$bad[0]) {. ([scriptblock]::Create($calls[4].Extent.Text));CheckRecord ([string]$path) $bad[1]}
}
$types=[Type[]]@([string],[IO.FileMode],[Security.AccessControl.FileSystemRights],[IO.FileShare],[int],[IO.FileOptions],[Security.AccessControl.FileSecurity])
Case 'actual direct legacy constructor branch receives all seven exact arguments' {$recordBcl=[Azurite.Fixture5Pure.FakeLegacyConstructor].GetConstructor($types);. ([scriptblock]::Create($firstCode));. ([scriptblock]::Create($argumentsCode));. ([scriptblock]::Create($bclIf[0].Extent.Text));CheckBcl 'legacy-constructor' 'System.String'}
Case 'actual direct modern method branch receives FileInfo and all six remaining types' {$recordBcl=[Azurite.Fixture5Pure.FakeModernMethod].GetMethod('Create');. ([scriptblock]::Create($firstCode));. ([scriptblock]::Create($argumentsCode));. ([scriptblock]::Create($bclIf[0].Extent.Text));CheckBcl 'modern-method' 'System.IO.FileInfo'}
Case 'actual group reflection expression preserves synthetic IntPtr and class 2' {$identity=[pscustomobject]@{Token=[IntPtr]123};$groupMethod=[Azurite.Fixture5Pure.FakeRawGroups].GetMethod('Groups');. ([scriptblock]::Create($groupsCode));$seen=[Azurite.Fixture5Pure.Capture]::Last;Check ([Azurite.Fixture5Pure.Capture]::Count -eq 1 -and $seen.Kind -ceq 'groups' -and $seen.Arguments[0] -eq [IntPtr]123 -and $seen.Arguments[1] -eq 2 -and ($seen.ArgumentTypes -join '|') -ceq 'System.IntPtr|System.Int32') 'Synthetic query argument types/values changed'}
$report=[ordered]@{scope='actual runner Invoke-Exact, actual parameter expressions and direct reflection branches against typed managed fakes with real Join-Path output';runnerPath=$RunnerPath;runnerSha256=$ExpectedRunnerSha256;powerShell=$PSVersionTable.PSVersion.ToString();passed=(@($rows.ToArray()|Where-Object {-not $_.passed}).Count -eq 0);tests=@($rows.ToArray());actualPortableCallSites=$calls.Count;directBclBranches=2;rawQueryArgumentExpressionTestedWithFake=$true;fixtureInvoked=$false;filesystemObjectsCreatedByFakes=$false;currentIdentityRead=$false;tokenQueried=$false;tokenCreatedOrModified=$false;nativeDllLoaded=$false}
[IO.File]::WriteAllText($ResultPath,($report|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false));[pscustomobject]@{passed=$report.passed;tests=$rows.Count;failed=@($rows.ToArray()|Where-Object {-not $_.passed}|Select-Object name,error)}|ConvertTo-Json -Depth 6
if(-not $report.passed){exit 1}
