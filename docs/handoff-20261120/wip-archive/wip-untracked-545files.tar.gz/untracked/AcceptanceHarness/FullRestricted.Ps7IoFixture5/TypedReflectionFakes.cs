using System;using System.IO;using System.Collections.Generic;using System.Security.AccessControl;
namespace Azurite.Fixture5Pure {
 public sealed class Observation {
  public string Kind,Path;public object Security;public byte[] Bytes;public object[] Arguments;public string[] ArgumentTypes;
 }
 public static class Capture {
  public static int Count;public static Observation Last;
  public static void Reset(){Count=0;Last=null;}
  public static void Set(string kind,string path,object security,byte[] data,object[] args){
   Count++;var types=new string[args.Length];for(int i=0;i<args.Length;i++)types[i]=args[i]==null?null:args[i].GetType().FullName;
   Last=new Observation{Kind=kind,Path=path,Security=security,Bytes=data==null?null:(byte[])data.Clone(),Arguments=args,ArgumentTypes=types};
  }
 }
 public sealed class FakeAclIo {
  public void CreateDirectory(string path,DirectorySecurity security){Capture.Set("directory",path,security,null,new object[]{path,security});}
  public void CreateRecord(string path,byte[] data,FileSecurity security){Capture.Set("record",path,security,data,new object[]{path,data,security});}
 }
 // Plain managed class: the signature mirrors the BCL constructor, but it is
 // not a FileStream and neither its base nor its body accesses the filesystem.
 public sealed class FakeLegacyConstructor {
  public FakeLegacyConstructor(string path,FileMode mode,FileSystemRights rights,FileShare share,int buffer,FileOptions options,FileSecurity security){Capture.Set("legacy-constructor",path,security,null,new object[]{path,mode,rights,share,buffer,options,security});}
 }
 public static class FakeModernMethod {
  public static object Create(FileInfo path,FileMode mode,FileSystemRights rights,FileShare share,int buffer,FileOptions options,FileSecurity security){Capture.Set("modern-method",path.FullName,security,null,new object[]{path,mode,rights,share,buffer,options,security});return new object();}
 }
 public static class FakeRawGroups {
  public static List<Dictionary<string,object>> Groups(IntPtr token,int informationClass){Capture.Set("groups",null,null,null,new object[]{token,informationClass});return new List<Dictionary<string,object>>();}
 }
}
