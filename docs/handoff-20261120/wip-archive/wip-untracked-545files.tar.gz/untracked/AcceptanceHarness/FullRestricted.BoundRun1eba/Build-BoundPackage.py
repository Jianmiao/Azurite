"""Copy the reviewed actor truthfully; derive a fresh fixed-run PS authority."""
import pathlib, json, hashlib, shutil, difflib
ROOT=pathlib.Path(__file__).resolve().parents[2]
HERE=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'artifacts/aa-handoff-bound-72f8-20261114/candidate1'
JSON=ROOT/'artifacts/aa-json-compatibility-20261114/source2'
OUT=ROOT/'artifacts/aa-handoff-json-bound-1eba-20261114/candidate1'
RUN='1ebaf8382f8c4424907a9150df495b46'
OLD_RUN='72f854a6f85149f58d20f286283d932b'
DLL='a6d4bfcb5e066a58c19222e4296117cf9b3b88c429923829df217b5268d23a10'
FULL='8e8623a4b4f3a2ecf9a559eaa20a263e7f9864900415bb9e92ffc255fe353cae'
COMP='3e31e7e9008b10a7217a5dac24bc036ba37c8eb4a25f0ea704a4912b4882b119'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
def put(p,s):
 if p.exists():raise RuntimeError('Fresh source output required '+str(p))
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8') if isinstance(s,str) else s)
def js(p,v):put(p,json.dumps(v,ensure_ascii=False,indent=2))
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
decision=ROOT/'artifacts/aa-actual-handoff-next-20261114/next-after-json-source2.json'
if sha(decision)!='84d3c418540a8a89db20d18bddc1e0b2b11d7534015907d7008d1859744e635a':raise RuntimeError('Root decision differs')
d=json.loads(read(decision))
if d['newRunId']!=RUN or d['prepared'] or d['executed'] or d['newBaselineCaptured']:raise RuntimeError('Root run/admission state differs')
manifest=JSON/'FROZEN-MANIFEST.json'
if sha(manifest)!='f6ed379c6eac267eb70a19c5ffc4edddc764b9bf34c2e21a915dbd5acffaa817':raise RuntimeError('Reviewed JSON manifest differs')
for row in json.loads(read(manifest))['files']:
 p=JSON/row['path']
 if p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise RuntimeError('Reviewed JSON file drift '+row['path'])
if sha(JSON/'build3/RestrictedCliNative.dll')!=DLL or sha(JSON/'build3/RestrictedCliFullRestricted.cs')!=FULL or sha(JSON/'composition-final.json')!=COMP:raise RuntimeError('Actual reviewed actor differs')
checkpoint=BASE/'source-checkpoint.json'
if sha(checkpoint)!='e87b007390557d9482be446dd8798441d57ab773d64be8dab1feeffc228d05d9':raise RuntimeError('Mature package checkpoint differs')
for row in json.loads(read(checkpoint))['files']:
 p=BASE/row['path']
 if p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise RuntimeError('Mature package source drift '+row['path'])
if OUT.exists():raise RuntimeError('Fresh candidate required')
OUT.mkdir(parents=True)
old_policy=read(BASE/'overlay/Qualification.Policy.ps1')
# Reused DLL has this immutable evidence root. Only its runtime run suffix changes.
evidence_directory=str(BASE/'native-evidence/runs'/RUN)
new_policy=old_policy.replace(OLD_RUN,RUN).replace('88f04c780207cfc47dceceea3e61a1993c072300ea26b205b4c8eb2b02fc985b',FULL).replace('e56d1517fd006388d17313b709ad410fd11933f4c86c3956bdeb613198207f08',COMP)
if evidence_directory not in new_policy:raise RuntimeError('Reused actor evidence path not bound truthfully')
diff=[];policy_copies=[]
for p in sorted((BASE/'overlay').iterdir()):
 if p.name in ('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs','RestrictedCliNative.dll','tooling-manifest.json'):continue
 origin=JSON/'overlay'/p.name
 if not origin.exists():origin=p
 before=read(origin);s=before
 if old_policy in s:
  if s.count(old_policy)!=1:raise RuntimeError('Ambiguous embedded policy '+p.name)
  s=s.replace(old_policy,'@PRESERVE_REUSED_ACTOR_POLICY@');policy_copies.append(p.name)
 s=s.replace(OLD_RUN,RUN).replace(str(BASE),str(OUT)).replace(str(BASE.relative_to(ROOT)),str(OUT.relative_to(ROOT)))
 s=s.replace('@PRESERVE_REUSED_ACTOR_POLICY@',new_policy)
 if p.name=='Qualification.Policy.ps1':s=new_policy
 if OLD_RUN in s:raise RuntimeError('Stale run literal '+p.name)
 put(OUT/'overlay'/p.name,s)
 diff.extend(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='reviewed/'+p.name,tofile='1eba/'+p.name))
if len(policy_copies)!=7:raise RuntimeError('Exact seven qualification policy copies required')
for name in ('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs','RestrictedCliNative.dll'):put(OUT/'overlay'/name,(JSON/'build3'/name).read_bytes())
put(OUT/'compiler-inputs.zip',(JSON/'build3/compiler-inputs.zip').read_bytes())
put(OUT/'composition.json',(JSON/'composition-final.json').read_bytes())
put(OUT/'compiler-build.json',(JSON/'compiler-build.json').read_bytes())
put(OUT/'original-compiler-process.json',(JSON/'build3/compile-process.json').read_bytes())
for row in json.loads(read(JSON/'composition-final.json'))['components']:
 p=pathlib.Path(row['path'])
 if sha(p)!=row['sha256']:raise RuntimeError('Composition source drift '+row['name'])
 put(OUT/'components'/row['name'],p.read_bytes())
shutil.copytree(BASE/'helper-build',OUT/'helper-build')
put(OUT/'72-to-1eba-powershell.diff',''.join(diff))
io=json.loads(read(BASE/'io-qualification-binding.json'));io.update(scope='1eba preserves previously qualified PortableAclIo bytes; no new physical IO qualification',runId=RUN,newDllActuallyIoTested=False,AAExecuted=False,nativeHandoffAcceptance=False)
js(OUT/'io-qualification-binding.json',io)
js(OUT/'derivation.json',dict(scope='truthful reuse of reviewed source2 actor with fresh fixed-run PS package',runId=RUN,rootDecision=pin(decision),source2Manifest=pin(manifest),old72Checkpoint=pin(checkpoint),runtimeDllSha256=DLL,fullSourceSha256=FULL,compositionSha256=COMP,actorSourcesChanged=False,newCompilationPerformed=False,originalCompilationReceipt=pin(JSON/'compiler-build.json'),originalCompilerInputsArchive=pin(JSON/'build3/compiler-inputs.zip'),originalCompilerProcess=pin(JSON/'build3/compile-process.json'),debuggerEvidenceDirectory=evidence_directory,evidenceRootIsImmutableActorConstant=True,oldRunEvidenceChanged=False,allPolicyCopies=policy_copies,baselineCreated=False,freshCaptureCreated=False,approvalCreated=False,nativeExecuted=False,FReadPerformed=False,FWritePerformed=False,remainingCoverage=d['remainingCoverage']))
print(json.dumps(dict(candidate=str(OUT),runId=RUN,dllSha256=DLL,newCompilationPerformed=False,debuggerEvidenceDirectory=evidence_directory,sourceOnly=True)))
