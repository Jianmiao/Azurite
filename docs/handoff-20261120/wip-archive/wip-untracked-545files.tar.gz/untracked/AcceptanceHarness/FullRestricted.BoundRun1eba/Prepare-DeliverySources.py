"""Derive exact source drivers from the mature reviewed binder and fixed Capture."""
import pathlib,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
OLD=ROOT/'AcceptanceHarness/FullRestricted.BoundRun72f8'
RUN='1ebaf8382f8c4424907a9150df495b46';PREVIOUS='72f854a6f85149f58d20f286283d932b'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
def put(name,s):
 p=HERE/name
 if p.exists():raise RuntimeError('Fresh derived source required '+name)
 p.write_text(s,encoding='utf-8')
def replace_once(s,a,b):
 if s.count(a)!=1:raise RuntimeError('Unique source anchor required '+a[:100])
 return s.replace(a,b)
source=OLD/'Make-Delivery.py'
if sha(source)!='bbd9c910e16a806ed86cfa2db98863fa5b2ac2881881f20548a4fbd254ec0861':raise RuntimeError('Original delivery builder differs')
s=read(source).replace(PREVIOUS,RUN).replace('aa-handoff-bound-72f8-20261114','aa-handoff-json-bound-1eba-20261114').replace('fixed-72f8-','fixed-1eba-').replace('root-selected-72f8-','root-selected-1eba-').replace('verified-72f8-','verified-1eba-').replace('Exact C 72f8 bound candidate','Exact C 1eba bound candidate')
s=s.replace("'actual-no-trace-72f8-candidate1/result.json'","'json-compatibility-source1-fix1/result.json'")
s=s.replace('actual-no-trace-72f8-candidate1/result.json','json-compatibility-source1-fix1/result.json')
s=s.replace('artifacts/root-ps7-io-20261114/next-after-bfdd-intent.json','artifacts/aa-actual-handoff-next-20261114/next-after-json-source2.json')
s=s.replace("'candidate3-to-bound.diff'","'72-to-1eba-powershell.diff'")
s=replace_once(s,"pathlib.Path(r'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Web.Extensions.dll')","pathlib.Path(r'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Runtime.Serialization.dll'),pathlib.Path(r'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Xml.dll')")
s=replace_once(s,"debuggerEvidenceDirectory=str(OUT/('native-evidence/runs/'+RUN))","debuggerEvidenceDirectory=json.loads(read(OUT/'derivation.json'))['debuggerEvidenceDirectory']")
anchor="harmless=ROOT/'artifacts/aa-fr-native-lifecycle-fixture/cleanup9974-root-supervision/harmless-cleanup-v2.json'"
addition="""# Explicit reviewed provenance, not a replacement hidden under old membership.
for relative in [
 'artifacts/aa-json-compatibility-20261114/source2/FROZEN-MANIFEST.json',
 'artifacts/aa-json-compatibility-20261114/source2/build3/RestrictedCliNative.dll',
 'artifacts/aa-json-compatibility-20261114/source2/build3/RestrictedCliNative.cs',
 'artifacts/aa-json-compatibility-20261114/source2/build3/RestrictedCliFullRestricted.cs',
 'artifacts/aa-json-compatibility-20261114/source2/build3/compile-process.json',
 'artifacts/aa-json-compatibility-20261114/source2/build3/compiler-inputs.zip',
 'artifacts/aa-json-compatibility-20261114/source2/composition-final.json',
 'artifacts/aa-json-compatibility-20261114/source2/compiler-build.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps7.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps7-process.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps51.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps51-process.json',
 '.superpowers/sdd/azurite-authoring-20261108/team/72-json-compatibility-independent-review.md',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/Capture-FreshShared.Fixed.ps1',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/source-addon.json',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/source-checkpoint.json',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/derivation.json',
 '.superpowers/sdd/azurite-authoring-20261108/team/72f8-fresh-shared-fix1-review.md']:
 add(ROOT/relative)
"""
s=replace_once(s,anchor,addition+anchor)
start=s.index("fresh=read(ROOT/('artifacts/aa-fr-closed-failed-recovery/plan-'")
end=s.index("put(drivers['Capture-FreshShared.Bound.ps1']",start)
fresh="""fixed=ROOT/'artifacts/aa-fresh-shared-72f8-fix1-20261114/Capture-FreshShared.Fixed.ps1'
if sha(fixed)!='71c204d3b231ff1ba60f64ca0ca887e524fd095d948de67826d395b0ffa464d3':raise RuntimeError('Reviewed fixed Capture source differs')
fresh=read(fixed)
fresh=fresh[fresh.index('if(-not $Capture){'):].replace('72f854a6f85149f58d20f286283d932b',RUN).replace('72f8-fresh-shared-source-plan','1eba-fresh-shared-source-plan')
if '$capture=' in fresh or fresh.count('$captureInputs')!=5:raise RuntimeError('Reviewed Capture local-variable correction was not retained')
"""
s=s[:start]+fresh+s[end:]
s=replace_once(s,"sequenceStages=['Capture'","remainingCoverage=json.loads(read(ROOT/'artifacts/aa-actual-handoff-next-20261114/next-after-json-source2.json'))['remainingCoverage'],jsonQualificationBinding=pin(OUT/'json-qualification-binding.json'),freshSourceBinding=pin(OUT/'fresh-source-binding.json'),\n sequenceStages=['Capture'")
s=replace_once(s,"'source-build-result.json','sequence-source-manifest.json'","'source-build-result.json','json-qualification-binding.json','fresh-source-binding.json','original-compiler-process.json','sequence-source-manifest.json'")
s=replace_once(s,".replace('@SOURCE_DIR@',str(HERE))",".replace('@SOURCE_DIR@',str(HERE)).replace('@DEBUGGER_EVIDENCE@',json.loads(read(OUT/'derivation.json'))['debuggerEvidenceDirectory'])")
put('Make-Delivery.py',s)
for name in ['RootIntent.Body.template.ps1','Test-BoundPolicy.ps1','Test-BoundConsistency.ps1','Test-BoundFailureGuards.ps1','Test-SourceOnlyDrivers.ps1']:
 s=read(OLD/name).replace(PREVIOUS,RUN).replace('72f8','1eba').replace('BoundRun72f8','BoundRun1eba')
 if name in ('Test-BoundPolicy.ps1','Test-BoundConsistency.ps1'):
  s=s.replace("(Join-Path $CandidateDirectory ('native-evidence\\runs\\'+$run))","$expectedEvidence")
  anchor="$ErrorActionPreference='Stop';Set-StrictMode -Version Latest"
  s=replace_once(s,anchor,anchor+"\n$expectedEvidence=(Get-Content -LiteralPath (Join-Path $CandidateDirectory 'derivation.json') -Raw|ConvertFrom-Json).debuggerEvidenceDirectory")
 put(name,s)
s=read(OLD/'ROOT-COMMANDS.template.md').replace('72f8','1eba').replace('new 72 baseline','new 1eba baseline')
s=s.replace('The new composed DLL has not been executed natively.','The copied a6d4 DLL retains the actual source2 compiler/archive/canonical provenance and dual-host managed JSON proof; this bound package does not claim a new compilation or native execution.')
s=s.replace('`@CANDIDATE@\\native-evidence\\runs\\@RUN@`','`@DEBUGGER_EVIDENCE@`')
s+='\nThe fixed evidence root is compiled into the reused actor. The new runtime run directory above is unique; no older run files may be changed. The reviewed Capture local-variable correction is integrated into the new exact delivery and linked by fresh-source-binding.json. Its executing path belongs to this new manifest; it is not presented as a member of the old 123-member package.\n'
put('ROOT-COMMANDS.template.md',s)
print('Derived new fixed-run delivery sources without producing live inputs.')
