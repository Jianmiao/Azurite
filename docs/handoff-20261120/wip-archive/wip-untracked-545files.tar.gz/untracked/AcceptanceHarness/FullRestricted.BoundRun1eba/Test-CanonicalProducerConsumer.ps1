param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh actual provenance test required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$overlay=Join-Path $CandidateDirectory 'overlay';$build=Join-Path $repo 'artifacts\aa-json-compatibility-20261114\source2\build3';$assembler=Join-Path $overlay 'New-AzuriteFullCapabilitiesInputs.ps1';$runtimePath=Join-Path $overlay 'FullRestrictedCapabilitiesRuntime.psm1'
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Need($v,[string]$m){if(-not $v){throw $m}}
function ImportFunctions([string]$path,[string[]]$only){$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);Need ($errors.Count -eq 0) 'Source parse error';foreach($f in $ast.EndBlock.Statements){if($f -is [Management.Automation.Language.FunctionDefinitionAst] -and ($only.Count -eq 0 -or $f.Name -cin $only)){. ([scriptblock]::Create('function script:'+$f.Name+$f.Extent.Text.Substring(('function '+$f.Name).Length)))}}}
ImportFunctions $assembler @();ImportFunctions $runtimePath @('Get-AzuriteFullToolNames','Assert-AzuriteFullToolManifest');$script:InputsRepo=$repo
$text=[IO.File]::ReadAllText($assembler);$start=$text.IndexOf('  $tooling=ConvertFrom-InputsJson $sources[');$end=$text.IndexOf('  $helperBuild=ConvertFrom-InputsJson',$start);Need ($start -ge 0 -and $end -gt $start) 'Actual native contract block absent';$block=$text.Substring($start,$end-$start)
$oldText=[IO.File]::ReadAllText((Join-Path $repo 'artifacts\aa-handoff-bound-72f8-20261114\candidate1\overlay\New-AzuriteFullCapabilitiesInputs.ps1'));$a=$oldText.IndexOf('  $tooling=ConvertFrom-InputsJson $sources[');$b=$oldText.IndexOf('  $helperBuild=ConvertFrom-InputsJson',$a);Need ($block -ceq $oldText.Substring($a,$b-$a)) 'Canonical source/archive/receipt contract was weakened'
$manifest=Get-Content -Raw -LiteralPath (Join-Path $overlay 'tooling-manifest.json')|ConvertFrom-Json -DateKind String;$sources=@{}
foreach($row in $manifest.files){$sources[$row.name]=Read-InputsPinned ([pscustomobject]@{path=(Join-Path $overlay $row.name);sha256=$row.sha256}) 8388608}
$sources['tooling-manifest.json']=Read-InputsPinned ([pscustomobject]@{path=(Join-Path $overlay 'tooling-manifest.json');sha256=(Hash (Join-Path $overlay 'tooling-manifest.json'))}) 8388608
. ([scriptblock]::Create($block))
Need ($nativeResult.scope -ceq 'SOURCE-only-bounded-JSON-compatibility-build' -and $nativeResult.newCompilationPerformed -eq $true -and $nativeResult.newNativeRunIdAssigned -eq $false -and $nativeResult.actualCompilerProcessPath -ceq (Join-Path $build 'compile-process.json')) 'Receipt is not the actual isolated build'
$process=Get-Content -Raw -LiteralPath $nativeResult.actualCompilerProcessPath|ConvertFrom-Json -DateKind String
Need ((Hash $nativeResult.actualCompilerProcessPath) -ceq $nativeResult.actualCompilerProcessSha256 -and $process.started -and $process.exited -and $process.exitCode -eq 0 -and -not $process.timedOut -and -not $process.terminatedOwnedPureChild -and -not $process.stderr -and -not $process.stdout) 'Compiler process is not the actual clean run'
$expectedArgs=@('/nologo','/target:library','/platform:x64','/optimize+','/warnaserror+',('/out:'+(Join-Path $build 'RestrictedCliNative.dll')),'/r:C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Runtime.Serialization.dll','/r:C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Xml.dll',(Join-Path $build 'RestrictedCliNative.cs'),(Join-Path $build 'RestrictedCliFullRestricted.cs'))
Need (($process.arguments -join '|') -ceq ($expectedArgs -join '|')) 'Exact actual two-source/two-reference compiler command differs'
Need ($nativeResult.dllSha256 -ceq (Hash (Join-Path $overlay 'RestrictedCliNative.dll')) -and $nativeResult.sourceArchivePath -ceq (Join-Path $build 'compiler-inputs.zip') -and $nativeResult.sourceArchiveSha256 -ceq (Hash $nativeResult.sourceArchivePath)) 'Actual binary/archive linkage differs'
Need ((Hash (Join-Path $CandidateDirectory 'compiler-inputs.zip')) -ceq $nativeResult.sourceArchiveSha256 -and (Hash (Join-Path $CandidateDirectory 'composition.json')) -ceq $nativeResult.compositionSha256) 'Copied original archive/composition differs'
$zip=[IO.Compression.ZipFile]::OpenRead($nativeResult.sourceArchivePath)
try{[string[]]$names=@($zip.Entries.FullName);[Array]::Sort($names,[StringComparer]::Ordinal);Need (($names -join '|') -ceq 'RestrictedCliFullRestricted.cs|RestrictedCliNative.cs|composition.json') 'Compiler archive set differs';foreach($entry in $zip.Entries){$s=$entry.Open();$m=[IO.MemoryStream]::new();try{$s.CopyTo($m);$bytes=$m.ToArray()}finally{$s.Dispose();$m.Dispose()};Need ([Convert]::ToBase64String($bytes) -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $build $entry.FullName)))) ('Archived actual input differs: '+$entry.FullName)}}finally{$zip.Dispose()}
$hashes=[ordered]@{};foreach($row in $manifest.files){$hashes[$row.name]=$row.sha256};$control=[pscustomobject]@{toolHashes=[pscustomobject]$hashes}
$helperBuild=Get-Content -Raw -LiteralPath (Join-Path $repo 'artifacts\aa-handoff-bound-72f8-20261114\candidate1\helper-build\build.json')|ConvertFrom-Json -DateKind String
$referenceLine=@($text -split '\r?\n'|Where-Object {$_ -like "*'Exact compiler/reference provenance differs'*"});Need ($referenceLine.Count -eq 1) 'Exact assembler reference guard missing'
$runtimeText=[IO.File]::ReadAllText($runtimePath);$start=$runtimeText.IndexOf(" `$framework=Join-Path ([Environment]::GetFolderPath('Windows')) 'Microsoft.NET\Framework64\v4.0.30319'");$end=$runtimeText.IndexOf(' foreach($file in $manifest.files)',$start);Need ($start -ge 0 -and $end -gt $start) 'Actual Framework pin block absent';$frameworkBlock=$runtimeText.Substring($start,$end-$start)
function Get-AzuriteSha256([string]$path){return Hash $path}
function CheckReferences($value){$manifest=$value;$tooling=$value;Assert-AzuriteFullToolManifest $manifest $control;. ([scriptblock]::Create($referenceLine[0]));. ([scriptblock]::Create($frameworkBlock))}
$checks=[Collections.Generic.List[object]]::new();CheckReferences $manifest;$checks.Add([pscustomobject]@{name='actual exact two-reference producer/runtime/Framework pins';passed=$true})
foreach($case in @('one-reference','extra-reference','wrong-order','unknown-name','unpinned-hash','wrong-reference-bytes','wrong-compiler-bytes')){
 $copy=$manifest|ConvertTo-Json -Depth 20|ConvertFrom-Json -DateKind String
 switch($case){
  'one-reference' {$copy.build.references=@($copy.build.references[0])}
  'extra-reference' {$copy.build.references+=,[pscustomobject]@{name='System.Web.Extensions.dll';sha256=('a'*64)}}
  'wrong-order' {$copy.build.references=@($copy.build.references[1],$copy.build.references[0])}
  'unknown-name' {$copy.build.references[1].name='System.Web.Extensions.dll'}
  'unpinned-hash' {$copy.build.references[1].sha256='bad'}
  'wrong-reference-bytes' {$copy.build.references[0].sha256='a'*64}
  'wrong-compiler-bytes' {$copy.build.compilerSha256='a'*64}
 }
 $rejected=$false;try{CheckReferences $copy}catch{$rejected=$true};Need $rejected ('Changed reference authority accepted: '+$case);$checks.Add([pscustomobject]@{name=$case;passed=$true})
}
$r=[ordered]@{scope='actual compiled artifact through unchanged canonical input block and exact new reference guards';passed=$true;referenceChecks=$checks.ToArray();canonicalContractUnchanged=$true;canonicalPath=$tooling.build.canonicalBuildResultPath;canonicalReceiptSha256=$tooling.build.canonicalBuildResultSha256;actualCompilerPid=$process.pid;actualCompilerCreationFileTime=$process.creationFileTime;dllSha256=$nativeResult.dllSha256;archiveSha256=$nativeResult.sourceArchiveSha256;actualCompilerInputs=$nativeResult.actualCompilerInputs;references=$nativeResult.references;old72ReceiptReused=$false;reviewedSource2ReceiptReused=$true;newCompilationPerformed=$false;fullAssemblerInvoked=$false;liveBaselineSupplied=$false;nativeExecuted=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($r|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false));$r|ConvertTo-Json -Depth 12
