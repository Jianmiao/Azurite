#requires -Version 7.0
[CmdletBinding(DefaultParameterSetName='Bind')]
param([Parameter(Mandatory,ParameterSetName='Bind')][ValidateSet('Preservation','Recovery')][string]$Phase,[Parameter(Mandatory)][string]$CandidateDirectory,
 [Parameter(Mandatory,ParameterSetName='Bind')][string]$ControllerFinalPath,[Parameter(Mandatory,ParameterSetName='Bind')][string]$ExpectedControllerFinalSha256,
 [string]$PreservationDirectory,[string]$SharedResultPath,[string]$SharedComparisonPath,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256,
 [Parameter(Mandatory,ParameterSetName='SourcesOnly')][switch]$VerifySourcesOnly)

$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$candidate=[IO.Path]::GetFullPath($CandidateDirectory)
if([IO.Path]::GetDirectoryName($candidate) -cne (Join-Path $repo 'artifacts\aa-handoff-json-bound-1eba-20261114')){throw 'Exact C 1eba bound candidate required'}
function Assert-QualificationPinnedDelivery([string]$Directory,[string]$ExpectedDigest,[string]$ExecutingDriver) {
 function Digest([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
 function PlainFile([string]$path,[long]$bytes,[string]$hash){
  $full=[IO.Path]::GetFullPath($path)
  if($full -cne $path -or -not $full.StartsWith('C:\',[StringComparison]::Ordinal) -or $hash -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Pinned source must be exact C path and SHA-256'}
  $cursor=$full;while($cursor){$item=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop;if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Pinned source reparse ancestry refused'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
  $item=Get-Item -LiteralPath $full -Force
  if($item.PSIsContainer -or $item.Length -ne $bytes -or (Digest $full) -cne $hash){throw ('Frozen delivery member drift: '+$full)}
 }
 $manifestPath=Join-Path $Directory 'delivery-pinned-manifest.json'
 if($ExpectedDigest -cnotmatch '\A[a-f0-9]{64}\z' -or $ExpectedDigest -ceq ('0'*64) -or (Digest $manifestPath) -cne $ExpectedDigest){throw 'Externally expected pinned delivery digest differs'}
 $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json -DateKind String
 if($manifest.schema -ne 1 -or $manifest.scope -cne 'fixed-1eba-qualification-pinned-delivery' -or $manifest.runId -cne '1ebaf8382f8c4424907a9150df495b46'){throw 'Pinned delivery scope/run differs'}
 $basePath=Join-Path $Directory 'delivery-manifest.json'
 if($manifest.baseDelivery.path -cne $basePath){throw 'Base candidate delivery path differs'}
 PlainFile $basePath $manifest.baseDelivery.bytes $manifest.baseDelivery.sha256
 $base=Get-Content -LiteralPath $basePath -Raw|ConvertFrom-Json -DateKind String
 if($base.schema -ne 1 -or $base.scope -cne 'actual-AA-no-trace-qualification-C-source-driver-delivery' -or $base.runId -cne $manifest.runId -or @($base.files).Count -ne 62 -or @($base.references).Count -ne 81){throw 'Frozen base candidate delivery closure differs'}
 $driver=@($manifest.references|Where-Object role -CEQ FailureBinder)
 if($driver.Count -ne 1 -or $driver[0].path -cne $ExecutingDriver){throw 'Executing failure binder is not the reviewed external reference'}
 $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($entry in @($base.files)+@($manifest.files)){
  $path=[IO.Path]::GetFullPath((Join-Path $Directory $entry.path))
  if(-not $path.StartsWith($Directory+'\',[StringComparison]::Ordinal) -or -not $seen.Add($path)){throw 'Pinned member escaped or duplicated its candidate scope'}
  PlainFile $path $entry.bytes $entry.sha256
 }
 foreach($entry in @($base.references)+@($manifest.references)){
  if(-not $seen.Add($entry.path)){throw 'Pinned external reference duplicated'}
  PlainFile $entry.path $entry.bytes $entry.sha256
 }
 return [pscustomobject]@{manifestPath=$manifestPath;manifestSha256=$ExpectedDigest;baseDeliverySha256=$manifest.baseDelivery.sha256;verifiedMemberCount=$seen.Count;verifiedBeforeModuleLoad=$true}
}
$frozenDelivery=Assert-QualificationPinnedDelivery $candidate $ExpectedDeliveryManifestSha256 $PSCommandPath
if($VerifySourcesOnly){[pscustomobject]@{scope='pinned-failure-binder-source-check-only';sourcesVerified=$true;delivery=$frozenDelivery;moduleLoaded=$false;runtimeEvidenceRead=$false;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false}|ConvertTo-Json -Depth 6;return}
$overlay=Join-Path $candidate 'overlay';. (Join-Path $overlay 'Qualification.Policy.ps1')

$run='1ebaf8382f8c4424907a9150df495b46';$lab='F:\AzuriteLabs\Editor-20261108-normal'
function Pin([string]$name,[string]$path){$full=[IO.Path]::GetFullPath($path);if(-not $full.StartsWith($repo+'\',[StringComparison]::Ordinal)){throw 'Only C workspace evidence can be bound'};$item=Get-Item -LiteralPath $full -Force;if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Regular C evidence required'};return [pscustomobject]@{name=$name;path=$full;sha256=(Get-FileHash -LiteralPath $full).Hash.ToLowerInvariant();bytes=$item.Length}}
function Read($pin){return ([IO.File]::ReadAllText($pin.path,[Text.Encoding]::UTF8)|ConvertFrom-Json -DateKind String)}
function Save([string]$path,$value){$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 30));$f=[IO.File]::Open($path,'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()};return Pin ([IO.Path]::GetFileName($path)) $path}
$finalPin=Pin final $ControllerFinalPath;if($finalPin.sha256 -cne $ExpectedControllerFinalSha256){throw 'Externally selected runtime final hash differs'};$final=Read $finalPin
if($final.runId -cne $run){throw 'Actual runtime final belongs to another run'}
if($final.ownerRetained -or $final.leaseHeld){throw 'Original ownership is retained; no automatic preservation or recovery binding'}
if($null -eq $final.result){throw 'No actual PumpResult exists; snapshot alone does not authorize closed-runtime recovery or prove no creation'}
$prepare=Join-Path $repo ('artifacts\aa-fr-transition-preparation\sequence-'+$run);$inputs=Join-Path $repo ('artifacts\aa-fr-inputs\sequence-'+$run)
$receiptPin=Pin receipts (Join-Path $prepare 'receipt-bundle.json');$receipt=Read $receiptPin
$bootstrapPin=Pin bootstrap $final.result.noTraceBootstrapEvidence.path
if($bootstrapPin.sha256 -cne $final.result.noTraceBootstrapEvidence.sha256 -or $bootstrapPin.bytes -ne $final.result.noTraceBootstrapEvidence.bytes -or [IO.Path]::GetDirectoryName($bootstrapPin.path) -cne [IO.Path]::GetDirectoryName($ControllerFinalPath)){throw 'Actual immutable C bootstrap copy differs'}
$bootstrap=Read $bootstrapPin;$classification=Assert-AzuriteNoTraceClosed $final $bootstrap $receipt.Plan
$outParent=Join-Path $candidate 'failure-inputs';[void][IO.Directory]::CreateDirectory($outParent);$out=Join-Path $outParent ($Phase.ToLowerInvariant()+'-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($out)
if($Phase -ceq 'Preservation'){
 $files=@((Pin observations (Join-Path $prepare 'observations.json')),(Pin preparation (Join-Path $prepare 'preparation-result.json')),(Pin beforeImages (Join-Path $prepare 'before-images-raw.json')),(Pin journal (Join-Path $prepare 'journal.jsonl')),(Pin release (Join-Path $prepare 'lease-release.json')),$receiptPin,$finalPin,$bootstrapPin,(Pin control (Join-Path $inputs 'control.json')))
 $sources=@(foreach($name in @('Preserve-AzuriteClosedFailedRuntime.ps1','Preserve-AzuriteFailedCapabilitiesRun.ps1','Preserve-AzuriteFailedCapabilitiesRun9c.ps1','FullRestrictedClosedFailedRecovery.ps1')){Pin $name (Join-Path $overlay $name)})
 $manifest=Save (Join-Path $out 'preservation-evidence.json') ([ordered]@{schema=1;scope='closed-failed-runtime-preservation-evidence';runId=$run;labRoot=$lab;sources=$sources;files=$files;frozenDelivery=$frozenDelivery})
 [pscustomobject]@{Phase=$Phase;EntryPath=(Join-Path $overlay 'Preserve-AzuriteClosedFailedRuntime.ps1');RunId=$run;EvidenceManifestPath=$manifest.path;ExpectedEvidenceManifestSha256=$manifest.sha256;OutputDirectory=(Join-Path $repo ('artifacts\aa-fr-closed-failed-preservation\no-trace-'+$run));creationStatus=$classification;CInputsOnly=$true;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false}|ConvertTo-Json -Depth 5
 return
}
if([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($PreservationDirectory)) -cne (Join-Path $repo 'artifacts\aa-fr-closed-failed-preservation')){throw 'Exact completed C preservation directory required'}
$files=@((Pin result (Join-Path $prepare 'preparation-result.json')),(Pin observations (Join-Path $prepare 'observations.json')),(Pin before (Join-Path $prepare 'before-images-raw.json')),(Pin receipt $receiptPin.path),(Pin lease (Join-Path $prepare 'lease-release.json')),(Pin runtimeFinal $finalPin.path),$bootstrapPin)
foreach($pair in @(@('preservation','preservation-result.json'),@('comparison','object-comparison.json'),@('inventory','run-inventory.json'),@('archive','archive-manifest.json'),@('important','important-path-status.json'),@('preservationInputs','preservation-inputs.json'))){$files+=,(Pin $pair[0] (Join-Path $PreservationDirectory $pair[1]))}
if([bool]$SharedResultPath -ne [bool]$SharedComparisonPath){throw 'Fresh shared result/comparison must be supplied together'}
if($SharedResultPath){$files+=@((Pin sharedResult $SharedResultPath),(Pin sharedComparison $SharedComparisonPath))}
$observations=Read ($files|Where-Object name -CEQ observations);$comparison=Read ($files|Where-Object name -CEQ comparison);$prepared=@{};foreach($obj in $observations.objects){$prepared[$obj.path]=$obj}
$categories=Get-AzuriteNoTraceRuntimeCategories;$runRoot=$lab+'\runs\restricted-'+$run
$extras=@(foreach($obj in $comparison.currentObjects){if(-not $prepared.ContainsKey($obj.path)){if(-not $obj.path.StartsWith($runRoot+'\',[StringComparison]::Ordinal)){throw 'Extra is outside exact run'};$relative=$obj.path.Substring($runRoot.Length+1);if(-not $categories.ContainsKey($relative) -or $obj.directory){throw 'Extra has no finite recovery category'};[pscustomobject]@{relativePath=$relative;category=$categories[$relative];identity=$obj.identity;sha256=$obj.sha256;bytes=$obj.bytes}}})
$evidence=Save (Join-Path $out 'recovery-evidence.json') ([ordered]@{schema=1;scope='closed-failed-runtime-recovery-evidence';runId=$run;labRoot=$lab;files=$files;runtimeExtras=$extras;frozenDelivery=$frozenDelivery})
$recovery=Import-Module (Join-Path $overlay 'FullRestrictedPreparationRecovery.psm1') -PassThru -Force -DisableNameChecking
$tokenPins=& $recovery {Get-RecoveryTokenPins}
$sourceRows=@((Pin 'FullRestrictedPreparationRecovery.psm1' (Join-Path $overlay 'FullRestrictedPreparationRecovery.psm1')),(Pin 'Recover-AzuriteFullPreparation.ps1' (Join-Path $overlay 'Recover-AzuriteFullPreparation.ps1')),(Pin 'FullRestrictedClosedFailedRecovery.ps1' (Join-Path $overlay 'FullRestrictedClosedFailedRecovery.ps1')),(Pin 'FullRestrictedStageTransition.psm1' (Join-Path $repo 'artifacts\aa-fr-empty-directory-helper-20261113\final-FullRestrictedStageTransition.psm1')))
foreach($name in @('FullRestrictedStageFileSecurity.cs','FullRestrictedStageFileSecurity.dll','build.json')){$sourceRows+=,(Pin $name (Join-Path $repo ('artifacts\aa-fr-empty-directory-helper-20261113\helper-build1\'+$name)))}
foreach($name in $tokenPins.Keys){$sourceRows+=,(Pin $name $tokenPins[$name].path)}
$source=Save (Join-Path $out 'recovery-source.json') ([ordered]@{schema=4;scope='closed-failed-runtime-recovery-source';runId=$run;evidenceManifestSha256=$evidence.sha256;files=$sourceRows;frozenDelivery=$frozenDelivery})
[pscustomobject]@{Phase=$Phase;EntryPath=(Join-Path $overlay 'Recover-AzuriteFullPreparation.ps1');RunId=$run;RecoveryEvidenceManifestPath=$evidence.path;ExpectedRecoveryEvidenceManifestSha256=$evidence.sha256;SourceManifestPath=$source.path;ExpectedSourceManifestSha256=$source.sha256;EvidenceDirectory=(Join-Path $repo ('artifacts\aa-fr-closed-failed-recovery\no-trace-'+$run));ClosedFailedRuntimeRecovery=$true;creationStatus=$classification;CInputsOnly=$true;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false}|ConvertTo-Json -Depth 5
