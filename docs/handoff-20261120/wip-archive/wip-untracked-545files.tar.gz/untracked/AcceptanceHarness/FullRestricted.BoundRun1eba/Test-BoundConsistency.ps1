param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$expectedEvidence=(Get-Content -LiteralPath (Join-Path $CandidateDirectory 'derivation.json') -Raw|ConvertFrom-Json).debuggerEvidenceDirectory
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh consistency evidence required'}
$run='1ebaf8382f8c4424907a9150df495b46';$full=(Get-FileHash (Join-Path $CandidateDirectory 'overlay\RestrictedCliFullRestricted.cs')).Hash.ToLowerInvariant();$composition=(Get-FileHash (Join-Path $CandidateDirectory 'composition.json')).Hash.ToLowerInvariant();$rows=@();$parseFailures=@()
foreach($file in Get-ChildItem -LiteralPath (Join-Path $CandidateDirectory 'overlay') -File|Where-Object Extension -In @('.ps1','.psm1')){
 $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$t,[ref]$e);$parseFailures+=@($e)
 $defs=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Get-AzuriteNoTraceQualification'},$false))
 foreach($def in $defs){. ([scriptblock]::Create($def.Extent.Text));$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run;$okay=$q.runId -ceq $run -and $q.nativeSourceSha256 -ceq $full -and $q.compositionSha256 -ceq $composition -and $q.debuggerEvidenceDirectory -ceq $expectedEvidence -and $q.runtimeTimeoutSeconds -eq 30 -and $q.nativeTimeoutSeconds -eq 10;$rows+=,[pscustomobject]@{file=$file.Name;passed=$okay;nativeSourceSha256=$q.nativeSourceSha256;compositionSha256=$q.compositionSha256}}
}
$seq=Import-Module (Join-Path $CandidateDirectory 'overlay\AzuriteCapabilitiesSequence.psm1') -PassThru -Force -DisableNameChecking;$roles=& $seq {Get-SequenceFixedRoles};$manifest=Get-Content (Join-Path $CandidateDirectory 'sequence-source-manifest.json') -Raw|ConvertFrom-Json -DateKind String
& $seq {param($r)Assert-SequenceSourcePins ([pscustomobject]@{SourceRows=$r})} @($manifest.files)
$helper=Get-Content (Join-Path $CandidateDirectory 'helper-build\build.json') -Raw|ConvertFrom-Json -DateKind String
$stage=@($manifest.files|Where-Object role -CEQ Stage)[0];$helperOkay=$helper.moduleSha256 -ceq $stage.sha256 -and $helper.assemblySha256 -ceq (Get-FileHash (Join-Path $CandidateDirectory 'helper-build\FullRestrictedStageFileSecurity.dll')).Hash.ToLowerInvariant()
$r=[ordered]@{scope='every actual embedded qualification policy plus original 28-role and helper binding';passed=($rows.Count -gt 0 -and @($rows|Where-Object {-not $_.passed}).Count -eq 0 -and $parseFailures.Count -eq 0 -and $roles.Count -eq 28 -and $helperOkay);policies=$rows;policyCount=$rows.Count;roleCount=$roles.Count;helperBindingVerified=$helperOkay;parseErrors=$parseFailures.Count;nativeExecuted=$false;baselineCreated=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($r|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));$r|ConvertTo-Json -Depth 8;if(-not $r.passed){exit 1}
