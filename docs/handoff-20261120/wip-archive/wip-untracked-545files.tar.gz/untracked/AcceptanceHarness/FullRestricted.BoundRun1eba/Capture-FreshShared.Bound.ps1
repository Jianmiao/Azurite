#requires -Version 7.0
[CmdletBinding(DefaultParameterSetName='Plan')]
param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256,
 [Parameter(Mandatory,ParameterSetName='Capture')][switch]$Capture,[Parameter(Mandatory,ParameterSetName='Capture')][string]$ExpectedBeforeSha256,[Parameter(Mandatory,ParameterSetName='Capture')][string]$ExpectedScopeSha256)

$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$candidate=[IO.Path]::GetFullPath($CandidateDirectory)
if([IO.Path]::GetDirectoryName($candidate) -cne (Join-Path $repo 'artifacts\aa-handoff-json-bound-1eba-20261114')){throw 'Exact C 1eba bound candidate required'}
function Assert-QualificationPinnedDelivery([string]$Directory,[string]$ExpectedDigest,[string]$ExecutingDriver) {
 function Digest([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
 function PlainFile([string]$path,[long]$bytes,[string]$hash){
  $full=[IO.Path]::GetFullPath($path)
  if($full -cne $path -or -not $full.StartsWith('C:\',[StringComparison]::Ordinal) -or $hash -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Pinned source must be exact C path and SHA-256'}
  $cursor=$full;while($cursor){$item=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop;if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Pinned source reparse ancestry refused'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
  $item=Get-Item -LiteralPath $full -Force
  if($item.PSIsContainer -or $item.Length -ne $bytes -or (Digest $full) -cne $hash){throw ('Frozen delivery member drift: '+$full)}
 }
 $manifestPath=Join-Path $Directory 'delivery-pinned-manifest.json'
 if($ExpectedDigest -cnotmatch '\A[a-f0-9]{64}\z' -or $ExpectedDigest -ceq ('0'*64) -or (Digest $manifestPath) -cne $ExpectedDigest){throw 'Externally expected pinned delivery digest differs'}
 $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json -DateKind String
 if($manifest.schema -ne 1 -or $manifest.scope -cne 'fixed-1eba-qualification-pinned-delivery' -or $manifest.runId -cne '1ebaf8382f8c4424907a9150df495b46'){throw 'Pinned delivery scope/run differs'}
 $basePath=Join-Path $Directory 'delivery-manifest.json'
 if($manifest.baseDelivery.path -cne $basePath){throw 'Base candidate delivery path differs'}
 PlainFile $basePath $manifest.baseDelivery.bytes $manifest.baseDelivery.sha256
 $base=Get-Content -LiteralPath $basePath -Raw|ConvertFrom-Json -DateKind String
 if($base.schema -ne 1 -or $base.scope -cne 'actual-AA-no-trace-qualification-C-source-driver-delivery' -or $base.runId -cne $manifest.runId -or @($base.files).Count -ne 62 -or @($base.references).Count -ne 81){throw 'Frozen base candidate delivery closure differs'}
 $driver=@($manifest.references|Where-Object role -CEQ FreshShared)
 if($driver.Count -ne 1 -or $driver[0].path -cne $ExecutingDriver){throw 'Executing failure binder is not the reviewed external reference'}
 $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($entry in @($base.files)+@($manifest.files)){
  $path=[IO.Path]::GetFullPath((Join-Path $Directory $entry.path))
  if(-not $path.StartsWith($Directory+'\',[StringComparison]::Ordinal) -or -not $seen.Add($path)){throw 'Pinned member escaped or duplicated its candidate scope'}
  PlainFile $path $entry.bytes $entry.sha256
 }
 foreach($entry in @($base.references)+@($manifest.references)){
  if(-not $seen.Add($entry.path)){throw 'Pinned external reference duplicated'}
  PlainFile $entry.path $entry.bytes $entry.sha256
 }
 return [pscustomobject]@{manifestPath=$manifestPath;manifestSha256=$ExpectedDigest;baseDeliverySha256=$manifest.baseDelivery.sha256;verifiedMemberCount=$seen.Count;verifiedBeforeModuleLoad=$true}
}
$frozenDelivery=Assert-QualificationPinnedDelivery $candidate $ExpectedDeliveryManifestSha256 $PSCommandPath
if(-not $Capture){[pscustomobject]@{scope='1eba-fresh-shared-source-plan';runId='1ebaf8382f8c4424907a9150df495b46';sourcesVerified=$true;delivery=$frozenDelivery;willCapture=$false;willReadShared=$false;willRestore=$false;willLaunch=$false}|ConvertTo-Json -Depth 6;return}
if($ExpectedBeforeSha256 -cnotmatch '\A[a-f0-9]{64}\z' -or $ExpectedScopeSha256 -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Externally reviewed actual before/scope digests required'}
$run='1ebaf8382f8c4424907a9150df495b46'
$captureInputs=Join-Path $repo 'artifacts\aa-fr-inputs\sequence-1ebaf8382f8c4424907a9150df495b46'
$parent=Join-Path $candidate 'recovery-shared'
$output=Join-Path $parent ('fresh-'+[guid]::NewGuid().ToString('N'))
function Need($v,[string]$message){if(-not $v){throw $message}}
function Hash([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save([string]$name,$value){$path=Join-Path $output $name;$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 90));Need ($bytes.Length -le 67108864) 'Output exceeds bounds';$s=[IO.File]::Open($path,'CreateNew','Write','Read');try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()};return [pscustomobject]@{path=$path;sha256=Hash $path}}
Need ([Environment]::Is64BitProcess) 'x64 process required'
$pins=@{'HeadlessCore.psm1'='75f2dccc4015059fe41a476c87117b315f2d38f27569629c5f2192d4792b757f';'RestrictedCliCore.psm1'='452a4255fd950c9b6d1e3e35c537fdb93bd4b40874fb4536dfcc44c754ab1f59';'CurrentAccountCli.psm1'='495efe99ea5f32330d7a1b25148d9cd637a508a83fac93b5037a0db1dcb45ea9'}
foreach($name in @('HeadlessCore.psm1','RestrictedCliCore.psm1','CurrentAccountCli.psm1')){$p=Join-Path $repo ('tools\headless\'+$name);Need ((Hash $p) -ceq $pins[$name]) 'Shared-state producer drift';Import-Module $p -Force -DisableNameChecking}
$beforeSha=$ExpectedBeforeSha256
Need ((Hash (Join-Path $captureInputs 'before.json')) -ceq $beforeSha) 'Original before drift'
Need ((Hash (Join-Path $captureInputs 'scope.json')) -ceq $ExpectedScopeSha256) 'Scope drift'
$before=Get-Content -LiteralPath (Join-Path $captureInputs 'before.json') -Raw|ConvertFrom-Json -DateKind String
$scope=Get-Content -LiteralPath (Join-Path $captureInputs 'scope.json') -Raw|ConvertFrom-Json -DateKind String
$mutex=[Threading.Mutex]::new($false,'Global\AzuriteRestrictedCli-AA');$held=$false;$disposed=$false;$releaseError=$null;$started=$false;$failure=$null;$comparison=$null;$aaAfter=-1
try{
 try{$held=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$held=$true;throw 'Abandoned lease requires inspection'}
 Need $held 'Another test owns lease'
 Need (@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'").Count -eq 0) 'AA/probe active'
 Need (-not(Test-Path -LiteralPath $output)) 'Fresh output required'
 [void][IO.Directory]::CreateDirectory($output);$started=$true
 $after=New-AzuriteSharedSnapshot $scope (Read-AzuritePlayerPrefsSnapshot) $run After
 $comparison=Compare-AzuriteSharedSnapshots $before $after $scope $run
 $null=Save 'after.json' $after;$comparisonPin=Save 'comparison.json' $comparison
 $aaAfter=@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'").Count
 Need ($aaAfter -eq 0) 'AA/probe appeared during capture'
 Need ($comparison.accepted -and $comparison.finalStateUnchanged -and -not $comparison.registryChanged -and @($comparison.deltas).Count -eq 0 -and @($comparison.unexpected).Count -eq 0 -and @($comparison.engineMetadata).Count -eq 0) 'Shared state changed; recovery admission refused'
}catch{$failure=$_.Exception.ToString()}
finally{
 if($held){try{$mutex.ReleaseMutex();$held=$false}catch{$releaseError=$_.Exception.ToString()}}
 if(-not $held){try{$mutex.Dispose();$disposed=$true}catch{$releaseError=$_.Exception.ToString()}}
 if($held -or -not $disposed){try{[Console]::Error.WriteLine('Shared comparison lease finalization uncertain; retaining host. '+$releaseError)}finally{while($true){[Threading.Thread]::Sleep(30000)}}}
}
if($failure){if($started){$null=Save 'failure.json' ([pscustomobject]@{utc=[datetime]::UtcNow.ToString('o');error=$failure;leaseHeld=$held;disposed=$disposed;sharedWrites=$false;registryWrites=$false})};throw $failure}
$result=[pscustomobject]@{scope='separate postfailure read-only comparison; not native monitor qualification';utc=$after.capturedUtc;beforeSha256=$beforeSha;output=$output;accepted=$comparison.accepted;finalStateUnchanged=$comparison.finalStateUnchanged;registryChanged=$comparison.registryChanged;deltas=@($comparison.deltas).Count;unexpected=@($comparison.unexpected).Count;engineMetadata=@($comparison.engineMetadata).Count;aaAfter=$aaAfter;registryWrites=$false;sharedWrites=$false;releaseSucceeded=(-not $held);disposeSucceeded=$disposed}
$resultPin=Save 'result.json' $result
[pscustomobject]@{observedUtc=$result.utc;sharedResult=$resultPin;sharedComparison=$comparisonPin;aaAfter=$aaAfter;sharedUnchanged=$true;willLaunch=$false;FWritePerformed=$false}|ConvertTo-Json -Depth 5
