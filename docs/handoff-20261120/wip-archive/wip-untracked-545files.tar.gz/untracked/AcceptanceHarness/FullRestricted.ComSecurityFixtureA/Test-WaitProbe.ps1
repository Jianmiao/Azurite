param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
function Fixture {
 $id='1234567890abcdef1234567890abcdef';$rows=@();$counter=1
 foreach($phase in @('natural-host-thread','explicit-sta-probe')){foreach($seed in @(0,1008)){foreach($path in @('raw','com','managed')){$rows+=,[pscustomobject]@{phase=$phase;seed=$seed;path=$path;before=[pscustomobject]@{nativeThreadId=43};created=$true;mutexName=('Global\AzuriteWaitFixture_'+$counter.ToString('x32'));acquired=$true;released=$true;errorType=$null;releaseError=$null};$counter++}}}
 return [pscustomobject]@{id=$id;entry=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;beforeManagedRuntime=$true};host=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;initializeHr=0;delegateHr=0;loadHr=0;closeHr=0;nativeError=0;managedBytes=1000;aaExecuted=$false};probe=[pscustomobject]@{schema=1;scope='fixed wait diagnostic only, no AA acceptance';pid=42;nativeThreadId=43;finalNativeThreadId=43;sameInitialThread=$true;before=[pscustomobject]@{nativeThreadId=43};runtime='.NET 6.0.36';corelib='C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\System.Private.CoreLib.dll';waitTimeoutMs=100;aaExecuted=$false;initializeStaHr=0;records=$rows}}
}
$checks=@()
foreach($name in @('valid','captured-wait-failure','sta-init-failed','foreign-run','foreign-process','foreign-startup-thread','late-thread-hop','wrong-runtime','unbounded-wait','missing-case','duplicate-case','reused-mutex','truncated-bytes','failed-host','failed-managed-hook','AA-promotion')){
 $f=Fixture;$allow=$name -cin @('valid','captured-wait-failure','sta-init-failed')
 switch($name){
  captured-wait-failure {$f.probe.records[0].acquired=$false;$f.probe.records[0].released=$false;$f.probe.records[0].errorType='System.Runtime.InteropServices.COMException'}
  sta-init-failed {$f.probe.initializeStaHr=-1;$f.probe.records=@($f.probe.records|Where-Object phase -CEQ 'natural-host-thread')}
  foreign-run {$f.host.runId='00000000000000000000000000000001'}
  foreign-process {$f.probe.pid=41}
  foreign-startup-thread {$f.entry.nativeThreadId=44}
  late-thread-hop {$f.probe.records[3].before.nativeThreadId=44}
  wrong-runtime {$f.probe.runtime='.NET 8.0.0'}
  unbounded-wait {$f.probe.waitTimeoutMs=-1}
  missing-case {$f.probe.records=$f.probe.records[0..10]}
  duplicate-case {$f.probe.records[1]=$f.probe.records[0]}
  reused-mutex {$f.probe.records[1].mutexName=$f.probe.records[0].mutexName}
  truncated-bytes {$f.host.managedBytes=999}
  failed-host {$f.host.loadHr=-1}
  failed-managed-hook {$f.probe|Add-Member probeFailed $true}
  AA-promotion {$f.probe.aaExecuted=$true}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureWaitProbe $f.entry $f.host $f.probe $f.id 42 43 1000;$passed=$allow -and $r.correlationVerified -and -not $r.applicationAccepted;if($name -ceq 'captured-wait-failure'){$passed=$passed -and -not $r.allWaitCallsSucceeded -and $r.successfulWaitCount -eq 11}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
function ComFixture([bool]$WithLocalService){
 $f=Fixture;$user='S-1-5-21-111-222-333-1001';$logon='S-1-5-5-11-22';$group='S-1-5-21-111-222-333-513';$mode=if($WithLocalService){'account-plus-localservice'}else{'account-local'};$sddl='O:'+$user+'G:'+$group+'D:(A;;0x3;;;'+$user+')(A;;0x3;;;'+$logon+')(A;;0x3;;;SY)';if($WithLocalService){$sddl+='(A;;0x3;;;LS)'}
 $f|Add-Member user $user;$f|Add-Member logon $logon;$f|Add-Member mode $mode
 $f.probe|Add-Member comSecurity ([pscustomobject]@{protocol='process-local-com-security.v1';mode=$mode;pid=42;nativeThreadBefore=43;nativeThreadAfter=43;apartmentBeforeHr=0;apartmentBefore=1;apartmentQualifierBefore=1;apartmentAfterHr=0;apartmentAfter=1;apartmentQualifierAfter=1;callCount=1;called=$true;hresult=0;configurationEstablished=$true;preparationError=0;tokenCloseError=0;duplicateCloseError=0;ownerSid=$user;groupSid=$group;logonSid=$logon;sddl=$sddl;descriptorAbsolute=$true;saclNull=$true;nullDescriptor=$false;aceMask=3;aceCount=$(if($WithLocalService){4}else{3});accessCheckCalledSuccessfully=$true;accessStatus=$true;accessGranted=3;authnServices=-1;authenticationLevel=0;impersonationLevel=2;capabilities=0;qpcBefore='100';qpcAfter='101';qpcFrequency='10000000';utcBeforeFileTime='1000';utcAfterFileTime='1001';systemAclChanged=$false;tokenDaclChanged=$false;desktopAclChanged=$false;threadTokenInstalled=$false})
 $f.probe|Add-Member firstWaitPhase 102;$f.probe|Add-Member waitClockFrequency 10000000;return $f
}
foreach($name in @('mode-a-valid','mode-b-valid','too-late-observed','s-false-observed','preparation-failure-observed','too-late-promoted','null-descriptor','remote-rights','extra-LocalService-in-A','missing-LocalService-in-B','foreign-owner','foreign-group','deny-ace','inherited-ace','wrong-thread','twice-called','after-first-wait','none-authentication','thread-token-installed','token-dacl-changed','token-close-failed')){
 $f=ComFixture ($name -cin @('mode-b-valid','missing-LocalService-in-B'));$s=$f.probe.comSecurity;$allow=$name -cin @('mode-a-valid','mode-b-valid','too-late-observed','s-false-observed','preparation-failure-observed')
 switch($name){
  too-late-observed {$s.hresult=-2147417831;$s.configurationEstablished=$false}
  s-false-observed {$s.hresult=1;$s.configurationEstablished=$false}
  preparation-failure-observed {$s.called=$false;$s.hresult=-2147418113;$s.preparationError=5;$s.configurationEstablished=$false;$s.sddl=''}
  too-late-promoted {$s.hresult=-2147417831}
  null-descriptor {$s.nullDescriptor=$true}
  remote-rights {$s.sddl=$s.sddl.Replace('0x3','0x7')}
  extra-LocalService-in-A {$s.sddl+='(A;;0x3;;;LS)';$s.aceCount=4}
  missing-LocalService-in-B {$s.sddl=$s.sddl.Replace('(A;;0x3;;;LS)','');$s.aceCount=3}
  foreign-owner {$s.sddl=$s.sddl.Replace(('O:'+$f.user),'O:SY')}
  foreign-group {$s.sddl=$s.sddl.Replace(('G:'+$s.groupSid),'G:SY')}
  deny-ace {$s.sddl=$s.sddl.Replace('(A;;0x3;;;SY)','(D;;0x3;;;SY)')}
  inherited-ace {$s.sddl=$s.sddl.Replace('(A;;0x3;;;SY)','(A;CI;0x3;;;SY)')}
  wrong-thread {$s.nativeThreadAfter=44}
  twice-called {$s.callCount=2}
  after-first-wait {$s.qpcAfter='103'}
  none-authentication {$s.authenticationLevel=1}
  thread-token-installed {$s.threadTokenInstalled=$true}
  token-dacl-changed {$s.tokenDaclChanged=$true}
  token-close-failed {$s.tokenCloseError=6}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureComSecurityProbe $f.entry $f.host $f.probe $f.id 42 43 1000 $f.mode $f.user $f.logon;$passed=$allow -and $r.caseCount -eq 12 -and -not $r.applicationAccepted;if($name -cin @('too-late-observed','s-false-observed','preparation-failure-observed')){$passed=$passed -and -not $r.configurationEstablished}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
$result=[pscustomobject]@{scope='C-only wait and process-local COM security consumer behavior';passed=(@($checks|Where-Object{-not $_.passed}).Count -eq 0);checks=$checks.Count;results=$checks;nativeExecuted=$false;FReadPerformed=$false;AAExecuted=$false;host=$PSVersionTable.PSVersion.ToString()}
if(Test-Path -LiteralPath $OutputPath){throw 'Retain previous result'};[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$result|Select-Object passed,checks,host|ConvertTo-Json
if(-not $result.passed){exit 1}
