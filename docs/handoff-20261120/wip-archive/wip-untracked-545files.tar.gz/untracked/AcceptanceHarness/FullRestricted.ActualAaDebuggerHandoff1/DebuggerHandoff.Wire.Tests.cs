using System;using System.Text;
namespace Azurite.Restricted.ActualDebugger {
 internal static class WireTests {
  static int total,failed;static readonly string Run="11111111111111111111111111111111";
  static TargetIdentity Target(){return new TargetIdentity(Run,17,123456,33);}
  static void Need(bool v,string why){if(!v)throw new Exception(why);}
  static void Deny(Action f){bool denied=false;try{f();}catch{denied=true;}Need(denied,"invalid record admitted");}
  static void Test(string name,Action body){total++;try{body();Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+" "+e.Message);}}
  public static int Main(){
   string canonical="AZURITE_CDB_STOP_V1 "+Run+" 17 000000000001e240 500\n";
   Test("literal request preserves exact real lifetime and original deadline",()=>{var r=StopWire.ParseRequest(Encoding.ASCII.GetBytes(canonical),Run);Need(r.Target.Pid==17&&r.Target.Created==123456&&r.Expiry==500,"request fields differ");Need(Encoding.ASCII.GetString(StopWire.Request(Target(),500))==canonical,"noncanonical encoding");});
   foreach(string bad in new[]{canonical.Replace(Run,new string('2',32)),canonical.Replace(" 17 "," 0 "),canonical.Replace(" 17 "," 017 "),canonical.Replace("000000000001e240","0000000000000000"),canonical.Replace(" 500"," 0"),canonical+"x",canonical.Replace(" 500"," 500 500"),canonical.Replace("AZURITE_CDB_STOP_V1","AZURITE_CDB_STOP_V2")}){string b=bad;Test("reject malformed request "+b.Trim(),()=>Deny(()=>StopWire.ParseRequest(Encoding.ASCII.GetBytes(b),Run)));}
   Test("positive and retained ack remain distinct",()=>{var r=StopWire.ParseRequest(Encoding.ASCII.GetBytes(canonical),Run);Need(StopWire.ParseAck(StopWire.Ack(r,true),r),"closed gate not accepted");Need(!StopWire.ParseAck(StopWire.Ack(r,false),r),"retained gate promoted");});
   Test("ack cannot cross target lifetime",()=>{var a=StopWire.ParseRequest(Encoding.ASCII.GetBytes(canonical),Run);var b=StopWire.ParseRequest(StopWire.Request(new TargetIdentity(Run,17,123457,33),500),Run);Deny(()=>StopWire.ParseAck(StopWire.Ack(a,true),b));});
   Test("ack cannot refresh or cross deadline",()=>{var a=StopWire.ParseRequest(Encoding.ASCII.GetBytes(canonical),Run);var b=StopWire.ParseRequest(StopWire.Request(Target(),501),Run);Deny(()=>StopWire.ParseAck(StopWire.Ack(a,true),b));});
   Test("ack refuses trailing data",()=>{var r=StopWire.ParseRequest(Encoding.ASCII.GetBytes(canonical),Run);Deny(()=>StopWire.ParseAck(Encoding.ASCII.GetBytes(Encoding.ASCII.GetString(StopWire.Ack(r,true))+"x"),r));});
   Test("actual Resume record preserves previous count and QPC",()=>{long qpc;Need(StopWire.ParseResume(StopWire.Resume(Target(),1,99),Target(),out qpc)==1&&qpc==99,"actual Resume fields lost");Need(StopWire.ParseResume(StopWire.Resume(Target(),UInt32.MaxValue,100),Target(),out qpc)==UInt32.MaxValue,"failed Resume evidence normalized");});
   Test("Resume record cannot cross main thread or process lifetime",()=>{var bytes=StopWire.Resume(Target(),1,99);long q;Deny(()=>StopWire.ParseResume(bytes,new TargetIdentity(Run,17,123457,33),out q));Deny(()=>StopWire.ParseResume(bytes,new TargetIdentity(Run,17,123456,34),out q));});
   Console.WriteLine("{\"total\":"+total+",\"failed\":"+failed+",\"nativeExecuted\":false}");return failed==0?0:1;
  }
 }
}
