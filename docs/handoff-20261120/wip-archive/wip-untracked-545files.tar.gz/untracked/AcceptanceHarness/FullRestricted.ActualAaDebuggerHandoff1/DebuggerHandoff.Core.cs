using System;
using System.Text;
using System.Threading;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Azurite.Restricted.ActualDebugger {
 internal sealed class TargetIdentity {
  internal readonly string Run; internal readonly int Pid, MainTid; internal readonly long Created;
  internal TargetIdentity(string run,int pid,long created,int mainTid){Run=run;Pid=pid;Created=created;MainTid=mainTid;}
 }
 internal sealed class DebuggerObservation {
  internal bool CreationComplete,Created,UncertainCreateOutput,DebuggerSignaled,TargetSignaled,ExitCodeKnown,ExactJobEmpty,HelperSignaled,StdoutEof,StderrEof;internal uint ExitCode;
  internal byte[] Stdout=new byte[0]; internal string Error;
  internal bool Drained {get{return CreationComplete&&!UncertainCreateOutput&&(!Created||DebuggerSignaled)&&ExactJobEmpty&&HelperSignaled&&StdoutEof&&StderrEof;}}
 }
 internal interface IDebuggerOwnerNative {
  void Prepare(TargetIdentity target); void CreateAttach(); void VerifyCreated(); uint ResumeDebugger();
  DebuggerObservation Observe(); void ContinueAfterOriginalResume(); void SetStopDeadline(long expiry); void RequestDetach(); void TerminateOwned(); bool CloseOwners(); void RetainOwners();
 }
 internal sealed class AttachedRecord {
  internal int Pid,EventTid; internal string Run;
 }
 internal sealed class AttachedRecordReader {
  readonly TargetIdentity target;readonly StringBuilder line=new StringBuilder();bool seen;int total;
  internal AttachedRecordReader(TargetIdentity value){target=value;}
  internal AttachedRecord Append(byte[] bytes){
   if(bytes==null||bytes.Length>1048576-total)throw new InvalidOperationException("raw stdout bound");total+=bytes.Length;AttachedRecord result=null;
   foreach(byte b in bytes){
    if(b>127||b==0)throw new InvalidOperationException("non-ASCII raw command channel");
    if(b==10){string text=line.ToString().TrimEnd('\r');line.Length=0;if(!text.StartsWith("AZURITE_CDB_ATTACHED ",StringComparison.Ordinal))continue;
     var m=Regex.Match(text,"\\AAZURITE_CDB_ATTACHED ([a-f0-9]{32}) ([a-f0-9]{8}) ([a-f0-9]{8})\\z",RegexOptions.CultureInvariant);
     if(!m.Success||seen)throw new InvalidOperationException("malformed or repeated attached context");
     uint pid=UInt32.Parse(m.Groups[2].Value,NumberStyles.HexNumber,CultureInfo.InvariantCulture),tid=UInt32.Parse(m.Groups[3].Value,NumberStyles.HexNumber,CultureInfo.InvariantCulture);
     if(m.Groups[1].Value!=target.Run||pid!=target.Pid||tid==0||tid>Int32.MaxValue)throw new InvalidOperationException("foreign debugger target context");
     seen=true;result=new AttachedRecord{Run=target.Run,Pid=(int)pid,EventTid=(int)tid};
    }else{if(line.Length==8192)throw new InvalidOperationException("raw line bound");line.Append((char)b);}
   }return result;
  }
  internal void Finish(){if(line.Length!=0)throw new InvalidOperationException("truncated debugger raw line");}
 }
 internal sealed class OwnedDebuggerSession {
  readonly object sync=new object();readonly TargetIdentity target;readonly IDebuggerOwnerNative native;readonly Func<long> clock;readonly long frequency,admissionExpiry,activeExpiry;
  readonly ManualResetEventSlim readyCompleted=new ManualResetEventSlim(false);readonly AttachedRecordReader reader;
  Thread worker;bool started,ready,stopRequested,stopComplete,cleanupAllowed,retained,deadlineMissed,continueIssued;long stopExpiry;int stopOperations,targetResumes;Exception first;
  internal OwnedDebuggerSession(TargetIdentity value,IDebuggerOwnerNative adapter,Func<long> now,long hz,long expiry,long activeDeadline=0){
   if(value==null||!Regex.IsMatch(value.Run??"","\\A[a-f0-9]{32}\\z")||value.Run==new string('0',32)||value.Pid<=0||value.Created<=0||value.MainTid<=0||adapter==null||now==null||hz<=0||expiry<=now())throw new ArgumentException("bound actual target and original admission clock required");
   activeExpiry=activeDeadline==0?expiry:Math.Min(activeDeadline,expiry);if(activeExpiry<=now())throw new ArgumentException("Original active deadline already exhausted");target=value;native=adapter;clock=now;frequency=hz;admissionExpiry=expiry;stopExpiry=expiry;reader=new AttachedRecordReader(value);
  }
  internal bool Ready {get{lock(sync)return ready&&first==null&&!stopRequested&&!stopComplete&&Remaining(activeExpiry)>0;}} internal bool TargetCleanupAllowed {get{lock(sync)return stopComplete&&cleanupAllowed&&!deadlineMissed;}}
  internal bool StopCompleted{get{lock(sync)return stopComplete;}}
  internal bool OwnerRetained {get{lock(sync)return retained||deadlineMissed;}} internal Exception FirstError {get{return Interlocked.CompareExchange(ref first,null,null);}}
  internal int StopOperations {get{lock(sync)return stopOperations;}} internal int TargetResumeObservations {get{lock(sync)return targetResumes;}}
  internal void RecordFirst(Exception error){if(error!=null){Interlocked.CompareExchange(ref first,error,null);lock(sync){ready=false;Monitor.PulseAll(sync);}readyCompleted.Set();}}
  int Remaining(long expiry){long ticks=expiry-clock();if(ticks<=0)return 0;return (int)Math.Min(Int32.MaxValue,Math.Max(1,(decimal)ticks*1000/frequency));}
  bool Stopping {get{lock(sync)return stopRequested;}}
  internal void Start(){lock(sync){if(started)throw new InvalidOperationException("one debugger owner per run");started=true;worker=new Thread(Work);worker.IsBackground=true;worker.Name="Azurite fixed debugger owner";worker.Start();}}
  internal bool WaitReady(int milliseconds){if(milliseconds<0)throw new ArgumentOutOfRangeException("milliseconds");readyCompleted.Wait(Math.Min(milliseconds,Remaining(activeExpiry)));return Ready;}
  // This records the already-returned original Resume. The controller must check
  // Ready/FirstError BEFORE publishing its lease ACK; rejection here is failure
  // evidence and containment, never a claim that a past Resume was prevented.
  internal void ObserveOriginalTargetResume(uint previous){lock(sync){if(!ready||first!=null||stopRequested||targetResumes!=0||previous!=1||Remaining(activeExpiry)==0){var e=new InvalidOperationException("original target Resume result violates live attached-state sequence");RecordFirst(e);throw e;}targetResumes=1;Monitor.PulseAll(sync);}}
  internal bool StopBeforeTargetCleanup(long originalCleanupExpiry){
   lock(sync){if(!started)throw new InvalidOperationException("owner was not started; null process is not no-debugger proof");if(stopComplete)return cleanupAllowed&&!deadlineMissed;
    stopExpiry=Math.Min(stopExpiry,Math.Min(admissionExpiry,originalCleanupExpiry));stopRequested=true;Monitor.PulseAll(sync);
    while(!stopComplete){int left=Remaining(stopExpiry);if(left==0){deadlineMissed=true;retained=true;RecordFirst(new TimeoutException("original cleanup deadline expired while debugger ownership remains"));Monitor.PulseAll(sync);return false;}Monitor.Wait(sync,Math.Min(left,20));}
    return cleanupAllowed&&!deadlineMissed;
   }
  }
  void Work(){
   try{
    native.Prepare(target);if(!Stopping){native.CreateAttach();if(!Stopping){native.VerifyCreated();if(native.ResumeDebugger()!=1)throw new InvalidOperationException("CDB Resume previous count differs");}}
    while(!Stopping){
     if(Remaining(activeExpiry)==0)throw new TimeoutException("original inner/outer active deadline exhausted");
     bool sendContinue=false;lock(sync){if(targetResumes==1&&!continueIssued&&!stopRequested&&first==null&&ready){continueIssued=true;sendContinue=true;}}if(sendContinue)native.ContinueAfterOriginalResume();
     var observation=native.Observe();if(observation.Error!=null)throw new InvalidOperationException(observation.Error);
     if(observation.DebuggerSignaled){reader.Append(observation.Stdout);bool completed;lock(sync){ready=false;completed=observation.TargetSignaled&&observation.ExitCodeKnown&&observation.ExitCode==0&&targetResumes==1&&continueIssued;}if(completed)break;throw new InvalidOperationException("debugger exited without the separately proved normal target-exit sequence");}
     var record=reader.Append(observation.Stdout);if(record!=null){native.VerifyCreated();lock(sync){if(first!=null||stopRequested||Remaining(activeExpiry)==0)throw new InvalidOperationException("late or failed attached context");ready=true;}readyCompleted.Set();}
     lock(sync){if(!stopRequested)Monitor.Wait(sync,5);}
    }
   }catch(Exception e){RecordFirst(e);}finally{readyCompleted.Set();}
   // The same owner thread performs all native operations. Inner/outer callers only join.
   lock(sync){while(!stopRequested){int left=Remaining(admissionExpiry);if(left==0){stopRequested=true;stopExpiry=admissionExpiry;deadlineMissed=true;break;}Monitor.Wait(sync,Math.Min(left,20));}stopOperations++;}
   bool success=false;
   try{
    bool detach=false,terminated=false;long forceAt;lock(sync)forceAt=clock()+Math.Max(0,(stopExpiry-clock())/2);
    for(;;){
     long expires;lock(sync)expires=stopExpiry;native.SetStopDeadline(expires);
     var observation=native.Observe();reader.Append(observation.Stdout);
     if(observation.Error!=null)throw new InvalidOperationException(observation.Error);
     if(observation.UncertainCreateOutput)throw new InvalidOperationException("FALSE/nonzero native creation outputs remain unproven");
     if(observation.Drained){reader.Finish();if(!native.CloseOwners())throw new InvalidOperationException("debugger owner close unconfirmed");lock(sync){success=!deadlineMissed&&Remaining(stopExpiry)>0;}break;}
     int left;lock(sync)left=Remaining(stopExpiry);if(left==0){lock(sync)deadlineMissed=true;throw new TimeoutException("debugger exit/Job/EOF not confirmed in original cleanup clock");}
     if(observation.Created&&!detach){native.RequestDetach();detach=true;}
     else if(observation.Created&&!terminated&&clock()>=forceAt){RecordFirst(new InvalidOperationException("Fixed detach did not finish; forced owned debugger containment required"));native.TerminateOwned();terminated=true;}
     lock(sync)Monitor.Wait(sync,Math.Min(left,5));
    }
   }catch(Exception e){RecordFirst(e);}
   if(!success){try{native.RetainOwners();}catch(Exception e){RecordFirst(e);}}
   lock(sync){retained=!success;cleanupAllowed=success;stopComplete=true;Monitor.PulseAll(sync);}
  }
 }
}
