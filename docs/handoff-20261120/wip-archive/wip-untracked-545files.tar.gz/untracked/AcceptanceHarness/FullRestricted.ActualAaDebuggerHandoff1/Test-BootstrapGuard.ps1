param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$InputStage,[Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$GuardedStage,[Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Stage)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
function FileHash([string]$Path){$h=[Security.Cryptography.SHA256]::Create();$f=[IO.File]::OpenRead($Path);try{([BitConverter]::ToString($h.ComputeHash($f))).Replace('-','').ToLowerInvariant()}finally{$f.Dispose();$h.Dispose()}}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$base=Join-Path $repo 'artifacts\aa-real-debugger-handoff-20261114\candidate1';$out=Join-Path $base $Stage
if(Test-Path -LiteralPath $out){throw 'Fresh bootstrap guard evidence required'};[void][IO.Directory]::CreateDirectory($out)
$driverPath=$MyInvocation.MyCommand.Path;$driverCopy=Join-Path $out 'Test-BootstrapGuard.executed.ps1';[IO.File]::Copy($driverPath,$driverCopy,$false);$driverHash=FileHash $driverCopy
$scriptPath=Join-Path (Join-Path $base $InputStage) 'FixtureBootstrap.generated.ps1';$proof=Get-Content -LiteralPath (Join-Path (Join-Path $base $InputStage) 'handoff-transform-provenance.json') -Raw|ConvertFrom-Json
$record=@($proof.bootstrapHunks|Where-Object reason -Like 'Final bootstrap Job*');if($record.Count -ne 1){throw 'Exact generated guard not found'};$guard=[string]$record[0].after
$actual=[IO.File]::ReadAllText($scriptPath);if(([regex]::Matches($actual,[regex]::Escape($guard))).Count -ne 1){throw 'Guard differs from generated script'}
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($scriptPath,[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Generated bootstrap parse failed'}
$f=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Invoke-FixtureHeldBoundary'},$false));if($f.Count -ne 1){throw 'Actual reused held boundary missing'};. ([scriptblock]::Create($f[0].Extent.Text))
$exe=Join-Path (Join-Path $base $GuardedStage) 'Handoff.Integration.Pure.exe';$null=[Reflection.Assembly]::Load([IO.File]::ReadAllBytes($exe))
$sleep='[Threading.Thread]::Sleep([Threading.Timeout]::Infinite)';if(([regex]::Matches($guard,[regex]::Escape($sleep))).Count -ne 1){throw 'One exact held callback required'};$guard=$guard.Replace($sleep,'$script:holdCalls++')
$checks=@();foreach($case in @('confirmed-no-offer','unknown-context','decision-throws','evidence-throws')){
 $script:terminateCalls=0;$script:holdCalls=0;$errorText=$null
 if($case -ceq 'confirmed-no-offer'){[Azurite.Restricted.HandoffIntegrationTests]::InstallNoOfferForBootstrapScript()}else{[Azurite.Restricted.HandoffIntegrationTests]::InstallUnknownForBootstrapScript()}
 $job=New-Object PSObject;$job|Add-Member ScriptMethod TerminateFull {param($code)$script:terminateCalls++}
 $c=[pscustomobject]@{runId='11111111111111111111111111111111'};$exit=0;$body=$guard
 if($case -in @('decision-throws','evidence-throws')){
  $a=[Management.Automation.Language.Parser]::ParseInput($body,[ref]$tokens,[ref]$errors);$command=@($a.FindAll({param($n)$n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -ceq 'Invoke-FixtureHeldBoundary'},$false))[0];$parameter=if($case -ceq 'decision-throws'){'NeedHold'}else{'Sink'}
  for($i=0;$i -lt $command.CommandElements.Count-1;$i++){if($command.CommandElements[$i] -is [Management.Automation.Language.CommandParameterAst] -and $command.CommandElements[$i].ParameterName -ceq $parameter){$old=$command.CommandElements[$i+1].Extent.Text;$body=$body.Replace($old,"{throw 'SOURCE injected boundary dependency failure'}");break}}
 }
 try{& ([scriptblock]::Create($body))}catch{$errorText=$_.Exception.Message}
 $pass=if($case -ceq 'confirmed-no-offer'){$script:terminateCalls -eq 1 -and $script:holdCalls -eq 0 -and $null -eq $errorText}else{$script:terminateCalls -eq 0 -and $script:holdCalls -eq 1 -and $null -ne $errorText}
 $checks+=,[pscustomobject]@{case=$case;passed=$pass;terminateCalls=$script:terminateCalls;holdCalls=$script:holdCalls;error=$errorText}
}
$failed=@($checks|Where-Object {-not $_.passed}).Count;$result=[pscustomobject]@{sourceOnly=$true;nativeExecuted=$false;AAExecuted=$false;FReadPerformed=$false;checks=$checks;failed=$failed;scriptSha256=(FileHash $scriptPath);driverPath=$driverPath;driverSourceCopy=$driverCopy;driverSha256=$driverHash;guardedAssemblySha256=(FileHash $exe);host=$PSVersionTable.PSVersion.ToString();guardedBoundaryOnly=$true;fullBootstrapNotInvoked=$true}
$hashFunction=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Get-HandoffFileHash'},$false))
if($hashFunction.Count -eq 1){. ([scriptblock]::Create($hashFunction[0].Extent.Text));$sample=Join-Path $out 'hash-input.bin';[IO.File]::WriteAllBytes($sample,[Text.Encoding]::ASCII.GetBytes('abc'));$hash=Get-HandoffFileHash $sample;$pass=$hash -ceq 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad';$checks+=,[pscustomobject]@{case='actual private raw-byte SHA256 in PS5.1';passed=$pass;hash=$hash};[IO.File]::WriteAllBytes($sample,[Text.Encoding]::ASCII.GetBytes('abd'));$changed=Get-HandoffFileHash $sample;$checks+=,[pscustomobject]@{case='changed input cannot retain accepted digest';passed=($changed -cne $hash);hash=$changed};$result.checks=$checks;$failed=@($checks|Where-Object {-not $_.passed}).Count;$result.failed=$failed}
[IO.File]::WriteAllText((Join-Path $out 'result.json'),($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$result|ConvertTo-Json -Depth 6
if($failed){exit 1}
