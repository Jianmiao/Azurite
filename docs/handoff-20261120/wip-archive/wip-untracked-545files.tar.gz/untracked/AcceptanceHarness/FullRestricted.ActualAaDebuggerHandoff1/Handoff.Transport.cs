using System;using System.Collections.Generic;using System.ComponentModel;using System.Diagnostics;using System.IO;using System.Threading;using Azurite.Restricted.ActualDebugger;
namespace Azurite.Restricted {
 internal interface IHandoffRecords {bool Exists(string name);byte[] Read(string name);void Create(string name,byte[] bytes);long Now{get;}void Pause();}
 internal static class HandoffRecordRead {internal static bool Try(IHandoffRecords records,string name,out byte[] bytes){bytes=null;try{if(!records.Exists(name))return false;bytes=records.Read(name);return true;}catch(Win32Exception e){if(e.NativeErrorCode==2||e.NativeErrorCode==32)return false;throw;}}}
 internal sealed class ProtectedHandoffRecords:IHandoffRecords {
  readonly string root,sddl;
  internal ProtectedHandoffRecords(string run,string owner,string logon){FullRestrictedContract.Require(System.Text.RegularExpressions.Regex.IsMatch(run??"","\\A[a-f0-9]{32}\\z"),"Exact handoff run");root=FullRestrictedContract.Lab+@"\runs\restricted-"+run+@"\control\";sddl=LeaseAcl.File(owner,logon);}
  string PathFor(string name){if(name!="debug-stop.request"&&name!="debug-stop.ack"&&name!="original-resume.record")throw new InvalidOperationException("Fixed handoff record name only");return root+name;}
  public bool Exists(string name){return File.Exists(PathFor(name));}public byte[] Read(string name){return LeaseFiles.Read(PathFor(name));}public void Create(string name,byte[] bytes){LeaseFiles.Create(PathFor(name),bytes,sddl);}public long Now{get{return Stopwatch.GetTimestamp();}}public void Pause(){Thread.Sleep(1);}
 }
 internal sealed class BootstrapStopClient {
  readonly string run;readonly IHandoffRecords records;TargetIdentity target;StopRequest requested;bool offerAttempted,resumeRecorded,retained;Exception first;
  internal BootstrapStopClient(string id,IHandoffRecords store){run=id;records=store;}
  internal bool Retained{get{return retained;}}internal Exception Error{get{return first;}}
  internal void BeforeOffer(TargetIdentity value){if(offerAttempted||value==null||value.Run!=run)throw new InvalidOperationException("One exact offer context");target=value;offerAttempted=true;}
  internal void ResumeReturned(uint previous){if(!offerAttempted||resumeRecorded)throw new InvalidOperationException("Observed Resume requires unique accepted offer");resumeRecorded=true;records.Create("original-resume.record",StopWire.Resume(target,previous,records.Now));}
  internal bool Stop(long originalExpiry){
   if(retained)return false;
   // Before any offer attempt, the fixed controller has no route to commit a CDB create.
   if(!offerAttempted)return true;
   try{
    if(requested==null){byte[] bytes=StopWire.Request(target,originalExpiry);requested=StopWire.ParseRequest(bytes,run);records.Create("debug-stop.request",bytes);}
    long expiry=Math.Min(originalExpiry,requested.Expiry);
    for(;;){byte[] ack;if(HandoffRecordRead.Try(records,"debug-stop.ack",out ack)){bool closed=StopWire.ParseAck(ack,requested);if(!closed)throw new InvalidOperationException("Controller retained debugger owner");if(records.Now>expiry)throw new TimeoutException("Stop acknowledgement after original cleanup deadline");return true;}if(records.Now>=expiry)throw new TimeoutException("Controller stop acknowledgement missing at original cleanup deadline");records.Pause();}
   }catch(Exception e){if(first==null)first=e;retained=true;return false;}
  }
 }
 public static class ActualAaBootstrapHandoff {
  static readonly object gate=new object();static string run;static BootstrapStopClient client;static readonly List<object> retained=new List<object>();static bool blocked;
  internal static void Configure(string id,string owner,string logon){lock(gate){if(client!=null)throw new InvalidOperationException("One bootstrap handoff per fresh host");run=id;client=new BootstrapStopClient(id,new ProtectedHandoffRecords(id,owner,logon));}}
  internal static void BeforeOffer(LeaseOffer offer){lock(gate){if(client==null||run!=offer.Run)throw new InvalidOperationException("Unconfigured bootstrap handoff");client.BeforeOffer(new TargetIdentity(offer.Run,offer.ChildPid,offer.ChildCreated,offer.MainTid));}}
  internal static void ResumeReturned(uint previous){lock(gate){if(client==null)throw new InvalidOperationException("Unconfigured Resume record");try{client.ResumeReturned(previous);}catch{blocked=true;throw;}}}
  internal static long CleanupExpiry(Stopwatch original){long now=Stopwatch.GetTimestamp();long elapsed=original.ElapsedTicks;return checked(now+Math.Max(0,checked(5*Stopwatch.Frequency)-elapsed));}
  internal static bool BeforeInnerCleanup(string id,object actualOwner,Stopwatch original){lock(gate){try{if(client==null||run!=id||blocked||!client.Stop(CleanupExpiry(original))){blocked=true;retained.Add(actualOwner);return false;}return true;}catch{blocked=true;retained.Add(actualOwner);return false;}}}
  internal static bool RetainInsteadOfClose(string id,object actualOwner){lock(gate){if(client==null||run!=id||blocked||client.Retained){blocked=true;retained.Add(actualOwner);return true;}return false;}}
  internal static void RetainSupporting(params object[] values){lock(gate){blocked=true;retained.AddRange(values);}}
  public static bool MustHoldHost(string id){lock(gate)return client==null||run!=id||blocked||client.Retained;}
  public static object Snapshot(){lock(gate)return new{runId=run,holdHost=client==null||blocked||client.Retained,retainedCount=retained.Count,error=client==null?"unconfigured":client.Error==null?null:client.Error.ToString(),applicationAccepted=false};}
 }
}
