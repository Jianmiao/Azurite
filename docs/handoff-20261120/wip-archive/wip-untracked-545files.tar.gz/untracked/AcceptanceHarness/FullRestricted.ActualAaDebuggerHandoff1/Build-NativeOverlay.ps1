param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Stage,[switch]$IncludeHandoff)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$out=Join-Path $repo ('artifacts\aa-real-debugger-handoff-20261114\candidate1\'+$Stage)
if(Test-Path -LiteralPath $out){throw 'Fresh immutable overlay stage required'};[void][IO.Directory]::CreateDirectory($out)
$script:changes=[Collections.Generic.List[object]]::new()
function HashText([string]$s){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash([Text.UTF8Encoding]::new($false).GetBytes($s)))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function Change([string]$s,[string]$old,[string]$new,[string]$why){if(([regex]::Matches($s,[regex]::Escape($old))).Count -ne 1){throw ('Unique source transform failed: '+$why)};$script:changes.Add([pscustomobject]@{reason=$why;before=$old;after=$new});return $s.Replace($old,$new)}
function Save([string]$name,[string]$text){[IO.File]::WriteAllText((Join-Path $out $name),$text,[Text.UTF8Encoding]::new($false))}
$baseline=Join-Path $repo 'artifacts\aa-cdb-toolcheck-20261113\build8\source';$nativePath=Join-Path $baseline 'CdbToolcheck.Native.cs'
if((Get-FileHash -LiteralPath $nativePath).Hash.ToLowerInvariant() -cne '91b4c46a4e13e25f6a5eb0dfe8f2c05190131e7c51645e8a51ed5bdf936193c0'){throw 'Frozen build8 native source changed'}
$old=[IO.File]::ReadAllText($nativePath).Replace("`r`n","`n");$s=$old
$start=$s.IndexOf('    // Only this parameterless, fixed-version entry');$end=$s.IndexOf('    internal sealed class CdbNativeRun');if($start -lt 0 -or $end -le $start){throw 'Fixed entry block not found'}
$s=Change $s ($s.Substring($start,$end-$start)) '' 'Remove public fixed-version executable entry; only leased candidate adapter may call owner'
$s=Change $s 'internal sealed class CdbNativeRun : ICdbToolcheckLifecycle' 'internal sealed partial class CdbNativeRun : ICdbToolcheckLifecycle' 'Private adapter shares retained native owner fields'
$start=$s.IndexOf('            Require(IntPtr.Size == 8, "Only the reviewed x64 host is permitted");');$end=$s.IndexOf('            Require(ObjectName(GetProcessWindowStation())', $start);if($start -lt 0 -or $end -le $start){throw 'File preparation block missing'}
$script:filePreparation=$s.Substring($start,$end-$start)
$s=Change $s $script:filePreparation ('            Require(filesPrepared, "Fixed files must be prepared before target spawn");'+[char]10) 'Split existing fixed file preparation before target spawn without resetting clock'
$start=$s.IndexOf('            byte[] descriptor;');$end=$s.IndexOf('            FullDesktopMonitor.ValidateIdentity', $start);if($start -lt 0 -or $end -le $start){throw 'Desktop creation block missing'}
$s=Change $s ($s.Substring($start,$end-$start)) "            AdoptHeldTargetDesktop();`n" 'Adopt duplicate of held target desktop, never create same-named desktop'
$s=Change $s 'new StringBuilder("\"" + CdbToolcheckPolicy.Executable + "\" -version")' 'new StringBuilder(FixedAttachCommand())' 'Fixed leased target attach command, no arbitrary PID/text'
$s=Change $s 'foreach (FullOwnedHandle h in new[] { stdinRead, stdoutWrite, stderrWrite, stdinWrite }) Require(h.Close(), "Close local child endpoint or stdin EOF failed: " + h.Role);' 'foreach (FullOwnedHandle h in new[] { stdinRead, stdoutWrite, stderrWrite }) Require(h.Close(), "Close local child endpoint failed: " + h.Role);' 'Retain only CDB stdin writer for fixed commands'
$s=Change $s 'facts["stdinEofBeforeResume"] = true;' 'facts["stdinEofBeforeResume"] = false; facts["fixedCommandWriterRetained"] = true;' 'Record distinct CDB command pipe policy'
$s=Change $s 'Require(CdbToolcheckPolicy.Remaining(runtime.ElapsedMilliseconds, CdbToolcheckPolicy.RuntimeMilliseconds) > 0, "Runtime deadline before create");' 'Require(RemainingAdmission() > 0, "Original admission deadline before CDB create");' 'No new spawn-time budget'
$s=Change $s 'Require(CdbToolcheckPolicy.Remaining(runtime.ElapsedMilliseconds, CdbToolcheckPolicy.RuntimeMilliseconds) > 0, "Runtime deadline before resume");' 'Require(RemainingAdmission() > 0, "Original admission deadline before CDB resume");' 'CDB resume shares original admission clock'
$s=Change $s 'int keep = budget.Accept(checked((int)read)); if (keep > 0) output.Stream.Write(bytes, 0, keep);' 'int keep = budget.Accept(checked((int)read)); if (keep > 0) { output.Stream.Write(bytes, 0, keep); CaptureRawForProtocol(output, bytes, keep); }' 'Parse the actual newly drained bytes while preserving original raw files and shared bound'
$s=Change $s 'void RequireCleanupTime() { Require(CdbToolcheckPolicy.Remaining(cleanup.ElapsedMilliseconds, CdbToolcheckPolicy.CleanupMilliseconds) > 0, "Owned drain and close exceeded the shared 5000 ms cleanup deadline"); }' 'void RequireCleanupTime() { Require(RemainingStop() > 0, "Owned drain and close exceeded the original shared cleanup deadline"); }' 'Close consumes original caller cleanup deadline'
$s=Change $s 'facts["fixedArgument"] = "-version";' 'facts["fixedArgument"] = "fixed leased-target suspended attach";' 'Evidence identifies actual candidate profile rather than old version command'
$s=Change $s 'Console.Out.WriteLine(json); Console.Out.Flush();' '// The held caller reports the fixed C evidence path; raw evidence remains in this owned result file.' 'Do not duplicate bounded raw streams into controller stdout'
$reverse=$s;for($i=$script:changes.Count-1;$i -ge 0;$i--){$r=$script:changes[$i];if($r.after.Length -gt 0){$reverse=$reverse.Replace($r.after,$r.before)}else{$at=$reverse.IndexOf('    internal sealed class CdbNativeRun');$reverse=$reverse.Insert($at,$r.before)}}
if($reverse -cne $old){throw 'Native source inverse transformation mismatch'}
Save 'CdbAttach.Native.generated.cs' $s
Save 'CdbAttach.FilePreparation.generated.cs' ('using System;using System.IO;using System.Security.AccessControl;using System.Security.Principal;'+[char]10+'namespace Azurite.Restricted { internal sealed partial class CdbNativeRun {internal void PrepareBeforeTarget(){Require(!filesPrepared,"Repeated fixed-file preparation");Require(RemainingAdmission()>0,"Original admission budget before pins");'+[char]10+$script:filePreparation+'PrepareFixedScript();filesPrepared=true;} } }'+[char]10)
$policy=[IO.File]::ReadAllText((Join-Path $baseline 'CdbToolcheck.Policy.cs')).Replace('Root + @"\artifacts\aa-cdb-toolcheck-20261113"','Root + @"\artifacts\aa-real-debugger-handoff-20261114\candidate1\native-evidence"');Save 'CdbToolcheck.Policy.cs' $policy
foreach($name in @('CdbToolcheck.JobEvidence.cs','CdbToolcheck.ConsoleHostPolicy.cs')){[IO.File]::Copy((Join-Path $baseline $name),(Join-Path $out $name),$false)}
foreach($name in @('RestrictedCliFullRestricted.cs','RestrictedCliNative.cs')){[IO.File]::Copy((Join-Path $repo ('tools\headless\'+$name)),(Join-Path $out $name),$false)}
$leaseRoot=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\build-cdb-owned-wait2-9974-cons1\source'
foreach($name in @('CdbLeaseNative.cs','CdbGateProtocol.cs','FullRestrictedStageFileSecurity.cs')){[IO.File]::Copy((Join-Path $leaseRoot $name),(Join-Path $out $name),$false)}
$lease=[IO.File]::ReadAllText((Join-Path $leaseRoot 'CdbTargetLease.cs'))
$anchor='  bool ProcessDrained(FullOwnedHandle owner,int pid,long created,uint rights,bool observeTarget) {'
$addition='  internal LeaseOffer BorrowDebuggerOffer(){Revalidate();return accepted;}'+[char]10+'  internal IntPtr BorrowDebuggerDesktop(){Revalidate();return desktop.Value;}'+[char]10+'  internal bool DebuggerTargetExited(){Require(Ready&&accepted!=null&&process!=null,"Confirmed target lease required");return ProcessDrained(process,accepted.ChildPid,accepted.ChildCreated,ProcessRights,true);}'+[char]10
if(([regex]::Matches($lease,[regex]::Escape($anchor))).Count -ne 1){throw 'Lease export anchor drift'};Save 'CdbTargetLease.cs' ($lease.Replace($anchor,$addition+$anchor))
foreach($name in @('DebuggerHandoff.Core.cs','CdbAttach.Adapter.cs','CdbAttach.Accounting.cs')){[IO.File]::Copy((Join-Path $PSScriptRoot $name),(Join-Path $out $name),$false)}
if($IncludeHandoff){. (Join-Path $PSScriptRoot 'Add-HandoffOverlay.ps1');Add-ActualHandoffOverlay $repo $out $PSScriptRoot}
$proof=@{sourceOnly=$true;nativeExecuted=$false;productionEdited=$false;nativeBaseline=$nativePath;nativeBaselineSha256=(Get-FileHash -LiteralPath $nativePath).Hash.ToLowerInvariant();nativeInverseNormalizedEqual=$true;nativeChanges=$script:changes;leaseAccessorOnly=$addition;files=@(Get-ChildItem -LiteralPath $out -File|ForEach-Object{@{name=$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant();bytes=$_.Length}})}
Save 'overlay-provenance.json' ($proof|ConvertTo-Json -Depth 8)
Import-Module (Join-Path $repo 'AcceptanceHarness\FullRestricted.CdbOwnedWaitFixture\SourceProcess.psm1') -Force
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe';$argsList=@('/nologo','/target:library','/platform:x64','/warn:4','/warnaserror+','/r:System.Web.Extensions.dll','/r:System.Runtime.Serialization.dll','/r:System.Xml.dll',('/out:'+(Join-Path $out 'ActualDebugger.SourceOnly.dll')))+@(Get-ChildItem -LiteralPath $out -Filter '*.cs' -File|Select-Object -ExpandProperty FullName)
$result=Invoke-FixtureSourceProcess -File $csc -Arguments $argsList -Directory $out -Record (Join-Path $out 'compile-process.json') -BoundMs 60000
if($result.exitCode -ne 0){throw ($result.stdout+$result.stderr)}
Get-FileHash -LiteralPath (Join-Path $out 'ActualDebugger.SourceOnly.dll')
