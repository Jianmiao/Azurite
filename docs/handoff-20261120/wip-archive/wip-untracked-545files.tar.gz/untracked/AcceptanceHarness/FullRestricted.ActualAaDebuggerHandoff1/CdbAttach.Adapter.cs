using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Azurite.Restricted.ActualDebugger;
namespace Azurite.Restricted {
 // Private adaptation of the fixed build8 owner, never an arbitrary PID entry.
 internal sealed partial class CdbNativeRun : IDebuggerOwnerNative {
  CdbTargetLease targetLease;LeaseOffer targetOffer;readonly long originalExpiry,originalFrequency;
  readonly List<byte> protocolBytes=new List<byte>();long stopLimit,activeLimit,cdbSignalQpc;string fixedScript,emptySymbols;bool detachWritten,terminationIssued,filesPrepared;
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr source,IntPtr targetProcess,out IntPtr target,uint access,bool inherit,uint options);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool WriteFile(IntPtr h,byte[] data,uint length,out uint written,IntPtr overlapped);
  internal CdbNativeRun(string run,long expiry,long frequency):this(run){
   originalExpiry=expiry;originalFrequency=frequency;stopLimit=expiry;activeLimit=checked(expiry-5*frequency);
   Require(frequency==Stopwatch.Frequency&&expiry>Stopwatch.GetTimestamp(),"Original bounded controller clock required");
  }
  internal void AttachVerifiedLease(CdbTargetLease lease){Require(targetLease==null&&lease!=null&&filesPrepared,"One verified lease after fixed preparation");var offer=lease.BorrowDebuggerOffer();Require(offer.Run==RunId&&offer.Frequency==originalFrequency,"Foreign target lease/clock");activeLimit=Math.Min(activeLimit,offer.NativeDeadline);Require(RemainingAdmission()>0,"Original inner active deadline before attach");targetOffer=offer;targetLease=lease;facts["originalInnerActiveDeadlineQpc"]=offer.NativeDeadline;facts["effectiveActiveDeadlineQpc"]=activeLimit;facts["originalOuterDeadlineQpc"]=originalExpiry;}
  internal bool ClosePreparedWithoutCreate(long expiry){Require(!createAttempted&&process==null&&job==null&&desktop==null,"Creation must never have started for preparation-only proof");stopLimit=Math.Min(originalExpiry,expiry);foreach(var file in files){RequireCleanupTime();file.Close();}return files.All(x=>x.Closed);}
  internal string SaveHandoffEvidence(CdbToolcheckOutcome outcome,object stages){facts["scope"]="actual-aa-debugger-no-trace-handoff";facts["applicationAccepted"]=false;facts["nativeQualificationRequiresIndependentReview"]=true;facts["controllerStages"]=stages;WriteResult(outcome);return RunDirectory+@"\result.json";}
  int Remaining(long end){long left=end-Stopwatch.GetTimestamp();return left<=0?0:(int)Math.Min(Int32.MaxValue,(decimal)left*1000/originalFrequency);}
  int RemainingAdmission(){return Remaining(activeLimit);}int RemainingStop(){return Remaining(stopLimit);}
  void AdoptHeldTargetDesktop(){
   targetLease.Revalidate();IntPtr value;bool okay=DuplicateHandle(GetCurrentProcess(),targetLease.BorrowDebuggerDesktop(),GetCurrentProcess(),out value,CdbTargetLease.DesktopRights,false,0);int error=okay?0:Marshal.GetLastWin32Error();
   creationOutputs.Add(new CdbCreateOutput(okay,value,IntPtr.Zero,0,0));if(okay)desktop=Own("cdb-target-desktop-duplicate",value,true);
   if(!okay)throw new Win32Exception(error,"Duplicate actual held target desktop");Require(desktop!=null,"TRUE desktop duplicate without handle");
   facts["targetPid"]=targetOffer.ChildPid;facts["targetCreation"]=targetOffer.ChildCreated;facts["borrowedActualDesktop"]=true;
  }
  string FixedAttachCommand(){
   targetLease.Revalidate();Require(fixedScript!=null&&emptySymbols!=null&&targetOffer.ChildPid>0,"Pinned command preparation required");
   return "\""+CdbToolcheckPolicy.Executable+"\" -p "+targetOffer.ChildPid+" -pb -pd -G -noshell -noinh -sins -netsyms no -y \""+emptySymbols+"\" -cf \""+fixedScript+"\"";
  }
  void CaptureRawForProtocol(ManagedFile output,byte[] data,int count){if(Object.ReferenceEquals(output,stdoutFile)){Require(protocolBytes.Count+count<=CdbToolcheckPolicy.RawByteLimit,"Protocol raw buffer bound");for(int i=0;i<count;i++)protocolBytes.Add(data[i]);}}
  void IDebuggerOwnerNative.Prepare(TargetIdentity target){
   targetLease.Revalidate();Require(target.Run==targetOffer.Run&&target.Pid==targetOffer.ChildPid&&target.Created==targetOffer.ChildCreated&&target.MainTid==targetOffer.MainTid,"Only the actual retained lease supplies arguments");
   Require(RemainingAdmission()>0,"Original preparation budget exhausted");Prepare();
  }
  void PrepareFixedScript(){
   fixedScript=RunDirectory+@"\attach-ready.cmd";emptySymbols=RunDirectory+@"\empty-symbols";Directory.CreateDirectory(emptySymbols);
   byte[] script=Encoding.ASCII.GetBytes(".printf \"AZURITE_CDB_ATTACHED "+RunId+" %08x %08x\\n\", @$tpid, @$tid\n");
   var writer=FileOwner("fixed-ready-script-writer",fixedScript,FileMode.CreateNew);writer.Stream.Write(script,0,script.Length);writer.Stream.Flush(true);writer.Close();Require(writer.Closed,"Fixed script writer close failed");
   var pin=FileOwner("fixed-ready-script-pin",fixedScript,FileMode.Open);facts["fixedScriptSha256"]=Hash(pin.Stream);facts["fixedAttachOptions"]="-p <held PID> -pb -pd -G -noshell -noinh -sins -netsyms no -y <empty> -cf <fixed>";
   facts["initialBreakpointClaimed"]=false;facts["preResumeAttachedContextNativeQualificationPending"]=true;
  }
  void IDebuggerOwnerNative.CreateAttach(){Require(RemainingAdmission()>0,"Original create deadline");CreateSuspended();}
  void IDebuggerOwnerNative.VerifyCreated(){
   Require(RemainingAdmission()>0,"Original active deadline before identity confirmation");targetLease.Revalidate();if(resumeCalls==0){VerifySuspendedIdentity();return;}
   Require(process!=null&&thread!=null&&!Signaled(process.Value)&&GetProcessId(process.Value)==pid&&GetThreadId(thread.Value)==tid&&GetProcessIdOfThread(thread.Value)==pid,"Held debugger identity after context drift");
   FileTime c,e,k,u;Win(GetProcessTimes(process.Value,out c,out e,out k,out u),"Recheck retained debugger creation");Require((((ulong)c.High<<32)|c.Low)==creationTime,"Debugger PID lifetime changed");
   bool inside;Win(IsProcessInJob(process.Value,job.Value,out inside),"Debugger exact Job at context");Require(inside&&consoleAllowance.Allows(JobMembers(),pid),"Debugger Job changed at context");
  }
  uint IDebuggerOwnerNative.ResumeDebugger(){CloseChildPipeCopies();return ResumeOnce();}
  DebuggerObservation IDebuggerOwnerNative.Observe(){
   CdbJobAccountingSnapshot accounting=null;
   if(job!=null){
    var snapshot=JobObservation("attach-owner-observe");int[] ids=snapshot.ParsedIds;
    if(creationSucceeded&&assigned){try{uint candidate=consoleAllowance.SelectNewCandidate(ids,pid);if(candidate!=0){AdmitConsoleHost(candidate,snapshot);snapshot=JobObservation("attach-post-helper-admission");ids=snapshot.ParsedIds;}Require(consoleAllowance.Allows(ids,pid),"Unowned debugger Job member");}catch(Exception rejection){throw CdbJobSnapshot.AfterRecording(rejection,delegate{RecordFirstJobFailure(snapshot,rejection.Message);},RecordJobEvidenceFailure);}}
    if(desktop!=null){CheckWindows(ids.Concat(new[]{targetOffer.BootstrapPid,targetOffer.ChildPid}).Distinct().ToArray());RequireNonInputDesktop();}
    accounting=ReadJobAccounting("attach-owner-observe");CdbConsoleHostPolicy.VerifyRunAccounting(accounting);jobDrained=accounting.ReadActiveCount()==0&&ids.Length==0;
   }else jobDrained=true;
   directExited=process==null?(!createAttempted||(createReturned&&!creationSucceeded)):Signaled(process.Value);consoleHostSignaled=ConsoleHostExited();Drain();Require(!budget.Overflow,"Combined raw output bound exceeded");
   if(directExited&&creationSucceeded)Win(GetExitCodeProcess(process.Value,out exitCode),"Debugger actual exit code");
   if(directExited&&creationSucceeded&&cdbSignalQpc==0)cdbSignalQpc=Stopwatch.GetTimestamp();bool targetSignaled=targetLease.DebuggerTargetExited();facts["targetSignalObserved"]=targetSignaled;facts["targetSignalFirstQpc"]=targetLease.TargetSignalObservedQpc;facts["debuggerSignalFirstQpc"]=cdbSignalQpc;facts["debuggerExitCodeKnown"]=directExited&&creationSucceeded;facts["debuggerExitCode"]=exitCode;
   if(job!=null&&directExited&&jobDrained&&streamsComplete&&consoleHostSignaled){facts["jobAccountingFinalCandidate"]=accounting;try{CdbAttachFinalEvidence.Verify(accounting,assigned,consoleAllowance.SlotClaimed);}catch(Exception e){facts["jobAccountingRejected"]=accounting;facts["jobAccountingPolicyError"]=e.ToString();throw;}}
   byte[] raw=protocolBytes.ToArray();protocolBytes.Clear();return new DebuggerObservation{CreationComplete=!createAttempted||createReturned,Created=creationSucceeded,UncertainCreateOutput=creationOutputs.Any(x=>x.RequiresOwnerRetention),DebuggerSignaled=directExited,TargetSignaled=targetSignaled,ExitCodeKnown=directExited&&creationSucceeded,ExitCode=exitCode,ExactJobEmpty=jobDrained,HelperSignaled=consoleHostSignaled,StdoutEof=stdoutRead==null||stdoutEof,StderrEof=stderrRead==null||stderrEof,Stdout=raw,Error=null};
  }
  void FixedWrite(string value){Require(stdinWrite!=null&&!stdinWrite.Closed,"Owned CDB command pipe required");byte[] bytes=Encoding.ASCII.GetBytes(value);uint written;Win(WriteFile(stdinWrite.Value,bytes,(uint)bytes.Length,out written,IntPtr.Zero),"Write fixed debugger command");Require(written==bytes.Length,"Partial fixed debugger command write");}
  void IDebuggerOwnerNative.ContinueAfterOriginalResume(){Require(RemainingAdmission()>0,"Original active deadline before fixed continue");FixedWrite("g\n");facts["fixedContinueCommandSent"]=true;facts["continueSuccessClaimed"]=false;}
  void IDebuggerOwnerNative.SetStopDeadline(long expiry){stopLimit=Math.Min(stopLimit,Math.Min(expiry,originalExpiry));foreach(var h in new[]{stdinRead,stdoutWrite,stderrWrite})if(h!=null&&!h.CloseAttempted)Require(h.Close(),"Stop could not close local child pipe copy");if(!creationSucceeded||(process!=null&&Signaled(process.Value))){if(stdinWrite!=null&&!stdinWrite.CloseAttempted)Require(stdinWrite.Close(),"CDB command writer close failed");}}
  void IDebuggerOwnerNative.RequestDetach(){Require(!detachWritten,"Repeated detach forbidden");detachWritten=true;FixedWrite(".detach /n; qd\n");facts["fixedDetachRequested"]=true;facts["pendingExceptionHandledClaimed"]=false;}
  void IDebuggerOwnerNative.TerminateOwned(){Require(!terminationIssued,"Repeated forced stop forbidden");terminationIssued=true;if(job!=null){bool ok=TerminateJobObject(job.Value,125);int error=ok?0:Marshal.GetLastWin32Error();facts["terminateCdbJob"]=new{returned=ok,error=error};}if(process!=null&&!Signaled(process.Value)){bool ok=TerminateProcess(process.Value,125);int error=ok?0:Marshal.GetLastWin32Error();facts["terminateHeldCdb"]=new{returned=ok,error=error};}}
  bool IDebuggerOwnerNative.CloseOwners(){return CloseOwned();}
  void IDebuggerOwnerNative.RetainOwners(){RetainOwner();}
 }
}
