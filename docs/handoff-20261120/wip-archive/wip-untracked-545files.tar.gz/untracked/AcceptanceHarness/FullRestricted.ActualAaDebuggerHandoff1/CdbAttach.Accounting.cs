namespace Azurite.Restricted {
 internal static class CdbAttachFinalEvidence {
  internal static void Verify(CdbJobAccountingSnapshot accounting,bool assigned,bool helperSlotClaimed){
   CdbConsoleHostPolicy.VerifyRunAccounting(accounting);
   CdbToolcheckPolicy.Require(accounting.Active==0,"Final debugger Job still active");
   if(assigned)CdbConsoleHostPolicy.VerifyFinalAccounting(accounting,helperSlotClaimed);
   else CdbToolcheckPolicy.Require(!helperSlotClaimed&&accounting.Total==0,"Unassigned/no-create debugger Job has unproved cumulative member");
  }
 }
}
