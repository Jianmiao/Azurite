param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$InputStage,[Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Stage,[switch]$ExpectRed)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$base=Join-Path $repo 'artifacts\aa-real-debugger-handoff-20261114\candidate1';$inputDir=Join-Path $base $InputStage;$out=Join-Path $base $Stage
if(Test-Path -LiteralPath $out){throw 'Preserve prior SOURCE evidence'};[void][IO.Directory]::CreateDirectory($out)
$paths=@(Get-ChildItem -LiteralPath $inputDir -Filter '*.cs' -File|Select-Object -ExpandProperty FullName)+@((Join-Path $PSScriptRoot 'DebuggerHandoff.Tests.cs'),(Join-Path $PSScriptRoot 'Handoff.Integration.Tests.cs'),(Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\build-cdb-owned-wait2-9974-cons1\source\CdbOwnedWait.Tests.cs'))
$sources=@();$proof=@();foreach($p in $paths){$old=[IO.File]::ReadAllText($p);$text=[regex]::Replace($old,'(\[DllImport\s*\(\s*)"[^"]+"','$1"Azurite.SourceOnly.Forbidden.Native.dll"');$nativeCount=([regex]::Matches($old,'\[DllImport')).Count
 if((Split-Path -Leaf $p) -ceq 'RestrictedCliFullRestricted.cs'){
  $replacements=@(@('FullRestrictedContract.ValidateBootstrap(info,runId,reviewedControlSha256);','HandoffSourceAudit.ValidateNoIo();'),@('process.Start()','HandoffSourceAudit.FailStart()'),@('int[] members=job.ProcessIds();bool noDescendants','int[] members=HandoffSourceAudit.BootstrapOnly();bool noDescendants'),@('protocolStopped=true;if(trace!=null)','protocolStopped=true;HandoffSourceAudit.OuterEntries++;if(trace!=null)'),@('FullOuterDrain.Run(new FullOuterDrainAdapter(process,started,finalObserver,finalDesktop,output,error,trace),','HandoffSourceAudit.Drain(new FullOuterDrainAdapter(process,started,finalObserver,finalDesktop,output,error,trace),'),@('FinalizeFullObserver(result,observer,trace);','HandoffSourceAudit.FinalizeCalls++;FinalizeFullObserver(result,observer,trace);'),@('if(output.Complete&&error.Complete)process.Dispose();','if(HandoffSourceAudit.CompleteStreams){HandoffSourceAudit.DisposeCalls++;process.Dispose();}'))
  foreach($r in $replacements){if(([regex]::Matches($text,[regex]::Escape($r[0]))).Count -ne 1){throw ('SOURCE seam not unique: '+$r[0])};$text=$text.Replace($r[0],$r[1])}
 }
 if((Split-Path -Leaf $p) -ceq 'Handoff.Controller.cs'){$text=$text.Replace('Thread.Sleep(Timeout.Infinite);','HandoffSourceAudit.Hold();')}
 $dest=Join-Path $out (Split-Path -Leaf $p);[IO.File]::WriteAllText($dest,$text,[Text.UTF8Encoding]::new($false));$sources+=$dest;$proof+=@{source=$p;sourceSha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant();guardedSha256=(Get-FileHash -LiteralPath $dest).Hash.ToLowerInvariant();poisonedImports=$nativeCount}
}
Import-Module (Join-Path $repo 'AcceptanceHarness\FullRestricted.CdbOwnedWaitFixture\SourceProcess.psm1') -Force
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe';$exe=Join-Path $out 'Handoff.Integration.Pure.exe';$argsList=@('/nologo','/target:exe','/platform:x64','/warn:4','/warnaserror+','/nowarn:0649','/r:System.Web.Extensions.dll','/r:System.Runtime.Serialization.dll','/r:System.Xml.dll','/main:Azurite.Restricted.HandoffIntegrationTests',('/out:'+$exe))+$sources
$compile=Invoke-FixtureSourceProcess -File $csc -Arguments $argsList -Directory $out -Record (Join-Path $out 'compile-process.json') -BoundMs 60000
if($compile.exitCode -ne 0){throw ($compile.stdout+$compile.stderr)}
$run=Invoke-FixtureSourceProcess -File $exe -Arguments @('source-only') -Directory $out -Record (Join-Path $out 'test-process.json') -BoundMs 20000
$record=@{sourceOnly=$true;nativeExecuted=$false;FReadPerformed=$false;FWritePerformed=$false;sourceStage=$InputStage;guardedInputs=$proof;exitCode=$run.exitCode;stdout=$run.stdout;stderr=$run.stderr}
[IO.File]::WriteAllText((Join-Path $out 'result.json'),($record|ConvertTo-Json -Depth 7),[Text.UTF8Encoding]::new($false));$run.stdout
if(($ExpectRed -and $run.exitCode -ne 1)-or(-not $ExpectRed -and $run.exitCode -ne 0)){throw 'Unexpected SOURCE integration result'}
