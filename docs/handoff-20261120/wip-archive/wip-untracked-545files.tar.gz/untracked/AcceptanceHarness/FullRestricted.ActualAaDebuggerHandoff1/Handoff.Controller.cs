using System;using System.Collections.Generic;using System.Diagnostics;using System.IO;using System.Threading;using System.Threading.Tasks;using Azurite.Restricted.ActualDebugger;
namespace Azurite.Restricted {
 public static class ActualAaHandoff {
  static readonly object sync=new object();static Session current;
  sealed class Session {
   internal string Run,Directory,Owner,Logon;internal int BootstrapPid;internal LeaseDeadline Deadline;internal LeasePinnedFiles Pins;internal LeaseFiles.DirectoryPins Directories;internal CdbTargetLease Lease;internal CdbGateProtocol Gate;internal CdbNativeRun Native;
   internal readonly object DebugGate=new object();internal readonly ManualResetEventSlim Started=new ManualResetEventSlim(false);internal readonly List<object> Retained=new List<object>();internal Task Worker;internal OwnedDebuggerSession Debugger;internal PumpResult Pump;
   internal bool CancelStart,NoCreateCloseAttempted,StopProven,Closed,ResumeObserved,OuterRetained;internal Exception FirstError;internal readonly List<string> Secondary=new List<string>();internal long AttachedContextQpc,AckBeforeQpc,AckAfterQpc,OriginalResumeQpc,StopProofQpc;internal string NativeEvidencePath;
   internal void First(Exception e){Interlocked.CompareExchange(ref FirstError,e,null);}internal void Later(Exception e){lock(Secondary)if(Secondary.Count<16)Secondary.Add(e.ToString());}
  }
  internal static void CaptureStartedBootstrap(Process actual,string id){Session s;lock(sync)s=current;FullRestrictedContract.Require(s!=null&&s.Run==id&&actual!=null,"Actual controller startup context required");try{s.Lease.CaptureStarted(actual.Id,actual.Handle);s.BootstrapPid=actual.Id;}catch(Exception e){s.First(e);throw;}finally{s.Started.Set();}}
  public static PumpResult RunPrepared(ProcessStartInfo info,string id,string controlHash,string targetHash,string shellHash,string ownerSid,string logonSid,long admissionQpc){
   FullRestrictedContract.ValidateBootstrap(info,id,controlHash);FullRestrictedContract.Require(IntPtr.Size==8&&admissionQpc>0&&admissionQpc<=Stopwatch.GetTimestamp(),"Original x64 controller admission clock");
   var s=new Session{Run=id,Directory=FullRestrictedContract.Lab+@"\runs\restricted-"+id,Owner=ownerSid,Logon=logonSid,Deadline=new LeaseDeadline(admissionQpc,Stopwatch.Frequency,30000,Stopwatch.GetTimestamp),Pins=new LeasePinnedFiles()};lock(sync){FullRestrictedContract.Require(current==null,"One actual debugger session per host");current=s;}
   PumpResult result=null;
   try{
    s.Directories=LeaseFiles.HoldControl(s.Directory+@"\control",LeaseAcl.Directory(ownerSid,logonSid));foreach(string name in new[]{"lease-offer.json","lease-ack.json","debug-stop.request","debug-stop.ack","original-resume.record"})FullRestrictedContract.Require(!File.Exists(s.Directory+@"\control\"+name),"Stale handoff record before target spawn");
    s.Pins.Add(FullRestrictedContract.Executable,targetHash);s.Pins.Add(info.FileName,shellHash);s.Lease=new CdbTargetLease(id,FullRestrictedContract.Executable,targetHash,info.FileName,shellHash,new CdbLeaseNative(s.Pins.Hashes));s.Gate=new CdbGateProtocol(s.Lease,id,s.Deadline,Stopwatch.GetTimestamp,()=>0UL);
    s.Native=new CdbNativeRun(id,s.Deadline.Expiry,Stopwatch.Frequency);s.Native.PrepareBeforeTarget();
    s.Worker=Task.Factory.StartNew(()=>Control(s),CancellationToken.None,TaskCreationOptions.LongRunning,TaskScheduler.Default);
    int remaining=s.Deadline.Remaining-5000;FullRestrictedContract.Require(remaining>0,"Original outer allowance before bootstrap");
    result=ProcessPump.RunBootstrapFullRestricted(info,remaining,id,controlHash,262144,new[]{s.Directory+@"\request",s.Directory+@"\output",s.Directory+@"\control"},4194304);s.Pump=result;
    if(!s.Worker.Wait(Math.Max(0,s.Deadline.Remaining)))throw new TimeoutException("Handoff worker still owned");
    if(s.FirstError!=null)throw new InvalidOperationException("Debugger handoff failed",s.FirstError);
    FullRestrictedContract.Require(s.Gate.Acknowledged&&s.ResumeObserved&&s.StopProven,"Actual attach/Resume/stop sequence incomplete");FullRestrictedContract.Require(result.CleanupVerified&&result.DirectProcessExited&&result.JobDrained&&result.StreamCaptureComplete,"Original target cleanup not proven");
    FullRestrictedContract.Require(s.Lease.CloseAfterDrain(true),"Retained lease close unconfirmed");s.Closed=true;FullRestrictedContract.Require(s.Deadline.Remaining>0,"Original admission deadline exhausted");
   }catch(Exception e){s.First(e);}finally{
    if(s.Worker==null){try{s.StopProven=Stop(s,ActualAaBootstrapHandoff.CleanupExpiry(Stopwatch.StartNew()));}catch(Exception e){s.Later(e);}}
    try{if(!s.Closed&&s.StopProven&&!s.OuterRetained)s.Closed=CloseAfterPump(result,s.Lease,s.Worker,s.Run,s.BootstrapPid,s.Gate);}catch(Exception e){s.Later(e);}
    try{if((s.Closed||(s.Lease==null||!s.Lease.BootstrapStarted))&&s.StopProven&&(s.Worker==null||s.Worker.IsCompleted)){s.Pins.Dispose();if(s.Directories!=null)s.Directories.Dispose();}}catch(Exception e){s.OuterRetained=true;s.Later(e);}
    try{if(s.Native!=null&&(s.Debugger==null||s.Debugger.StopCompleted)){var verdict=new CdbToolcheckOutcome{Passed=s.FirstError==null&&s.StopProven&&s.Closed,CleanupVerified=s.StopProven,AllClosed=s.StopProven,OwnerRetained=MustHoldHost(),PrimaryError=s.FirstError==null?null:s.FirstError.ToString()};s.NativeEvidencePath=s.Native.SaveHandoffEvidence(verdict,new{attachedContextQpc=s.AttachedContextQpc,ackPublicationBeforeQpc=s.AckBeforeQpc,ackPublicationAfterQpc=s.AckAfterQpc,originalResumeObservedQpc=s.OriginalResumeQpc,stopProofQpc=s.StopProofQpc,originalOuterDeadlineQpc=s.Deadline.Expiry,continuousAttachmentClaimed=false,applicationAccepted=false});}}catch(Exception e){s.Later(e);s.First(e);}finally{RetainCurrentHostIfRequired();}
   }
   if(s.Deadline.Remaining<=0)s.First(new TimeoutException("Original admission deadline exhausted before controller completion"));if(s.FirstError!=null)throw new InvalidOperationException("Actual-AA debugger handoff failed",s.FirstError);return result;
  }
  internal static bool CloseAfterPump(PumpResult result,CdbTargetLease lease,Task worker,string run,int bootstrapPid,CdbGateProtocol gate){
   if(result==null||lease==null||(worker!=null&&!worker.IsCompleted))return false;
   bool normal=result.CleanupVerified&&result.DirectProcessExited&&result.JobDrained;
   bool failedBootstrap=!result.CleanupVerified&&worker!=null&&worker.IsCompleted&&gate!=null&&gate.Offer==null&&!gate.Acknowledged&&!gate.GoPublished&&lease.BootstrapStarted&&!lease.Ready&&lease.Owners.Count==1&&bootstrapPid>0&&result.Pid==bootstrapPid&&result.RunId==run&&result.FullRestrictedMode&&!result.NoProcessCreated&&result.JobObserved&&result.DirectProcessExited&&result.JobDrained&&result.RemainingOwnedProcesses==0&&result.DesktopLeaseObserved&&result.DesktopLeaseClosed&&!result.DesktopLeaseRetained&&result.StreamCaptureComplete&&result.FullJobObserverClosed&&!result.FullJobObserverRetained&&result.FullJobObserverCloseError==0&&(!String.IsNullOrEmpty(result.Error)||!String.IsNullOrEmpty(result.CleanupError));
   if(failedBootstrap){var owner=lease.Owners[0];failedBootstrap=owner.Role=="bootstrap"&&owner.Value!=IntPtr.Zero&&owner.Value==owner.Acquired&&!owner.Closed&&!owner.Retained&&!owner.CloseAttempted&&owner.CloseError==0&&String.IsNullOrEmpty(owner.CloseException);}
   if(!normal&&!failedBootstrap)return false;return lease.CloseAfterDrain(true);
  }
  static int Remaining(Session s){if(s.CancelStart)return 0;int left=Math.Max(0,s.Deadline.Remaining-5000);if(s.Gate.Offer!=null){long ticks=s.Gate.Offer.NativeDeadline-Stopwatch.GetTimestamp();left=(int)Math.Min(left,ticks<=0?0:(decimal)ticks*1000/Stopwatch.Frequency);}return left;}
  static bool Stop(Session s,long expiry){OwnedDebuggerSession debugger;lock(s.DebugGate){s.CancelStart=true;debugger=s.Debugger;if(debugger==null){if(s.NoCreateCloseAttempted)return s.StopProven;s.NoCreateCloseAttempted=true;try{s.StopProven=s.Native==null||s.Native.ClosePreparedWithoutCreate(Math.Min(expiry,s.Deadline.Expiry));if(s.StopProven&&s.StopProofQpc==0)s.StopProofQpc=Stopwatch.GetTimestamp();return s.StopProven;}catch(Exception e){s.First(e);s.OuterRetained=true;return false;}}}bool closed=debugger.StopBeforeTargetCleanup(Math.Min(expiry,s.Deadline.Expiry));lock(s.DebugGate){s.StopProven=closed;if(closed&&s.StopProofQpc==0)s.StopProofQpc=Stopwatch.GetTimestamp();}if(debugger.FirstError!=null)s.First(debugger.FirstError);return closed;}
  static void Control(Session s){
   var records=new ProtectedHandoffRecords(s.Run,s.Owner,s.Logon);TargetIdentity target=null;
   try{
    while(!s.Started.IsSet){int left=Remaining(s);if(left<=0)throw new TimeoutException("Bootstrap ownership capture deadline");s.Started.Wait(Math.Min(5,left));}if(s.FirstError!=null)throw new InvalidOperationException("Capture failed",s.FirstError);
    s.Gate.AcceptOffer(LeaseRecords.ParseOffer(LeaseFiles.AwaitRead(s.Directory+@"\control\lease-offer.json",()=>Remaining(s))));var offer=s.Gate.Offer;target=new TargetIdentity(s.Run,offer.ChildPid,offer.ChildCreated,offer.MainTid);
    s.Native.AttachVerifiedLease(s.Lease);
    lock(s.DebugGate){if(s.CancelStart)throw new InvalidOperationException("CDB start cancelled before commit");long activeExpiry=Math.Min(offer.NativeDeadline,s.Deadline.Expiry-5*Stopwatch.Frequency);s.Debugger=new OwnedDebuggerSession(target,s.Native,Stopwatch.GetTimestamp,Stopwatch.Frequency,s.Deadline.Expiry,activeExpiry);s.Debugger.Start();}
    if(!s.Debugger.WaitReady(Remaining(s)))throw new InvalidOperationException("No live actual attached context before original target Resume",s.Debugger.FirstError);
    s.AttachedContextQpc=Stopwatch.GetTimestamp();s.Gate.PublishAck(bytes=>{if(!s.Debugger.Ready||s.Debugger.FirstError!=null)throw new InvalidOperationException("Owner failure revoked pre-Resume ACK");s.AckBeforeQpc=Stopwatch.GetTimestamp();LeaseFiles.Create(s.Directory+@"\control\lease-ack.json",bytes,LeaseAcl.File(s.Owner,s.Logon));s.AckAfterQpc=Stopwatch.GetTimestamp();});
   }catch(Exception e){s.First(e);}
   try{
    while(!s.StopProven){
     byte[] resumeRecord;if(target!=null&&!s.ResumeObserved&&HandoffRecordRead.Try(records,"original-resume.record",out resumeRecord)){try{long qpc;uint previous=StopWire.ParseResume(resumeRecord,target,out qpc);FullRestrictedContract.Require(qpc>=s.Gate.Offer.NativeStart&&qpc>=s.AttachedContextQpc&&qpc>=s.AckBeforeQpc&&qpc<=Stopwatch.GetTimestamp(),"Actual Resume QPC outside original lifetime/ACK sequence");s.ResumeObserved=true;s.OriginalResumeQpc=qpc;s.Debugger.ObserveOriginalTargetResume(previous);}catch(Exception e){s.First(e);s.Debugger.RecordFirst(e);}}
     byte[] stopRecord;if(HandoffRecordRead.Try(records,"debug-stop.request",out stopRecord)){var request=StopWire.ParseRequest(stopRecord,s.Run);if(target!=null)FullRestrictedContract.Require(request.Target.Pid==target.Pid&&request.Target.Created==target.Created,"Stop request target lifetime differs");bool closed=Stop(s,request.Expiry);records.Create("debug-stop.ack",StopWire.Ack(request,closed));return;}
     if(s.Deadline.Remaining<=0){Stop(s,s.Deadline.Expiry);return;}Thread.Sleep(2);
    }
   }catch(Exception e){s.First(e);try{Stop(s,Math.Min(s.Deadline.Expiry,ActualAaBootstrapHandoff.CleanupExpiry(Stopwatch.StartNew())));}catch(Exception later){s.Later(later);}}
  }
  internal static bool BeforeOuterCleanup(string id,Stopwatch original){Session s;lock(sync)s=current;if(s==null||s.Run!=id)return false;return Stop(s,ActualAaBootstrapHandoff.CleanupExpiry(original));}
  internal static void RetainOuter(string id,params object[] objects){Session s;lock(sync)s=current;if(s==null||s.Run!=id)throw new InvalidOperationException("Missing owner for outer retention");lock(s.Retained){s.OuterRetained=true;s.Retained.AddRange(objects);}}
  public static bool MustHoldHost(){Session s;lock(sync)s=current;return s!=null&&(s.OuterRetained||!s.StopProven||(s.Debugger!=null&&s.Debugger.OwnerRetained)||(s.Worker!=null&&!s.Worker.IsCompleted)||(s.Lease!=null&&s.Lease.BootstrapStarted&&!s.Closed)||(s.Pump!=null&&(s.Pump.DesktopLeaseRetained||s.Pump.FullJobObserverRetained)));}
  public static void RetainCurrentHostIfRequired(){bool hold=true;try{hold=MustHoldHost();}catch{}if(hold){try{Console.Error.WriteLine("AZURITE_DEBUGGER_CONTROLLER_OWNER_RETAINED");}finally{GC.KeepAlive(current);Thread.Sleep(Timeout.Infinite);}}}
  public static object Snapshot(){Session s;lock(sync)s=current;if(s==null)return new{session=false,holdHost=false};return new{session=true,runId=s.Run,holdHost=MustHoldHost(),stopProven=s.StopProven,originalResumeObserved=s.ResumeObserved,attachedContextObserved=s.AttachedContextQpc>0,attachedContextStillUsable=s.Debugger!=null&&s.Debugger.Ready,attachedContextQpc=s.AttachedContextQpc,ackBeforeQpc=s.AckBeforeQpc,ackAfterQpc=s.AckAfterQpc,originalResumeQpc=s.OriginalResumeQpc,stopProofQpc=s.StopProofQpc,nativeEvidencePath=s.NativeEvidencePath,ownerError=s.FirstError==null?null:s.FirstError.ToString(),retainedOuter=s.OuterRetained,applicationAccepted=false,nativeQualificationClaimed=false};}
 }
}
