param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Stage,[switch]$ExpectRed,[ValidateSet('Core','Wire')][string]$Suite='Core')
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$out=Join-Path $repo ('artifacts\aa-real-debugger-handoff-20261114\candidate1\'+$Stage)
if(Test-Path -LiteralPath $out){throw 'Fresh stage required; previous evidence retained'}
[void][IO.Directory]::CreateDirectory($out)
Import-Module (Join-Path $repo 'AcceptanceHarness\FullRestricted.CdbOwnedWaitFixture\SourceProcess.psm1') -Force
$paths=if($Suite -ceq 'Core'){@('DebuggerHandoff.Core.cs','DebuggerHandoff.Tests.cs')}else{@('DebuggerHandoff.Core.cs','DebuggerHandoff.Wire.cs','DebuggerHandoff.Wire.Tests.cs')};$sources=@();$pins=@()
foreach($name in $paths){$p=Join-Path $PSScriptRoot $name;$text=[IO.File]::ReadAllText($p);if($text -match 'DllImport|Process\.Start|\.Load\('){throw 'Core SOURCE tests must have no native boundary'};$copy=Join-Path $out $name;[IO.File]::Copy($p,$copy,$false);$sources+=$copy;$pins+=@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}}
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe';$exe=Join-Path $out 'DebuggerHandoff.Pure.exe';$argsList=@('/nologo','/target:exe','/platform:x64','/warn:4','/warnaserror+','/nowarn:0649',('/out:'+$exe))+$sources
$build=Invoke-FixtureSourceProcess -File $csc -Arguments $argsList -Directory $out -Record (Join-Path $out 'compile-process.json') -BoundMs 60000
if($build.exitCode -ne 0){throw ('Compile failed: '+$build.stdout+$build.stderr)}
$run=Invoke-FixtureSourceProcess -File $exe -Arguments @('source-only') -Directory $out -Record (Join-Path $out 'test-process.json') -BoundMs 15000
$record=@{sources=$pins;compilerPath=$csc;compilerSha256=(Get-FileHash -LiteralPath $csc).Hash.ToLowerInvariant();sourceOnly=$true;nativeExecuted=$false;expectedRed=[bool]$ExpectRed;exitCode=$run.exitCode;stdout=$run.stdout;stderr=$run.stderr}
[IO.File]::WriteAllText((Join-Path $out 'result.json'),($record|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
$run.stdout
if(($ExpectRed -and $run.exitCode -ne 1)-or(-not $ExpectRed -and $run.exitCode -ne 0)){throw 'Unexpected SOURCE test result'}
