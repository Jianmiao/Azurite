param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh actual Capture admission result required'}
if($PSVersionTable.PSVersion.Major -ne 5){throw 'Actual Capture prefix requires original PS51 selection'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$run='1ebaf8382f8c4424907a9150df495b46';$manifest=Get-Content -LiteralPath (Join-Path $CandidateDirectory 'sequence-source-manifest.json') -Raw|ConvertFrom-Json
$row=@($manifest.files|Where-Object role -CEQ Capture);if($row.Count -ne 1){throw 'Exact Capture role required'}
$path=$row[0].path;if((Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -cne $row[0].sha256){throw 'Real selected Capture source differs'}
$text=Get-Content -LiteralPath $path -Raw;$end=$text.IndexOf('$mutex=[Threading.Mutex]::new(');if($end -le 0){throw 'Exact before-mutex boundary missing'}
$prefix=$text.Substring(0,$end)
if($prefix.Contains('New-AzuriteSharedSnapshot $') -or $prefix.Contains('[Threading.Mutex]::new')){throw 'Admission slice crossed live boundary'}
$block=[scriptblock]::Create($prefix+"`n"+'[pscustomobject]@{runId=$run;beforeMutexReached=$true;receiptPinned=$true;sourcePinsChecked=$true}')
$harmless=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\cleanup9974-root-supervision\harmless-cleanup-v2.json';$hash='3609ced64ba027750871940236411869392f2ff0255bba74508df78df0272d28';$checks=@()
$result=& $block -RunId $run -HarmlessReceiptPath $harmless -HarmlessReceiptSha256 $hash
$checks+=[pscustomobject]@{name='actual selected Capture parameter and C receipt/source admission reaches pre-mutex boundary';passed=($result.runId -ceq $run -and $result.beforeMutexReached -and $result.receiptPinned -and $result.sourcePinsChecked)}
$refused=$false;try{& $block -RunId $run -HarmlessReceiptPath $harmless -HarmlessReceiptSha256 ('a'*64)|Out-Null}catch{$refused=$_.Exception.Message -like '*Bounded receipt bytes drift*'}
$checks+=[pscustomobject]@{name='actual Capture wrong harmless digest rejects before lease and native work';passed=$refused}
$record=[ordered]@{scope='actual PS51 Capture producer admission prefix only; whole Capture not invoked';passed=(@($checks|Where-Object {-not $_.passed}).Count -eq 0);runId=$run;tests=$checks;sourcePath=$path;sourceSha256=$row[0].sha256;host=$PSVersionTable.PSVersion.ToString();actualPrefixExecuted=$true;wholeCaptureInvoked=$false;mutexCodeExcluded=$true;baselineCreated=$false;captureOutputCreated=$false;nativeExecuted=$false;tokenAclRegistryAccess=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($record|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));$record|ConvertTo-Json -Depth 8;if(-not $record.passed){exit 1}
