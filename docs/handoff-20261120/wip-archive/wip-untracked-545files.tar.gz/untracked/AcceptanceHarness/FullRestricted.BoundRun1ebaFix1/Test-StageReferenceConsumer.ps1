param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh Stage consumer result required'}
$path=Join-Path $CandidateDirectory 'overlay\FullRestrictedStageTransition.psm1';$text=Get-Content -LiteralPath $path -Raw;$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors)
if($errors.Count -ne 0){throw 'Actual Stage module parse error'}
foreach($name in @('Get-TransitionHash','Assert-Transition')){$defs=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq $name},$false));if($defs.Count -ne 1){throw 'Exact production pure helper missing'};. ([scriptblock]::Create($defs[0].Extent.Text))}
$start=$text.IndexOf(' $framework=Join-Path $env:WINDIR');$end=$text.IndexOf(' Assert-Transition ($control.toolingManifestSha256',$start);if($start -lt 0 -or $end -le $start){throw 'Actual Stage reference guard boundary missing'};$guard=[scriptblock]::Create($text.Substring($start,$end-$start))
$actual=Get-Content -LiteralPath (Join-Path $CandidateDirectory 'overlay\tooling-manifest.json') -Raw|ConvertFrom-Json;$checks=[Collections.Generic.List[object]]::new()
function Check([string]$name,$value,[bool]$expectAccepted){$tooling=$value;$errorText=$null;try{. $guard}catch{$errorText=$_.Exception.Message};$accepted=$null -eq $errorText;$checks.Add([pscustomobject]@{name=$name;passed=($accepted -eq $expectAccepted);accepted=$accepted;error=$errorText})}
Check 'actual reviewed actor exact two-reference manifest' $actual $true
foreach($name in @('missing-reference','extra-reference','wrong-order','wrong-name','malformed-hash','wrong-reference-bytes','wrong-compiler-bytes')){
 $copy=$actual|ConvertTo-Json -Depth 20|ConvertFrom-Json
 switch($name){
  'missing-reference' {$copy.build.references=@($copy.build.references[0])}
  'extra-reference' {$copy.build.references+=,[pscustomobject]@{name='System.Web.Extensions.dll';sha256='a'*64}}
  'wrong-order' {$copy.build.references=@($copy.build.references[1],$copy.build.references[0])}
  'wrong-name' {$copy.build.references[0].name='System.Web.Extensions.dll'}
  'malformed-hash' {$copy.build.references[1].sha256='bad'}
  'wrong-reference-bytes' {$copy.build.references[1].sha256='a'*64}
  'wrong-compiler-bytes' {$copy.build.compilerSha256='a'*64}
 }
 Check $name $copy $false
}
function Hash([string]$p){(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()}
$helper=Get-Content -LiteralPath (Join-Path $CandidateDirectory 'helper-build\build.json') -Raw|ConvertFrom-Json;$processPath=Join-Path $CandidateDirectory 'helper-compile-process.json';$p=Get-Content -LiteralPath $processPath -Raw|ConvertFrom-Json
$sourcePath=Join-Path $CandidateDirectory 'helper-build\FullRestrictedStageFileSecurity.cs';$dllPath=Join-Path $CandidateDirectory 'helper-build\FullRestrictedStageFileSecurity.dll'
$embedded=[regex]::Match($text,"(?s)\`$script:TransitionNativeSource=@'\r?\n(.*?)\r?\n'@");if(-not $embedded.Success){throw 'Embedded unchanged helper source missing'};$embeddedHash=Get-TransitionHash ([Text.UTF8Encoding]::new($false).GetBytes($embedded.Groups[1].Value))
$expected=@('/nologo','/target:library','/platform:x64','/optimize+',('/out:'+$dllPath),$sourcePath)
$helperOkay=$helper.sourceSha256 -ceq 'bb8772ffb40c9ac7857b722e6ceb8fc76719bb7c2099f062f8c052b7b1921253' -and $helper.sourceSha256 -ceq (Hash $sourcePath) -and $helper.sourceSha256 -ceq $embeddedHash -and $helper.moduleSha256 -ceq (Hash $path) -and $helper.assemblySha256 -ceq (Hash $dllPath) -and $helper.compilerSha256 -ceq (Hash $p.file) -and ($p.arguments -join '|') -ceq ($expected -join '|') -and $p.exited -and $p.exitCode -eq 0 -and -not $p.timedOut -and -not $p.terminatedOwnedPureChild -and -not $p.stdout -and -not $p.stderr
$checks.Add([pscustomobject]@{name='actual unchanged helper C compilation binds corrected Stage module and output';passed=$helperOkay;accepted=$helperOkay;error=$null})
$record=[ordered]@{scope='actual Stage reference guard C-only execution plus actual unchanged-helper compiler provenance';runId='1ebaf8382f8c4424907a9150df495b46';passed=(@($checks|Where-Object {-not $_.passed}).Count -eq 0);tests=$checks.ToArray();host=$PSVersionTable.PSVersion.ToString();stageModuleSha256=(Hash $path);helperSourceSha256=$helper.sourceSha256;helperAssemblySha256=$helper.assemblySha256;helperCompilerPid=$p.pid;helperCompilerCreationFileTime=$p.creationFileTime;helperCompilerProcessSha256=(Hash $processPath);actualWholeReadTransitionInputsInvoked=$false;actualGuardBlockInvoked=$true;nativeOperationsExecuted=$false;tokenAclRegistryAccess=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($record|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));$record|ConvertTo-Json -Depth 8;if(-not $record.passed){exit 1}
