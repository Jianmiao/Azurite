"""C-only drivers and source authority; never manufacture live-run inputs."""
import pathlib,json,hashlib,re
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'artifacts/aa-handoff-json-bound-1eba-20261114/candidate2'
BASE=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114/candidate3'
OLD=ROOT/'AcceptanceHarness/FullRestricted.ActualAaNoTraceQualification1'
RUN='1ebaf8382f8c4424907a9150df495b46';OLD_RUN='0e494be63f3248ffb7bd7bbd040987f8'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
def put(p,s):
 if p.exists():raise RuntimeError('Fresh delivery output required '+str(p))
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def js(p,v):put(p,json.dumps(v,ensure_ascii=False,indent=2))
def pin(p,**extra):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),**extra)
seq=json.loads(read(OUT/'sequence-source-manifest.json'));build=json.loads(read(OUT/'source-build-result.json'))
refs={}
def add(p,expected=None):
 p=pathlib.Path(p)
 if not p.is_file() or not str(p).startswith('C:\\'):raise RuntimeError('Existing exact C reference required '+str(p))
 if expected and sha(p)!=expected:raise RuntimeError('Frozen reference drift '+str(p))
 refs[str(p)]=pin(p)
for row in seq['files']:
 p=pathlib.Path(row['path'])
 if not p.is_relative_to(OUT):add(p,row['sha256'])
for manifest in [ROOT/'AcceptanceHarness/FullRestricted.FreshPreflight/source-index.json',ROOT/'artifacts/aa-fr-fresh-preflight-tooling/build-cf95-qual1/manifest.json']:
 m=json.loads(read(manifest))
 for r in m['files']:add(manifest.parent/r['path'],r['sha256'])
for p in (ROOT/'.superpowers/sdd/azurite-authoring-20261108/aa-fr-ftarget-cf95-build-20261114/tooling').iterdir():
 if p.is_file():add(p)
for relative in [
 '.superpowers/sdd/azurite-authoring-20261108/json-compatibility-source1-fix1/result.json',
 'artifacts/aa-actual-handoff-next-20261114/next-after-json-source2.json',
 'artifacts/aa-handoff-bound-bfdd-20261114/candidate2/source-checkpoint.json',
 'artifacts/aa-canonical-build-receipt-20261114/repair1/repair-manifest.json',
 'tools/headless/Get-AzuriteFullStageBaseline.ps1','tools/headless/HeadlessCore.psm1','tools/headless/RestrictedCliCore.psm1','tools/headless/CurrentAccountCli.psm1',
 'artifacts/aa-fr-transition-preparation/integration-20261110-01/helper-build1/FullRestrictedStageFileSecurity.dll',
 'artifacts/editor-normal-install-preparation/source-bound-manifest-v2.json','artifacts/editor-normal-install-postverify/verification-08a369f8f1e54fc58da8e0d2f72bf607.json',
 'artifacts/aa-fr-native-lifecycle-fixture/cleanup9974-root-supervision/harmless-cleanup-v2.json',
 'artifacts/aa-fr-empty-directory-helper-20261113/final-FullRestrictedStageTransition.psm1',
 'artifacts/aa-fr-empty-directory-helper-20261113/helper-build1/FullRestrictedStageFileSecurity.cs','artifacts/aa-fr-empty-directory-helper-20261113/helper-build1/FullRestrictedStageFileSecurity.dll','artifacts/aa-fr-empty-directory-helper-20261113/helper-build1/build.json',
 '.superpowers/sdd/azurite-authoring-20261108/aa-fr-ftarget-freeze2-build-20261112/tooling/RestrictedCliNative.dll','.superpowers/sdd/azurite-authoring-20261108/aa-fr-ftarget-freeze2-build-20261112/tooling/RestrictedCliNative.cs','.superpowers/sdd/azurite-authoring-20261108/aa-fr-ftarget-freeze2-build-20261112/tooling/RestrictedCliFullRestricted.cs',
 'AcceptanceHarness/FullRestricted.CdbOwnedWaitFixture/SourceProcess.psm1',
 'artifacts/root-ps7-io-20261114/actual-io-root-readback.json','artifacts/aa-handoff-ps7-io-compatibility-20261114/io-fixture5/fixture-manifest.json','artifacts/aa-handoff-ps7-io-compatibility-20261114/io-fixture5/root-io-fixture5-ps7-result.json','artifacts/aa-handoff-ps7-io-compatibility-20261114/io-fixture5/root-io-fixture5-ps51-result.json',
 'artifacts/aa-handoff-ps7-io-compatibility-20261114/candidate3/source-checkpoint.json','artifacts/aa-handoff-ps7-io-compatibility-20261114/candidate3/components/PortableAclIo.cs']:
 add(ROOT/relative)
for p in [pathlib.Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'),pathlib.Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Runtime.Serialization.dll'),pathlib.Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Xml.dll')]:add(p)
# Explicit reviewed provenance, not a replacement hidden under old membership.
for relative in [
 'artifacts/aa-json-compatibility-20261114/source2/FROZEN-MANIFEST.json',
 'artifacts/aa-json-compatibility-20261114/source2/build3/RestrictedCliNative.dll',
 'artifacts/aa-json-compatibility-20261114/source2/build3/RestrictedCliNative.cs',
 'artifacts/aa-json-compatibility-20261114/source2/build3/RestrictedCliFullRestricted.cs',
 'artifacts/aa-json-compatibility-20261114/source2/build3/compile-process.json',
 'artifacts/aa-json-compatibility-20261114/source2/build3/compiler-inputs.zip',
 'artifacts/aa-json-compatibility-20261114/source2/composition-final.json',
 'artifacts/aa-json-compatibility-20261114/source2/compiler-build.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps7.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps7-process.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps51.json',
 'artifacts/aa-json-compatibility-20261114/source2/tests/full-build3-ps51-process.json',
 '.superpowers/sdd/azurite-authoring-20261108/team/72-json-compatibility-independent-review.md',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/Capture-FreshShared.Fixed.ps1',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/source-addon.json',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/source-checkpoint.json',
 'artifacts/aa-fresh-shared-72f8-fix1-20261114/derivation.json',
 '.superpowers/sdd/azurite-authoring-20261108/team/72f8-fresh-shared-fix1-review.md']:
 add(ROOT/relative)
harmless=ROOT/'artifacts/aa-fr-native-lifecycle-fixture/cleanup9974-root-supervision/harmless-cleanup-v2.json'
if sha(harmless)!='3609ced64ba027750871940236411869392f2ff0255bba74508df78df0272d28':raise RuntimeError('Actual harmless baseline drift')
drivers={name:HERE/name for name in ['Get-SourcePlan.ps1','New-RootIntent.ps1','New-FailureInputs.Pinned.ps1','Capture-FreshShared.Bound.ps1']}
plan=dict(schema=1,scope='root-selected-1eba-source-plan-not-live-inputs',runId=RUN,sourceOnly=True,willReadF=False,willWriteF=False,willLaunch=False,runtimeAllowed=False,nativeHandoffAcceptance=False,
 sourcePackage=str(OUT),sequenceSourceManifest=pin(OUT/'sequence-source-manifest.json'),runtimeDll=pin(OUT/'overlay/RestrictedCliNative.dll'),ioQualificationBinding=pin(OUT/'io-qualification-binding.json'),
 baselineProducer=pin(ROOT/'tools/headless/Get-AzuriteFullStageBaseline.ps1'),existingHarmlessBaseline=pin(harmless,classification='actual CF95 baseline receipt permitted by unchanged qualification policy; not a new bound-DLL harmless run'),
 requiredActualInputs=[dict(when='before intent materialization',name='same-run stage baseline capture-result.json and sibling identity-baseline.json',producer='Get-AzuriteFullStageBaseline.ps1 -RunId '+RUN+' -Capture',requiredFacts='actual successful released same-run capture; 1228 observed objects and identities; externally reviewed digests; no reused old-run baseline'),dict(when='during one Execute sequence',name='fresh identity/shared capture and fresh warm preflight',producer='existing Capture and Warm stages',requiredFacts='actual current identity, shared scope/before snapshot, fresh C receipts; no fabricated or reused old-run outputs'),dict(when='after an actually closed failed run',name='actual controller-final, C bootstrap copy, prepared receipt graph and completed preservation archive',producer='existing runtime and preservation entrypoints',requiredFacts='original owners and stop/drain/stream/desktop closure proven; unknown/NoPump evidence does not imply no creation'),dict(when='immediately before recovery Apply',name='fresh shared-state result and comparison',producer='Capture-FreshShared.Bound.ps1 -Capture',requiredFacts='actual same-run before/scope digests from preparation; zero delta and freshness required by existing recovery policy')],
 remainingCoverage=json.loads(read(ROOT/'artifacts/aa-actual-handoff-next-20261114/next-after-json-source2.json'))['remainingCoverage'],jsonQualificationBinding=pin(OUT/'json-qualification-binding.json'),freshSourceBinding=pin(OUT/'fresh-source-binding.json'),
 sequenceStages=['Capture','Warm','Assemble','Approval','PreparePlan','Apply','Projection','RuntimePlan','Runtime'],
 drivers={k:str(v) for k,v in drivers.items()},executionEntry=str(OUT/'overlay/Invoke-AzuriteCapabilitiesSequence.ps1'),
 runtimeEvidenceRoot=str(ROOT/('artifacts/aa-fr-capabilities-sequence/run-'+RUN)),debuggerEvidenceDirectory=json.loads(read(OUT/'derivation.json'))['debuggerEvidenceDirectory'],
 preservationEntry=str(OUT/'overlay/Preserve-AzuriteClosedFailedRuntime.ps1'),preservationDirectory=str(ROOT/('artifacts/aa-fr-closed-failed-preservation/no-trace-'+RUN)),recoveryEntry=str(OUT/'overlay/Recover-AzuriteFullPreparation.ps1'),recoveryDirectory=str(ROOT/('artifacts/aa-fr-closed-failed-recovery/no-trace-'+RUN)),
 safety=dict(originalOuterMilliseconds=30000,originalNativeMilliseconds=10000,rawDebuggerBytes=1048576,automaticRetry=False,automaticRecovery=False,noProcessCreatedInferredFromMissingRecords=False,noPumpAutomaticRecovery=False,oldRun0eSpecialRecoveryReusable=False,rootOwnsEveryLiveProcess=True,baselineOrFreshFactsCreatedBySourceBuild=False))
js(OUT/'source-plan.json',plan)
put(OUT/'ROOT-COMMANDS.md',read(HERE/'ROOT-COMMANDS.template.md').replace('@CANDIDATE@',str(OUT)).replace('@RUN@',RUN).replace('@SEQUENCE_SHA@',sha(OUT/'sequence-source-manifest.json')).replace('@SOURCE_DIR@',str(HERE)).replace('@DEBUGGER_EVIDENCE@',json.loads(read(OUT/'derivation.json'))['debuggerEvidenceDirectory']))
runtimeFiles=[]
for folder in ['components','overlay','helper-build']:
 runtimeFiles.extend(p for p in sorted((OUT/folder).rglob('*')) if p.is_file())
for name in ['compiler-build.json','compiler-inputs.zip','composition.json','derivation.json','io-qualification-binding.json','source-build-result.json','json-qualification-binding.json','fresh-source-binding.json','original-compiler-process.json','sequence-source-manifest.json','72-to-1eba-powershell.diff','source-plan.json','ROOT-COMMANDS.md']:runtimeFiles.append(OUT/name)
baseManifest=dict(schema=1,scope='actual-AA-no-trace-qualification-C-source-driver-delivery',runId=RUN,files=[dict(path=p.relative_to(OUT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in runtimeFiles],references=list(refs.values()),sourceOnly=True,baselineOrFreshInputsCreated=False,nativeAcceptance=False)
js(OUT/'delivery-manifest.json',baseManifest)
oldFailure=read(OLD/'New-FailureInputs.Pinned.ps1');a=oldFailure.index('function Assert-QualificationPinnedDelivery');b=oldFailure.index('$frozenDelivery=Assert-QualificationPinnedDelivery')
verifier=oldFailure[a:b].replace(OLD_RUN,RUN).replace("'fixed-no-trace-failure-binder-pinned-delivery'","'fixed-1eba-qualification-pinned-delivery'").replace('@($base.files).Count -ne 92','@($base.files).Count -ne '+str(len(runtimeFiles))).replace('@($base.references).Count -ne 37','@($base.references).Count -ne '+str(len(refs)))
prefix=r'''$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$candidate=[IO.Path]::GetFullPath($CandidateDirectory)
if([IO.Path]::GetDirectoryName($candidate) -cne (Join-Path $repo 'artifacts\aa-handoff-json-bound-1eba-20261114')){throw 'Exact C 1eba bound candidate required'}
'''
def entry(params,role,body):return '#requires -Version 7.0\n'+params+'\n'+prefix+verifier.replace('-CEQ FailureBinder','-CEQ '+role)+'$frozenDelivery=Assert-QualificationPinnedDelivery $candidate $ExpectedDeliveryManifestSha256 $PSCommandPath\n'+body
sourceParams='param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256)'
sourceBody=r'''$planPath=Join-Path $candidate 'source-plan.json';$plan=Get-Content -LiteralPath $planPath -Raw|ConvertFrom-Json -DateKind String
[pscustomobject]@{scope='verified-1eba-source-plan';sourcesVerified=$true;delivery=$frozenDelivery;plan=$plan;liveInputsEvaluated=$false;moduleLoaded=$false;baselineCreated=$false;freshCapturePerformed=$false;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false}|ConvertTo-Json -Depth 20
'''
put(drivers['Get-SourcePlan.ps1'],entry(sourceParams,'SourcePlan',sourceBody))
intentParams=r'''[CmdletBinding(DefaultParameterSetName='Materialize')]
param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256,
 [Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedSourceManifestSha256,
 [Parameter(Mandatory,ParameterSetName='Materialize')][string]$BaselineCapturePath,[Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedBaselineCaptureSha256,[Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedBaselineIdentitySha256,
 [Parameter(Mandatory,ParameterSetName='Materialize')][string]$HarmlessReceiptPath,[Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedHarmlessReceiptSha256,[string]$IntentValidUntilUtc,
 [Parameter(Mandatory,ParameterSetName='SourcesOnly')][switch]$VerifySourcesOnly)
'''
put(drivers['New-RootIntent.ps1'],entry(intentParams,'RootIntent',read(HERE/'RootIntent.Body.template.ps1')))
failureParams=r'''[CmdletBinding(DefaultParameterSetName='Bind')]
param([Parameter(Mandatory,ParameterSetName='Bind')][ValidateSet('Preservation','Recovery')][string]$Phase,[Parameter(Mandatory)][string]$CandidateDirectory,
 [Parameter(Mandatory,ParameterSetName='Bind')][string]$ControllerFinalPath,[Parameter(Mandatory,ParameterSetName='Bind')][string]$ExpectedControllerFinalSha256,
 [string]$PreservationDirectory,[string]$SharedResultPath,[string]$SharedComparisonPath,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256,
 [Parameter(Mandatory,ParameterSetName='SourcesOnly')][switch]$VerifySourcesOnly)
'''
failure=oldFailure[oldFailure.index('if($VerifySourcesOnly)'):].replace(OLD_RUN,RUN)
anchor='$finalPin=Pin final $ControllerFinalPath;if($finalPin.sha256 -cne $ExpectedControllerFinalSha256){throw \'Externally selected runtime final hash differs\'};$final=Read $finalPin'
guard=anchor+"\nif($final.runId -cne $run){throw 'Actual runtime final belongs to another run'}\nif($final.ownerRetained -or $final.leaseHeld){throw 'Original ownership is retained; no automatic preservation or recovery binding'}\nif($null -eq $final.result){throw 'No actual PumpResult exists; snapshot alone does not authorize closed-runtime recovery or prove no creation'}"
if failure.count(anchor)!=1:raise RuntimeError('Final evidence guard anchor differs')
failure=failure.replace(anchor,guard)
put(drivers['New-FailureInputs.Pinned.ps1'],entry(failureParams,'FailureBinder',failure))
freshParams=r'''[CmdletBinding(DefaultParameterSetName='Plan')]
param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256,
 [Parameter(Mandatory,ParameterSetName='Capture')][switch]$Capture,[Parameter(Mandatory,ParameterSetName='Capture')][string]$ExpectedBeforeSha256,[Parameter(Mandatory,ParameterSetName='Capture')][string]$ExpectedScopeSha256)
'''
fixed=ROOT/'artifacts/aa-fresh-shared-72f8-fix1-20261114/Capture-FreshShared.Fixed.ps1'
if sha(fixed)!='71c204d3b231ff1ba60f64ca0ca887e524fd095d948de67826d395b0ffa464d3':raise RuntimeError('Reviewed fixed Capture source differs')
fresh=read(fixed)
fresh=fresh[fresh.index('if(-not $Capture){'):].replace('72f854a6f85149f58d20f286283d932b',RUN).replace('72f8-fresh-shared-source-plan','1eba-fresh-shared-source-plan')
if '$capture=' in fresh or fresh.count('$captureInputs')!=5:raise RuntimeError('Reviewed Capture local-variable correction was not retained')
put(drivers['Capture-FreshShared.Bound.ps1'],entry(freshParams,'FreshShared',fresh))
supp=dict(schema=1,scope='fixed-1eba-qualification-pinned-delivery',runId=RUN,baseDelivery=pin(OUT/'delivery-manifest.json'),files=[],references=[pin(drivers[n],role=r) for n,r in [('Get-SourcePlan.ps1','SourcePlan'),('New-RootIntent.ps1','RootIntent'),('New-FailureInputs.Pinned.ps1','FailureBinder'),('Capture-FreshShared.Bound.ps1','FreshShared')]],sourceOnly=True,baselineOrFreshInputsCreated=False)
js(OUT/'delivery-pinned-manifest.json',supp)
print(json.dumps(dict(candidate=str(OUT),baseFiles=len(runtimeFiles),baseReferences=len(refs),entryReferences=4,deliverySha256=sha(OUT/'delivery-pinned-manifest.json'),sequenceSha256=sha(OUT/'sequence-source-manifest.json'),liveInputsCreated=False)))
