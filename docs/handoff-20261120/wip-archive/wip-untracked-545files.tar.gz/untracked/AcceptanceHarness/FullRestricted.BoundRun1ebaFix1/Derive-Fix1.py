"""Preserve rejected candidate1; derive only the Stage reference/provenance fix."""
import pathlib,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
OLD=ROOT/'AcceptanceHarness/FullRestricted.BoundRun1eba'
CHECK=ROOT/'artifacts/aa-handoff-json-bound-1eba-20261114/candidate1/source-checkpoint.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
def once(s,a,b):
 if s.count(a)!=1:raise RuntimeError('Unique narrow fix anchor required '+a[:100])
 return s.replace(a,b)
def put(name,s):
 p=HERE/name
 if p.exists():raise RuntimeError('Fresh fix source required '+name)
 p.write_text(s,encoding='utf-8')
if sha(CHECK)!='8d7cf5bc54abaff3821d548381dd67bf2740dd324913e47bc4c4dfe6b82c5f3d':raise RuntimeError('Preserved rejected package checkpoint differs')
checkpoint=json.loads(read(CHECK))
for row in checkpoint['files']:
 p=CHECK.parent/row['path']
 if sha(p)!=row['sha256']:raise RuntimeError('Rejected package evidence changed '+row['path'])
for row in checkpoint['sources']:
 p=pathlib.Path(row['path'])
 if sha(p)!=row['sha256']:raise RuntimeError('Rejected package source changed '+str(p))
names=['Build-BoundPackage.py','Finalize-ReusedArtifact.ps1','Make-Delivery.py','ROOT-COMMANDS.template.md','RootIntent.Body.template.ps1','Test-BoundPolicy.ps1','Test-BoundConsistency.ps1','Test-BoundFailureGuards.ps1','Test-SourceOnlyDrivers.ps1','Test-CanonicalProducerConsumer.ps1','Test-ActualCaptureAdmission.ps1','Test-FreshAndAssembleConsumers.ps1']
for name in names:
 s=read(OLD/name).replace('aa-handoff-json-bound-1eba-20261114/candidate1','aa-handoff-json-bound-1eba-20261114/candidate2').replace('aa-handoff-json-bound-1eba-20261114\\candidate1','aa-handoff-json-bound-1eba-20261114\\candidate2').replace('FullRestricted.BoundRun1eba','FullRestricted.BoundRun1ebaFix1')
 if name=='Build-BoundPackage.py':
  guard_old=" $framework=Join-Path $env:WINDIR 'Microsoft.NET\\Framework64\\v4.0.30319';$compilerHash=Get-TransitionHash ([IO.File]::ReadAllBytes((Join-Path $framework 'csc.exe')));$referenceHash=Get-TransitionHash ([IO.File]::ReadAllBytes((Join-Path $framework 'System.Web.Extensions.dll')))\n Assert-Transition ($tooling.build.compilerSha256 -ceq $compilerHash -and $tooling.build.references[0].sha256 -ceq $referenceHash) 'Native build compiler/reference provenance differs from fixed Framework inputs'"
  guard_new=" $framework=Join-Path $env:WINDIR 'Microsoft.NET\\Framework64\\v4.0.30319';$compilerHash=Get-TransitionHash ([IO.File]::ReadAllBytes((Join-Path $framework 'csc.exe')));$serializationHash=Get-TransitionHash ([IO.File]::ReadAllBytes((Join-Path $framework 'System.Runtime.Serialization.dll')));$xmlHash=Get-TransitionHash ([IO.File]::ReadAllBytes((Join-Path $framework 'System.Xml.dll')))\n Assert-Transition (@($tooling.build.references).Count -eq 2 -and $tooling.build.references[0].name -ceq 'System.Runtime.Serialization.dll' -and $tooling.build.references[1].name -ceq 'System.Xml.dll' -and $tooling.build.compilerSha256 -ceq $compilerHash -and $tooling.build.references[0].sha256 -ceq $serializationHash -and $tooling.build.references[1].sha256 -ceq $xmlHash) 'Native build compiler/reference provenance differs from fixed Framework inputs'"
  insertion=" if p.name=='FullRestrictedStageTransition.psm1':\n  old_guard="+repr(guard_old)+"\n  new_guard="+repr(guard_new)+"\n  if s.count(old_guard)!=1:raise RuntimeError('Exact old Stage reference consumer absent')\n  s=s.replace(old_guard,new_guard)\n"
  s=once(s," if p.name=='Qualification.Policy.ps1':s=new_policy",insertion+" if p.name=='Qualification.Policy.ps1':s=new_policy")
  s=once(s,"shutil.copytree(BASE/'helper-build',OUT/'helper-build')","put(OUT/'helper-build/FullRestrictedStageFileSecurity.cs',(BASE/'helper-build/FullRestrictedStageFileSecurity.cs').read_bytes())")
 if name=='Finalize-ReusedArtifact.ps1':
  s=once(s,'helperRecompiled=$false;','helperRecompiled=$true;helperCSourceChanged=$false;helperCompilerProcessPath=(Join-Path $directory ''helper-compile-process.json'');')
  # Keep PowerShell literal quoting after Python's adjacent-string handling.
  s=s.replace('(Join-Path $directory helper-compile-process.json)','(Join-Path $directory \'helper-compile-process.json\')')
 put(name,s)
print('Derived candidate2 source with exact Stage two-reference consumer and unchanged helper C source.')
