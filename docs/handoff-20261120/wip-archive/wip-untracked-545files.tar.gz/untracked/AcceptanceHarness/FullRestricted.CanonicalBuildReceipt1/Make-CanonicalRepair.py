"""Create a canonical receipt from verified existing csc evidence; no compile/run."""
import pathlib,json,hashlib,zipfile,copy
ROOT=pathlib.Path(__file__).resolve().parents[2]
BASE=ROOT/'artifacts/aa-handoff-bound-bfdd-20261114/candidate2'
OUT=ROOT/'artifacts/aa-canonical-build-receipt-20261114/repair1'
RUN=ROOT/'artifacts/aa-fr-capabilities-sequence/run-bfdd50364b9049c4a58e36be683d76c8'
REL='.superpowers/sdd/azurite-authoring-20261108/bfdd-canonical-receipt-source1/result.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):
 if p.exists():raise RuntimeError('Fresh evidence required '+str(p))
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
checkpoint=BASE/'source-checkpoint.json'
if sha(checkpoint)!='c1f94c9422077b71fde046abcf1419b744f1f164fc85aa68dbb47ddd8b605bb9':raise RuntimeError('Frozen source checkpoint differs')
rows={r['path']:r for r in read(checkpoint)['files']}
needed=['native-compile-process.json','compiler-build.json','compiler-inputs.zip','composition.json','overlay/RestrictedCliNative.cs','overlay/RestrictedCliFullRestricted.cs','overlay/RestrictedCliNative.dll','overlay/tooling-manifest.json']
for name in needed:
 p=BASE/name;r=rows[name]
 if p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise RuntimeError('Frozen actual build evidence drift '+name)
process=read(BASE/'native-compile-process.json');original=read(BASE/'compiler-build.json');tooling=read(BASE/'overlay/tooling-manifest.json')
if not process['started'] or not process['exited'] or process['exitCode']!=0 or process['timedOut'] or process['terminatedOwnedPureChild'] or process['errors'] or process['stdout'] or process['stderr'] or not process['sourceOnly'] or process['nativeExecuted']:raise RuntimeError('Actual csc process was not a clean SOURCE build')
compiler=pathlib.Path(process['file']);reference=pathlib.Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll')
dll=BASE/'overlay/RestrictedCliNative.dll';archive=BASE/'compiler-inputs.zip';inputs=[BASE/'overlay/RestrictedCliNative.cs',BASE/'overlay/RestrictedCliFullRestricted.cs']
expected=['/nologo','/target:library','/platform:x64','/optimize+','/warnaserror+','/out:'+str(dll),'/r:'+str(reference)]+[str(p) for p in inputs]
if process['arguments']!=expected:raise RuntimeError('Actual csc command differs')
if sha(compiler)!=original['compilerSha256'] or sha(reference)!=original['referenceSha256'] or sha(dll)!=original['dllSha256'] or sha(archive)!=original['sourceArchiveSha256']:raise RuntimeError('Compiler/reference/output/archive do not match actual receipt')
if original['exitCode']!=0 or original['aaExecuted'] or original['nativeFixtureExecuted'] or original['stageWrites']:raise RuntimeError('Original actual build flags differ')
for p,row in zip(inputs,original['actualCompilerInputs']):
 if p.name!=row['name'] or sha(p)!=row['sha256']:raise RuntimeError('Actual compiler input differs')
with zipfile.ZipFile(archive) as z:
 if sorted(z.namelist())!=['RestrictedCliFullRestricted.cs','RestrictedCliNative.cs','composition.json']:raise RuntimeError('Actual compiler archive membership differs')
 for p in inputs+[BASE/'composition.json']:
  if z.read(p.name)!=p.read_bytes():raise RuntimeError('Actual archive input differs '+p.name)
receipt=dict(scope='canonical-SOURCE-native-build-receipt-from-actual-retained-csc-process',runId='bfdd50364b9049c4a58e36be683d76c8',dllSha256=sha(dll),sourceArchiveSha256=sha(archive),actualCompilerInputs=[dict(name=p.name,path=str(p),sha256=sha(p)) for p in inputs],compilerSha256=sha(compiler),referenceSha256=sha(reference),compositionSha256=sha(BASE/'composition.json'),exitCode=0,aaExecuted=False,cdbExecuted=False,nativeFixtureExecuted=False,stageWrites=False,actualCompilerProcess=pin(BASE/'native-compile-process.json'),actualCompilerPid=process['pid'],actualCompilerCreationFileTime=process['creationFileTime'],actualDllPath=str(dll),actualSourceArchivePath=str(archive),originalBuildReceipt=pin(BASE/'compiler-build.json'),newCompilationPerformed=False,receiptCorrectsMetadataLocationOnly=True)
canonical=ROOT/REL;write(canonical,receipt)
corrected=copy.deepcopy(tooling);corrected['build']['canonicalBuildResultPath']=REL;corrected['build']['canonicalBuildResultSha256']=sha(canonical)
manifest=OUT/'tooling-manifest.corrected.json';write(manifest,corrected)
actualInput=RUN/'complete-input.json'
if sha(actualInput)!='d5a7ef2bab3d7be034cbd9e0cc98e88a26e295af27173004ab8e6fdcf17e289e':raise RuntimeError('Actual failed CompleteInput differs')
data=read(actualInput);patched=copy.deepcopy(data);changes=[]
for row in patched['sources']:
 if row['name']=='tooling-manifest.json':
  changes.append(dict(name=row['name'],before=copy.deepcopy(row),after=dict(name=row['name'],path=str(manifest),sha256=sha(manifest))))
  row['path']=str(manifest);row['sha256']=sha(manifest)
if len(changes)!=1:raise RuntimeError('Exactly one metadata source pin must change')
replay=OUT/'complete-input.metadata-replay.json';write(replay,patched)
inverse=copy.deepcopy(patched)
for row in inverse['sources']:
 if row['name']=='tooling-manifest.json':row.update(changes[0]['before'])
if inverse!=data:raise RuntimeError('Non-metadata real input field changed')
for r in data['sources']:
 if sha(pathlib.Path(r['path']))!=r['sha256']:raise RuntimeError('Original actual source pin drift '+r['name'])
inputPins=[data['baseline']['identity'],data['baseline']['capture'],data['harmless'],data['preflight'],data['shared']['scope'],data['shared']['before'],data['originalIdentity'],data['helperSource']]
for r in inputPins:
 if sha(pathlib.Path(r['path']))!=r['sha256']:raise RuntimeError('Actual observation/input drift '+r['path'])
evidence=[]
for name in ['sequence-result.json','complete-input.json','Capture-child-result.json','Capture-child-ownership.json','Warm-child-result.json','Warm-child-ownership.json','Assemble-child-result.json','Assemble-child-ownership.json']:evidence.append(pin(RUN/name))
write(OUT/'repair-provenance.json',dict(scope='canonical build receipt and metadata-only production assembler replay package',canonicalReceipt=pin(canonical),correctedTooling=pin(manifest),originalTooling=pin(BASE/'overlay/tooling-manifest.json'),actualCompilerProcess=pin(BASE/'native-compile-process.json'),actualDll=pin(dll),actualArchive=pin(archive),originalCompleteInput=pin(actualInput),replayInput=pin(replay),sourcePinChanges=changes,allOtherInputFieldsEqual=True,originalIntentValidUntilUtc=data['intentValidUntilUtc'],freshTimeFieldsEdited=False,actualInputReferences=inputPins,actualFailedSequenceEvidence=evidence,newCompilationPerformed=False,nativeCodeChanged=False,newRunIdSelected=False,liveContinuationAuthorized=False,executeEntryProvided=False))
print(json.dumps(dict(canonicalReceiptPath=str(canonical),canonicalReceiptSha256=sha(canonical),toolingSha256=sha(manifest),replayInputSha256=sha(replay),nativeDllSha256=sha(dll),newCompilationPerformed=False,freshTimesChanged=False)))
