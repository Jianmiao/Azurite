param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$assembler=Join-Path $repo 'artifacts\aa-handoff-bound-bfdd-20261114\candidate2\overlay\New-AzuriteFullCapabilitiesInputs.ps1';$repair=Join-Path $repo 'artifacts\aa-canonical-build-receipt-20261114\repair1'
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh receipt field controls required'}
if((Get-FileHash $assembler).Hash.ToLowerInvariant() -cne 'f387c3327ccd1252457b30076b74ea4157a0de704626924cce20a4a5cbf7b42c'){throw 'Frozen production assembler changed'}
$t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($assembler,[ref]$t,[ref]$e);if($e.Count){throw 'Frozen assembler parse errors'}
$def=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Assert-Inputs'},$false))[0];. ([scriptblock]::Create($def.Extent.Text))
$calls=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -ceq 'Assert-Inputs' -and $n.CommandElements[-1].Extent.Text -ceq "'Accepted native build result differs from pinned source/assembly'"},$true));if($calls.Count -ne 1){throw 'Exact actual receipt field assertion missing'}
$assertion=[scriptblock]::Create($calls[0].Extent.Text);$tooling=Get-Content -LiteralPath (Join-Path $repair 'tooling-manifest.corrected.json') -Raw|ConvertFrom-Json -DateKind String
$canonical=Join-Path $repo $tooling.build.canonicalBuildResultPath;$raw=Get-Content -LiteralPath $canonical -Raw;$rows=@()
foreach($case in @('valid','wrong-dll','wrong-archive','aa-true','native-fixture-true','stage-write-true','missing-native-fixture')){
 $nativeResult=$raw|ConvertFrom-Json -DateKind String
 switch($case){'wrong-dll'{$nativeResult.dllSha256='0'*64};'wrong-archive'{$nativeResult.sourceArchiveSha256='0'*64};'aa-true'{$nativeResult.aaExecuted=$true};'native-fixture-true'{$nativeResult.nativeFixtureExecuted=$true};'stage-write-true'{$nativeResult.stageWrites=$true};'missing-native-fixture'{$nativeResult.PSObject.Properties.Remove('nativeFixtureExecuted')}}
 $errorText=$null;try{. $assertion}catch{$errorText=$_.Exception.Message}
 $okay=if($case -eq 'valid'){$null -eq $errorText}elseif($case -eq 'missing-native-fixture'){$errorText -like '*nativeFixtureExecuted*'}else{$errorText -ceq 'Accepted native build result differs from pinned source/assembly'}
 $rows+=,[pscustomobject]@{case=$case;passed=$okay;refused=($null -ne $errorText);error=$errorText}
}
$r=[ordered]@{scope='actual frozen production assembler receipt-field assertion, isolated in-memory negative controls';passed=(@($rows|Where-Object {-not $_.passed}).Count -eq 0);tests=$rows;assemblerSha256=(Get-FileHash $assembler).Hash.ToLowerInvariant();canonicalReceiptSha256=(Get-FileHash $canonical).Hash.ToLowerInvariant();invalidReceiptsWritten=$false;productionValidationRelaxed=$false;FReadPerformed=$false;FWritePerformed=$false;nativeExecuted=$false}
[IO.File]::WriteAllText($ResultPath,($r|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false));$r|ConvertTo-Json -Depth 10;if(-not $r.passed){exit 1}
