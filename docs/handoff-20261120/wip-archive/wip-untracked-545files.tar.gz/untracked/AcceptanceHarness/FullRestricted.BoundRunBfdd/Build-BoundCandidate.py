"""Derive fixed bfdd SOURCE only from candidate3; never read F or run native code."""
import pathlib,hashlib,json,re,difflib,zipfile,shutil
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114/candidate3'
OUT=ROOT/'artifacts/aa-handoff-bound-bfdd-20261114/candidate2'
RUN='bfdd50364b9049c4a58e36be683d76c8'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8') if isinstance(s,str) else s)
def js(p,v):put(p,json.dumps(v,ensure_ascii=False,indent=2))
checkpoint=BASE/'source-checkpoint.json'
if sha(checkpoint)!='e0a77596152bb6d76fd15df3ad59500d288c86eaeb804bb0448f83ee8e825fad':raise RuntimeError('Frozen candidate3 checkpoint differs')
for row in json.loads(read(checkpoint))['files']:
 p=BASE/row['path']
 if p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise RuntimeError('Frozen candidate3 member drift '+row['path'])
ioRoot=ROOT/'artifacts/root-ps7-io-20261114/actual-io-root-readback.json'
if sha(ioRoot)!='73841f6e095633f9cc9baa799e6b53185f00787583b0edf08ebd50586e3f63a5':raise RuntimeError('Root actual IO readback differs')
io=json.loads(read(ioRoot));ioPins=[]
if io['nativeHandoffAcceptance'] or io['AAExecuted'] or io['nextActualRunIdSelected']!=RUN:raise RuntimeError('IO proof or Root run selection differs')
for host in io['hosts']:
 p=pathlib.Path(host['resultPath']);r=json.loads(read(p))
 if sha(p)!=host['resultSha256'] or not r['passed'] or r['error'] or len(r['checks'])!=16 or host['naturalExitCode']!=0 or not host['actualDirectoryAndFileAclsRechecked']:raise RuntimeError('Root actual host IO result is not qualified')
 ioPins.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,host=host['host']))
if sorted(h['host'] for h in ioPins)!=['ps51','ps7']:raise RuntimeError('Both actual hosts required')
if OUT.exists():raise RuntimeError('Fresh bound candidate required')
OUT.mkdir(parents=True);components=[];diff=[];usings=set();bodies=[]
for p in sorted((BASE/'components').glob('*.cs')):
 before=read(p);s=before
 if p.name=='CdbToolcheck.Policy.cs':
  old='\\'+str(BASE.relative_to(ROOT))+'\\native-evidence';new='\\'+str(OUT.relative_to(ROOT))+'\\native-evidence'
  if s.count(old)!=1:raise RuntimeError('Exact evidence constant anchor differs')
  s=s.replace(old,new)
  if s.replace(new,old)!=before:raise RuntimeError('Evidence-only inverse differs')
 put(OUT/'components'/p.name,s)
 components.append(dict(name=p.name,baseSha256=sha(p),boundSha256=hashlib.sha256(s.encode()).hexdigest(),unchanged=(s==before),change=('unique C evidence directory only' if s!=before else None)))
 diff+=list(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='candidate3/components/'+p.name,tofile='bound/components/'+p.name))
 if p.name=='RestrictedCliNative.cs':put(OUT/'overlay'/p.name,s);continue
 at=re.search(r'\bnamespace\s+',s);header=s[:at.start()];usings.update(re.findall(r'\busing\s+[^;]+;',header));bodies.append('// COMPONENT '+p.name+'\n'+s[at.start():].rstrip()+'\n')
full='// Truthful second compiler input; component bytes and composition are separately recorded.\n'+'\n'.join(sorted(usings))+'\n'+'\n'.join(bodies)
put(OUT/'overlay/RestrictedCliFullRestricted.cs',full)
if len([x for x in components if x['unchanged']])!=17:raise RuntimeError('Only evidence binding may change a component')
js(OUT/'composition.json',dict(scope='root-selected-bfdd-two-input-bound-composition',runId=RUN,baseCheckpointSha256=sha(checkpoint),components=components,actualCompilerInputs=['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs'],rootRunIdAssigned=True,sourceOnly=True,nativeExecuted=False))
beforePolicy=read(BASE/'overlay/Qualification.Policy.ps1')
guard=' throw "SOURCE/BUILD candidate is unbound; Root must assign and review a fresh actual RunId"\n'
if beforePolicy.count(guard)!=1:raise RuntimeError('Exact unbound guard absent')
oldFull=sha(BASE/'overlay/RestrictedCliFullRestricted.cs');oldComposition=sha(BASE/'composition.json')
if beforePolicy.count(oldFull)!=1 or beforePolicy.count(oldComposition)!=1:raise RuntimeError('Exact parent policy source/composition pins differ')
policy=beforePolicy.replace(guard,'').replace('@ROOT_RUN_ID@',RUN).replace(str(BASE),str(OUT)).replace(oldFull,sha(OUT/'overlay/RestrictedCliFullRestricted.cs')).replace(oldComposition,sha(OUT/'composition.json'))
for p in sorted((BASE/'overlay').iterdir()):
 if p.name in ['RestrictedCliNative.dll','tooling-manifest.json','RestrictedCliNative.cs','RestrictedCliFullRestricted.cs']:continue
 before=read(p);s=before.replace(beforePolicy,policy).replace(str(BASE),str(OUT)).replace(str(BASE.relative_to(ROOT)),str(OUT.relative_to(ROOT))).replace('@ROOT_RUN_ID@',RUN)
 if p.name=='Qualification.Policy.ps1':s=policy
 if guard in s or '@ROOT_RUN_ID@' in s or '0e494be63f3248ffb7bd7bbd040987f8' in s:raise RuntimeError('Old/unbound run authorization remains '+p.name)
 put(OUT/'overlay'/p.name,s);diff+=list(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='candidate3/overlay/'+p.name,tofile='bound/overlay/'+p.name))
diff+=list(difflib.unified_diff(read(BASE/'overlay/RestrictedCliFullRestricted.cs').splitlines(True),full.splitlines(True),fromfile='candidate3/overlay/RestrictedCliFullRestricted.cs',tofile='bound/overlay/RestrictedCliFullRestricted.cs'))
put(OUT/'candidate3-to-bound.diff',''.join(diff));shutil.copytree(BASE/'helper-build',OUT/'helper-build')
helper=json.loads(read(OUT/'helper-build/build.json'))
if helper['moduleSha256']!=sha(OUT/'overlay/FullRestrictedStageTransition.psm1') or helper['assemblySha256']!=sha(OUT/'helper-build/FullRestrictedStageFileSecurity.dll'):raise RuntimeError('Unchanged stage helper binding differs')
portable=OUT/'components/PortableAclIo.cs'
if sha(portable)!='9a1f91a43b2dca8ef21f2720ac4e842cd9f62d462312c1c3cfbede0bc3d420d7':raise RuntimeError('Actually IO-tested portable component changed')
js(OUT/'io-qualification-binding.json',dict(scope='new source binding to Root actual C IO proof for unchanged portable component and callsites',runId=RUN,rootReadback=dict(path=str(ioRoot),sha256=sha(ioRoot),bytes=ioRoot.stat().st_size),actualHostResults=ioPins,originalTestedDllSha256=io['candidate3DllSha256'],portableComponentSha256=sha(portable),unchangedComponentCount=17,newDllActuallyIoTested=False,AAExecuted=False,nativeHandoffAcceptance=False,limitations=['Root actual C IO qualified candidate3 DLL on both hosts.','This bound build preserves the exact portable IO component and both callsites; only C debugger evidence location changes in C#.', 'New AA/handoff execution is still unperformed.']))
with zipfile.ZipFile(OUT/'compiler-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs']:z.write(OUT/'overlay'/name,arcname=name)
 z.write(OUT/'composition.json',arcname='composition.json')
js(OUT/'derivation.json',dict(runId=RUN,base=str(BASE),baseCheckpointSha256=sha(checkpoint),fullSha256=sha(OUT/'overlay/RestrictedCliFullRestricted.cs'),sharedSha256=sha(OUT/'overlay/RestrictedCliNative.cs'),compositionSha256=sha(OUT/'composition.json'),nativeCandidateExecuted=False,baselineCaptureCreated=False,freshCaptureCreated=False,stageRead=False,stageWrite=False))
print(json.dumps(dict(candidate=str(OUT),runId=RUN,unchangedComponents=17,sourceOnly=True)))
