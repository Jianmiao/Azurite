#requires -Version 7.0
[CmdletBinding(DefaultParameterSetName='Materialize')]
param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256,
 [Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedSourceManifestSha256,
 [Parameter(Mandatory,ParameterSetName='Materialize')][string]$BaselineCapturePath,[Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedBaselineCaptureSha256,[Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedBaselineIdentitySha256,
 [Parameter(Mandatory,ParameterSetName='Materialize')][string]$HarmlessReceiptPath,[Parameter(Mandatory,ParameterSetName='Materialize')][string]$ExpectedHarmlessReceiptSha256,[string]$IntentValidUntilUtc,
 [Parameter(Mandatory,ParameterSetName='SourcesOnly')][switch]$VerifySourcesOnly)

$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$candidate=[IO.Path]::GetFullPath($CandidateDirectory)
if([IO.Path]::GetDirectoryName($candidate) -cne (Join-Path $repo 'artifacts\aa-handoff-bound-bfdd-20261114')){throw 'Exact C bfdd bound candidate required'}
function Assert-QualificationPinnedDelivery([string]$Directory,[string]$ExpectedDigest,[string]$ExecutingDriver) {
 function Digest([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
 function PlainFile([string]$path,[long]$bytes,[string]$hash){
  $full=[IO.Path]::GetFullPath($path)
  if($full -cne $path -or -not $full.StartsWith('C:\',[StringComparison]::Ordinal) -or $hash -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Pinned source must be exact C path and SHA-256'}
  $cursor=$full;while($cursor){$item=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop;if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Pinned source reparse ancestry refused'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
  $item=Get-Item -LiteralPath $full -Force
  if($item.PSIsContainer -or $item.Length -ne $bytes -or (Digest $full) -cne $hash){throw ('Frozen delivery member drift: '+$full)}
 }
 $manifestPath=Join-Path $Directory 'delivery-pinned-manifest.json'
 if($ExpectedDigest -cnotmatch '\A[a-f0-9]{64}\z' -or $ExpectedDigest -ceq ('0'*64) -or (Digest $manifestPath) -cne $ExpectedDigest){throw 'Externally expected pinned delivery digest differs'}
 $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json -DateKind String
 if($manifest.schema -ne 1 -or $manifest.scope -cne 'fixed-bfdd-qualification-pinned-delivery' -or $manifest.runId -cne 'bfdd50364b9049c4a58e36be683d76c8'){throw 'Pinned delivery scope/run differs'}
 $basePath=Join-Path $Directory 'delivery-manifest.json'
 if($manifest.baseDelivery.path -cne $basePath){throw 'Base candidate delivery path differs'}
 PlainFile $basePath $manifest.baseDelivery.bytes $manifest.baseDelivery.sha256
 $base=Get-Content -LiteralPath $basePath -Raw|ConvertFrom-Json -DateKind String
 if($base.schema -ne 1 -or $base.scope -cne 'actual-AA-no-trace-qualification-C-source-driver-delivery' -or $base.runId -cne $manifest.runId -or @($base.files).Count -ne 57 -or @($base.references).Count -ne 58){throw 'Frozen base candidate delivery closure differs'}
 $driver=@($manifest.references|Where-Object role -CEQ RootIntent)
 if($driver.Count -ne 1 -or $driver[0].path -cne $ExecutingDriver){throw 'Executing failure binder is not the reviewed external reference'}
 $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($entry in @($base.files)+@($manifest.files)){
  $path=[IO.Path]::GetFullPath((Join-Path $Directory $entry.path))
  if(-not $path.StartsWith($Directory+'\',[StringComparison]::Ordinal) -or -not $seen.Add($path)){throw 'Pinned member escaped or duplicated its candidate scope'}
  PlainFile $path $entry.bytes $entry.sha256
 }
 foreach($entry in @($base.references)+@($manifest.references)){
  if(-not $seen.Add($entry.path)){throw 'Pinned external reference duplicated'}
  PlainFile $entry.path $entry.bytes $entry.sha256
 }
 return [pscustomobject]@{manifestPath=$manifestPath;manifestSha256=$ExpectedDigest;baseDeliverySha256=$manifest.baseDelivery.sha256;verifiedMemberCount=$seen.Count;verifiedBeforeModuleLoad=$true}
}
$frozenDelivery=Assert-QualificationPinnedDelivery $candidate $ExpectedDeliveryManifestSha256 $PSCommandPath
if($VerifySourcesOnly){[pscustomobject]@{scope='bound-intent-source-check-only';sourcesVerified=$true;delivery=$frozenDelivery;moduleLoaded=$false;runtimeEvidenceRead=$false;baselineCreated=$false;FReadPerformed=$false;FWritePerformed=$false}|ConvertTo-Json -Depth 6;return}
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadPin([string]$p,[string]$h,[long]$limit=4194304){
 $full=[IO.Path]::GetFullPath($p);if($full -cne $p -or -not $full.StartsWith($repo+'\',[StringComparison]::Ordinal) -or $h -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Exact C input and externally expected SHA required'}
 $cursor=$full;while($cursor){$i=Get-Item -LiteralPath $cursor -Force;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'C input reparse ancestry refused'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
 $item=Get-Item -LiteralPath $full;if($item.PSIsContainer -or $item.Length -gt $limit -or (Hash $full) -cne $h){throw 'Actual C input bytes differ'}
 return (Get-Content -LiteralPath $full -Raw|ConvertFrom-Json -DateKind String)
}
$run='bfdd50364b9049c4a58e36be683d76c8';$sources=Join-Path $candidate 'sequence-source-manifest.json';$null=ReadPin $sources $ExpectedSourceManifestSha256
$b=ReadPin $BaselineCapturePath $ExpectedBaselineCaptureSha256 1048576;$identityPath=Join-Path (Split-Path -Parent $BaselineCapturePath) 'identity-baseline.json';$bi=ReadPin $identityPath $ExpectedBaselineIdentitySha256
if($b.schema -ne 1 -or $b.scope -cne 'read-only-stage-baseline-capture' -or $b.runId -cne $run -or $b.success -ne $true -or $b.observedObjects -ne 1228 -or $b.lease.state -cne 'released' -or $b.error -or $b.willWriteF -or $b.runtimeAllowed -or $b.launchPermission -or $b.baselineSha256 -cne $ExpectedBaselineIdentitySha256 -or $bi.schema -ne 1 -or $bi.scope -cne 'preapproval-stage-object-identities' -or $bi.runId -cne $run -or @($bi.objects).Count -ne 1228){throw 'Actual completed same-run baseline is missing or differs; old-run inputs are forbidden'}
$h=ReadPin $HarmlessReceiptPath $ExpectedHarmlessReceiptSha256 131072
. (Join-Path $candidate 'overlay\Qualification.Policy.ps1')
$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run
if($ExpectedHarmlessReceiptSha256 -cne $q.harmlessReceiptSha256 -or -not (Test-AzuriteNoTraceHarmlessBinding $h $q $q.nativeSourceSha256 $q.sharedNativeSourceSha256 $ExpectedHarmlessReceiptSha256)){throw 'Actual reviewed CF95 harmless baseline binding differs; no new harmless proof is synthesized'}
if(-not $IntentValidUntilUtc){$IntentValidUntilUtc=[datetime]::UtcNow.AddMinutes(9).ToString('yyyy-MM-ddTHH:mm:ssZ')}
if($IntentValidUntilUtc -cnotmatch '\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\z' -or [datetimeoffset]::Parse($IntentValidUntilUtc) -le [datetimeoffset]::UtcNow){throw 'Fresh explicit future intent expiry required'}
$inputRecord=[ordered]@{schema=1;scope='root-authorized-one-capabilities-sequence';runId=$run;baselineCapture=[ordered]@{path=$BaselineCapturePath;sha256=$ExpectedBaselineCaptureSha256};harmless=[ordered]@{path=$HarmlessReceiptPath;sha256=$ExpectedHarmlessReceiptSha256};intentValidUntilUtc=$IntentValidUntilUtc;runtimeTimeoutSeconds=30;sourcesSha256=$ExpectedSourceManifestSha256;noTraceQualification='actual-aa-debugger-no-trace-qualification.v1'}
$folder=Join-Path $candidate 'root-intents';[void][IO.Directory]::CreateDirectory($folder);$path=Join-Path $folder ([guid]::NewGuid().ToString('N')+'.json')
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($inputRecord|ConvertTo-Json -Depth 6));$stream=[IO.File]::Open($path,'CreateNew','Write','Read');try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
[pscustomobject]@{RunId=$run;EntryPath=(Join-Path $candidate 'overlay\Invoke-AzuriteCapabilitiesSequence.ps1');InputRecordPath=$path;ExpectedInputRecordSha256=(Hash $path);ReviewedSourcesPath=$sources;ExpectedReviewedSourcesSha256=$ExpectedSourceManifestSha256;ExpectedReviewedBaselineSha256=$ExpectedBaselineIdentitySha256;delivery=$frozenDelivery;freshCapturePerformed=$false;baselineCreated=$false;stageRead=$false;stageWrite=$false;aaExecuted=$false;executeAddsOneActualNativeAttempt=$true}|ConvertTo-Json -Depth 6
