using BepInEx;
using BepInEx.Unity.IL2CPP;
using AzureArchive.Automation;
using Azurite.EditorIsolation;
using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Adapter.Host;
using Azurite.NormalEditor.Entry;
using Azurite.NormalEditor.Entry.Host;
using Azurite.NormalEditor.Entry.Evidence;
using System.Diagnostics;
using System.Reflection;

namespace Azurite.NormalEditor.Loader;

[BepInPlugin("lab.azurite.normal-editor.loader","Azurite Normal Editor Loader PREPARATION ONLY","0.1.0")]
public sealed class NormalLoaderPlugin : BasePlugin
{
    private static NormalLoaderLifetime? lifetime;
    private static CorrelatedEvidence? routingEvidence;
    public override void Load()
    {
        NormalGuardSession? session=null;
        try{
            string install=Path.Combine(InstallationAuthority.ApprovedLabRoot,"install");
            NormalDeployment.RequireLoaded(install,NormalDeployment.PluginNames.Append("Azurite.NormalEditor.Loader.Guard.PreparationOnly"));
            var guard=AppDomain.CurrentDomain.GetAssemblies().Single(a=>a.GetName().Name=="Azurite.NormalEditor.Loader.Guard.PreparationOnly");
            session=(NormalGuardSession)(guard.GetType("Azurite.NormalEditor.Loader.Guard.NormalStartupGuard",true)!.GetMethod("GetSession",BindingFlags.Public|BindingFlags.Static)!.Invoke(null,null)??throw new InvalidOperationException("Guard session absent."));
            session.ClaimLoader();var prepared=session.Preparation;var manifest=prepared.Manifest;
            string Pin(string name)=>prepared.Facts.Files.Single(p=>p.RelativePath==Path.Combine(InstallationAuthority.AdapterSubdirectory,name+".dll")).Sha256;
            var binding=new AdapterBinding(new(manifest.RunId,1,session.Owner.ProcessId,session.Owner.NativeThreadId,manifest.Paths,manifest.SeedSha256,manifest.ControlSha256,"lab-read-"+manifest.RunId),prepared.Facts.ExpectedNativeSettingsPath){HostAssemblySha256=Pin("Azurite.NormalEditor.Adapter.Host.PreparationOnly"),CoreAssemblySha256=Pin("Azurite.NormalEditor.Adapter.Core.PreparationOnly")};
            var routeAssembly=AppDomain.CurrentDomain.GetAssemblies().Single(a=>a.GetName().Name=="Azurite.NormalEditor.Loader.Routes.PreparationOnly");
            var routeType=routeAssembly.GetType("Azurite.NormalEditor.Loader.Routes.NormalRoutes",true)!;
            var routes=(INormalRoutes)(Activator.CreateInstance(routeType)??throw new InvalidOperationException("Actual normal route installer is absent."));
            var environment=new LiveEnvironment(prepared);
            routingEvidence=new CorrelatedEvidence(prepared.BoundManifest,"editor-isolation-evidence.jsonl");
            var admission=new NormalEntryAdmission(binding,prepared.BoundManifest.Sha256,prepared.EvidenceSha256,session.Owner,prepared.Facts.Resources.Preparation,environment,routes,session,r=>routingEvidence.Emit("normal-settings-route",r));
            admission.RequirePreNativeInstallation(binding);
            var clock=CatalogClockAnchor.Capture();var identity=new CatalogRunIdentity(new(manifest.RunId,session.Owner.ProcessId,session.Owner.ManagedThreadId,session.Owner.NativeThreadId,120000),new DateTimeOffset(DateTime.FromFileTimeUtc(session.Owner.ProcessCreationFileTime)),clock.ObserverStartedUtc);
            var writer=CatalogEvidenceWriter.CreateNew(Path.Combine(manifest.Paths.Output,"normal-catalog-evidence.jsonl"),identity,binding.Policy);
            var created=new NormalLoaderLifetime(binding,admission,session.Owner,prepared.Facts.Resources.Preparation,routes,session,session,prepared.BoundManifest.Sha256,clock,writer,
                (b,a)=>NativeAdapterHost.Register(b,a),
                (b,a,record,anchor)=>CatalogEntryHost.Register(b,a,Pin("Azurite.NormalEditor.Entry.Host.PreparationOnly"),Pin("Azurite.NormalEditor.Entry.Core.PreparationOnly"),record,anchor,120000),
                CatalogEntryHost.Close);
            created.Register();lifetime=created;
        }catch(Exception error){
            if(session is not null)session.Terminate("Normal Loader.Load failed: "+error.GetBaseException().Message);
            // BepInEx catches plugin exceptions. Exact normal-child failures must
            // not silently return to native startup with missing containment.
            using var process=Process.GetCurrentProcess();if(RunPaths.Same(process.MainModule?.FileName,Path.Combine(InstallationAuthority.ApprovedLabRoot,"install","AzureArchive.exe")))OwnProcessAbort.Terminate(86);
            throw;
        }
    }
    // Called explicitly by the separately admitted owner-thread shutdown path.
    // Ready/Record/Load never call this; it does not Quit or prove process exit.
    public static bool Close()=>lifetime?.Close()??false;
    private sealed class LiveEnvironment : INormalAdmissionEnvironment
    {
        private readonly NormalPreparation prepared;
        internal LiveEnvironment(NormalPreparation prepared)=>this.prepared=prepared;
        public NormalHostObservation Observe()
        {
            var actual=ObserveProcess();
            return new(actual.Identity,actual.Arguments,AuthoringCliHost._IsActive_k__BackingField,actual.CliTransportPresent);
        }
        public NormalProcessObservation ObserveProcess()
        {
            using var process=Process.GetCurrentProcess();
            var owner=new NormalOwnerIdentity(process.Id,process.StartTime.ToUniversalTime().ToFileTimeUtc(),Environment.CurrentManagedThreadId,NormalGuardRuntime.NativeThreadId(),process.MainModule?.FileName??throw new InvalidOperationException("Actual executable path absent."),typeof(NormalLoaderPlugin).Assembly.Location);
            return new(owner,Environment.GetCommandLineArgs(),!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("AZUREARCHIVE_CLI_DIRECTORY")));
        }
        public void RequireUnchanged(){prepared.RequireUnchanged();NormalDeployment.RequireLoaded(prepared.Manifest.InstallRoot,NormalDeployment.PluginNames.Append("Azurite.NormalEditor.Loader.Guard.PreparationOnly"));}
    }
}
