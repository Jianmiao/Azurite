param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
function Clone($x){$x|ConvertTo-Json -Depth 30|ConvertFrom-Json}
function NewCase([string]$mode){
 $attached=$mode -ceq 'attached';$status=if($attached){0}else{4294967295};$flag=if($attached){1}else{0};$run='1234567890abcdef1234567890abcdef'
 $s=[pscustomobject]@{protocol='fixed-nt-errors.v1';runId=$run;pid=42;nativeThreadId=43;mode=$mode;tokenFlags=1;prepareStatus=0;abi=1;bytes=232;prepared=1;rejected=0;threadCountBefore=1;threadCountAfter=1;resolveStatus=0;snapshotBeforeStatus=0;snapshotAfterStatus=0;beginStatus=$status;updateStatus=$status;commitStatus=$status;abortStatus=4294967295;transactionStarted=$flag;transactionCommitted=$flag;abortAttempted=0;atomicThreadFreezeClaimed=$false;onlineDetachCalled=$false;attach=@(0..7|ForEach-Object{[pscustomobject]@{api=$_;status=$status;original=1000+100*$_;trampoline=$(if($attached){2000+100*$_}else{1000+100*$_})}})}
 function Window($id,$capacity,$begin){[pscustomobject]@{id=$id;openCalls=1;closeCalls=1;valid=1;ownerThread=43;sequence=0;dropped=0;reentrant=0;used=0;capacity=$capacity;beginQpc=$begin;endQpc=$begin+10;counts=@(0..7|ForEach-Object{[pscustomobject]@{api=$_;calls=0;success=0;nonSuccess=0}});events=@()}}
 $r=[pscustomobject]@{protocol='fixed-nt-errors.v1';runId=$run;pid=42;nativeThreadId=43;mode=$mode;enabled=$flag;activeWindow=0;eventBytes=64;objectPointersDereferenced=$false;objectNamesRead=$false;stackCaptured=$false;onlineDetachCalled=$false;target='explicit-sta-probe/seed=0/direct-com';eventColumns=@('sequence','api','status','severity','lastError','access','a','b','c','d','subject','attributes','caller','module','rva');modules=@('unresolved','ntdll.dll','kernelbase.dll','kernel32.dll','combase.dll','ole32.dll','rpcrt4.dll','coreclr.dll','WaitNative.dll','AzuriteLifecycleProbe.exe');proof=(Window 1 16 100);sta=(Window 2 128 200)}
 if($attached){$r.proof.counts[3].calls=9;$r.proof.counts[3].success=1;$r.proof.counts[3].nonSuccess=8;$r.proof.sequence=9;$r.proof.used=8;$r.proof.events=@(1..8|ForEach-Object{,@($_,3,-1073741790,3,5,2,0,0,0,0,0,123,12345,1,100)});$r.sta.counts[7].calls=1;$r.sta.counts[7].nonSuccess=1;$r.sta.sequence=1;$r.sta.used=1;$r.sta.events=@(,@(1,7,-1073741700,3,1008,8,1,0,0,0,456,0,23456,4,200))}
 [pscustomobject]@{startup=$s;report=$r;mode=$mode;run=$run}
}
$names=@('control-valid','attached-valid','target-zero-calls','expected-no-token-preserved','dropped-full','reentrant','wrong-mode','flags9','wrong-child','multi-thread-before','multi-thread-after','no-commit','partial-attach','duplicate-original','control-trampoline','control-fake-calls','unclosed-window','repeated-window','active-window','wrong-thread','bad-qpc','wrong-capacity','extra-record','drop-with-room','count-mismatch','wrong-order','success-recorded','wrong-severity','wrong-api','short-record','oversized-scalar','unresolved-rva','invented-module','no-success-proof','too-few-denials','names-read','stack-read','online-detach','atomic-freeze-claim','wrong-columns')
$results=@();foreach($name in $names){$mode=if($name.StartsWith('control-')){'control'}else{'attached'};$f=NewCase $mode;$s=$f.startup;$r=$f.report;$expected=$name -in @('control-valid','attached-valid','target-zero-calls','expected-no-token-preserved','dropped-full','reentrant');$coverage=$name -notin @('dropped-full','reentrant')
 switch($name){
  target-zero-calls {$r.sta.counts[7].calls=0;$r.sta.counts[7].nonSuccess=0;$r.sta.sequence=0;$r.sta.used=0;$r.sta.events=@()}
  dropped-full {$r.sta.events=@(1..128|ForEach-Object{,@($_,7,-1073741700,3,1008,8,1,0,0,0,456,0,23456,4,200)});$r.sta.used=128;$r.sta.dropped=1;$r.sta.sequence=129;$r.sta.counts[7].calls=129;$r.sta.counts[7].nonSuccess=129}
  reentrant {$r.sta.reentrant=1}
  wrong-mode {$s.mode='control'}
  flags9 {$s.tokenFlags=9}
  wrong-child {$r.pid=44}
  multi-thread-before {$s.threadCountBefore=2}
  multi-thread-after {$s.threadCountAfter=2}
  no-commit {$s.transactionCommitted=0}
  partial-attach {$s.attach[3].status=5}
  duplicate-original {$s.attach[1].original=$s.attach[0].original}
  control-trampoline {$s.attach[1].trampoline=999}
  control-fake-calls {$r.sta.counts[0].calls=1;$r.sta.counts[0].success=1;$r.sta.sequence=1}
  unclosed-window {$r.sta.closeCalls=0}
  repeated-window {$r.sta.openCalls=2}
  active-window {$r.activeWindow=2}
  wrong-thread {$r.sta.ownerThread=44}
  bad-qpc {$r.sta.endQpc=1}
  wrong-capacity {$r.sta.capacity=256}
  extra-record {$r.sta.events+=,@(2,7,-1073741700,3,1008,8,1,0,0,0,456,0,23456,4,200)}
  drop-with-room {$r.sta.dropped=1;$r.sta.counts[7].calls=2;$r.sta.counts[7].nonSuccess=2;$r.sta.sequence=2}
  count-mismatch {$r.sta.counts[7].calls=2}
  wrong-order {$r.proof.events[1][0]=1}
  success-recorded {$r.sta.events[0][2]=0}
  wrong-severity {$r.sta.events[0][3]=2}
  wrong-api {$r.sta.events[0][1]=8}
  short-record {$r.sta.events=@(,@(1,7,-1073741700))}
  oversized-scalar {$r.sta.events[0][4]=4294967296}
  unresolved-rva {$r.sta.events[0][13]=0}
  invented-module {$r.sta.events[0][13]=10}
  no-success-proof {$r.proof.counts[3].success=0;$r.proof.counts[3].calls=8;$r.proof.sequence=8}
  too-few-denials {$r.proof.events[0][2]=-1073741700}
  names-read {$r.objectNamesRead=$true}
  stack-read {$r.stackCaptured=$true}
  online-detach {$r.onlineDetachCalled=$true}
  atomic-freeze-claim {$s.atomicThreadFreezeClaimed=$true}
  wrong-columns {$r.eventColumns[0]='other'}
 }
 $passed=$false;$err=$null;try{$a=Assert-FixtureNtObserver $s $r $mode $f.run 42 43;$passed=$expected -and $a.completed -and $a.coverageCompleteForSelectedWindow -eq $coverage -and -not $a.firstFailureIsRootCauseClaimed -and -not $a.applicationAccepted}catch{$err=$_.Exception.Message;$passed=-not $expected};$results+=,[pscustomobject]@{name=$name;passed=$passed;error=$err}
}
# The compact format remains bounded even with every event field at its widest
# JSON number; this constructs records only and calls no native observer code.
$wide=NewCase 'attached';$wide.report.proof.events=@(1..16|ForEach-Object{,@([uint64]::MaxValue,7,-2147483648,3,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,[uint64]::MaxValue,[uint64]::MaxValue,[uint64]::MaxValue,9,[uint64]::MaxValue)});$wide.report.sta.events=@(1..128|ForEach-Object{,@([uint64]::MaxValue,7,-2147483648,3,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,[uint64]::MaxValue,[uint64]::MaxValue,[uint64]::MaxValue,9,[uint64]::MaxValue)});$wideBytes=[Text.Encoding]::UTF8.GetByteCount(($wide.report|ConvertTo-Json -Compress -Depth 30));$results+=,[pscustomobject]@{name='full-capacity-compact-json-bound';passed=($wideBytes -lt 32768);error=$null}
$result=[ordered]@{scope='synthetic observer consumer and compact serialization checks only';passed=(@($results|Where-Object{-not $_.passed}).Count -eq 0);checks=$results.Count;maximumNumericRecordBytes=$wideBytes;results=$results;nativeExecuted=$false;registryAccessed=$false;AAExecuted=$false;host=$PSVersionTable.PSVersion.ToString()};if(Test-Path -LiteralPath $OutputPath){throw 'Preserve prior synthetic evidence'};[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));[pscustomobject]$result|Select-Object passed,checks,maximumNumericRecordBytes,host|ConvertTo-Json;if(-not $result.passed){exit 1}
