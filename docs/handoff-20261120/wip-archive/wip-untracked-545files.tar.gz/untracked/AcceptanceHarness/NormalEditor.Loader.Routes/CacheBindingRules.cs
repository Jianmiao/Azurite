using Azurite.CacheRootLab;
using Azurite.EditorIsolation;
using Azurite.NormalEditor.Adapter;

namespace Azurite.NormalEditor.Loader.Routes;

public static class CacheBindingRules
{
    public const string CoreSha256="32ac8c188e676779c371d628c96c493ec8f7866da04e17e014a92f97895c8ed7";
    public static string DefaultCachePath(RunPaths paths)=>Path.Combine(paths.Run,"unity-knownfolder","Unity","foxxlight_AzureArchive");
    private static void Need(bool value,string why){if(!value)throw new InvalidOperationException(why);}
    public static void RequireHost(AdapterBinding binding,string executable,int process,uint nativeThread)
    {
        var b=binding.Policy;var p=b.Paths;
        Need(Guid.TryParseExact(b.RunId,"D",out var id)&&id!=Guid.Empty&&id.ToString("D")==b.RunId&&b.Generation>0,"Exact normal run identity required.");
        Need(RunPaths.Same(p.Lab,InstallationAuthority.ApprovedLabRoot)&&RunPaths.Same(p.Install,Path.Combine(p.Lab,"install"))&&RunPaths.Same(p.Run,Path.Combine(p.Lab,"runs",b.RunId)),"Raw cache binding belongs only to the fixed F normal lab.");
        Need(process>0&&b.ProcessId==process&&nativeThread!=0&&b.NativeThreadId==nativeThread&&RunPaths.Same(executable,Path.Combine(p.Install,"AzureArchive.exe")),"Actual normal executable/process/native thread identity differs.");
        foreach(var path in new[]{p.Lab,p.Install,p.Run,executable})_=SeedPathPolicy.ValidateText(path);
    }
    // These values are necessary observations, never an exclusion or mutation
    // permit. In particular, the manager is published after native setup.
    public static void RequirePristineObservation(PreUseState state,uint ownerThread)
    {
        Need(ownerThread!=0&&state.NativeThreadId==ownerThread&&state.CrtState==2&&state.Allocator!=0&&state.Manager==0&&state.ExactInitialRoot,"Pristine cache observations differ; no normal pre-use qualification follows.");
    }
    public static void RequireCachePath(NativeStringValue value,RunPaths paths)
    {
        Need(value.Label==9&&value.Kind is NativeStringKind.Inline or NativeStringKind.Owned,"Native cache path requires the existing label-9 inline/owned representation.");
        Need(value.ByteLength>=0&&value.ByteLength<=NativeStringReader.MaximumBytes&&value.DataAddress!=0,"Native cache path bounds differ.");
        Need(value.Kind==NativeStringKind.Owned?value.Tag==0x5f:value.Tag<=0x1f&&value.ByteLength==0x1f-value.Tag,"Native cache path tag does not describe its decoded representation.");
        var actual=SeedPathPolicy.ValidateText(value.Text.Replace('/','\\'));
        var selected=SeedPathPolicy.ValidateText(paths.Cache);var expectedDefault=SeedPathPolicy.ValidateText(DefaultCachePath(paths));
        Need(string.Equals(actual,selected,StringComparison.OrdinalIgnoreCase)||string.Equals(actual,expectedDefault,StringComparison.OrdinalIgnoreCase),"Native cache path escapes the two exact run-owned targets.");
    }
}
