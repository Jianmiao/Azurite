using Azurite.CacheRootLab;
using System.Buffers.Binary;
namespace Azurite.NormalEditor.Loader.Routes;

public static class NativeJumpVerification
{
    public static void RequireTrampoline(IBoundedMemory memory,ulong original,byte[] originalBytes,ulong trampoline,IReadOnlyList<int> instructionBoundaries)
    {
        ArgumentNullException.ThrowIfNull(memory);ArgumentNullException.ThrowIfNull(originalBytes);ArgumentNullException.ThrowIfNull(instructionBoundaries);
        if(original==0||trampoline==0||original==trampoline||originalBytes.Length>32||instructionBoundaries.Count==0||instructionBoundaries.Any(x=>x<=0||x>originalBytes.Length)||!instructionBoundaries.SequenceEqual(instructionBoundaries.Distinct().OrderBy(x=>x)))
            throw new InvalidOperationException("A bounded pinned original instruction prefix and distinct trampoline are required.");
        MemoryRange.Check(original,14);var patch=memory.Read(original,14);
        var patchBytes=patch.Length!=14?0:patch[0]==0xe9?5:patch[0]==0xff&&patch[1]==0x25&&BinaryPrimitives.ReadInt32LittleEndian(patch.AsSpan(2,4))==0?14:patch[0]==0x48&&patch[1]==0xb8&&patch[10]==0xff&&patch[11]==0xe0?12:patch[0]==0x49&&patch[1]==0xbb&&patch[10]==0x41&&patch[11]==0xff&&patch[12]==0xe3?13:0;
        if(patchBytes==0)throw new InvalidOperationException("Unrecognized original-entry patch shape.");
        foreach(var length in instructionBoundaries.Where(x=>x>=patchBytes))
        {
            try
            {
                MemoryRange.Check(trampoline,(ulong)(length+14));
                if(!memory.Read(trampoline,length).SequenceEqual(originalBytes.Take(length)))continue;
                RequireTarget(memory,checked(trampoline+(ulong)length),checked(original+(ulong)length));return;
            }
            catch(InvalidOperationException){ /* Try another complete, non-relative instruction boundary. */ }
            catch(OverflowException){ /* Never wrap to another address. */ }
        }
        throw new InvalidOperationException("Trampoline does not replay a sufficient pinned prefix and return to its exact continuation.");
    }
    // Decodes only bounded, explicit x64 unconditional patch shapes. The live
    // caller supplies executable-page checked memory; this is not an IsApplied
    // flag or proof that a native callback has actually run.
    public static void RequireTarget(IBoundedMemory memory,ulong entry,ulong expected)
    {
        ArgumentNullException.ThrowIfNull(memory);
        if(entry==0||expected==0||entry==expected)throw new InvalidOperationException("Distinct nonzero native entry and detour pointers required.");
        var address=entry;var seen=new HashSet<ulong>();
        try
        {
            for(var hop=0;hop<2;hop++)
            {
                if(!seen.Add(address))throw new InvalidOperationException("Native patch relay cycles.");
                MemoryRange.Check(address,14);var bytes=memory.Read(address,14);
                if(bytes.Length!=14)throw new InvalidOperationException("Incomplete native patch window.");
                ulong destination;var relative=false;
                if(bytes[0]==0xff&&bytes[1]==0x25&&BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(2,4))==0)
                    destination=BinaryPrimitives.ReadUInt64LittleEndian(bytes.AsSpan(6,8));
                else if(bytes[0]==0x48&&bytes[1]==0xb8&&bytes[10]==0xff&&bytes[11]==0xe0)
                    destination=BinaryPrimitives.ReadUInt64LittleEndian(bytes.AsSpan(2,8));
                else if(bytes[0]==0x49&&bytes[1]==0xbb&&bytes[10]==0x41&&bytes[11]==0xff&&bytes[12]==0xe3)
                    destination=BinaryPrimitives.ReadUInt64LittleEndian(bytes.AsSpan(2,8));
                else if(bytes[0]==0xe9)
                {
                    relative=true;var displacement=BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(1,4));var next=checked(address+5);
                    destination=displacement>=0?checked(next+(ulong)displacement):checked(next-(ulong)(-(long)displacement));
                }
                else throw new InvalidOperationException("Unrecognized native detour branch; no ownership can be inferred.");
                if(destination==expected)return;
                if(!relative||destination==0)throw new InvalidOperationException("Native detour points to another target.");
                address=destination;
            }
        }
        catch(OverflowException e){throw new InvalidOperationException("Native patch address arithmetic overflowed.",e);}
        throw new InvalidOperationException("Native detour exceeds the single permitted relay.");
    }
}
