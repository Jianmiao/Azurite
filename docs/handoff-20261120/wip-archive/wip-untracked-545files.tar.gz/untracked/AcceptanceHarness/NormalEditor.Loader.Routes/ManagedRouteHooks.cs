using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using AzureArchive.Automation;
using Azurite.EditorIsolation;
using HarmonyLib;
using Il2CppInterop.Runtime.InteropTypes;
using UnityEngine.AddressableAssets.ResourceProviders;
using UnityEngine.AddressableAssets.ResourceLocators;

namespace Azurite.NormalEditor.Loader.Routes;

internal sealed class ManagedRouteFrame
{
    internal ManagedRouteFrame(string id,MethodBase method,long receiver){Id=id;Method=method;Receiver=receiver;}
    internal readonly string Id;internal readonly MethodBase Method;internal readonly long Receiver;
    internal RouteCall? Consumer;internal bool Returned;internal string? Input;
}
internal sealed class ManagedRouteHooks
{
    private sealed record PatchSpec(string Id,string Prefix,string Postfix,bool Static);
    private static readonly PatchSpec[] specifications={
        new("cache",nameof(CachePrefix),nameof(SettingsGetterPostfix),false),new("workspace",nameof(WorkspacePrefix),nameof(SettingsGetterPostfix),false),
        new("discovery",nameof(DiscoveryPrefix),nameof(DiscoveryGetterPostfix),true),new("offline",nameof(OfflinePrefix),nameof(OfflinePostfix),true),
        new("addressSet",nameof(AddressSetPrefix),nameof(AddressSetPostfix),true),new("addressClear",nameof(AddressClearPrefix),nameof(AddressClearPostfix),true),
        new("addressEvaluate",nameof(AddressEvaluatePrefix),nameof(AddressEvaluatePostfix),true),new("resolve",nameof(ResolvePrefix),nameof(ResolvePostfix),false),
        new("discoveryCtor",nameof(DiscoveryCtorPrefix),nameof(DiscoveryCtorPostfix),false),new("discoveryDispose",nameof(DiscoveryDisposePrefix),nameof(DiscoveryDisposePostfix),false),
        new("providerTransform",nameof(TransformPrefix),nameof(TransformPostfix),false),new("providerDetermine",nameof(DeterminePrefix),nameof(DeterminePostfix),false),
        new("providerLoaded",nameof(LoadedPrefix),nameof(LoadedPostfix),false)};
    private static ManagedRouteHooks? current;
    private readonly NormalRouteContext context;private readonly ManagedRouteBindings bindings;private readonly RouteConsumerFacts facts;
    private readonly NativeCacheInitializerGuard initializer;private readonly GlobalRootWriteSentinel rootWrites;private readonly Harmony harmony;
    private readonly int ownerThread=Environment.CurrentManagedThreadId;
    private readonly HashSet<ManagedRouteFrame> active=new();private bool registered;
    private ManagedRouteHooks(NormalRouteContext context,ManagedRouteBindings bindings,RouteConsumerFacts facts,NativeCacheInitializerGuard initializer,GlobalRootWriteSentinel rootWrites)
    {this.context=context;this.bindings=bindings;this.facts=facts;this.initializer=initializer;this.rootWrites=rootWrites;harmony=new("lab.azurite.normal-resource-routes."+context.Binding.Policy.RunId);}
    internal static ManagedRouteHooks Install(NormalRouteContext context,ManagedRouteBindings bindings,RouteConsumerFacts facts,NativeCacheInitializerGuard initializer,GlobalRootWriteSentinel rootWrites)
    {
        context.RequireStartupWindow(context.Binding);initializer.RequireRegisteredForInterop(context);rootWrites.RequireRegisteredForInterop(context);
        foreach(var spec in specifications)if(Harmony.GetPatchInfo(bindings.Methods[spec.Id].Managed)?.Owners.Any()==true)throw new InvalidOperationException("Another owner already patches a resource route.");
        var state=new ManagedRouteHooks(context,bindings,facts,initializer,rootWrites);
        if(Interlocked.CompareExchange(ref current,state,null) is not null)throw new InvalidOperationException("Managed resource hooks are single-use.");
        try
        {
            foreach(var spec in specifications)
            {
                context.RequireStartupWindow(context.Binding);
                state.harmony.Patch(bindings.Methods[spec.Id].Managed,new HarmonyMethod(typeof(ManagedRouteHooks),spec.Prefix),new HarmonyMethod(typeof(ManagedRouteHooks),spec.Postfix),finalizer:new HarmonyMethod(typeof(ManagedRouteHooks),spec.Static?nameof(StaticFinalizer):nameof(InstanceFinalizer)));
            }
            state.VerifyOwnership();state.registered=true;return state;
        }
        catch(Exception e){state.Abort(e);throw;}
    }
    internal void VerifyOwnership()
    {
        if(Environment.CurrentManagedThreadId!=ownerThread||Environment.ProcessId!=context.Binding.Policy.ProcessId)throw new InvalidOperationException("Foreign resource-hook owner.");
        initializer.VerifyOwnership();rootWrites.VerifyOwnership();
        foreach(var spec in specifications)
        {
            var info=Harmony.GetPatchInfo(bindings.Methods[spec.Id].Managed)??throw new InvalidOperationException("Resource hook disappeared.");
            static OwnedPatch[] Rows(IEnumerable<Patch> patches)=>patches.Select(p=>new OwnedPatch(p.owner,p.PatchMethod)).ToArray();
            static MethodInfo Method(string name)=>typeof(ManagedRouteHooks).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.DeclaredOnly)??throw new MissingMethodException(name);
            HookOwnership.Require(new(Rows(info.Prefixes),Rows(info.Postfixes),Rows(info.Finalizers),Rows(info.Transpilers),Rows(info.ILManipulators),info.Owners.ToArray()),harmony.Id,Method(spec.Prefix),Method(spec.Postfix),Method(spec.Static?nameof(StaticFinalizer):nameof(InstanceFinalizer)));
        }
    }
    internal IReadOnlyCollection<string> InstalledCategories
    {
        get{if(!registered)return Array.Empty<string>();VerifyOwnership();return Array.AsReadOnly(new[]{"workspace","discovery","offline","addressSet","addressClear","addressEvaluate"});}
    }
    internal void RequireQuiescent(){VerifyOwnership();if(active.Count!=0)throw new InvalidOperationException("Managed resource callback is still active.");}
    private static ManagedRouteHooks State=>current??throw new InvalidOperationException("Resource hooks are not registered.");
    private ManagedRouteFrame Begin(string id,MethodBase method,Il2CppObjectBase? receiver)
    {
        if(!registered)throw new InvalidOperationException("Resource callback raced partial installation.");VerifyOwnership();bindings.Require(id,method,receiver);
        var pointer=receiver?.Pointer.ToInt64()??0;
        if(active.Count>=128||active.Any(f=>f.Id==id&&f.Receiver==pointer))throw new InvalidOperationException("Resource callback reentry/bound exceeded.");
        var frame=new ManagedRouteFrame(id,method,pointer);active.Add(frame);return frame;
    }
    private void Check(ManagedRouteFrame frame,MethodBase method,Il2CppObjectBase? receiver)
    {
        VerifyOwnership();if(!active.Contains(frame)||frame.Method!=method||frame.Receiver!=(receiver?.Pointer.ToInt64()??0))throw new InvalidOperationException("Foreign or retired resource callback frame.");bindings.Require(frame.Id,method,receiver);
    }
    private void Returned(ManagedRouteFrame frame,MethodBase method,Il2CppObjectBase? receiver)
    {Check(frame,method,receiver);if(frame.Returned)throw new InvalidOperationException("Duplicate resource return.");frame.Returned=true;}
    private Exception? Finish(ManagedRouteFrame? frame,MethodBase method,Il2CppObjectBase? receiver,Exception? error)
    {
        if(frame is null)return error;Check(frame,method,receiver);
        if(!frame.Returned||error is not null)throw new InvalidOperationException("Resource original/finalizer did not complete successfully.",error);
        if(frame.Consumer is not null)facts.OriginalFinalized(frame.Consumer,error);active.Remove(frame);return error;
    }
    [DoesNotReturn]private void Abort(Exception error)
    {if(Environment.CurrentManagedThreadId==ownerThread)try{context.Reject(error.Message);}catch{}context.Fatal.Terminate("Resource route failed: "+error.Message);Environment.FailFast("Owned resource fatal boundary returned.");throw new InvalidOperationException("Unreachable.");}
    private static bool CachePrefix(global::UserSettings __instance,MethodBase __originalMethod,ref string __result,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("cache",__originalMethod,__instance);__result=TypedRouteConsumers.CacheGetter(State.facts,__instance);return false;}catch(Exception e){State.Abort(e);return false;}}
    private static bool WorkspacePrefix(global::UserSettings __instance,MethodBase __originalMethod,ref string __result,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("workspace",__originalMethod,__instance);__result=TypedRouteConsumers.WorkspaceGetter(State.facts,__instance);return false;}catch(Exception e){State.Abort(e);return false;}}
    private static void SettingsGetterPostfix(global::UserSettings __instance,MethodBase __originalMethod,string __result,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var s=State;var f=__state??throw new InvalidOperationException("Missing getter frame.");s.Check(f,__originalMethod,__instance);var target=f.Id=="cache"?s.context.Binding.Policy.Paths.Cache:s.context.Binding.Policy.Paths.Workspace;if(__runOriginal||!RunPaths.Same(__result,target))throw new InvalidOperationException("Routed getter result/original differs.");s.Returned(f,__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static bool DiscoveryPrefix(MethodBase __originalMethod,ref string __result,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("discovery",__originalMethod,null);__result=TypedRouteConsumers.DiscoveryGetter(State.facts);return false;}catch(Exception e){State.Abort(e);return false;}}
    private static void DiscoveryGetterPostfix(MethodBase __originalMethod,string __result,bool __runOriginal,ManagedRouteFrame? __state)
    {try{if(__state is null||__runOriginal||!RunPaths.Same(__result,State.context.Binding.Policy.Paths.Discovery))throw new InvalidOperationException("Discovery getter route differs.");State.Returned(__state,__originalMethod,null);}catch(Exception e){State.Abort(e);}}
    private static void OfflinePrefix(string __0,string __1,string __2,ref string __3,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("offline",__originalMethod,null);__state.Consumer=TypedRouteConsumers.OfflineEntered(State.facts,__0,__1,__2,ref __3);}catch(Exception e){State.Abort(e);}}
    private static void OfflinePostfix(MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var f=__state??throw new InvalidOperationException("Missing offline frame.");State.Check(f,__originalMethod,null);State.facts.OriginalReturned(f.Consumer!,__runOriginal);State.Returned(f,__originalMethod,null);}catch(Exception e){State.Abort(e);}}
    private static void AddressSetPrefix(string __0,ref string __1,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;if(__0!=RoutePathRules.PersistentProperty)return;try{__state=State.Begin("addressSet",__originalMethod,null);TypedRouteConsumers.AddressSetEntered(State.facts,__0,ref __1);}catch(Exception e){State.Abort(e);}}
    private static void AddressSetPostfix(MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {if(__state is null)return;try{State.Check(__state,__originalMethod,null);if(!__runOriginal)throw new InvalidOperationException("Original property setter was suppressed.");var actual=UnityEngine.AddressableAssets.Initialization.AddressablesRuntimeProperties.s_CachedValues[RoutePathRules.PersistentProperty];if(!RunPaths.Same(actual,State.context.Binding.Policy.Paths.Persistent))throw new InvalidOperationException("Original property setter retained another value.");State.Returned(__state,__originalMethod,null);}catch(Exception e){State.Abort(e);}}
    private static void AddressClearPrefix(MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("addressClear",__originalMethod,null);}catch(Exception e){State.Abort(e);}}
    private static void AddressClearPostfix(MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var f=__state??throw new InvalidOperationException("Missing property-clear frame.");State.Check(f,__originalMethod,null);TypedRouteConsumers.AddressClearReturned(State.facts,__runOriginal);State.Returned(f,__originalMethod,null);}catch(Exception e){State.Abort(e);}}
    private static void AddressEvaluatePrefix(string __0,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;if(__0!=RoutePathRules.PersistentProperty)return;try{__state=State.Begin("addressEvaluate",__originalMethod,null);TypedRouteConsumers.AddressEvaluateEntered(State.facts,__0);}catch(Exception e){State.Abort(e);}}
    private static void AddressEvaluatePostfix(string __0,string __result,MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {if(__state is null)return;try{State.Check(__state,__originalMethod,null);TypedRouteConsumers.AddressEvaluateReturned(State.facts,__0,__result,__runOriginal);State.Returned(__state,__originalMethod,null);}catch(Exception e){State.Abort(e);}}
    private static void ResolvePrefix(Il2CppObjectBase __instance,string __0,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;if(__0?.Contains("{"+RoutePathRules.PersistentProperty+"}",StringComparison.Ordinal)!=true)return;try{__state=State.Begin("resolve",__originalMethod,__instance);__state.Input=__0;}catch(Exception e){State.Abort(e);}}
    private static void ResolvePostfix(Il2CppObjectBase __instance,string __result,MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {if(__state is null)return;try{State.Check(__state,__originalMethod,__instance);TypedRouteConsumers.ResolveReturned(State.facts,__state.Input!,__result,__runOriginal);State.Returned(__state,__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static void DiscoveryCtorPrefix(AuthoringControlServer __instance,string __1,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("discoveryCtor",__originalMethod,__instance);__state.Consumer=TypedRouteConsumers.DiscoveryEntered(State.facts,__instance,__1);}catch(Exception e){State.Abort(e);}}
    private static void DiscoveryCtorPostfix(AuthoringControlServer __instance,MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var f=__state??throw new InvalidOperationException("Missing discovery ctor frame.");State.Check(f,__originalMethod,__instance);TypedRouteConsumers.DiscoveryReturned(State.facts,__instance,f.Consumer!,__runOriginal);State.Returned(f,__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static void DiscoveryDisposePrefix(AuthoringControlServer __instance,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("discoveryDispose",__originalMethod,__instance);__state.Consumer=TypedRouteConsumers.DiscoveryDisposeEntered(State.facts,__instance);}catch(Exception e){State.Abort(e);}}
    private static void DiscoveryDisposePostfix(AuthoringControlServer __instance,MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var f=__state??throw new InvalidOperationException("Missing discovery dispose frame.");State.Check(f,__originalMethod,__instance);State.facts.OriginalReturned(f.Consumer!,__runOriginal);State.Returned(f,__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static void TransformPrefix(ContentCatalogProvider.InternalOp __instance,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("providerTransform",__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static void TransformPostfix(ContentCatalogProvider.InternalOp __instance,string __result,MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var f=__state??throw new InvalidOperationException("Missing transformed-id frame.");State.Check(f,__originalMethod,__instance);TypedRouteConsumers.ProviderTransformReturned(State.facts,__instance,__runOriginal,__result);State.Returned(f,__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static void DeterminePrefix(ContentCatalogProvider.InternalOp __instance,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("providerDetermine",__originalMethod,__instance);__state.Consumer=TypedRouteConsumers.ProviderDecisionEntered(State.facts,__instance);}catch(Exception e){State.Abort(e);}}
    private static void DeterminePostfix(ContentCatalogProvider.InternalOp __instance,string __result,MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var f=__state??throw new InvalidOperationException("Missing provider decision frame.");State.Check(f,__originalMethod,__instance);TypedRouteConsumers.ProviderDecisionReturned(State.facts,__instance,f.Consumer!,__runOriginal,__result);State.Returned(f,__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static void LoadedPrefix(ContentCatalogProvider.InternalOp __instance,MethodBase __originalMethod,out ManagedRouteFrame? __state)
    {__state=null;try{__state=State.Begin("providerLoaded",__originalMethod,__instance);__state.Consumer=TypedRouteConsumers.CatalogEffectsEntered(State.facts,__instance);}catch(Exception e){State.Abort(e);}}
    private static void LoadedPostfix(ContentCatalogProvider.InternalOp __instance,ContentCatalogData? __0,MethodBase __originalMethod,bool __runOriginal,ManagedRouteFrame? __state)
    {try{var f=__state??throw new InvalidOperationException("Missing catalog effects frame.");State.Check(f,__originalMethod,__instance);TypedRouteConsumers.CatalogEffectsReturned(State.facts,f.Consumer!,__runOriginal,__0);State.Returned(f,__originalMethod,__instance);}catch(Exception e){State.Abort(e);}}
    private static Exception? StaticFinalizer(MethodBase __originalMethod,ManagedRouteFrame? __state,Exception? __exception)
    {try{return State.Finish(__state,__originalMethod,null,__exception);}catch(Exception e){State.Abort(e);return __exception;}}
    private static Exception? InstanceFinalizer(Il2CppObjectBase __instance,MethodBase __originalMethod,ManagedRouteFrame? __state,Exception? __exception)
    {try{return State.Finish(__state,__originalMethod,__instance,__exception);}catch(Exception e){State.Abort(e);return __exception;}}
}
