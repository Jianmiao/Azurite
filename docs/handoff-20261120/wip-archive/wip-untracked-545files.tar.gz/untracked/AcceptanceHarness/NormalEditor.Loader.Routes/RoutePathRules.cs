using Azurite.EditorIsolation;
using Azurite.NormalEditor.Adapter;
using System.Text.RegularExpressions;

namespace Azurite.NormalEditor.Loader.Routes;

// Path checks only. This object neither grants admission nor proves a native hit,
// file identity, installation, cache-root preparation, or materialization.
public sealed class RoutePathRules
{
    public const string PersistentProperty="UnityEngine.Application.persistentDataPath";
    private readonly RunPaths paths;
    private readonly NormalResourcePreparation resources;
    private readonly string cachedJson,cachedHash;
    public RoutePathRules(AdapterBinding binding,NormalResourcePreparation resources)
    {
        ArgumentNullException.ThrowIfNull(binding);ArgumentNullException.ThrowIfNull(resources);
        paths=binding.Policy.Paths;this.resources=resources;
        foreach(var path in new[]{paths.Lab,paths.Run,paths.Install,paths.Cache,paths.Workspace,paths.Persistent,paths.Discovery,resources.OfflineRoot,resources.InstalledCatalogPath,resources.OfflineCatalogPath,resources.InstalledSettingsPath,resources.CatalogHashPath})Canonical(path);
        Require(RunPaths.Below(paths.Run,paths.Lab)&&RunPaths.Below(paths.Install,paths.Lab)&&!RunPaths.Below(paths.Run,paths.Install),"Separate normal run and installation required.");
        Require(RunPaths.Below(resources.OfflineRoot,paths.Lab)&&!RunPaths.Below(resources.OfflineRoot,paths.Run)&&!RunPaths.Same(resources.OfflineRoot,paths.Run),"Offline input must be a separate selected lab input.");
        var installed=Path.Combine(paths.Install,"AzureArchive_Data","StreamingAssets","aa");
        Require(RunPaths.Same(resources.InstalledCatalogPath,Path.Combine(installed,"catalog.json"))&&RunPaths.Same(resources.InstalledSettingsPath,Path.Combine(installed,"settings.json")),"Installed catalog/settings paths differ.");
        Require(RunPaths.Same(Path.GetDirectoryName(resources.OfflineCatalogPath),resources.OfflineRoot)&&Path.GetExtension(resources.OfflineCatalogPath)==".json"&&RunPaths.Same(resources.CatalogHashPath,Path.ChangeExtension(resources.OfflineCatalogPath,".hash")),"Offline catalog/hash paths differ.");
        cachedJson=Path.Combine(paths.Persistent,"com.unity.addressables",Path.GetFileName(resources.OfflineCatalogPath));cachedHash=Path.ChangeExtension(cachedJson,".hash");
    }
    private static void Require(bool value,string reason){if(!value)throw new InvalidOperationException(reason);}
    internal static string Canonical(string value,bool fileUri=false)
    {
        Require(!string.IsNullOrWhiteSpace(value)&&value.Length<=8192&&!value.Contains('\0'),"A bounded nonempty local path is required.");
        var path=value;
        if(value.StartsWith("file:",StringComparison.OrdinalIgnoreCase))
        {
            Require(fileUri,"This native argument must be an ordinary canonical path.");
            Require(value.StartsWith("file:///",StringComparison.OrdinalIgnoreCase)&&!value.Contains('\\')&&!value.Split('/').Any(x=>x is "." or ".."),"File URI aliases are refused before URI normalization.");
            Require(!Regex.IsMatch(value,"%(2e|2f|5c|00|3a)",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant),"Encoded path aliases are not admitted.");
            Require(Uri.TryCreate(value,UriKind.Absolute,out var uri)&&uri.IsFile&&!uri.IsUnc&&string.IsNullOrEmpty(uri.Host)&&string.IsNullOrEmpty(uri.Query)&&string.IsNullOrEmpty(uri.Fragment),"Only an unambiguous local file URI is admitted.");
            path=uri!.LocalPath;
        }
        Require(Path.IsPathFullyQualified(path)&&path.Length>=3&&path[1]==':'&&!path.StartsWith("\\\\",StringComparison.Ordinal)&&!path.AsSpan(2).Contains(':')&&!path.Contains('/'),"Canonical local drive path required.");
        Require(!path.Split('\\').Skip(1).Any(x=>x is "." or ".."||x.EndsWith(' ')||x.EndsWith('.'))&&RunPaths.Same(Path.GetFullPath(path),path),"Path traversal, aliases and streams are refused.");
        return path;
    }
    private static void ExistingAncestors(string path)
    {
        // Future cache/metadata leaves may not exist yet. Missing is distinct
        // from inaccessible, and every existing ancestor still excludes links.
        for(string? p=path;!string.IsNullOrEmpty(p);p=Path.GetDirectoryName(p))
        {
            try{Require((File.GetAttributes(p)&FileAttributes.ReparsePoint)==0,"Reparse path is refused before native file use.");}
            catch(FileNotFoundException){}
            catch(DirectoryNotFoundException){}
        }
    }
    private static void Same(string value,string target,bool fileUri=false)
    {var path=Canonical(value,fileUri);Require(RunPaths.Same(path,target),"Native consumer path differs from the exact selected target.");ExistingAncestors(path);}
    public string Getter(string category,long actualOwner,long boundOwner)
    {
        string target;
        if(category=="discovery"){Require(actualOwner==0,"Discovery getter must be the static route.");target=paths.Discovery;}
        else{Require(boundOwner>0&&actualOwner==boundOwner,"Settings getter owner is unbound or changed.");target=category switch{"cache"=>paths.Cache,"workspace"=>paths.Workspace,_=>throw new InvalidOperationException("Unknown getter route.")};}
        RunPaths.RequireSafeExisting(target);Require(Directory.Exists(target),"Routed directory must already exist.");return target;
    }
    public void OfflineArguments(string root,string catalog,string settings,string persistent)
    {Same(root,resources.OfflineRoot);Same(catalog,resources.InstalledCatalogPath);Same(settings,resources.InstalledSettingsPath);Same(persistent,paths.Persistent);}
    public void PersistentResolution(string input,string resolved)
    {
        ArgumentNullException.ThrowIfNull(input);
        if(input.Contains("{"+PersistentProperty+"}",StringComparison.Ordinal))
        {var path=Canonical(resolved,true);Require(RunPaths.Same(path,cachedJson)||RunPaths.Same(path,cachedHash),"Persistent placeholder escaped its selected run catalog.");ExistingAncestors(path);}
    }
    public void ProviderPath(string resolved)
    {
        var path=Canonical(resolved,true);
        Require(new[]{resources.InstalledCatalogPath,resources.OfflineCatalogPath,resources.CatalogHashPath,cachedJson,cachedHash}.Any(x=>RunPaths.Same(x,path)),"Catalog provider resolved an unselected input or network target.");ExistingAncestors(path);
    }
    public void WritableCatalog(string path)
    {path=Canonical(path);Require(RunPaths.Same(path,cachedJson)||RunPaths.Same(path,cachedHash),"Catalog write/deletion escaped the exact run cache leaves.");ExistingAncestors(path);}
    public void DiscoveryDirectory(string directory)=>Same(directory,paths.Discovery);
    public void DiscoveryMetadata(string path)
    {path=Canonical(path);Require(RunPaths.Same(Path.GetDirectoryName(path),paths.Discovery)&&!string.IsNullOrEmpty(Path.GetFileName(path)),"Discovery metadata must be a direct owned-directory leaf.");ExistingAncestors(path);}
}
