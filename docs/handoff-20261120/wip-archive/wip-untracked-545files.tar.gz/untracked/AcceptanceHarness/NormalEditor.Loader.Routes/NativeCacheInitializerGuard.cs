using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;
using Azurite.CacheRootLab;
using BepInEx.Unity.IL2CPP.Hook;

namespace Azurite.NormalEditor.Loader.Routes;

// A first-effect path guard, not a root-seeding permission or proof that no
// caller was already in flight before installation. Kept until child exit.
internal sealed class NativeCacheInitializerGuard
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate byte Initializer(IntPtr cache,byte readIndex);
    private sealed class ExecutableMemory:IBoundedMemory
    {
        private readonly CurrentProcessMemory memory;
        internal ExecutableMemory(CurrentProcessMemory memory)=>this.memory=memory;
        public byte[] Read(ulong address,int count){memory.RequireExecutable(address,count);return memory.Read(address,count);}
    }
    private static NativeCacheInitializerGuard? retained;
    private readonly NormalCacheBindings native;
    private readonly NormalRouteContext context;
    private readonly int ownerThread=Environment.CurrentManagedThreadId;
    private readonly Initializer handler;
    private readonly byte[] originalPrefix;
    private INativeDetour? hook;
    private Initializer? original;
    private bool registered;
    private int active;
    private long hits,returns;
    private NativeCacheInitializerGuard(NormalCacheBindings native)
    {
        this.native=native;context=native.Context;handler=Callback;
        originalPrefix=native.Memory.Read(native.InitializerAddress,18);
    }
    internal static NativeCacheInitializerGuard Install(NormalCacheBindings native)
    {
        ArgumentNullException.ThrowIfNull(native);native.RequireOwner();native.Context.RequireStartupWindow(native.Context.Binding);
        native.VerifyOriginalWindow("cache_initializer_complete");var state=new NativeCacheInitializerGuard(native);
        if(Interlocked.CompareExchange(ref retained,state,null) is not null)throw new InvalidOperationException("Native initializer guard registration is single-use.");
        try
        {
            state.hook=INativeDetour.CreateAndApply<Initializer>((IntPtr)(long)native.InitializerAddress,state.handler,out var trampoline);
            state.original=trampoline;
            state.VerifyOwnership();native.Context.RequireStartupWindow(native.Context.Binding);state.registered=true;
            return state;
        }
        catch(Exception e){state.Abort(e);throw;}
    }
    internal void VerifyOwnership()
    {
        native.RequireOwner();var actual=hook??throw new InvalidOperationException("Native detour object is absent.");
        var callback=Marshal.GetFunctionPointerForDelegate(handler);
        if(actual.GetType().FullName!="BepInEx.Unity.IL2CPP.Hook.Dobby.DobbyDetour"||actual.OriginalMethodPtr!=(IntPtr)(long)native.InitializerAddress||actual.DetourMethodPtr!=callback||actual.TrampolinePtr==IntPtr.Zero||actual.TrampolinePtr==actual.OriginalMethodPtr||actual.TrampolinePtr==actual.DetourMethodPtr||original is null)
            throw new InvalidOperationException("Native provider, entry, callback or original trampoline identity differs.");
        if(Marshal.GetFunctionPointerForDelegate(original)!=actual.TrampolinePtr)throw new InvalidOperationException("Returned original delegate does not reference the native trampoline.");
        var memory=native.Memory;var trampoline=(ulong)actual.TrampolinePtr;
        memory.RequireExecutable((ulong)callback.ToInt64(),1);memory.RequireExecutable(trampoline,5);
        // The first six complete instructions occupy 5/6/10/13/16/18 bytes
        // and contain no RIP-relative operand. Match the actual patch width,
        // copied instructions, and exact jump back, not a fixed 16-byte guess.
        var executable=new ExecutableMemory(memory);
        NativeJumpVerification.RequireTarget(executable,native.InitializerAddress,(ulong)callback.ToInt64());
        NativeJumpVerification.RequireTrampoline(executable,native.InitializerAddress,originalPrefix,trampoline,new[]{5,6,10,13,16,18});
    }
    private byte Callback(IntPtr cache,byte readIndex)
    {
        Interlocked.Increment(ref active);
        try
        {
            if(!registered)throw new InvalidOperationException("Native caller raced incomplete guard installation.");
            VerifyOwnership();_=native.InspectInitializer(cache,readIndex);
            Interlocked.Increment(ref hits);
            var value=original!(cache,readIndex); // Preserve byte inputs and output exactly.
            Interlocked.Increment(ref returns);return value;
        }
        catch(Exception e){Abort(e);throw;}
        finally{Interlocked.Decrement(ref active);}
    }
    [DoesNotReturn]
    private void Abort(Exception error)
    {
        // No foreign-thread call into a possibly owner-held managed audit sink.
        if(Environment.CurrentManagedThreadId==ownerThread)try{context.Reject(error.Message);}catch{}
        context.Fatal.Terminate("Native cache initializer containment failed: "+error.Message);
        Environment.FailFast("Owned native cache fatal boundary unexpectedly returned.");
        throw new InvalidOperationException("Unreachable native cache failure.");
    }
    internal void RequireQuiescent()
    {native.RequireOwner();VerifyOwnership();if(Volatile.Read(ref active)!=0)throw new InvalidOperationException("Native initializer callback is still active.");}
    internal (long Hits,long OriginalReturns) Counts=>(Interlocked.Read(ref hits),Interlocked.Read(ref returns));
    internal void RequireRegisteredForInterop(NormalRouteContext expected)
    {if(!registered||!ReferenceEquals(context,expected))throw new InvalidOperationException("Matching native initializer guard is not fully registered.");VerifyOwnership();}
}
