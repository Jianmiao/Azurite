using System.Runtime.InteropServices;
using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Entry;

namespace Azurite.NormalEditor.Loader.Routes;

// Real guarded registration composition. The cache category is deliberately
// not published while the independently identified native qualification is absent.
public sealed class NormalRoutes:INormalRoutes
{
    [DllImport("kernel32.dll",ExactSpelling=true)]private static extern uint GetCurrentThreadId();
    private NormalRouteContext? context;
    private NormalCacheBindings? raw;
    private NativeCacheInitializerGuard? initializer;
    private GlobalRootWriteSentinel? rootWrites;
    private RouteConsumerFacts? facts;
    private ManagedRouteHooks? hooks;
    public NormalRoutes(){}
    public void Register(NormalRouteContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        if(this.context is not null)throw new InvalidOperationException("Normal route registration is single-use.");
        this.context=context;context.RequireStartupWindow(context.Binding);
        raw=NormalCacheBindings.Bind(context);
        // Both native boundaries precede generated target-type initialization.
        rootWrites=GlobalRootWriteSentinel.Install(raw);
        initializer=NativeCacheInitializerGuard.Install(raw);
        facts=new RouteConsumerFacts(context,GetCurrentThreadId);
        var bindings=ManagedRouteBindings.Bind(context,raw,initializer,rootWrites);
        hooks=ManagedRouteHooks.Install(context,bindings,facts,initializer,rootWrites);
        context.RequireStartupWindow(context.Binding);
    }
    public IReadOnlyCollection<string> InstalledRoutes=>hooks?.InstalledCategories??Array.Empty<string>();
    private void Same(AdapterBinding binding)
    {
        if(context is null||hooks is null||!ReferenceEquals(binding,context.Binding)||Environment.ProcessId!=binding.Policy.ProcessId)throw new InvalidOperationException("Normal routes are incomplete or belong to another binding.");
        raw!.RequireOwner();
    }
    public void RequireResourceEntry(AdapterBinding binding,long resource,NativeSettings settings)
    {
        Same(binding);hooks!.VerifyOwnership();
        if(resource<=0||settings.Owner<=0||settings.Owner!=context!.BoundSettingsOwner())throw new InvalidOperationException("Resource entry lacks the actual admitted settings owner.");
        // No readiness requirement here: native OnReady calls Initialize before
        // the later isReady store. Cache qualification is a separate unfinished fact.
        throw new InvalidOperationException("Normal cache pre-use/exclusion and complete cache routing are not yet qualified; resource entry remains closed.");
    }
    public void RequireCatalogClosure(AdapterBinding binding,CatalogEvidence observation)
    {
        Same(binding);facts!.RequireRecordedCatalogFacts(observation);
        throw new InvalidOperationException("Recorded consumers do not replace the missing complete normal cache qualification.");
    }
    public void RequireShutdownSafe(AdapterBinding binding)
    {Same(binding);hooks!.RequireQuiescent();facts!.RequireQuiescent();initializer!.RequireQuiescent();rootWrites!.RequireQuiescent();}
}
