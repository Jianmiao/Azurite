using System.Buffers.Binary;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using Azurite.CacheRootLab;
using Azurite.EditorIsolation;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;

namespace Azurite.NormalEditor.Loader.Routes;

internal sealed record BoundRoute(RouteMethod Specification,MethodBase Managed,IntPtr Class,IntPtr MethodInfo,IntPtr Entry);
internal sealed class ManagedRouteBindings
{
    internal readonly Dictionary<string,BoundRoute> Methods=new(StringComparer.Ordinal);
    private readonly NormalRouteContext context;
    private readonly NormalCacheBindings raw;
    private ManagedRouteBindings(NormalRouteContext context,NormalCacheBindings raw){this.context=context;this.raw=raw;}
    internal static ManagedRouteBindings Bind(NormalRouteContext context,NormalCacheBindings raw,NativeCacheInitializerGuard initializer,GlobalRootWriteSentinel rootWrites)
    {
        if(!ReferenceEquals(context,raw.Context))throw new InvalidOperationException("Managed routes require the same raw/context binding.");
        raw.RequireOwner();context.RequireStartupWindow(context.Binding);
        initializer.RequireRegisteredForInterop(context);rootWrites.RequireRegisteredForInterop(context);
        // Only now may resolving/initializing a generated target type happen.
        var install=context.Binding.Policy.Paths.Install;
        var files=new Dictionary<string,string>(StringComparer.Ordinal){
            ["Assembly-CSharp"]="d95062f3a49fba645986dc7fe0cee749197c9d0c84ff381fc3ca2d9d2823c013",
            ["UnityEngine.CoreModule"]="fd65570bc81061e45fd9ce3bd162cd5839e0efb8f4d76f6902ead8232cd69e69",
            ["Unity.Addressables"]="06c6cd741d28c5b19c8d22620d16b10d30122abf4f7fff7ec5a21eda92102b5e",
            ["Unity.ResourceManager"]="deb4598e5eb03b0dae8f165016fff8ded4445542f8926330b249e969e40608f6"};
        var assemblies=new Dictionary<string,Assembly>(StringComparer.Ordinal);
        foreach(var (name,pin) in files)
        {
            var path=Path.Combine(install,"BepInEx","interop",name+".dll");PinContract.RequireFileHash(path,pin);
            var loaded=AppDomain.CurrentDomain.GetAssemblies().Where(a=>a.GetName().Name==name).ToArray();
            if(loaded.Length>1)throw new InvalidOperationException("Duplicate route interop identities are loaded.");
            var assembly=loaded.Length==1?loaded[0]:AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
            if(AppDomain.CurrentDomain.GetAssemblies().Count(a=>a.GetName().Name==name)!=1)throw new InvalidOperationException("Route interop identity became ambiguous.");
            if(!RunPaths.Same(path,assembly.Location))throw new InvalidOperationException("Route interop was loaded from another location.");assemblies.Add(name,assembly);
        }
        using var process=Process.GetCurrentProcess();var game=process.Modules.Cast<ProcessModule>().Single(m=>string.Equals(m.ModuleName,"GameAssembly.dll",StringComparison.OrdinalIgnoreCase));
        if(!RunPaths.Same(game.FileName,Path.Combine(install,"GameAssembly.dll")))throw new InvalidOperationException("Route GameAssembly location differs.");
        var gameBase=(ulong)game.BaseAddress.ToInt64();var result=new ManagedRouteBindings(context,raw);
        foreach(var spec in RouteBindingCatalog.Methods)
        {
            context.RequireStartupWindow(context.Binding);initializer.VerifyOwnership();rootWrites.VerifyOwnership();
            var type=assemblies[spec.Assembly].GetType(spec.Type,true)!;
            RuntimeHelpers.RunClassConstructor(type.TypeHandle);
            var cls=Il2CppClassPointerStore.GetNativeClassPointer(type);if(cls==IntPtr.Zero)throw new InvalidOperationException("Route native class is missing.");
            const BindingFlags flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance|BindingFlags.DeclaredOnly;
            var candidates=type.GetMethods(flags).Cast<MethodBase>().Concat(type.GetConstructors(flags));
            var method=candidates.Single(m=>m.Name==spec.Method&&m.IsStatic==spec.Static&&ReturnName(m)==spec.ReturnType&&m.GetParameters().Select(p=>TypeName(p.ParameterType)).SequenceEqual(spec.Parameters));
            var pointer=type.GetField(spec.PointerField,BindingFlags.NonPublic|BindingFlags.Static)??throw new MissingFieldException(spec.PointerField);
            var info=(IntPtr)(pointer.GetValue(null)??throw new InvalidOperationException("Route method pointer is absent."));
            if(info==IntPtr.Zero||info!=IL2CPP.GetIl2CppMethodByToken(cls,spec.Token))throw new InvalidOperationException("Route method token/field identity differs: "+spec.Id);
            var address=BinaryPrimitives.ReadUInt64LittleEndian(raw.Memory.Read((ulong)info.ToInt64(),8));
            if(address!=checked(gameBase+(ulong)spec.Rva))throw new InvalidOperationException("Route native RVA differs: "+spec.Id);
            raw.Memory.RequireModuleImage(address,1,gameBase);raw.Memory.RequireExecutable(address,1);
            result.Methods.Add(spec.Id,new(spec,method,cls,info,(IntPtr)(long)address));
        }
        context.RequireStartupWindow(context.Binding);return result;
    }
    private static string ReturnName(MethodBase m)=>m is MethodInfo info?TypeName(info.ReturnType):"System.Void";
    private static string TypeName(Type type)
    {
        if(type.IsByRef)return TypeName(type.GetElementType()!)+"&";
        if(type.IsGenericType)return type.GetGenericTypeDefinition().FullName+"<"+string.Join(",",type.GetGenericArguments().Select(TypeName))+">";
        return type.FullName??throw new InvalidOperationException("Unnamed route parameter type.");
    }
    internal BoundRoute Require(string id,MethodBase original,Il2CppObjectBase? receiver)
    {
        raw.RequireOwner();var bound=Methods[id];
        if(original!=bound.Managed)throw new InvalidOperationException("Foreign route callback method.");
        if(bound.Specification.Static){if(receiver is not null)throw new InvalidOperationException("Static route carried an unexpected receiver.");}
        else if(receiver is null||receiver.Pointer==IntPtr.Zero||IL2CPP.il2cpp_object_get_class(receiver.Pointer)!=bound.Class)throw new InvalidOperationException("Route native receiver class differs.");
        return bound;
    }
}
