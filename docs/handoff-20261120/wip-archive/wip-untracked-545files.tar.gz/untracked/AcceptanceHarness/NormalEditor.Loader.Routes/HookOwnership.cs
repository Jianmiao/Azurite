using System.Reflection;
namespace Azurite.NormalEditor.Loader.Routes;

public sealed record OwnedPatch(string Owner,MethodInfo Method);
public sealed record HookSnapshot(IReadOnlyList<OwnedPatch> Prefixes,IReadOnlyList<OwnedPatch> Postfixes,IReadOnlyList<OwnedPatch> Finalizers,IReadOnlyList<OwnedPatch> Transpilers,IReadOnlyList<OwnedPatch> ILManipulators,IReadOnlyList<string> Owners);
public static class HookOwnership
{
    public static void Require(HookSnapshot snapshot,string owner,MethodInfo prefix,MethodInfo postfix,MethodInfo finalizer)
    {
        if(snapshot is null||string.IsNullOrWhiteSpace(owner)||prefix is null||postfix is null||finalizer is null)throw new InvalidOperationException("Complete hook ownership input required.");
        bool Match(IReadOnlyList<OwnedPatch>? rows,MethodInfo expected)=>rows is not null&&rows.Count==1&&rows[0] is not null&&rows[0].Owner==owner&&rows[0].Method==expected;
        if(!Match(snapshot.Prefixes,prefix)||!Match(snapshot.Postfixes,postfix)||!Match(snapshot.Finalizers,finalizer)||snapshot.Transpilers is null||snapshot.Transpilers.Count!=0||snapshot.ILManipulators is null||snapshot.ILManipulators.Count!=0||snapshot.Owners is null||snapshot.Owners.Count!=1||snapshot.Owners[0]!=owner)
            throw new InvalidOperationException("One exact prefix/postfix/finalizer and no transpiler or ILManipulator are required.");
    }
}
