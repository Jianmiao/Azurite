namespace Azurite.NormalEditor.Loader.Routes;

public sealed record RouteMethod(string Id,string Category,string Assembly,string Type,string Method,string PointerField,int Token,long Rva,string ReturnType,bool Static,IReadOnlyList<string> Parameters);
public static class RouteBindingCatalog
{
    private static RouteMethod M(string id,string category,string assembly,string type,string method,string pointer,int token,long rva,string returns,bool isStatic,params string[] parameters)
        =>new(id,category,assembly,type,method,"NativeMethodInfoPtr_"+pointer,token,rva,returns,isStatic,Array.AsReadOnly(parameters));
    public static IReadOnlyList<RouteMethod> Methods { get; }=Array.AsReadOnly(new[]{
        M("cache","cache","Assembly-CSharp","UserSettings","get_CachePath","get_CachePath_Public_get_String_0",100689255,0x7f6a20,"System.String",false),
        M("workspace","workspace","Assembly-CSharp","UserSettings","get_WorkspacePath","get_WorkspacePath_Public_get_String_0",100689256,0x7f6c70,"System.String",false),
        M("discovery","discovery","Assembly-CSharp","AzureArchive.Automation.AuthoringControlProtocol","get_DiscoveryDirectory","get_DiscoveryDirectory_Internal_Static_get_String_0",100694828,0x90a330,"System.String",true),
        M("offline","offline","Assembly-CSharp","AzureArchive.Automation.AuthoringOfflineResources","ValidateDirectory","ValidateDirectory_Public_Static_Void_String_String_String_String_0",100695181,0x93c5b0,"System.Void",true,"System.String","System.String","System.String","System.String"),
        M("addressSet","addressSet","Unity.Addressables","UnityEngine.AddressableAssets.Initialization.AddressablesRuntimeProperties","SetPropertyValue","SetPropertyValue_Public_Static_Void_String_String_0",100663883,0x2f6f900,"System.Void",true,"System.String","System.String"),
        M("addressClear","addressClear","Unity.Addressables","UnityEngine.AddressableAssets.Initialization.AddressablesRuntimeProperties","ClearCachedPropertyValues","ClearCachedPropertyValues_Public_Static_Void_0",100663884,0x2f6edb0,"System.Void",true),
        M("addressEvaluate","addressEvaluate","Unity.Addressables","UnityEngine.AddressableAssets.Initialization.AddressablesRuntimeProperties","EvaluateProperty","EvaluateProperty_Public_Static_String_String_0",100663885,0x2f6ee30,"System.String",true,"System.String"),
        M("discoveryCtor","discovery","Assembly-CSharp","AzureArchive.Automation.AuthoringControlServer",".ctor","_ctor_Internal_Void_Func_4_String_JObject_CancellationToken_Task_1_JObject_String_0",100694848,0x90b160,"System.Void",false,"Il2CppSystem.Func`4<System.String,Newtonsoft.Json.Linq.JObject,Il2CppSystem.Threading.CancellationToken,Il2CppSystem.Threading.Tasks.Task`1<Newtonsoft.Json.Linq.JObject>>","System.String"),
        M("discoveryDispose","discovery","Assembly-CSharp","AzureArchive.Automation.AuthoringControlServer","Dispose","Dispose_Public_Virtual_Final_New_Void_0",100694855,0x90a550,"System.Void",false),
        M("resolve","addressEvaluate","Unity.Addressables","UnityEngine.AddressableAssets.AddressablesImpl","ResolveInternalId","ResolveInternalId_Public_String_String_0",100663497,0x2f6d350,"System.String",false,"System.String"),
        M("providerTransform","addressEvaluate","Unity.Addressables","UnityEngine.AddressableAssets.ResourceProviders.ContentCatalogProvider+InternalOp","GetTransformedInternalId","GetTransformedInternalId_Private_String_IResourceLocation_0",100663791,0x2f7de60,"System.String",false,"UnityEngine.ResourceManagement.ResourceLocations.IResourceLocation"),
        M("providerDetermine","addressEvaluate","Unity.Addressables","UnityEngine.AddressableAssets.ResourceProviders.ContentCatalogProvider+InternalOp","DetermineIdToLoad","DetermineIdToLoad_Internal_String_IResourceLocation_IList_1_Object_Boolean_0",100663792,0x2f7d940,"System.String",false,"UnityEngine.ResourceManagement.ResourceLocations.IResourceLocation","Il2CppSystem.Collections.Generic.IList`1<Il2CppSystem.Object>","System.Boolean"),
        M("providerLoaded","addressEvaluate","Unity.Addressables","UnityEngine.AddressableAssets.ResourceProviders.ContentCatalogProvider+InternalOp","OnCatalogLoaded","OnCatalogLoaded_Private_Void_ContentCatalogData_0",100663793,0x2f7e3e0,"System.Void",false,"UnityEngine.AddressableAssets.ResourceLocators.ContentCatalogData"),
        M("cacheDefault","cache","UnityEngine.CoreModule","UnityEngine.Caching","get_defaultCache","get_defaultCache_Public_Static_get_Cache_0",100663819,0x33977b0,"UnityEngine.Cache",true),
        M("cacheLookup","cache","UnityEngine.CoreModule","UnityEngine.Caching","GetCacheByPath","GetCacheByPath_Public_Static_Cache_String_0",100663817,0x3397100,"UnityEngine.Cache",true,"System.String"),
        M("cacheAdd","cache","UnityEngine.CoreModule","UnityEngine.Caching","AddCache","AddCache_Public_Static_Cache_String_0",100663815,0x33968b0,"UnityEngine.Cache",true,"System.String"),
        M("cacheSelect","cache","UnityEngine.CoreModule","UnityEngine.Caching","set_currentCacheForWriting","set_currentCacheForWriting_Public_Static_set_Void_Cache_0",100663821,0x33978a0,"System.Void",true,"UnityEngine.Cache"),
        M("cacheMove","cache","UnityEngine.CoreModule","UnityEngine.Caching","MoveCacheBefore","MoveCacheBefore_Public_Static_Void_Cache_Cache_0",100663818,0x33976b0,"System.Void",true,"UnityEngine.Cache","UnityEngine.Cache")
    });
}
