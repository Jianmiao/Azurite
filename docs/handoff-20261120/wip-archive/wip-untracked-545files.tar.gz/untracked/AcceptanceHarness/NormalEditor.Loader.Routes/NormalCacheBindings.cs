using System.Buffers.Binary;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Azurite.CacheRootLab;
using Azurite.EditorIsolation;
using Azurite.NormalEditor.Adapter;

namespace Azurite.NormalEditor.Loader.Routes;

// F-specific raw observation only. Reuses the fixed decoder/code/metadata
// contract, not PreparedPathProbe or its E/CLI admission. This class neither
// calls original helpers nor writes/seeds the global root or installs hooks.
internal sealed class NormalCacheBindings
{
    private static int claimed;
    private static readonly List<IntPtr> retainedModules=new();
    [DllImport("kernel32.dll",ExactSpelling=true)]private static extern uint GetCurrentThreadId();
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,EntryPoint="GetModuleHandleExW",SetLastError=true)]
    [return:MarshalAs(UnmanagedType.Bool)]private static extern bool GetModuleHandleEx(uint flags,IntPtr address,out IntPtr module);
    private readonly NormalRouteContext context;
    private readonly int managedThread;
    private readonly CurrentProcessMemory memory=new();
    private readonly NativeStringReader strings;
    private readonly ulong imageBase;
    internal NormalRouteContext Context=>context;
    internal CurrentProcessMemory Memory=>memory;
    private NormalCacheBindings(NormalRouteContext context,ulong imageBase)
    {this.context=context;this.imageBase=imageBase;managedThread=Environment.CurrentManagedThreadId;strings=new(memory);}
    internal ulong RootAddress=>Address(PinContract.RootRva,NativeStringReader.MeaningfulSize);
    internal ulong InitializerAddress=>Address(0x4c6810,1);
    internal ulong BuilderAddress=>Address(0x4d0170,1);
    internal ulong RootHelperAddress=>Address(0x4d45c0,1);
    internal static NormalCacheBindings Bind(NormalRouteContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        using var process=Process.GetCurrentProcess();
        var executable=process.MainModule?.FileName??throw new InvalidOperationException("Current executable identity unavailable.");
        CacheBindingRules.RequireHost(context.Binding,executable,Environment.ProcessId,GetCurrentThreadId());
        context.RequireStartupWindow(context.Binding); // Existing actual continuation assertion; not an exclusion proof.
        if(!OperatingSystem.IsWindows()||IntPtr.Size!=8||RuntimeInformation.ProcessArchitecture!=Architecture.X64)throw new InvalidOperationException("Exact x64 Windows binding required.");
        if(Interlocked.CompareExchange(ref claimed,1,0)!=0)throw new InvalidOperationException("Raw cache binding is a single attempt per owned child.");
        var install=context.Binding.Policy.Paths.Install;
        var core=typeof(PinContract).Assembly;var expectedCore=Path.Combine(install,InstallationAuthority.AdapterSubdirectory,"Azurite.CacheRoot.Core.LabOnly.dll");
        if(!RunPaths.Same(core.Location,expectedCore))throw new InvalidOperationException("Cache decoder must be the one pinned plugin dependency.");
        PinContract.RequireFileHash(expectedCore,CacheBindingRules.CoreSha256);
        PinContract.RequireFileHash(executable,"260fc3ecc5f38dab5230ba624a52e495708d861196dda72486c1250760fe6eff");
        PinContract.RequireFileHash(Path.Combine(install,"GameAssembly.dll"),"0776516c59811c724c450e205930546c5d102975f279e33c46c96b878fa06c8b");
        PinContract.VerifyFilesAndMetadata(install);
        var modules=process.Modules.Cast<ProcessModule>().ToArray();
        var unity=modules.Single(m=>string.Equals(m.ModuleName,"UnityPlayer.dll",StringComparison.OrdinalIgnoreCase));
        if(!RunPaths.Same(unity.FileName,Path.Combine(install,"UnityPlayer.dll"))||unity.ModuleMemorySize!=PinContract.UnityImageSize)throw new InvalidOperationException("Loaded Unity path/image size differs.");
        var game=modules.Single(m=>string.Equals(m.ModuleName,"GameAssembly.dll",StringComparison.OrdinalIgnoreCase));
        if(!RunPaths.Same(game.FileName,Path.Combine(install,"GameAssembly.dll")))throw new InvalidOperationException("Loaded GameAssembly location differs.");
        foreach(var pin in PinContract.ManagedModules)
        {
            var name=Path.GetFileNameWithoutExtension(pin.FileName);
            var assembly=AppDomain.CurrentDomain.GetAssemblies().Single(a=>a.GetName().Name==name);
            if(!RunPaths.Same(assembly.Location,Path.Combine(install,"BepInEx","core",pin.FileName))||assembly.ManifestModule.ModuleVersionId!=pin.Mvid||assembly.GetName().Version?.ToString()!=pin.Version)throw new InvalidOperationException("Loaded native-binding metadata differs: "+name);
        }
        var dobby=modules.Single(m=>string.Equals(m.ModuleName,"dobby.dll",StringComparison.OrdinalIgnoreCase));
        if(!RunPaths.Same(dobby.FileName,Path.Combine(install,"BepInEx","core","dobby.dll"))||dobby.ModuleMemorySize!=0x38000)throw new InvalidOperationException("Loaded native detour module differs.");
        context.RequireStartupWindow(context.Binding);
        if(!GetModuleHandleEx(4,unity.BaseAddress,out var retained)||retained!=unity.BaseAddress)throw new InvalidOperationException("Cannot retain the already verified Unity image.");
        lock(retainedModules)retainedModules.Add(retained); // Retained to child exit, never hot-unloaded.
        var result=new NormalCacheBindings(context,(ulong)unity.BaseAddress.ToInt64());
        result.RequireLiveImage();result.VerifyOriginalWindows();result.RequireDataSlots();
        context.RequireStartupWindow(context.Binding);
        return result;
    }
    internal void RequireOwner()
    {
        if(Environment.ProcessId!=context.Binding.Policy.ProcessId||Environment.CurrentManagedThreadId!=managedThread||GetCurrentThreadId()!=context.Binding.Policy.NativeThreadId)throw new InvalidOperationException("Raw cache observation belongs to another owner thread/process.");
    }
    private ulong Address(uint rva,int count)
    {
        if(count<0||(ulong)rva+(ulong)count>PinContract.UnityImageSize)throw new InvalidOperationException("Raw cache address escapes the pinned Unity image.");
        var address=checked(imageBase+rva);MemoryRange.Check(address,(ulong)count);return address;
    }
    private void RequireLiveImage()
    {
        memory.RequireModuleImage(imageBase,64,imageBase);var dos=memory.Read(imageBase,64);
        var offset=BinaryPrimitives.ReadInt32LittleEndian(dos.AsSpan(0x3c,4));
        if(dos[0]!='M'||dos[1]!='Z'||offset<64||offset>4096)throw new InvalidOperationException("Loaded Unity DOS header differs.");
        var pe=memory.Read(Address((uint)offset,84),84);
        if(BinaryPrimitives.ReadUInt32LittleEndian(pe)!=0x4550||BinaryPrimitives.ReadUInt16LittleEndian(pe.AsSpan(4))!=0x8664||BinaryPrimitives.ReadUInt16LittleEndian(pe.AsSpan(24))!=0x20b||BinaryPrimitives.ReadUInt32LittleEndian(pe.AsSpan(80))!=PinContract.UnityImageSize)throw new InvalidOperationException("Loaded Unity PE identity differs.");
    }
    // Before a future installer changes any entry; never use a post-detour
    // mismatch as permission to skip this original-code verification.
    internal void VerifyOriginalWindows()
    {
        RequireOwner();context.RequireStartupWindow(context.Binding);
        foreach(var pin in PinContract.CodeWindows)
        {var address=Address(pin.Rva,pin.Size);memory.RequireModuleImage(address,pin.Size,imageBase);memory.RequireExecutable(address,pin.Size);PinContract.CheckWindow(pin,memory.Read(address,pin.Size));}
    }
    internal void VerifyOriginalWindow(string name)
    {
        RequireOwner();context.RequireStartupWindow(context.Binding);
        var pin=PinContract.CodeWindows.Single(x=>x.Name==name);var address=Address(pin.Rva,pin.Size);
        memory.RequireModuleImage(address,pin.Size,imageBase);memory.RequireExecutable(address,pin.Size);PinContract.CheckWindow(pin,memory.Read(address,pin.Size));
    }
    private void RequireDataSlots()
    {
        foreach(var (rva,count) in new[]{(PinContract.RootRva,34),(PinContract.ManagerRva,8),(PinContract.AllocatorRva,8),(PinContract.CrtRva,4),(0x1913400U,2)})memory.RequireModuleImage(Address(rva,count),count,imageBase);
        if(!memory.Read(Address(0x1913400,2),2).SequenceEqual(new byte[]{9,0}))throw new InvalidOperationException("Native allocator-label literal differs.");
    }
    internal PreUseState Observe()
    {
        RequireOwner();
        return new PreUseState(BinaryPrimitives.ReadUInt32LittleEndian(memory.Read(Address(PinContract.CrtRva,4),4)),U64(PinContract.AllocatorRva),U64(PinContract.ManagerRva),memory.Read(RootAddress,34).SequenceEqual(PinContract.InitialRoot),GetCurrentThreadId());
    }
    internal NativeStringValue ReadRoot(){RequireOwner();return strings.Read(RootAddress,expectedLabel:0x49);}
    internal NativeStringValue InspectInitializer(IntPtr rawNativeCache,byte readIndex)
    {
        RequireOwner();if(rawNativeCache==IntPtr.Zero||readIndex>1)throw new InvalidOperationException("Native cache initializer pointer/byte argument differs.");
        var address=checked((ulong)rawNativeCache.ToInt64()+0x38);MemoryRange.Check(address,NativeStringReader.MeaningfulSize);
        var value=strings.Read(address,expectedLabel:9);CacheBindingRules.RequireCachePath(value,context.Binding.Policy.Paths);return value;
    }
    private ulong U64(uint rva)=>BinaryPrimitives.ReadUInt64LittleEndian(memory.Read(Address(rva,8),8));
}
