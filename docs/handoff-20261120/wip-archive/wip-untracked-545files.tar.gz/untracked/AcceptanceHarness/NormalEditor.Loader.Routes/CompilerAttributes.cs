// Same compiler metadata shim as the fixed Adapter.Host. The pinned Unity
// interop exposes a constructor-less NullableAttribute; this invokes no host.
namespace System.Runtime.CompilerServices;

[CompilerGenerated]
[AttributeUsage(AttributeTargets.All,Inherited=false)]
internal sealed class NullableAttribute : Attribute
{
    public readonly byte[] NullableFlags;
    public NullableAttribute(byte flag)=>NullableFlags=new[]{flag};
    public NullableAttribute(byte[] flags)=>NullableFlags=flags;
}
