using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;
using Azurite.CacheRootLab;
using BepInEx.Unity.IL2CPP.Hook;

namespace Azurite.NormalEditor.Loader.Routes;

// Temporary closed write boundary while global pre-use qualification is absent.
// This is not a permitting cache backend and cannot complete the cache category.
// Unrelated helper destinations retain their original behaviour and arguments.
internal sealed class GlobalRootWriteSentinel
{
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]private delegate void Helper(IntPtr utf16,IntPtr destination);
    private sealed class ExecutableMemory:IBoundedMemory
    {
        private readonly CurrentProcessMemory memory;
        internal ExecutableMemory(CurrentProcessMemory memory)=>this.memory=memory;
        public byte[] Read(ulong address,int count){memory.RequireExecutable(address,count);return memory.Read(address,count);}
    }
    private static GlobalRootWriteSentinel? retained;
    private readonly NormalCacheBindings native;
    private readonly NormalRouteContext context;
    private readonly int ownerThread=Environment.CurrentManagedThreadId;
    private readonly Helper callback;
    private readonly byte[] prefix;
    private INativeDetour? hook;
    private Helper? original;
    private bool registered;
    private int active;
    private GlobalRootWriteSentinel(NormalCacheBindings native)
    {this.native=native;context=native.Context;callback=Callback;prefix=native.Memory.Read(native.RootHelperAddress,21);}
    internal static GlobalRootWriteSentinel Install(NormalCacheBindings native)
    {
        native.RequireOwner();native.Context.RequireStartupWindow(native.Context.Binding);native.VerifyOriginalWindow("root_copy_helper");
        var state=new GlobalRootWriteSentinel(native);
        if(Interlocked.CompareExchange(ref retained,state,null) is not null)throw new InvalidOperationException("Root write sentinel registration is single-use.");
        try
        {
            state.hook=INativeDetour.CreateAndApply<Helper>((IntPtr)(long)native.RootHelperAddress,state.callback,out var trampoline);state.original=trampoline;
            state.VerifyOwnership();native.Context.RequireStartupWindow(native.Context.Binding);state.registered=true;return state;
        }
        catch(Exception e){state.Abort(e);throw;}
    }
    internal void VerifyOwnership()
    {
        native.RequireOwner();var h=hook??throw new InvalidOperationException("Root sentinel native hook is absent.");var target=Marshal.GetFunctionPointerForDelegate(callback);
        if(h.GetType().FullName!="BepInEx.Unity.IL2CPP.Hook.Dobby.DobbyDetour"||h.OriginalMethodPtr!=(IntPtr)(long)native.RootHelperAddress||h.DetourMethodPtr!=target||h.TrampolinePtr==IntPtr.Zero||h.TrampolinePtr==h.OriginalMethodPtr||h.TrampolinePtr==h.DetourMethodPtr||original is null||Marshal.GetFunctionPointerForDelegate(original)!=h.TrampolinePtr)
            throw new InvalidOperationException("Root sentinel native ownership differs.");
        var memory=new ExecutableMemory(native.Memory);native.Memory.RequireExecutable((ulong)target.ToInt64(),1);
        NativeJumpVerification.RequireTarget(memory,native.RootHelperAddress,(ulong)target.ToInt64());
        NativeJumpVerification.RequireTrampoline(memory,native.RootHelperAddress,prefix,(ulong)h.TrampolinePtr,new[]{5,10,11,15,18,21});
    }
    private void Callback(IntPtr utf16,IntPtr destination)
    {
        Interlocked.Increment(ref active);
        try
        {
            if(!registered||original is null)throw new InvalidOperationException("Root helper raced incomplete write-sentinel installation.");
            if(RootDestinationPolicy.OverlapsGlobal(destination,native.RootAddress))throw new InvalidOperationException("Global root mutation remains closed: no real normal pre-use/exclusion qualification exists.");
            // The helper is generic. Do not read an unrelated native string,
            // acquire the main-thread sink, rewrite it, or suppress its original.
            original(utf16,destination);
        }
        catch(Exception e){Abort(e);throw;}
        finally{Interlocked.Decrement(ref active);}
    }
    [DoesNotReturn]private void Abort(Exception e)
    {
        if(Environment.CurrentManagedThreadId==ownerThread)try{context.Reject(e.Message);}catch{}
        context.Fatal.Terminate("Global cache-root sentinel refused: "+e.Message);
        Environment.FailFast("Owned cache-root fatal boundary unexpectedly returned.");throw new InvalidOperationException("Unreachable.");
    }
    internal void RequireQuiescent(){native.RequireOwner();VerifyOwnership();if(Volatile.Read(ref active)!=0)throw new InvalidOperationException("Root helper callback is active.");}
    internal void RequireRegisteredForInterop(NormalRouteContext expected)
    {if(!registered||!ReferenceEquals(context,expected))throw new InvalidOperationException("Matching root write sentinel is not fully registered.");VerifyOwnership();}
}
