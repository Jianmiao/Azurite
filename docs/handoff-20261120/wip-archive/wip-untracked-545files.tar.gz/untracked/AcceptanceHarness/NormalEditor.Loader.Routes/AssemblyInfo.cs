using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("NormalEditor.Loader.Routes.Tests")]
