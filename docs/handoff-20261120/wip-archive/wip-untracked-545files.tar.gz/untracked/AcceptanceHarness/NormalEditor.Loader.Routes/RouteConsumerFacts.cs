using Azurite.NormalEditor.Entry;

namespace Azurite.NormalEditor.Loader.Routes;

public sealed class RouteCall
{
    internal RouteCall(string kind,long receiver){Kind=kind;Receiver=receiver;}
    public string Kind{get;}
    public long Receiver{get;}
}
public sealed class RouteConsumerFacts
{
    // This audit is consumed by future verified native hooks. It is not a hook
    // installer, cache pre-use proof, permission lease, or complete INormalRoutes.
    private sealed class Pending
    {
        internal bool Returned,CatalogData;
        internal string? Path;
    }
    private readonly NormalRouteContext context;
    private readonly RoutePathRules paths;
    private readonly Func<uint> nativeThread;
    private readonly int managedThread=Environment.CurrentManagedThreadId;
    private readonly Dictionary<RouteCall,Pending> active=new();
    private readonly Dictionary<long,string> providerPaths=new();
    private string? failure,discoveryMetadata;
    private long discoveryOwner;
    private int cacheGetters,offlineCompleted,persistentResolutions,catalogLoads;
    private bool discoveryDisposed;
    internal NormalRouteContext Context=>context;
    internal void AssertBoundCallback()=>Guard(()=>{});
    internal void RequireReturnCandidate(RouteCall frame,bool originalRan)=>Guard(()=>Need(!Frame(frame).Returned&&originalRan,"Original consumer must return before native field readback."));
    internal void RequireKnownProvider(long receiver)=>Guard(()=>Need(providerPaths.ContainsKey(receiver),"Unbound provider receiver before native field read."));
    internal void RequireKnownDiscovery(long receiver)=>Guard(()=>Need(receiver>0&&receiver==discoveryOwner&&!discoveryDisposed,"Unbound discovery receiver before native field read."));
    internal RouteConsumerFacts(NormalRouteContext context,Func<uint> nativeThread)
    {
        this.context=context??throw new ArgumentNullException(nameof(context));this.nativeThread=nativeThread??throw new ArgumentNullException(nameof(nativeThread));
        ArgumentNullException.ThrowIfNull(context.BoundSettingsOwner);ArgumentNullException.ThrowIfNull(context.Reject);
        paths=new(context.Binding,context.Resources);
    }
    private static void Need(bool value,string why){if(!value)throw new InvalidOperationException(why);}
    private T Guard<T>(Func<T> operation)
    {
        try
        {
            Need(Environment.ProcessId==context.Binding.Policy.ProcessId&&Environment.CurrentManagedThreadId==managedThread,"Foreign route process or managed callback thread.");
            Need(nativeThread()==context.Binding.Policy.NativeThreadId,"Foreign route native callback thread.");
            Need(Volatile.Read(ref failure) is null,"A prior consumer route failure is latched.");
            return operation();
        }
        catch(Exception e)
        {
            var first=Interlocked.CompareExchange(ref failure,e.Message,null) is null;
            // A foreign callback never enters a possibly owner-held admission
            // sink. Its latch is authoritative; the host must abort its own child.
            if(first&&Environment.CurrentManagedThreadId==managedThread)try{context.Reject(e.Message);}catch{}
            throw new InvalidOperationException("Resource consumer route refused: "+e.Message,e);
        }
    }
    private void Guard(Action operation)=>Guard(()=>{operation();return true;});
    private RouteCall Begin(string kind,long receiver)
    {
        Need(active.Count<32,"Bounded consumer callback audit exceeded.");
        Need(!active.Keys.Any(x=>x.Kind==kind&&x.Receiver==receiver),"Reentrant identical consumer callback.");
        var call=new RouteCall(kind,receiver);active.Add(call,new());return call;
    }
    private Pending Frame(RouteCall frame,string? kind=null)
    {
        Need(frame is not null&&active.ContainsKey(frame),"Foreign, completed or unknown consumer frame.");
        Need(kind is null||frame!.Kind==kind,"Consumer callback kind differs.");return active[frame!];
    }
    private Pending Returned(RouteCall frame,bool originalRan,string? kind=null)
    {
        var state=Frame(frame,kind);Need(!state.Returned&&originalRan,"Original consumer was suppressed or returned twice.");state.Returned=true;return state;
    }
    public string Getter(string category,long receiver)=>Guard(()=>
    {
        var result=paths.Getter(category,receiver,context.BoundSettingsOwner());if(category=="cache")cacheGetters++;return result;
    });
    public RouteCall OfflineEntered(string root,string catalog,string settings,string persistent)=>Guard(()=>
    {paths.OfflineArguments(root,catalog,settings,persistent);return Begin("offline",0);});
    public RouteCall DiscoveryEntered(long receiver,string directory)=>Guard(()=>
    {
        Need(receiver>0&&discoveryOwner==0&&!active.Keys.Any(x=>x.Kind=="discoveryCtor"),"Duplicate or invalid native discovery constructor.");
        paths.DiscoveryDirectory(directory);Need(Directory.EnumerateFileSystemEntries(directory).Take(1).Count()==0,"Native discovery must start in an empty owned directory.");return Begin("discoveryCtor",receiver);
    });
    public void DiscoveryReturned(RouteCall frame,bool originalRan,string metadata)=>Guard(()=>
    {paths.DiscoveryMetadata(metadata);Returned(frame,originalRan,"discoveryCtor").Path=metadata;});
    public RouteCall DiscoveryDisposeEntered(long receiver,string metadata)=>Guard(()=>
    {
        Need(discoveryOwner>0&&receiver==discoveryOwner&&!discoveryDisposed&&string.Equals(metadata,discoveryMetadata,StringComparison.OrdinalIgnoreCase),"Discovery disposal owner or published metadata drifted.");
        paths.DiscoveryMetadata(metadata);return Begin("discoveryDispose",receiver);
    });
    public RouteCall ProviderDecisionEntered(long receiver)=>Guard(()=>
    {Need(receiver>0&&providerPaths.Count<32,"Invalid or excessive native catalog provider instances.");return Begin("providerDetermine",receiver);});
    public void ProviderDecisionReturned(RouteCall frame,bool originalRan,string resolved,string local)=>Guard(()=>
    {
        paths.ProviderPath(resolved);if(!string.IsNullOrEmpty(local))paths.WritableCatalog(local);
        Returned(frame,originalRan,"providerDetermine").Path=local;
    });
    public RouteCall CatalogEffectsEntered(long receiver,string local)=>Guard(()=>
    {
        Need(receiver>0&&providerPaths.TryGetValue(receiver,out var expected)&&string.Equals(expected,local,StringComparison.OrdinalIgnoreCase),"Catalog effects lack their completed native decision or its exact local path.");
        Need(!active.Keys.Any(x=>x.Kind=="providerDetermine"&&x.Receiver==receiver),"Catalog effects arrived before a current decision finalized.");
        if(!string.IsNullOrEmpty(local))paths.WritableCatalog(local);return Begin("providerLoaded",receiver);
    });
    public void OriginalReturned(RouteCall frame,bool originalRan,bool catalogDataPresent=false)=>Guard(()=>
    {
        Need(frame.Kind is "offline" or "providerLoaded" or "discoveryDispose","This original return requires its typed path readback.");
        Returned(frame,originalRan).CatalogData=catalogDataPresent;
    });
    public void OriginalFinalized(RouteCall frame,Exception? error)=>Guard(()=>
    {
        var state=Frame(frame);Need(state.Returned&&error is null,"Original consumer finalizer lacks a successful original return.");
        switch(frame.Kind)
        {
            case "offline":offlineCompleted++;break;
            case "discoveryCtor":Need(discoveryOwner==0&&state.Path is not null,"Discovery completion was duplicated.");discoveryOwner=frame.Receiver;discoveryMetadata=state.Path;break;
            case "discoveryDispose":discoveryDisposed=true;break;
            case "providerDetermine":Need(state.Path is not null,"Provider decision path was never read back.");providerPaths[frame.Receiver]=state.Path!;break;
            case "providerLoaded":if(state.CatalogData)catalogLoads++;break;
            default:throw new InvalidOperationException("Unknown original consumer kind.");
        }
        active.Remove(frame);
    });
    public void Resolved(string input,string result)=>Guard(()=>
    {paths.PersistentResolution(input,result);if(input.Contains("{"+RoutePathRules.PersistentProperty+"}",StringComparison.Ordinal))persistentResolutions++;});
    public void Transformed(long receiver,string result,bool originalRan=true)=>Guard(()=>
    {
        Need(originalRan&&receiver>0&&(providerPaths.ContainsKey(receiver)||active.Keys.Any(x=>x.Kind=="providerDetermine"&&x.Receiver==receiver)),"Transformed catalog ID lacks its actual bound native provider call.");
        paths.ProviderPath(result);
    });
    public void RequireRecordedCatalogFacts(CatalogEvidence evidence)=>Guard(()=>
    {
        var binding=context.Binding.Policy;var stamp=evidence.Stamp;var observed=evidence.Observation;
        Need(evidence.Kind=="catalog-ready"&&evidence.Failure is null&&evidence.RunId==binding.RunId&&stamp.RunId==binding.RunId&&stamp.ProcessId==binding.ProcessId&&stamp.ManagedThreadId==managedThread&&stamp.NativeThreadId==binding.NativeThreadId,"Catalog consumer evidence identity differs.");
        Need(observed is not null&&observed.SettingsOwner==context.BoundSettingsOwner()&&observed.SettingsOwner>0&&observed.ResourceOwner>0,"Catalog refers to an unbound settings/resource owner.");
        Need(active.Count==0&&cacheGetters>0&&offlineCompleted>0&&persistentResolutions>0&&providerPaths.Count>0&&catalogLoads>0&&discoveryOwner>0&&!discoveryDisposed,"Required original consumer facts are incomplete.");
        // Deliberately no cache-root/hook-complete/readiness claim here.
    });
    public void RequireQuiescent()=>Guard(()=>Need(active.Count==0,"A native consumer callback has not finalized."));
}
