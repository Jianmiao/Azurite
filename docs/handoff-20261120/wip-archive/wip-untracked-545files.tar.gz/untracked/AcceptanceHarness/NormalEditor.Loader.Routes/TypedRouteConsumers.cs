using Azurite.EditorIsolation;
using AzureArchive.Automation;
using Il2CppInterop.Runtime.InteropTypes;
using UnityEngine.AddressableAssets.Initialization;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.AddressableAssets.ResourceProviders;

namespace Azurite.NormalEditor.Loader.Routes;

// Typed adapters for the exact generated interop. No automatic entry or hook
// registration: the eventual installer must first verify module/type/method
// identity and normal cache pre-use containment, and terminate its owned child
// on any callback exception. Original calls are performed by the native host.
public static class TypedRouteConsumers
{
    private static long Receiver(Il2CppObjectBase value,RouteCall? frame=null)
    {
        if(value is null||value.Pointer==IntPtr.Zero)throw new InvalidOperationException("Actual native receiver is absent.");
        var pointer=value.Pointer.ToInt64();if(frame is not null&&frame.Receiver!=pointer)throw new InvalidOperationException("Native callback receiver changed before field readback.");return pointer;
    }
    public static string CacheGetter(RouteConsumerFacts facts,global::UserSettings owner)=>facts.Getter("cache",Receiver(owner));
    public static string WorkspaceGetter(RouteConsumerFacts facts,global::UserSettings owner)=>facts.Getter("workspace",Receiver(owner));
    public static string DiscoveryGetter(RouteConsumerFacts facts)=>facts.Getter("discovery",0);
    public static RouteCall OfflineEntered(RouteConsumerFacts facts,string root,string catalog,string settings,ref string persistent)
    {
        facts.AssertBoundCallback();
        persistent=facts.Context.Binding.Policy.Paths.Persistent;
        var frame=facts.OfflineEntered(root,catalog,settings,persistent);
        AddressablesRuntimeProperties.SetPropertyValue(RoutePathRules.PersistentProperty,persistent);
        if(!RunPaths.Same(AddressablesRuntimeProperties.EvaluateProperty(RoutePathRules.PersistentProperty),persistent))throw new InvalidOperationException("Offline validator and Addressables persistent roots disagree.");
        return frame;
    }
    public static void AddressSetEntered(RouteConsumerFacts facts,string property,ref string value)
    {if(property!=RoutePathRules.PersistentProperty)return;facts.AssertBoundCallback();value=facts.Context.Binding.Policy.Paths.Persistent;}
    public static void AddressClearReturned(RouteConsumerFacts facts,bool originalRan)
    {
        facts.AssertBoundCallback();if(!originalRan||AddressablesRuntimeProperties.s_CachedValues.Count!=0)throw new InvalidOperationException("Original Addressables clear did not complete.");
        AddressablesRuntimeProperties.SetPropertyValue(RoutePathRules.PersistentProperty,facts.Context.Binding.Policy.Paths.Persistent);
    }
    public static void AddressEvaluateEntered(RouteConsumerFacts facts,string property)
    {if(property!=RoutePathRules.PersistentProperty)return;facts.AssertBoundCallback();AddressablesRuntimeProperties.SetPropertyValue(property,facts.Context.Binding.Policy.Paths.Persistent);}
    public static void AddressEvaluateReturned(RouteConsumerFacts facts,string property,string result,bool originalRan)
    {
        if(property!=RoutePathRules.PersistentProperty)return;facts.AssertBoundCallback();
        if(!originalRan||!RunPaths.Same(result,facts.Context.Binding.Policy.Paths.Persistent))throw new InvalidOperationException("Original persistent-property evaluation escaped its exact run.");
    }
    public static void ResolveReturned(RouteConsumerFacts facts,string input,string result,bool originalRan)
    {if(!originalRan)throw new InvalidOperationException("Original resolver was suppressed.");facts.Resolved(input,result);}
    public static RouteCall DiscoveryEntered(RouteConsumerFacts facts,AuthoringControlServer actual,string directory)=>facts.DiscoveryEntered(Receiver(actual),directory);
    public static void DiscoveryReturned(RouteConsumerFacts facts,AuthoringControlServer actual,RouteCall frame,bool originalRan)
    {facts.AssertBoundCallback();facts.RequireReturnCandidate(frame,originalRan);_=Receiver(actual,frame);facts.DiscoveryReturned(frame,originalRan,actual.metadataPath);}
    public static RouteCall DiscoveryDisposeEntered(RouteConsumerFacts facts,AuthoringControlServer actual)
    {var pointer=Receiver(actual);facts.RequireKnownDiscovery(pointer);return facts.DiscoveryDisposeEntered(pointer,actual.metadataPath);}
    public static RouteCall ProviderDecisionEntered(RouteConsumerFacts facts,ContentCatalogProvider.InternalOp actual)=>facts.ProviderDecisionEntered(Receiver(actual));
    public static void ProviderDecisionReturned(RouteConsumerFacts facts,ContentCatalogProvider.InternalOp actual,RouteCall frame,bool originalRan,string resolved)
    {facts.AssertBoundCallback();facts.RequireReturnCandidate(frame,originalRan);_=Receiver(actual,frame);facts.ProviderDecisionReturned(frame,originalRan,resolved,actual.m_LocalDataPath);}
    public static void ProviderTransformReturned(RouteConsumerFacts facts,ContentCatalogProvider.InternalOp actual,bool originalRan,string resolved)
    {facts.Transformed(Receiver(actual),resolved,originalRan);}
    public static RouteCall CatalogEffectsEntered(RouteConsumerFacts facts,ContentCatalogProvider.InternalOp actual)
    {var pointer=Receiver(actual);facts.RequireKnownProvider(pointer);return facts.CatalogEffectsEntered(pointer,actual.m_LocalDataPath);}
    public static void CatalogEffectsReturned(RouteConsumerFacts facts,RouteCall frame,bool originalRan,ContentCatalogData? actualCatalog)
    {facts.OriginalReturned(frame,originalRan,actualCatalog is not null&&actualCatalog.Pointer!=IntPtr.Zero);}
}
