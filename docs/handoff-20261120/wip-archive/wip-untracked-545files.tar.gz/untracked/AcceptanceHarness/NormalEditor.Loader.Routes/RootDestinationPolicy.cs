using Azurite.CacheRootLab;
namespace Azurite.NormalEditor.Loader.Routes;

public static class RootDestinationPolicy
{
    public static bool OverlapsGlobal(IntPtr destination,ulong globalRoot)
    {
        var value=unchecked((ulong)destination.ToInt64());
        MemoryRange.Check(value,NativeStringReader.SlotSize);MemoryRange.Check(globalRoot,NativeStringReader.SlotSize);
        return MemoryRange.Overlaps(value,NativeStringReader.SlotSize,globalRoot,NativeStringReader.SlotSize);
    }
}
