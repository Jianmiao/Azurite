#requires -Version 5.1
param([switch]$Execute,[string]$ReviewedPackageSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$build=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-build7'
if(-not $Execute){[pscustomobject]@{diagnosticOnly=$true;willExecute=$false;routes=@('fresh-created-full','same-process-DuplicateHandle-SAME_ACCESS','OpenDesktop-READOBJECTS');probesPerRoute=6;invalidMinusOneProbes=6;originalMeasurements=24;additionalNativeLists=8;additionalPairedEnumerations=8;listCapacities=@(1,64);maxMeasurements=40;undocumentedAbiDiagnosticOnly=$true;systemBinaryHashPinsRequired=$true;snapshotAtomicityClaimed=$false;createsWindows=$false;switchesDesktops=$false;createsChild=$false;createsJob=$false;restrictsToken=$false;changesFilesystemAcl=$false;usesExistingGlobalMutex=$true;productionMonitorChanged=$false};return}
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Diagnostic launcher must be system x64 PS5.1'}
if($ReviewedPackageSha256 -cnotmatch '^[a-f0-9]{64}$' -or (Get-FileHash (Join-Path $build 'manifest.json')).Hash.ToLowerInvariant() -cne $ReviewedPackageSha256){throw 'Externally reviewed diagnostic package digest required'}
$m=[IO.File]::ReadAllText((Join-Path $build 'manifest.json'))|ConvertFrom-Json
foreach($f in $m.files){$p=Join-Path $build $f.path;if((Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant() -cne $f.sha256 -or (Get-Item $p).Length -ne $f.bytes){throw 'Diagnostic package member changed'}}
if((Get-FileHash -LiteralPath $PSCommandPath).Hash -cne (Get-FileHash (Join-Path $build 'source\Run-Diagnostic.ps1')).Hash){throw 'Executed launcher differs from reviewed source'}
# No fixture pending recovery/clear occurs here. The diagnostic owns only its new
# desktop handles and one new C result directory; production monitor is unchanged.
& (Join-Path $build 'DesktopEnumDiagnostic.exe') --execute-reviewed-diagnostic
if($LASTEXITCODE -ne 0){throw 'Diagnostic failed; preserve all measurements and handles/results.'}
