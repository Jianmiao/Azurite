#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
/* Diagnostic snapshot only. Does not classify a false/error-zero result as success. */
typedef struct {
 DWORD size,input_error,mode,callback_count,owner_query_failures;
 DWORD first_owner_error,first_owner_pid,first_owner_tid,returned_error;
 BOOL returned_value,callback_returned_false;
} ENUM_SNAPSHOT;
static BOOL CALLBACK diagnostic_callback(HWND window,LPARAM context){
 ENUM_SNAPSHOT *s=(ENUM_SNAPSHOT*)context;DWORD pid=0,tid,error;
 s->callback_count++;
 if(s->mode==1){
  tid=GetWindowThreadProcessId(window,&pid);error=tid==0?GetLastError():0;
  if(tid==0||pid==0){s->owner_query_failures++;s->first_owner_error=error;s->first_owner_pid=pid;s->first_owner_tid=tid;s->callback_returned_false=TRUE;return FALSE;}
  (void)IsWindowVisible(window);
 }
 return TRUE;
}
__declspec(dllexport) BOOL WINAPI MeasureEnumeration(HDESK desktop,DWORD seed,DWORD mode,ENUM_SNAPSHOT *result){
 BOOL value;DWORD error;
 if(!result||mode>1)return FALSE;
 ZeroMemory(result,sizeof(*result));result->size=sizeof(*result);result->input_error=seed;result->mode=mode;
 SetLastError(seed);
 value=EnumDesktopWindows(desktop,diagnostic_callback,(LPARAM)result);
 error=GetLastError(); /* Captured immediately in native code, before any managed transition. */
 result->returned_value=value;result->returned_error=error;return TRUE;
}

/* Version-bound diagnostic ONLY. Signature is decoded from the exact pinned
   user32 callsite (desktop,0,0,1,0,capacity,handles,needed), not a public API.
   No list/BOOL/error combination is converted into production monitor success. */
typedef LONG (WINAPI *BUILD_HWND_LIST)(HDESK,HWND,BOOL,BOOL,DWORD,ULONG,HWND*,ULONG*);
typedef struct {
 DWORD size,capacity,seed,needed,status_bits,list_error,guard_before_ok,guard_after_ok,tail_unchanged,copied_slots;
 ULONGLONG before_list_qpc,after_list_qpc,after_enum_qpc,qpc_frequency;
 ULONGLONG slots[64];
 ENUM_SNAPSHOT enumeration;
 DWORD reserved;
} LIST_PAIR_SNAPSHOT;
typedef struct {ULONGLONG before;HWND slots[64];ULONGLONG after;} GUARDED_LIST;
_Static_assert(sizeof(LIST_PAIR_SNAPSHOT)==632,"AMD64 list diagnostic ABI size");
_Static_assert(sizeof(ENUM_SNAPSHOT)==44,"AMD64 enumeration diagnostic ABI size");
_Static_assert(sizeof(HWND)==8,"Pinned syscall ABI requires AMD64");
static BOOL list_guards(const GUARDED_LIST *b,ULONG capacity,BOOL *before,BOOL *after){
 ULONG i;BOOL tail=TRUE;
 *before=b->before==0xC0FFEE1122334455ULL;*after=b->after==0x55AA665544332211ULL;
 for(i=capacity;i<64;i++)if((ULONGLONG)(ULONG_PTR)b->slots[i]!=0x1111222233334444ULL)tail=FALSE;
 return tail;
}
__declspec(dllexport) BOOL WINAPI MeasureListAndEnumeration(HDESK desktop,DWORD capacity,DWORD seed,LIST_PAIR_SNAPSHOT *result){
 GUARDED_LIST buffer;ULONG i,needed=0xF00DFACE;LONG status;DWORD error;LARGE_INTEGER a,b,c,freq;BOOL first,last,tail;HMODULE module;BUILD_HWND_LIST build;
 if(!result||(capacity!=1&&capacity!=64))return FALSE;
 ZeroMemory(result,sizeof(*result));result->size=sizeof(*result);result->capacity=capacity;result->seed=seed;
 module=GetModuleHandleW(L"win32u.dll");if(!module)return FALSE;
 build=(BUILD_HWND_LIST)(void*)GetProcAddress(module,"NtUserBuildHwndList");if(!build)return FALSE;
 buffer.before=0xC0FFEE1122334455ULL;buffer.after=0x55AA665544332211ULL;
 for(i=0;i<64;i++)buffer.slots[i]=(HWND)(ULONG_PTR)0x1111222233334444ULL;
 if(!QueryPerformanceFrequency(&freq)||!QueryPerformanceCounter(&a))return FALSE;
 SetLastError(seed);
 status=build(desktop,NULL,FALSE,TRUE,0,capacity,buffer.slots,&needed);
 error=GetLastError(); /* Raw NTSTATUS, needed, data and error are independent. */
 if(!QueryPerformanceCounter(&b))return FALSE;
 tail=list_guards(&buffer,capacity,&first,&last);
 result->needed=needed;result->status_bits=(DWORD)status;result->list_error=error;
 result->guard_before_ok=first;result->guard_after_ok=last;result->tail_unchanged=tail;result->copied_slots=capacity;
 for(i=0;i<capacity;i++)result->slots[i]=(ULONGLONG)(ULONG_PTR)buffer.slots[i];
 result->before_list_qpc=(ULONGLONG)a.QuadPart;result->after_list_qpc=(ULONGLONG)b.QuadPart;result->qpc_frequency=(ULONGLONG)freq.QuadPart;
 if(!first||!last||!tail)return TRUE; /* Record corruption without a second call. */
 if(!MeasureEnumeration(desktop,seed,1,&result->enumeration))return FALSE;
 if(!QueryPerformanceCounter(&c))return FALSE;result->after_enum_qpc=(ULONGLONG)c.QuadPart;
 return TRUE;
}

#ifdef DESKTOP_LIST_PURE_TEST
#include <stdio.h>
int main(void){
 GUARDED_LIST buffer;BOOL before,after;ULONG i;int checks=0;
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL native pure guard %d\n",checks);return 1;}}while(0)
 buffer.before=0xC0FFEE1122334455ULL;buffer.after=0x55AA665544332211ULL;
 for(i=0;i<64;i++)buffer.slots[i]=(HWND)(ULONG_PTR)0x1111222233334444ULL;
 buffer.slots[0]=NULL;CHECK(list_guards(&buffer,1,&before,&after)&&before&&after);
 buffer.slots[1]=NULL;CHECK(!list_guards(&buffer,1,&before,&after)&&before&&after);
 CHECK(list_guards(&buffer,64,&before,&after)&&before&&after);
 buffer.before=0;CHECK(list_guards(&buffer,64,&before,&after)&&!before&&after);
 buffer.before=0xC0FFEE1122334455ULL;buffer.after=0;CHECK(list_guards(&buffer,64,&before,&after)&&before&&!after);
 printf("{\"scope\":\"native list buffer guards and ABI only\",\"passed\":true,\"checks\":%d,\"nativeApiInvoked\":false}\n",checks);return 0;
}
#endif
