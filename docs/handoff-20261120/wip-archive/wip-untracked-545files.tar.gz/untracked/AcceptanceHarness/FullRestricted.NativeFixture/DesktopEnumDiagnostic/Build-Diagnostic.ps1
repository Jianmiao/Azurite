#requires -Version 7.0
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$build=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-build7'
if(Test-Path -LiteralPath $build){throw 'Diagnostic build exists; preserve it instead of overwriting.'}
[void][IO.Directory]::CreateDirectory((Join-Path $build 'source'))
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
$pins=@{'RestrictedCliNative.cs'='fd5327d66f8963491c535a5a28b0e7b761e09316c44c172277431db35bb29987';'RestrictedCliFullRestricted.cs'='fd8cacca1945a45b49194094a0dd12cd226295fdf9fa0216b22a9b5522b9f8b3'}
foreach($name in $pins.Keys){$p=Join-Path $repo ('tools\headless\'+$name);if((Hash $p) -cne $pins[$name]){throw 'Accepted production source differs'};Copy-Item -LiteralPath $p -Destination (Join-Path $build ('source\'+$name))}
foreach($name in @('Diagnostic.cs','NativeEnumeration.c','Build-Diagnostic.ps1','Run-Diagnostic.ps1')){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $build ('source\'+$name))}
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
& $csc /nologo /target:exe /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll ('/out:'+(Join-Path $build 'DesktopEnumDiagnostic.exe')) (Join-Path $build 'source\RestrictedCliNative.cs') (Join-Path $build 'source\RestrictedCliFullRestricted.cs') (Join-Path $build 'source\Diagnostic.cs') 2>&1|Tee-Object -FilePath (Join-Path $build 'managed-build.log')
if($LASTEXITCODE -ne 0){throw 'Diagnostic managed compilation failed'}
$vcvars='C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
$lines=@('@echo off','setlocal',('call "'+$vcvars+'"'),'if errorlevel 1 exit /b 1',('where cl.exe > "'+$build+'\compiler-path.txt"'),
 ('cl.exe /nologo /LD /TC /std:c11 /W4 /WX /MT /O2 /GS /guard:cf /Fo:"'+$build+'\NativeEnumeration.obj" /Fe:"'+$build+'\NativeEnumeration.dll" "'+$build+'\source\NativeEnumeration.c" /link /MACHINE:X64 /DYNAMICBASE /NXCOMPAT /HIGHENTROPYVA /guard:cf user32.lib kernel32.lib'),
 'if errorlevel 1 exit /b 1',
 ('cl.exe /nologo /TC /std:c11 /W4 /WX /MT /O2 /DDESKTOP_LIST_PURE_TEST /Fo:"'+$build+'\NativeListPure.obj" /Fe:"'+$build+'\NativeListPure.exe" "'+$build+'\source\NativeEnumeration.c" /link /MACHINE:X64 /SUBSYSTEM:CONSOLE user32.lib kernel32.lib'),
 'if errorlevel 1 exit /b 1',('dumpbin /imports "'+$build+'\NativeEnumeration.dll" > "'+$build+'\native-imports.txt"'),'exit /b %errorlevel%')
[IO.File]::WriteAllText((Join-Path $build 'build-native.cmd'),(($lines -join ([string][char]13+[char]10))+[char]13+[char]10),[Text.Encoding]::ASCII)
& $env:ComSpec /d /c (Join-Path $build 'build-native.cmd') 2>&1|Tee-Object -FilePath (Join-Path $build 'native-build.log')
if($LASTEXITCODE -ne 0){throw 'Diagnostic native shim compilation failed'}
& (Join-Path $build 'NativeListPure.exe') 2>&1|Tee-Object -FilePath (Join-Path $build 'native-list-pure.json')
if($LASTEXITCODE -ne 0){throw 'Native buffer guard/ABI pure tests failed'}
& (Join-Path $build 'DesktopEnumDiagnostic.exe') --selftest 2>&1|Tee-Object -FilePath (Join-Path $build 'pure-result.json')
if($LASTEXITCODE -ne 0){throw 'Pure diagnostic classification/serialization tests failed'}
$compiler=Get-Content (Join-Path $build 'compiler-path.txt')|Select-Object -First 1
$record=[ordered]@{schema=1;diagnosticOnly=$true;desktopApisExecuted=$false;productionSources=$pins;csc=$csc;cscSha256=(Hash $csc);compiler=$compiler;compilerSha256=(Hash $compiler);vcvarsSha256=(Hash $vcvars);runtimeCommandExecuted='--selftest only';requestedMeasurementCommand='--execute-reviewed-diagnostic';files=@(Get-ChildItem -LiteralPath $build -File -Recurse|ForEach-Object{[ordered]@{path=$_.FullName.Substring($build.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Hash $_.FullName)}})}
[IO.File]::WriteAllText((Join-Path $build 'manifest.json'),(($record|ConvertTo-Json -Depth 10)+[char]10),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{built=$true;desktopApisExecuted=$false;manifestSha256=(Hash (Join-Path $build 'manifest.json'));path=$build}
