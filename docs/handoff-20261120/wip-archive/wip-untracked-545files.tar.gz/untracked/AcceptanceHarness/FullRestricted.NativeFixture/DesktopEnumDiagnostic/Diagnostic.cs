using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using Azurite.Restricted;
internal static class DesktopEnumDiagnostic {
 const string OutputRoot=@"C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-results";
 const string SourceHash="fd8cacca1945a45b49194094a0dd12cd226295fdf9fa0216b22a9b5522b9f8b3";
 const string User32Hash="4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91";
 const string Win32uHash="ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4";
 [StructLayout(LayoutKind.Sequential)]struct Sa{public int Size;public IntPtr Descriptor;[MarshalAs(UnmanagedType.Bool)]public bool Inherit;}
 [StructLayout(LayoutKind.Sequential)]public struct Snapshot {
  public uint Size,InputError,Mode,CallbackCount,OwnerQueryFailures,FirstOwnerError,FirstOwnerPid,FirstOwnerTid,ReturnedError;
  [MarshalAs(UnmanagedType.Bool)]public bool ReturnedValue;
  [MarshalAs(UnmanagedType.Bool)]public bool CallbackReturnedFalse;
 }
 [StructLayout(LayoutKind.Sequential)]struct ObjectBasic{public uint Attributes,GrantedAccess,HandleCount,PointerCount;[MarshalAs(UnmanagedType.ByValArray,SizeConst=10)]public uint[] Reserved;}
 [StructLayout(LayoutKind.Sequential)]struct UserFlags{public int Inherit,Reserved;public uint Flags;}
 [StructLayout(LayoutKind.Sequential)]struct ListPairSnapshot{
  public uint Size,Capacity,Seed,Needed,StatusBits,ListError,GuardBeforeOkay,GuardAfterOkay,TailUnchanged,CopiedSlots;
  public ulong BeforeListQpc,AfterListQpc,AfterEnumQpc,QpcFrequency;
  [MarshalAs(UnmanagedType.ByValArray,SizeConst=64)]public ulong[] Slots;
  public Snapshot Enumeration;public uint Reserved;
 }
 [DllImport("NativeEnumeration.dll",CallingConvention=CallingConvention.Winapi,SetLastError=false)]static extern bool MeasureEnumeration(IntPtr desktop,uint seed,uint mode,out Snapshot result);
 [DllImport("NativeEnumeration.dll",CallingConvention=CallingConvention.Winapi,SetLastError=false)]static extern bool MeasureListAndEnumeration(IntPtr desktop,uint capacity,uint seed,out ListPairSnapshot result);
 [DllImport("kernel32.dll")]static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr handle);
 [DllImport("kernel32.dll")]static extern uint GetCurrentThreadId();
 [DllImport("kernel32.dll",EntryPoint="SetLastError")]static extern void SetNativeLastError(uint error);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr source,IntPtr destinationProcess,out IntPtr duplicate,uint rights,bool inherit,uint options);
 [DllImport("kernel32.dll")]static extern IntPtr LocalFree(IntPtr pointer);
 [DllImport("ntdll.dll")]static extern int NtQueryObject(IntPtr handle,int kind,out ObjectBasic info,uint length,out uint needed);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool ConvertStringSecurityDescriptorToSecurityDescriptorW(string text,uint revision,out IntPtr descriptor,out uint bytes);
 [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateDesktopW(string name,IntPtr device,IntPtr mode,uint flags,uint access,ref Sa attributes);
 [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr OpenDesktopW(string name,uint flags,bool inherit,uint access);
 [DllImport("user32.dll",SetLastError=true)]static extern bool CloseDesktop(IntPtr handle);
 [DllImport("user32.dll",SetLastError=true)]static extern IntPtr OpenInputDesktop(uint flags,bool inherit,uint access);
 [DllImport("user32.dll")]static extern IntPtr GetThreadDesktop(uint thread);
 [DllImport("user32.dll")]static extern IntPtr GetProcessWindowStation();
 [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool GetUserObjectInformationW(IntPtr h,int index,StringBuilder text,uint size,out uint needed);
 [DllImport("user32.dll",EntryPoint="GetUserObjectInformationW",SetLastError=true)]static extern bool UserObjectFlags(IntPtr h,int index,out UserFlags flags,uint bytes,out uint needed);
 static readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=1048576};
 static readonly List<object> retained=new List<object>();
 static readonly List<string> cleanupFailures=new List<string>();
 static void Require(bool b,string why){if(!b)throw new InvalidOperationException(why);}
 interface IOriginalTokenQuery {
  int Open(out IntPtr token);Dictionary<string,object> Read(IntPtr token,Dictionary<string,object> capture);int Close(IntPtr token);
 }
 sealed class AcceptedOriginalTokenQuery:IOriginalTokenQuery {
  public int Open(out IntPtr token){bool okay=FullRestrictedToken.OpenProcessToken(GetCurrentProcess(),8,out token);return okay?0:Marshal.GetLastWin32Error();}
  public Dictionary<string,object> Read(IntPtr token,Dictionary<string,object> capture){return FullRestrictedToken.Read(token,capture);}
  public int Close(IntPtr token){if(CloseHandle(token))return 0;int error=Marshal.GetLastWin32Error();return error==0?-1:error;}
 }
 static Dictionary<string,object> ReadOriginalToken(IOriginalTokenQuery api,Dictionary<string,object> evidence,List<object> retainedReferences){
  IntPtr token=IntPtr.Zero;Exception primary=null;string closeFailure=null;Dictionary<string,object> actual=null;
  var capture=new Dictionary<string,object>();evidence["source"]="accepted-FullRestrictedToken.Read+ValidateOriginal";evidence["requestedAccess"]=8;evidence["snapshot"]=capture;evidence["restrictedTokenCreated"]=false;
  try{
   int error=api.Open(out token);evidence["openError"]=error;evidence["acquiredHandle"]=token.ToInt64().ToString("X");
   Require(error==0&&token!=IntPtr.Zero,"Open current original token failed; nativeError="+error);
   actual=api.Read(token,capture);Require(actual!=null,"Original token reader returned null snapshot");evidence["snapshot"]=actual;
   FullRestrictedToken.ValidateOriginal(actual);
   object user,logon,session;
   Require(actual.TryGetValue("user_sid",out user)&&user is string&&!String.IsNullOrEmpty((string)user),"Original user SID missing");
   Require(actual.TryGetValue("logon_sid",out logon)&&logon is string&&System.Text.RegularExpressions.Regex.IsMatch((string)logon,@"^S-1-5-5-\d+-\d+$"),"Original reader must return one actual Logon SID string");
   Require(actual.TryGetValue("session_id",out session)&&(session is int||session is uint||session is long)&&Convert.ToInt64(session)>=0,"Original session field missing or malformed");
   evidence["validated"]=true;
  }catch(Exception e){primary=e;evidence["readError"]=e.ToString();evidence["validated"]=false;}
  finally{
   if(token!=IntPtr.Zero){int error=-1;try{error=api.Close(token);}catch(Exception e){closeFailure=e.ToString();}
    evidence["closeAttempted"]=true;evidence["closeError"]=error;evidence["closed"]=error==0&&closeFailure==null;
    if(error!=0||closeFailure!=null){if(closeFailure==null)closeFailure="Close original-token query handle failed; nativeError="+error;evidence["closeFailure"]=closeFailure;evidence["retained"]=true;retainedReferences.Add(new{role="original-token-query",handle=token,error=error,exception=closeFailure});}
   }else{evidence["closeAttempted"]=false;evidence["closed"]=false;}
  }
  if(primary!=null||closeFailure!=null)throw new InvalidOperationException("Original token observation failed; read="+(primary==null?"none":primary.Message)+"; close="+(closeFailure??"none"),primary);
  return actual;
 }
 static string Classification(bool result,uint error,uint count,bool callbackStopped){
  if(result)return count==0?"api-returned-true-zero-callbacks":"api-returned-true-with-callbacks";
  if(callbackStopped)return "api-false-callback-stopped";
  return error==0?"api-false-error-zero-unresolved":"api-false-with-native-error";
 }
 static Dictionary<string,object> Info(IntPtr handle){
  var r=new Dictionary<string,object>{{"handle",handle.ToInt64().ToString("X")}};
  foreach(var pair in new[]{new{Index=2,Name="name"},new{Index=3,Name="type"}}){
   uint needed;var text=new StringBuilder(512);bool ok=GetUserObjectInformationW(handle,pair.Index,text,1024,out needed);int e=ok?0:Marshal.GetLastWin32Error();
   r[pair.Name]=new{success=ok,error=e,value=ok?text.ToString():null,needed=needed};
  }
  UserFlags flags;uint bytes;bool flagOkay=UserObjectFlags(handle,1,out flags,(uint)Marshal.SizeOf(typeof(UserFlags)),out bytes);
  r["flags"]=new{success=flagOkay,error=flagOkay?0:Marshal.GetLastWin32Error(),inherit=flags.Inherit,flags=flags.Flags,needed=bytes};
  ObjectBasic basic;uint returned;int status=NtQueryObject(handle,0,out basic,(uint)Marshal.SizeOf(typeof(ObjectBasic)),out returned);
  r["queriedRights"]=new{ntStatus=status,success=status>=0,grantedAccess=status>=0?(object)basic.GrantedAccess:null,requestedReadObjectsPresent=status>=0?(object)((basic.GrantedAccess&1)!=0):null,returned=returned};
  return r;
 }
 static void CloseOwned(ref IntPtr handle,string role,List<object> closes){
  if(handle==IntPtr.Zero)return;IntPtr value=handle;bool okay=CloseDesktop(value);int error=okay?0:Marshal.GetLastWin32Error();
  closes.Add(new{role=role,handle=value.ToInt64().ToString("X"),success=okay,error=error});
  if(!okay){retained.Add(new{role=role,handle=value,error=error});cleanupFailures.Add("CloseDesktop "+role+" failed; nativeError="+error);}
  handle=IntPtr.Zero; /* ownership moved to retained on failure; never retry close */
 }
 static object Context(List<object> closes,string phase){
  IntPtr input=OpenInputDesktop(0,false,1);int error=input==IntPtr.Zero?Marshal.GetLastWin32Error():0;object info=input==IntPtr.Zero?null:Info(input);
  CloseOwned(ref input,"input-observer-"+phase,closes);
  return new{threadId=GetCurrentThreadId(),threadDesktopBorrowed=Info(GetThreadDesktop(GetCurrentThreadId())),processWindowStationBorrowed=Info(GetProcessWindowStation()),inputDesktop=new{openError=error,info=info}};
 }
 static object ProductionProbe(IntPtr handle,uint seed){
  SetNativeLastError(seed);
  try{bool violation=WindowProbe.HasVisibleOnDesktop(handle,new int[0]);return new{path="exact-accepted-production-WindowProbe",seed=seed,returned=true,violation=violation,exception=(object)null,callbackCount=(object)null,note="No callback instrumentation added to accepted method"};}
  catch(Exception e){var native=e as Win32Exception;return new{path="exact-accepted-production-WindowProbe",seed=seed,returned=false,violation=(object)null,exception=new{type=e.GetType().FullName,message=e.Message,hresult=e.HResult,nativeErrorCode=native==null?(object)null:native.NativeErrorCode,stack=e.StackTrace},callbackCount=(object)null,note="Structured NativeErrorCode retained; no success reinterpretation"};}
 }
 static void Measure(string route,IntPtr handle,List<object> results){
  foreach(uint seed in new uint[]{0,0x1BADB002}){
   foreach(uint mode in new uint[]{0,1}){
    Snapshot s;bool wrapper=MeasureEnumeration(handle,seed,mode,out s);
    Require(wrapper&&s.Size==Marshal.SizeOf(typeof(Snapshot)),"Native diagnostic ABI mismatch");
    results.Add(new{route=route,path=mode==0?"direct-native-count-only":"direct-native-owner-query-callback",classification=Classification(s.ReturnedValue,s.ReturnedError,s.CallbackCount,s.CallbackReturnedFalse),raw=s});
   }
   results.Add(new{route=route,acceptedProduction=ProductionProbe(handle,seed)});
  }
 }
 static string ListClassification(ListPairSnapshot s){
  Require(s.Size==632&&(s.Capacity==1||s.Capacity==64)&&s.CopiedSlots==s.Capacity&&s.Slots!=null&&s.Slots.Length==64,"List diagnostic ABI/capacity mismatch");
  Require(s.GuardBeforeOkay==1&&s.GuardAfterOkay==1&&s.TailUnchanged==1,"List buffer guard/tail modified outside requested capacity");
  if(unchecked((int)s.StatusBits)<0)return s.Needed>s.Capacity?"negative-status-with-needed-over-capacity":"negative-status";
  Require(s.StatusBits==0,"Unexpected informational/nonzero successful status; retain and refuse interpretation");
  Require(s.Needed>0&&s.Needed<=s.Capacity,"Successful list count missing or beyond bounded capacity");
  for(int i=0;i<s.Needed;i++)Require(s.Slots[i]!=0x1111222233334444UL,"Successful list left an in-range slot uninitialized");
  return s.Needed==1&&s.Slots[0]==0?"observed-status-zero-one-null-entry-not-atomicity-proof":"observed-status-zero-bounded-list";
 }
 static void MeasureListPairs(string route,IntPtr handle,List<object> results){
  foreach(uint capacity in new uint[]{1,64}){
   ListPairSnapshot s;bool copied=MeasureListAndEnumeration(handle,capacity,0x1BADB002,out s);
   Require(copied,"Native list-pair diagnostic wrapper failed before complete observation");
   // Persist raw data before interpretation so negative/overflow/canary evidence survives.
   var row=new Dictionary<string,object>{{"route",route},{"raw",s},{"undocumentedDiagnosticOnly",true},{"snapshotAtomicityClaimed",false}};results.Add(row);
   row["classification"]=ListClassification(s);
   Require(s.QpcFrequency>0&&s.AfterListQpc>=s.BeforeListQpc&&s.AfterEnumQpc>=s.AfterListQpc,"Paired measurement timing invalid");
  }
 }
 static List<object> RequirePinnedSystemImages(bool requireLoaded){
  var result=new List<object>();foreach(var item in new[]{new{Name="user32.dll",Hash=User32Hash,Version="10.0.26100.9949"},new{Name="win32u.dll",Hash=Win32uHash,Version="10.0.26100.9818"}}){
   string path=Path.Combine(Environment.SystemDirectory,item.Name),actual;using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read))using(var hash=SHA256.Create())actual=BitConverter.ToString(hash.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
   Require(actual==item.Hash,"Pinned installed system image changed: "+item.Name);string version=FileVersionInfo.GetVersionInfo(path).FileVersion;Require(version.StartsWith(item.Version+" ",StringComparison.Ordinal)||version==item.Version,"System image version mismatch");
   string loadedPath=null;foreach(ProcessModule module in Process.GetCurrentProcess().Modules)if(String.Equals(module.ModuleName,item.Name,StringComparison.OrdinalIgnoreCase)){loadedPath=module.FileName;break;}
   Require(!requireLoaded||loadedPath!=null,"Pinned system module not loaded");Require(loadedPath==null||String.Equals(loadedPath,path,StringComparison.OrdinalIgnoreCase),"Loaded system module path differs");
   result.Add(new{path=path,sha256=actual,version=version,loadedPath=loadedPath,undocumentedAbiBound=true});
  }return result;
 }
 static void CompleteReport(Dictionary<string,object> report,string failure,List<string> cleanupErrors,int remaining,int measurements,long elapsed){
  string finalFailure=failure;
  if(cleanupErrors.Count>0)finalFailure=(finalFailure??String.Empty)+(finalFailure==null?String.Empty:"; ")+String.Join("; ",cleanupErrors);
  if(remaining>0&&finalFailure==null)finalFailure="Owned references retained without successful cleanup: "+remaining;
  report["finalFailure"]=finalFailure;report["cleanupErrors"]=cleanupErrors.ToArray();report["elapsedMs"]=elapsed;report["retainedOwnedReferences"]=remaining;report["completedMeasurements"]=measurements;report["diagnosticCompleted"]=finalFailure==null&&remaining==0;report["resultInterpretation"]="Measurements only; no native monitor acceptance rule is changed";
 }
 static int Selftest(){
  int count=0;Action<bool> check=b=>{count++;Require(b,"Pure diagnostic control "+count);};
  check(Classification(false,0,0,false)=="api-false-error-zero-unresolved");
  check(Classification(false,5,0,false)=="api-false-with-native-error");
  check(Classification(false,0,1,true)=="api-false-callback-stopped");
  check(Classification(true,0,0,false)=="api-returned-true-zero-callbacks");
  check(Classification(true,5,2,false)=="api-returned-true-with-callbacks");
  var examples=new List<object>();foreach(int code in new[]{0,5,6,87}){var e=new Win32Exception(code,"Private desktop window enumeration failed");examples.Add(new{inputNativeCode=code,nativeCode=e.NativeErrorCode,hresult=e.HResult,toString=e.ToString()});check(e.NativeErrorCode==code);}
  check(Marshal.SizeOf(typeof(Snapshot))==44);check(Marshal.SizeOf(typeof(ObjectBasic))==56);
  var cleanupReport=new Dictionary<string,object>();CompleteReport(cleanupReport,null,new List<string>{"Priority restore: injected"},0,24,1);
  check(!(bool)cleanupReport["diagnosticCompleted"]);
  check(cleanupReport.ContainsKey("finalFailure")&&((string)cleanupReport["finalFailure"]).Contains("Priority restore: injected"));
  check(((string[])cleanupReport["cleanupErrors"]).Length==1);
  var primaryAndCleanup=new Dictionary<string,object>{{"failure",new{message="primary-create-failure"}}};CompleteReport(primaryAndCleanup,"primary-create-failure",new List<string>{"Mutex release: injected"},1,0,1);
  check(!(bool)primaryAndCleanup["diagnosticCompleted"]&&((string)primaryAndCleanup["finalFailure"]).Contains("primary-create-failure")&&((string)primaryAndCleanup["finalFailure"]).Contains("Mutex release: injected")&&primaryAndCleanup.ContainsKey("failure"));
  var closeOnly=new Dictionary<string,object>();CompleteReport(closeOnly,null,new List<string>{"CloseDesktop failed; nativeError=6"},1,24,1);
  check(!(bool)closeOnly["diagnosticCompleted"]&&((string)closeOnly["finalFailure"]).Contains("nativeError=6"));
  var unresolved=new Dictionary<string,object>{{"classification",Classification(false,0,0,false)}};CompleteReport(unresolved,null,new List<string>(),0,24,1);
  check((bool)unresolved["diagnosticCompleted"]&&(string)unresolved["classification"]=="api-false-error-zero-unresolved");
  check(unresolved["finalFailure"]==null&&((string[])unresolved["cleanupErrors"]).Length==0);
  foreach(string mode in new[]{"okay","zero-logon","multiple-logons","null-snapshot","missing-logon","null-logon","array-zero-logon","array-multi-logon","missing-session","close-error","close-throw","read-and-close-error","open-failed","open-partial"}){
   CheckOriginalQueryCase(mode,new FakeOriginalTokenQuery(mode),check);
  }
  bool unexpectedSuccessRejected=false;
  try{CheckOriginalQueryCase("missing-logon",new FakeOriginalTokenQuery("okay"),value=>{if(!value)throw new TestAssertionException();});}
  catch(TestAssertionException){unexpectedSuccessRejected=true;}
  check(unexpectedSuccessRejected);
  check(Marshal.SizeOf(typeof(ListPairSnapshot))==632);
  var sample=new ListPairSnapshot{Size=632,Capacity=1,CopiedSlots=1,Needed=1,StatusBits=0,GuardBeforeOkay=1,GuardAfterOkay=1,TailUnchanged=1,Slots=new ulong[64]};
  check(ListClassification(sample)=="observed-status-zero-one-null-entry-not-atomicity-proof");
  sample.Slots[0]=10;check(ListClassification(sample)=="observed-status-zero-bounded-list");
  sample.StatusBits=0xC0000023;sample.Needed=2;check(ListClassification(sample)=="negative-status-with-needed-over-capacity");
  sample.StatusBits=0xC0000008;sample.Needed=0;check(ListClassification(sample)=="negative-status");
  foreach(string fault in new[]{"before-canary","after-canary","tail","too-many","zero-count","unwritten","informational","capacity","wrong-size"}){
   var bad=new ListPairSnapshot{Size=632,Capacity=1,CopiedSlots=1,Needed=1,StatusBits=0,GuardBeforeOkay=1,GuardAfterOkay=1,TailUnchanged=1,Slots=new ulong[64]};
   switch(fault){case "before-canary":bad.GuardBeforeOkay=0;break;case "after-canary":bad.GuardAfterOkay=0;break;case "tail":bad.TailUnchanged=0;break;case "too-many":bad.Needed=2;break;case "zero-count":bad.Needed=0;break;case "unwritten":bad.Slots[0]=0x1111222233334444UL;break;case "informational":bad.StatusBits=1;break;case "capacity":bad.Capacity=65;break;case "wrong-size":bad.Size=628;break;}
   bool refused=false;try{ListClassification(bad);}catch(InvalidOperationException){refused=true;}check(refused);
  }
  Console.WriteLine(json.Serialize(new{scope="pure classification exception serialization ABI and identity harness only",passed=true,checks=count,unexpectedSuccessMetaNegativePassed=unexpectedSuccessRejected,desktopApisCalled=false,examples=examples}));return 0;
 }
 sealed class TestAssertionException:Exception {}
 static void CheckOriginalQueryCase(string mode,FakeOriginalTokenQuery api,Action<bool> check){
   var evidence=new Dictionary<string,object>();var saved=new List<object>();bool refused=false;string message=null;Dictionary<string,object> original=null;
   // Only the operation belongs inside this catch. Test assertions must escape.
   try{original=ReadOriginalToken(api,evidence,saved);}catch(Exception e){refused=true;message=e.Message;}
   if(!refused)check(mode=="okay"&&(string)original["logon_sid"]=="S-1-5-5-1-2");
   check(refused==(mode!="okay"));
   check(api.CloseCalls==(mode=="open-failed"?0:1));
   if(mode=="close-error"||mode=="close-throw"||mode=="read-and-close-error"){check(saved.Count==1&&!(bool)evidence["closed"]&&message.Contains("close="));}
   else check(saved.Count==0);
   if(mode=="read-and-close-error")check(message.Contains("injected zero actual Logon matches")&&message.Contains("nativeError=6"));
   if(mode=="zero-logon"||mode=="multiple-logons")check(evidence.ContainsKey("readError")&&api.ReadCalls==1);
 }
 sealed class FakeOriginalTokenQuery:IOriginalTokenQuery {
  readonly string mode;internal int ReadCalls,CloseCalls;internal FakeOriginalTokenQuery(string value){mode=value;}
  public int Open(out IntPtr token){token=mode=="open-failed"?IntPtr.Zero:new IntPtr(1234);return mode=="open-failed"||mode=="open-partial"?5:0;}
  public Dictionary<string,object> Read(IntPtr token,Dictionary<string,object> capture){
   ReadCalls++;Require(token.ToInt64()==1234,"Fake query changed acquired identity");
   if(mode=="zero-logon"||mode=="read-and-close-error")throw new InvalidOperationException("injected zero actual Logon matches");
   if(mode=="multiple-logons")throw new InvalidOperationException("injected multiple actual Logon matches");
   if(mode=="null-snapshot")return null;
   var result=new Dictionary<string,object>{{"user_sid","S-1-5-21-1-2-3-1001"},{"logon_sid","S-1-5-5-1-2"},{"session_id",1},{"is_restricted",false},{"elevated",false},{"is_app_container",false},{"app_container_raw",0},{"token_type",1},{"users_group_count",1},{"users_group_attributes",7},{"users_enabled",true}};
   if(mode=="missing-logon")result.Remove("logon_sid");if(mode=="null-logon")result["logon_sid"]=null;if(mode=="array-zero-logon")result["logon_sid"]=new string[0];if(mode=="array-multi-logon")result["logon_sid"]=new[]{"S-1-5-5-1-2","S-1-5-5-3-4"};if(mode=="missing-session")result.Remove("session_id");return result;
  }
  public int Close(IntPtr token){CloseCalls++;Require(token.ToInt64()==1234,"Close changed acquired token identity");if(mode=="close-throw")throw new InvalidOperationException("injected CloseHandle exception");return mode=="close-error"||mode=="read-and-close-error"?6:0;}
 }
 static int Execute(){
  string id=Guid.NewGuid().ToString("N"),name="AzuriteEnumDiag_"+id,run=Path.Combine(OutputRoot,id);Directory.CreateDirectory(run);
  var report=new Dictionary<string,object>{{"schema",1},{"diagnosticOnly",true},{"productionTargetExecuted",false},{"acceptedSourceSha256",SourceHash},{"id",id},{"requestedDesktopName",name},{"falseZeroAcceptanceChanged",false}};
  var closes=new List<object>();var results=new List<object>();var listResults=new List<object>();report["closes"]=closes;report["measurements"]=results;report["nativeListPairs"]=listResults;report["additionalNativeListCallsLimit"]=8;report["additionalPairedEnumerationCallsLimit"]=8;
  IntPtr direct=IntPtr.Zero,duplicate=IntPtr.Zero,opened=IntPtr.Zero,sd=IntPtr.Zero;Mutex mutex=null;bool held=false;string failure=null;
  var watch=Stopwatch.StartNew();ProcessPriorityClass priority=Process.GetCurrentProcess().PriorityClass;
  try{
   mutex=new Mutex(false,@"Global\AzuriteRestrictedCli-AA");try{held=mutex.WaitOne(0);}catch(AbandonedMutexException){held=true;}Require(held,"Existing diagnostic/AA mutex is held");
   Require(Process.GetProcessesByName("AzureArchive").Length==0&&Process.GetProcessesByName("AzuriteLifecycleProbe").Length==0,"Actual AA/probe must be absent");
   report["pinnedSystemImages"]=RequirePinnedSystemImages(false);
   {
    var tokenEvidence=new Dictionary<string,object>();report["originalTokenRead"]=tokenEvidence;
    var original=ReadOriginalToken(new AcceptedOriginalTokenQuery(),tokenEvidence,retained);
    string user=(string)original["user_sid"],logon=(string)original["logon_sid"];
    report["userSid"]=user;report["logonSid"]=logon;report["sessionId"]=original["session_id"];
    report["before"]=Context(closes,"before");
    report["pinnedLoadedSystemImages"]=RequirePinnedSystemImages(true);
    IntPtr existing=OpenDesktopW(name,0,false,1);int absence=existing==IntPtr.Zero?Marshal.GetLastWin32Error():0;
    if(existing!=IntPtr.Zero){CloseOwned(ref existing,"unexpected-existing",closes);throw new InvalidOperationException("Diagnostic desktop name already exists");}
    Require(absence==2,"Fresh desktop absence not proven; error="+absence);report["absenceError"]=absence;
    string sddl="O:"+user+"D:P(A;;0xF01FF;;;"+user+")(A;;0xF01FF;;;"+logon+")";report["descriptorIntent"]=sddl;
    uint bytes;Require(ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl,1,out sd,out bytes),"Build same descriptor intent");
    var attributes=new Sa{Size=Marshal.SizeOf(typeof(Sa)),Descriptor=sd,Inherit=false};
    direct=CreateDesktopW(name,IntPtr.Zero,IntPtr.Zero,0,0xF01FF,ref attributes);int creationError=direct==IntPtr.Zero?Marshal.GetLastWin32Error():0;report["createError"]=creationError;Require(direct!=IntPtr.Zero,"CreateDesktop error="+creationError);
    report["afterCreateContext"]=Context(closes,"after-create");report["direct"]=Info(direct);
    Require(DuplicateHandle(GetCurrentProcess(),direct,GetCurrentProcess(),out duplicate,0,false,2),"Duplicate same-access diagnostic desktop");report["duplicateSameAccess"]=Info(duplicate);
    opened=OpenDesktopW(name,0,false,1);int openError=opened==IntPtr.Zero?Marshal.GetLastWin32Error():0;report["openReadObjectsError"]=openError;Require(opened!=IntPtr.Zero,"OpenDesktop READOBJECTS error="+openError);report["openedReadObjects"]=Info(opened);
    Process.GetCurrentProcess().PriorityClass=ProcessPriorityClass.BelowNormal;
    Measure("owned-CreateDesktop-full",direct,results);Require(watch.ElapsedMilliseconds<10000,"Diagnostic deadline");
    Measure("owned-DuplicateHandle-SAME_ACCESS",duplicate,results);Require(watch.ElapsedMilliseconds<10000,"Diagnostic deadline");
    Measure("owned-OpenDesktop-READOBJECTS",opened,results);Require(watch.ElapsedMilliseconds<10000,"Diagnostic deadline");
    Measure("invalid-minus-one-query-negative",new IntPtr(-1),results);
    MeasureListPairs("owned-CreateDesktop-full",direct,listResults);Require(watch.ElapsedMilliseconds<10000,"Diagnostic list deadline");
    MeasureListPairs("owned-DuplicateHandle-SAME_ACCESS",duplicate,listResults);Require(watch.ElapsedMilliseconds<10000,"Diagnostic list deadline");
    MeasureListPairs("owned-OpenDesktop-READOBJECTS",opened,listResults);Require(watch.ElapsedMilliseconds<10000,"Diagnostic list deadline");
    MeasureListPairs("invalid-minus-one-query-negative",new IntPtr(-1),listResults);
    report["afterMeasurementsContext"]=Context(closes,"after-measurements");
   }
  }catch(Exception e){failure=e.ToString();report["failure"]=new{type=e.GetType().FullName,message=e.Message,hresult=e.HResult,nativeErrorCode=e is Win32Exception?(object)((Win32Exception)e).NativeErrorCode:null,stack=e.StackTrace};}
  finally{
   CloseOwned(ref opened,"owned-opened",closes);CloseOwned(ref duplicate,"owned-duplicate",closes);CloseOwned(ref direct,"owned-created",closes);
   try{report["afterCleanupContext"]=Context(closes,"after-cleanup");}catch(Exception e){cleanupFailures.Add("Final desktop context: "+e.ToString());}
   if(sd!=IntPtr.Zero){bool freed=LocalFree(sd)==IntPtr.Zero;int error=freed?0:Marshal.GetLastWin32Error();closes.Add(new{role="owned-security-descriptor",success=freed,error=error});if(!freed){retained.Add(sd);cleanupFailures.Add("LocalFree security descriptor failed; nativeError="+error);}}
   try{Process.GetCurrentProcess().PriorityClass=priority;}catch(Exception e){cleanupFailures.Add("Priority restore: "+e.ToString());}
   if(mutex!=null){try{if(held){mutex.ReleaseMutex();held=false;}}catch(Exception e){cleanupFailures.Add("Mutex release: "+e.ToString());retained.Add(mutex);}if(!held)try{mutex.Dispose();}catch(Exception e){cleanupFailures.Add("Mutex dispose: "+e.ToString());retained.Add(mutex);}}
   CompleteReport(report,failure,cleanupFailures,retained.Count,results.Count,watch.ElapsedMilliseconds);
   report["completedNativeListPairs"]=listResults.Count;
   byte[] data=new UTF8Encoding(false).GetBytes(json.Serialize(report));using(var fs=new FileStream(Path.Combine(run,"result.json"),FileMode.CreateNew,FileAccess.Write,FileShare.Read)){fs.Write(data,0,data.Length);fs.Flush(true);}
  }
  Console.WriteLine(json.Serialize(new{diagnosticOnly=true,resultPath=Path.Combine(run,"result.json"),completed=(bool)report["diagnosticCompleted"],finalFailure=report["finalFailure"],productionTargetExecuted=false}));
  return (bool)report["diagnosticCompleted"]?0:1;
 }
 static int Main(string[] args){try{if(args.Length==1&&args[0]=="--selftest")return Selftest();if(args.Length==1&&args[0]=="--execute-reviewed-diagnostic")return Execute();Console.WriteLine("Only --selftest or separately reviewed --execute-reviewed-diagnostic is supported.");return 2;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
