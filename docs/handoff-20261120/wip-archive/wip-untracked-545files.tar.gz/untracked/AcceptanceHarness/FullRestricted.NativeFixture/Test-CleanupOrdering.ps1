param([Parameter(Mandatory)][string]$OutputDirectory,[string]$MonitorPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
if(-not (Get-Command Assert-FixtureCleanupOrdering -ErrorAction SilentlyContinue)){throw 'Required actual cleanup-ordering predicate is absent'}
if(-not $MonitorPath){$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$MonitorPath=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\build-structured2\serialization-ps51-monitor.json'}
$monitor=Read-FixtureJson $MonitorPath
$id='a'*32;$count=0;$names=[Collections.Generic.List[string]]::new()
function Copy-Case($value){$p=@{InputObject=($value|ConvertTo-Json -Depth 70 -Compress);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$p.DateKind='String'};ConvertFrom-Json @p}
function Check($ok,[string]$name){if(-not $ok){throw ('Cleanup-ordering test failed: '+$name)};$script:count++;$script:names.Add($name)}
function New-Case([int[]]$Counts){
 $rows=[Collections.Generic.List[object]]::new();$ordinal=0;$qpc=[long]9007199254741000;$iteration=0
 foreach($remaining in $Counts){
  $iteration++;$ops=@('DirectExited','ActiveProcesses','WindowViolation','ProcessIds');if($remaining -gt 0){$ops+=,'Pause'}else{$ops+=@('FinishStreams','CloseDesktop','FinalizeFullObserver')}
  $parent=0
  foreach($op in $ops){$ordinal++;$before=$qpc;$after=$qpc+10;$qpc+=20;if($op -ceq 'WindowViolation'){$parent=$ordinal;$after=$before+35};if($op -ceq 'ProcessIds'){$before-=5;$after-=5}
   $close=$op -ceq 'CloseDesktop';$final=$op -ceq 'FinalizeFullObserver';$kind=if($op -in @('DirectExited','WindowViolation','FinishStreams')){'boolean'}elseif($op -in @('ActiveProcesses','ProcessIds','Pause')){'number'}else{'void'}
   $rows.Add([ordered]@{ordinal=$ordinal;parentOrdinal=$(if($op -ceq 'ProcessIds'){$parent}else{0});phase=$(if($final){'finalize'}else{'drain'});iteration=$iteration;operation=$op;beforeQpc=$before;afterQpc=$after;completed=$true;threw=$false;resultKind=$kind;boolean=$(if($kind -ceq 'boolean'){$op -cne 'WindowViolation'}else{$null});number=$(if($kind -ceq 'number'){if($op -ceq 'Pause'){10}else{$remaining}}else{$null});error=$null;jobAcquired=777;jobBefore=777;jobAfter=$(if($final){0}else{777});jobClosedBefore=$false;jobClosedAfter=$final;jobRetainedBefore=$false;jobRetainedAfter=$false;jobCloseAttemptedBefore=$false;jobCloseAttemptedAfter=$final;jobCloseErrorAfter=0;desktopAcquired=1234;desktopBefore=$(if($final){0}else{1234});desktopAfter=$(if($close -or $final){0}else{1234});desktopClosedBefore=$final;desktopClosedAfter=($close -or $final);desktopRetainedBefore=$false;desktopRetainedAfter=$false;desktopCloseAttemptedBefore=$final;desktopCloseAttemptedAfter=($close -or $final);desktopCloseErrorAfter=0})
  }
 }
 $trace=[ordered]@{schema='cleanup-ordering.v1';runId=$id;bootstrapPid=40;processStarted=$true;contextBound=$true;jobRole='outer-job-observer';jobAcquired=777;desktopRole='outer-private-desktop';desktopAcquired=1234;desktopName=('AzuriteFullCli_'+$id);qpcFrequency=10000000;capacity=2048;recordCount=$rows.Count;droppedCount=0;complete=$true;recordError=$null;externalLiveDescendantIntervalClaimed=$false;records=$rows.ToArray()}
 $m=Copy-Case $monitor;$m.emptyCount=1000;$m|Add-Member -NotePropertyName outerDrain -NotePropertyValue $trace -Force
 $outer=[ordered]@{Pid=40;RunId=$id;StartedUtc='2026-11-13T01:02:03.1234567Z';ExitCode=73;CleanupVerified=$true;DirectProcessExited=$true;JobDrained=$true;RemainingOwnedProcesses=0;JobObserved=$true;DesktopLeaseObserved=$true;DesktopLeaseClosed=$true;DesktopLeaseRetained=$false;FullJobObserverClosed=$true;FullJobObserverRetained=$false;FullJobObserverCloseError=0;StreamCaptureComplete=$true;TimedOut=$false;WindowViolation=$false;OutputLimitExceeded=$false;NoProcessCreated=$false;FullRestrictedMode=$true;Error=$null;CleanupError='';FullDesktopMonitorEvidence=$m}
 return Copy-Case ([ordered]@{Trace=$trace;Outer=$outer})
}
function Test-Case($c){$c.Outer.FullDesktopMonitorEvidence.outerDrain=$c.Trace;Assert-FixtureCleanupOrdering $c.Trace $c.Outer $id}
$zero=New-Case @(0);$multi=New-Case @(2,1,0)
Test-Case $zero;Check $true 'synthetic first Job0 still monitors and closes'
Test-Case $multi;Check $true 'synthetic multiround monitors until Job0 then closes'
function Refuse([scriptblock]$mutate,[string]$name){$c=Copy-Case $multi;Test-Case (Copy-Case $multi);& $mutate $c;$caught=$false;try{Test-Case $c}catch{$caught=$true};Check $caught $name}
foreach($field in @('schema','runId','jobRole','desktopRole','desktopName')){Refuse {param($c)$c.Trace.$field='wrong'} ('trace '+$field)}
foreach($field in @('bootstrapPid','jobAcquired','desktopAcquired','qpcFrequency','capacity','recordCount')){Refuse {param($c)$c.Trace.$field=0} ('trace numeric '+$field);Refuse {param($c)$c.Trace.$field=[string]$c.Trace.$field} ('trace numeric string '+$field)}
foreach($field in @('processStarted','contextBound','complete')){Refuse {param($c)$c.Trace.$field=$false} ('trace false '+$field);Refuse {param($c)$c.Trace.$field='true'} ('trace string bool '+$field)}
Refuse {param($c)$c.Trace.externalLiveDescendantIntervalClaimed=$true} 'cannot claim old external interval'
Refuse {param($c)$c.Trace.externalLiveDescendantIntervalClaimed='false'} 'external flag typed'
Refuse {param($c)$c.Trace.droppedCount=1} 'overflow rejects'
Refuse {param($c)$c.Trace.recordError='record failed'} 'record error rejects'
Refuse {param($c)$c.Trace.records=$null} 'missing records'
Refuse {param($c)$c.Trace.records=[pscustomobject]@{value=$c.Trace.records;Count=$c.Trace.recordCount}} 'array wrapper refused'
foreach($field in @('CleanupVerified','DirectProcessExited','JobDrained','JobObserved','DesktopLeaseObserved','DesktopLeaseClosed','FullJobObserverClosed','StreamCaptureComplete','FullRestrictedMode')){Refuse {param($c)$c.Outer.$field=$false} ('outer false '+$field);Refuse {param($c)$c.Outer.$field='true'} ('outer typed '+$field)}
foreach($field in @('TimedOut','WindowViolation','OutputLimitExceeded','DesktopLeaseRetained','FullJobObserverRetained','NoProcessCreated')){Refuse {param($c)$c.Outer.$field=$true} ('outer bad '+$field);Refuse {param($c)$c.Outer.$field='false'} ('outer typed '+$field)}
foreach($field in @('Pid','RemainingOwnedProcesses','FullJobObserverCloseError')){Refuse {param($c)$c.Outer.$field=99} ('outer numeric '+$field)}
Refuse {param($c)$c.Outer.RunId='wrong'} 'outer run binding'
Refuse {param($c)$c.Outer.Error='failed'} 'outer error'
Refuse {param($c)$c.Outer.CleanupError='failed'} 'outer cleanup error'
Refuse {param($c)$c.Outer.StartedUtc='invalid'} 'outer start identity'
foreach($field in @($multi.Trace.PSObject.Properties.Name)){Refuse {param($c)$c.Trace.PSObject.Properties.Remove($field)} ('missing envelope '+$field)}
foreach($field in @($multi.Trace.records[0].PSObject.Properties.Name)){Refuse {param($c)$c.Trace.records[0].PSObject.Properties.Remove($field)} ('missing row '+$field)}
foreach($field in @('completed','threw','jobClosedBefore','jobClosedAfter','jobRetainedBefore','jobRetainedAfter','jobCloseAttemptedBefore','jobCloseAttemptedAfter','desktopClosedBefore','desktopClosedAfter','desktopRetainedBefore','desktopRetainedAfter','desktopCloseAttemptedBefore','desktopCloseAttemptedAfter')){Refuse {param($c)$c.Trace.records[0].$field=[string]$c.Trace.records[0].$field} ('row bool type '+$field);Refuse {param($c)$c.Trace.records[0].$field=-not $c.Trace.records[0].$field} ('row state flip '+$field)}
foreach($field in @('ordinal','parentOrdinal','iteration','beforeQpc','afterQpc','jobAcquired','jobBefore','jobAfter','jobCloseErrorAfter','desktopAcquired','desktopBefore','desktopAfter','desktopCloseErrorAfter')){Refuse {param($c)$c.Trace.records[0].$field=[string]$c.Trace.records[0].$field} ('row integer type '+$field)}
Refuse {param($c)$c.Trace.records[0].ordinal=2} 'ordinal gap'
Refuse {param($c)$c.Trace.records[0].phase='finalize'} 'early finalize phase'
Refuse {param($c)$c.Trace.records[0].operation='CloseDesktop'} 'early close operation'
Refuse {param($c)$c.Trace.records[0].error='failed'} 'operation error'
Refuse {param($c)$c.Trace.records[0].boolean='true'} 'operation boolean typed'
Refuse {param($c)$c.Trace.records[1].number='2'} 'operation number typed'
Refuse {param($c)$c.Trace.records[2].boolean=$true} 'window violation'
Refuse {param($c)$c.Trace.records[3].parentOrdinal=1} 'ProcessIds wrong parent'
Refuse {param($c)$c.Trace.records[3].afterQpc=$c.Trace.records[2].afterQpc+1} 'child interval outside monitor'
Refuse {param($c)$c.Trace.records[3].beforeQpc=$c.Trace.records[2].beforeQpc-1} 'child interval begins before monitor'
Refuse {param($c)$c.Trace.records[4].number=1} 'Pause must remain10'
Refuse {param($c)$c.Trace.records[4].beforeQpc=$c.Trace.records[2].afterQpc-1} 'next call overlaps monitor'
Refuse {param($c)$c.Trace.records[5].iteration=1} 'iteration fails to advance'
Refuse {param($c)$c.Trace.records[-7].boolean=$false} 'terminal direct exit required'
Refuse {param($c)$c.Trace.records[-6].number=1} 'terminal Job0 required'
Refuse {param($c)$c.Trace.records[-4].number=1} 'terminal ProcessIds empty'
Refuse {param($c)$c.Trace.records[-3].boolean=$false} 'streams incomplete'
Refuse {param($c)$c.Trace.records[-2].desktopAfter=1234} 'close must zero desktop'
Refuse {param($c)$c.Trace.records[-1].jobAfter=777} 'finalize must zero Job'
Refuse {param($c)$c.Trace.records[-1].desktopBefore=1234} 'finalize after desktop close'
Refuse {param($c)$c.Trace.records=@($c.Trace.records|Where-Object operation -CNE 'ProcessIds');$c.Trace.recordCount=$c.Trace.records.Count} 'missing native ProcessIds child'
Refuse {param($c)$c.Trace.records=@($c.Trace.records)+@($c.Trace.records[-1]);$c.Trace.recordCount=$c.Trace.records.Count} 'duplicate finalization'
Refuse {param($c)$c.Trace.records[1].number=0} 'must finish when first direct true Job0'
Refuse {param($c)$c.Outer.FullDesktopMonitorEvidence.last.handle=999} 'foreign monitor handle'
Refuse {param($c)$c.Outer.FullDesktopMonitorEvidence.last.expectedName='wrong'} 'foreign monitor name'
Refuse {param($c)$c.Outer.FullDesktopMonitorEvidence.failedCount=1} 'raw native monitor failure'
Refuse {param($c)$c.Outer.FullDesktopMonitorEvidence.last.list.guardsIntact='true'} 'raw monitor string Boolean refused'
Refuse {param($c)$c.Outer.FullDesktopMonitorEvidence.emptyCount=1} 'monitor counts cover all drain calls'
$extra=Copy-Case $multi;$extra.Trace|Add-Member extra 'unknown';$denied=$false;try{Test-Case $extra}catch{$denied=$true};Check $denied 'unknown schema field refused'
$record=[ordered]@{scope='cleanup-ordering.v1 actual predicate with synthetic data only';synthetic=$true;passed=$true;checks=$count;nativeCallsExecuted=$false;receiptCreated=$false;externalLiveDescendantIntervalClaimed=$false;host=$PSVersionTable.PSVersion.ToString();tests=$names.ToArray()}
$path=Join-Path $OutputDirectory ('cleanup-ordering-'+$PSVersionTable.PSVersion.Major+'.json');Write-FixtureJson $path $record;$record|ConvertTo-Json -Depth 4
