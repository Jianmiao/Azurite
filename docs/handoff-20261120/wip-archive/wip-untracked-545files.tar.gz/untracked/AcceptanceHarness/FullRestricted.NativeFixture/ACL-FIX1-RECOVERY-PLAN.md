# Preserve the empty failed lab before a fresh fixture

Source-only recovery plan, November 12, 2026. **No recovery command has executed.** This is separate from the fixture runner; it must not run automatically on fixture refusal or retry.

Failed attempt: 2f679d4301364b63b0d04517d1a02a85. Original result SHA-256 c718ae8ca3a1ee77e0e7d5d00dc6aec93d4dab0dd6e476d8081356de6ff982d8. The original passed=false and cleanupVerified=false must remain unchanged. Root observed failure at the first lab ACL readback, before install/runs/marker/pending, bootstrap or probe creation.

Independent root readback is now available at .superpowers/sdd/azurite-authoring-20261108/native-fixture-failed-lab-root-identity.json, SHA-256 **a2d46a12735b18d7f8429ea2879ea538e6d2d62351014d41fb019d2984a9d4ed**. It records directory identity **6059895d00000000000f0000000f7909**, volume **\\?\Volume{4a8c325c-ce86-4b12-b555-c6aee7ea5dc4}\**, owner S-1-5-21-222280291-4039000738-1914192245-1001, raw descriptor, full SDDL and zero children. Use those frozen values as the expected recovery input, then independently recheck the live object under the mutex. Do not refresh this expected record to match a changed object.

Fixed source:

    C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\lab

Fixed preservation destination:

    C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\lab.failed-2f679d4301364b63b0d04517d1a02a85

## Preconditions for root's separately authorized action

1. The F baseline capture has finished and released Global/AzuriteRestrictedCli-AA. Acquire that same mutex with a nonblocking wait; refuse if unavailable. No recovery may race the running capture.
2. Verify the unchanged failed result and its original acl-before-001.json bytes against the retained hashes. Check fresh actual AzureArchive.exe and AzuriteLifecycleProbe.exe count zero, plus no fixture bootstrap whose command line belongs to the fixed lab.
3. Resolve the source and destination as the exact C paths above, inspect their ancestry for reparses, and require that the destination does not exist. No user-supplied alternate path or overwrite is allowed.
4. Using the pinned qualified eef4c21387daef216ef7bcc7870b331e123d69e7be852498adcd07f253ef4c8f helper, read the source directory's identity, owner, volume, canonical final path, raw descriptor and SDDL. Require source directory/nonreparse and exact independently captured root descriptor/identity from the a2d46a... record above. **The expected identity/hash values must not be populated from the same object immediately before mutation.**
5. Require exactly zero children, including hidden/system entries. No install, runs, marker, pending, reparse child or unexpected file can be silently accepted. Any mismatch stops recovery.
6. Persist a C-only recovery intent with the two exact paths, source identity/owner/volume/raw descriptor, supplied expected pins, failure-result hash, fresh no-process observation, mutex ownership and the intended no-overwrite rename.

## One mutation, then verification

Under the held mutex, rename the single empty owned directory to the fixed sibling preservation path without replacement, deletion, recursive traversal, ACL change or content rewrite. A direct .NET Directory.Move on those already checked literal paths is one possible root implementation; no shell delete/move chain is needed. If it fails, retain its original error and both paths, and stop. Do not retry with weaker checks.

After a successful rename, re-read the destination with the same pinned helper. Require the original file identity, owner, volume and exact raw descriptor/SDDL, exactly zero children, and original source absence. Persist the actual results. A mismatch is a failed recovery; do not create a new lab to conceal it.

Release the mutex explicitly and record the result. A recovery pass does not make the old fixture pass and does not grant a new trial. Only after root reviews the corrected source and any separately authorized C-object permission check may it authorize a fresh normal case using the new package. The new runner will CreateNew a fresh fixed lab; it will never repair, adopt, clear or overwrite the preserved failed lab.

The native target constants remain unchanged by this recovery. No F/E object, registry value, workspace ancestor ACL, old evidence or original 33-member package is mutated.
