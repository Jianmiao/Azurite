using System;
using System.Collections.Generic;
using System.Text;

namespace Azurite.Restricted {
 public static class FixturePreResumeRecordTests {
  const string Good="{\"fixtureOnly\":true,\"productionTargetExecuted\":false,\"runId\":\"0123456789abcdef0123456789abcdef\",\"bootstrapPid\":123,\"bootstrapStartUtc\":\"2026-11-12T19:59:03.1234567Z\",\"childPid\":456,\"jobHandle\":9007199254740993,\"desktopHandle\":9223372036854775807,\"processHandle\":2147483648,\"calls\":[\"ReadOriginalAndDerive\",\"CreateSuspended\"],\"nativeEvidence\":{\"created\":true,\"nested\":[1,null,{\"x\":\"unicode-\u6c49\"}]},\"desktopLeaseAcknowledged\":true}";
  static byte[] Utf8(string value){return new UTF8Encoding(false,true).GetBytes(value);}
  public static Dictionary<string,object> Run(){
   int checks=0;var failures=new List<string>();
   Action<string,Action> test=delegate(string name,Action body){checks++;try{body();}catch(Exception e){failures.Add(name+": "+e.GetType().Name+": "+e.Message);}};
   Action<bool,string> need=delegate(bool value,string message){if(!value)throw new InvalidOperationException(message);};
   Action<string,string> rejected=delegate(string name,string json){test(name,delegate{bool failed=false;try{FixturePreResumeRecord.Parse(Utf8(json));}catch(InvalidOperationException){failed=true;}need(failed,"Malformed record was accepted");});};
   test("exact twelve-field record projects eight typed values",delegate{var r=FixturePreResumeRecord.Parse(Utf8(Good));need(r.Count==8,"Projection count");foreach(string name in new[]{"runId","bootstrapPid","bootstrapStartUtc","childPid","jobHandle","desktopHandle","processHandle","desktopLeaseAcknowledged"})need(r.ContainsKey(name),"Missing "+name);need((string)r["runId"]=="0123456789abcdef0123456789abcdef","Run identity");need(r["bootstrapPid"] is int&&(int)r["bootstrapPid"]==123&&r["childPid"] is int&&(int)r["childPid"]==456,"PID numeric types");need(r["jobHandle"] is long&&(long)r["jobHandle"]==9007199254740993L,"Handle precision above double integer range");need((long)r["desktopHandle"]==Int64.MaxValue&&(long)r["processHandle"]==2147483648L,"Int64 handle range");need(r["desktopLeaseAcknowledged"] is bool&&(bool)r["desktopLeaseAcknowledged"],"ACK type");need((string)r["bootstrapStartUtc"]=="2026-11-12T19:59:03.1234567Z","Timestamp preserved");});
   string[] members={"\"fixtureOnly\":true,","\"productionTargetExecuted\":false,","\"runId\":\"0123456789abcdef0123456789abcdef\",","\"bootstrapPid\":123,","\"bootstrapStartUtc\":\"2026-11-12T19:59:03.1234567Z\",","\"childPid\":456,","\"jobHandle\":9007199254740993,","\"desktopHandle\":9223372036854775807,","\"processHandle\":2147483648,","\"calls\":[\"ReadOriginalAndDerive\",\"CreateSuspended\"],","\"nativeEvidence\":{\"created\":true,\"nested\":[1,null,{\"x\":\"unicode-\u6c49\"}]},",",\"desktopLeaseAcknowledged\":true"};
   for(int i=0;i<members.Length;i++)rejected("missing required member "+i,Good.Replace(members[i],""));
   rejected("unknown field",Good.Substring(0,Good.Length-1)+",\"unexpected\":0}");
   rejected("duplicate scalar",Good.Substring(0,Good.Length-1)+",\"childPid\":456}");
   rejected("duplicate ignored calls",Good.Substring(0,Good.Length-1)+",\"calls\":[]}");
   rejected("escaped duplicate name",Good.Substring(0,Good.Length-1)+",\"child\\u0050id\":456}");
   rejected("fixture-only false",Good.Replace("\"fixtureOnly\":true","\"fixtureOnly\":false"));
   rejected("production target true",Good.Replace("\"productionTargetExecuted\":false","\"productionTargetExecuted\":true"));
   rejected("false desktop ACK",Good.Replace("\"desktopLeaseAcknowledged\":true","\"desktopLeaseAcknowledged\":false"));
   rejected("quoted bool",Good.Replace("\"fixtureOnly\":true","\"fixtureOnly\":\"true\""));
   rejected("PID quoted number",Good.Replace("\"bootstrapPid\":123","\"bootstrapPid\":\"123\""));
   rejected("PID zero",Good.Replace("\"bootstrapPid\":123","\"bootstrapPid\":0"));
   rejected("PID overflow",Good.Replace("\"bootstrapPid\":123","\"bootstrapPid\":2147483648"));
   rejected("fraction PID",Good.Replace("\"childPid\":456","\"childPid\":456.0"));
   rejected("exponent PID",Good.Replace("\"childPid\":456","\"childPid\":4.56e2"));
   rejected("negative handle",Good.Replace("\"processHandle\":2147483648","\"processHandle\":-1"));
   rejected("handle overflow",Good.Replace("9223372036854775807","9223372036854775808"));
   rejected("handle quoted",Good.Replace("\"jobHandle\":9007199254740993","\"jobHandle\":\"9007199254740993\""));
   rejected("uppercase run",Good.Replace("0123456789abcdef0123456789abcdef","0123456789ABCDEF0123456789ABCDEF"));
   rejected("run trailing newline",Good.Replace("0123456789abcdef0123456789abcdef","0123456789abcdef0123456789abcdef\\n"));
   rejected("run nonstring",Good.Replace("\"runId\":\"0123456789abcdef0123456789abcdef\"","\"runId\":123"));
   rejected("UTC offset is not canonical Z",Good.Replace("2026-11-12T19:59:03.1234567Z","2026-11-12T19:59:03.1234567+00:00"));
   rejected("timestamp invalid date",Good.Replace("2026-11-12T19:59:03.1234567Z","2026-02-31T19:59:03.1234567Z"));
   rejected("calls not array",Good.Replace("\"calls\":[\"ReadOriginalAndDerive\",\"CreateSuspended\"]","\"calls\":{}"));
   rejected("native evidence not object",Good.Replace("\"nativeEvidence\":{\"created\":true,\"nested\":[1,null,{\"x\":\"unicode-\u6c49\"}]}","\"nativeEvidence\":[]"));
   rejected("native evidence null",Good.Replace("\"nativeEvidence\":{\"created\":true,\"nested\":[1,null,{\"x\":\"unicode-\u6c49\"}]}","\"nativeEvidence\":null"));
   rejected("root array","["+Good+"]");rejected("trailing JSON",Good+"{}");rejected("truncated JSON",Good.Substring(0,Good.Length-1));
   rejected("truncated nested object",Good.Replace("\"nativeEvidence\":{\"created\":true,\"nested\":[1,null,{\"x\":\"unicode-\u6c49\"}]}","\"nativeEvidence\":{\"created\":true,\"nested\":[1,null,{\"x\":\"unicode-\u6c49\"}]"));
   test("framing ignores quoted delimiters and escapes",delegate{string value=Good.Replace("unicode-\u6c49","brace-}]-\\\"-\\\\-\u6c49");need(FixturePreResumeRecord.Parse(Utf8(value)).Count==8,"Quoted framing affected root boundary");});
   test("strict UTF8 rejects invalid sequence",delegate{byte[] valid=Utf8(Good);byte[] bad=new byte[valid.Length+2];Array.Copy(valid,bad,valid.Length);bad[valid.Length]=0xc3;bad[valid.Length+1]=0x28;bool failed=false;try{FixturePreResumeRecord.Parse(bad);}catch(InvalidOperationException){failed=true;}need(failed,"Bad UTF8 accepted");});
   test("null bytes rejected",delegate{bool failed=false;try{FixturePreResumeRecord.Parse(null);}catch(InvalidOperationException){failed=true;}need(failed,"null accepted");});
   test("over 64 KiB rejected",delegate{bool failed=false;try{FixturePreResumeRecord.Parse(new byte[65537]);}catch(InvalidOperationException){failed=true;}need(failed,"Oversize accepted");});
   test("exact 64 KiB valid JSON accepted",delegate{byte[] valid=Utf8(Good);string padded=Good+new string(' ',65536-valid.Length);need(FixturePreResumeRecord.Parse(Utf8(padded)).Count==8,"Exact byte bound rejected");});
   return new Dictionary<string,object>{{"passed",failures.Count==0},{"checks",checks},{"failures",failures.ToArray()},{"nativeExecuted",false},{"filesystemReadPerformed",false},{"registryAccessPerformed",false}};
  }
 }
}
