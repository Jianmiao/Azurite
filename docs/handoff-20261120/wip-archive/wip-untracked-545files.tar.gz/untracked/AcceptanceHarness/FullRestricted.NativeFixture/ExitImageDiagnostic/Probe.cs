using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
internal static class ExitImageProbe {
 const string OutputRoot=@"C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\exit-image-observation-20261114\results1";
 static readonly JavaScriptSerializer Json=new JavaScriptSerializer{MaxJsonLength=1048576};
 static Process retainedOriginal;static IntPtr retainedDuplicate;static int observations;static bool started,startAttempted,naturalExit,waitAttempted,duplicateUnconfirmed;
 static Dictionary<string,object> currentState;static string currentRun;
 [StructLayout(LayoutKind.Sequential)]struct Basic {public uint Attributes,Access,HandleCount,PointerCount;[MarshalAs(UnmanagedType.ByValArray,SizeConst=10)]public uint[] Reserved;}
 [DllImport("kernel32.dll")]static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll")]static extern uint GetCurrentProcessId();
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr sourceHandle,IntPtr targetProcess,out IntPtr targetHandle,uint access,bool inherit,uint options);
 [DllImport("kernel32.dll",SetLastError=true)]static extern uint GetProcessId(IntPtr handle);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetProcessTimes(IntPtr handle,out long created,out long exited,out long kernel,out long user);
 [DllImport("kernel32.dll",SetLastError=true)]static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetExitCodeProcess(IntPtr handle,out uint code);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetHandleInformation(IntPtr handle,out uint flags);
 [DllImport("ntdll.dll")]static extern int NtQueryObject(IntPtr handle,int kind,out Basic value,uint size,out uint returned);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool QueryFullProcessImageNameW(IntPtr handle,uint flags,StringBuilder path,ref uint length);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr handle);
 [DllImport("kernel32.dll",EntryPoint="SetLastError")]static extern void ClearError(uint error);
 static Dictionary<string,object> D(params object[] pairs){var d=new Dictionary<string,object>();for(int i=0;i<pairs.Length;i+=2)d.Add((string)pairs[i],pairs[i+1]);return d;}
 static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
 static void Save(string path,object value){byte[] data=new UTF8Encoding(false).GetBytes(Json.Serialize(value));using(var file=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.Read)){file.Write(data,0,data.Length);file.Flush(true);}}
 static void Add(Dictionary<string,object> row,string name,Func<Dictionary<string,object>> query){try{row.Add(name,query());}catch(Exception e){row.Add(name,D("success",false,"nativeErrorCode",null,"exception",e.ToString()));}}
 static Dictionary<string,object> Query(string phase){
  Require(retainedDuplicate!=IntPtr.Zero&&observations<2,"Only two queries on the one owned duplicate");
  IntPtr h=retainedDuplicate;var row=D("phase",phase,"sequence",++observations,"handle",h.ToInt64(),"observedUtc",DateTime.UtcNow.ToString("o"));
  Add(row,"pid",()=>{ClearError(0);uint value=GetProcessId(h);int error=Marshal.GetLastWin32Error();return D("success",value!=0,"value",value,"nativeErrorCode",error);});
  Add(row,"times",()=>{long c,e,k,u;ClearError(0);bool okay=GetProcessTimes(h,out c,out e,out k,out u);int error=Marshal.GetLastWin32Error();return D("success",okay,"createdFileTime",c,"exitFileTime",e,"kernelTime",k,"userTime",u,"nativeErrorCode",error);});
  Add(row,"wait0",()=>{ClearError(0);uint value=WaitForSingleObject(h,0);int error=Marshal.GetLastWin32Error();return D("success",value==0||value==258,"value",value,"nativeErrorCode",error);});
  Add(row,"exitCode",()=>{uint value;ClearError(0);bool okay=GetExitCodeProcess(h,out value);int error=Marshal.GetLastWin32Error();return D("success",okay,"value",value,"nativeErrorCode",error);});
  Add(row,"handleFlags",()=>{uint flags;ClearError(0);bool okay=GetHandleInformation(h,out flags);int error=Marshal.GetLastWin32Error();return D("success",okay,"value",flags,"inherited",okay?(object)((flags&1)!=0):null,"nativeErrorCode",error);});
  Add(row,"rights",()=>{Basic value;uint returned;uint size=(uint)Marshal.SizeOf(typeof(Basic));int status=NtQueryObject(h,0,out value,size,out returned);return D("success",status==0&&returned==size&&size==56,"ntStatus",status,"returnedBytes",returned,"requestedBytes",size,"grantedAccess",value.Access,"attributes",value.Attributes,"handleCount",value.HandleCount,"pointerCount",value.PointerCount);});
  // Record this API independently and LAST. A FALSE image lookup must not
  // throw away successful same-handle exit, identity, access or flags facts.
  Add(row,"image",()=>{var path=new StringBuilder(32768);uint length=(uint)path.Capacity;ClearError(0);bool okay=QueryFullProcessImageNameW(h,0,path,ref length);int error=Marshal.GetLastWin32Error();return D("success",okay,"nativeErrorCode",error,"immediateErrorCapture",true,"path",okay?path.ToString():null,"untrustedBuffer",okay?null:path.ToString(),"returnedCharacters",length,"bufferCapacity",path.Capacity);});
  return row;
 }
 static void VerifyImage(){
  Require(IntPtr.Size==8,"Fresh x64 probe required");Require((File.GetAttributes(ObservationPolicy.ChildImage)&FileAttributes.ReparsePoint)==0,"Exact System32 image must not be reparse");
  using(var file=new FileStream(ObservationPolicy.ChildImage,FileMode.Open,FileAccess.Read,FileShare.Read)){
   string hash;using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(file)).Replace("-","").ToLowerInvariant();Require(hash==ObservationPolicy.ChildSha,"Exact System32 PowerShell image hash changed");
   using(var reader=new BinaryReader(file)){file.Position=0x3c;int pe=reader.ReadInt32();Require(pe>0&&pe<file.Length-6,"PE header position invalid");file.Position=pe;Require(reader.ReadUInt32()==0x4550&&reader.ReadUInt16()==0x8664,"Exact AMD64 PowerShell PE required");}
  }
 }
 static bool WaitNatural(Dictionary<string,object> state,Stopwatch timer,string run){
  Require(started&&!waitAttempted,"One original-Process natural wait only");waitAttempted=true;state["naturalWaitAttempted"]=true;
  int remaining=(int)Math.Max(0,8000-timer.ElapsedMilliseconds);bool exited=retainedOriginal.WaitForExit(remaining);naturalExit=exited;
  state["naturalExitObservedByOriginalProcess"]=exited;state["waitBudgetMs"]=remaining;Save(Path.Combine(run,"03-natural-wait.json"),state);return exited;
 }
 static void Retain(Dictionary<string,object> state,string run,string reason){
  state["retentionReason"]=reason;state["retainedOriginalProcess"]=retainedOriginal!=null;state["retainedDuplicate"]=retainedDuplicate.ToInt64();state["terminationRequested"]=false;state["comparisonCompleted"]=false;
  try{Save(Path.Combine(run,"retained-state.json"),state);}catch(Exception e){Console.Error.WriteLine("Could not save retained state: "+e);}
  Console.Error.WriteLine("Original Process / duplicate retained; root must inspect "+run+". No further queries or termination will occur.");
  while(true)Thread.Sleep(1000);
 }
 static int Execute(){
  Require(!Directory.Exists(OutputRoot),"Unique results root already exists; do not retry or overwrite");Directory.CreateDirectory(OutputRoot);
  string id=Guid.NewGuid().ToString("N"),run=Path.Combine(OutputRoot,id);
  var state=D("schema","same-owned-handle-image-observation.v1","id",id,"probePid",GetCurrentProcessId(),"childImage",ObservationPolicy.ChildImage,"childSha256",ObservationPolicy.ChildSha,"childArguments",ObservationPolicy.ChildArguments,"maximumChildren",1,"maximumObservationBundles",2,"duplicateAccess",ObservationPolicy.Access,"duplicateOptions",0,"duplicateInheritable",false,"childStandardStreamsRedirected",false,"guiCreated",false,"aaStarted",false,"ipcCreated",false,"debuggerUsed",false,"pidReopenUsed",false,"terminationRequested",false,"comparisonCompleted",false,"comparisonPreconditionsMet",false,"originalProcessDisposeCompleted",false,"duplicateClosed",false);
  Save(Path.Combine(OutputRoot,"reservation.json"),state);Directory.CreateDirectory(run);currentState=state;currentRun=run;var timer=Stopwatch.StartNew();Dictionary<string,object> live=null,post=null;int childPid=0;long copyValue=0;string failure=null;bool comparison=false;
  try{
   VerifyImage();
   var psi=new ProcessStartInfo{FileName=ObservationPolicy.ChildImage,Arguments=ObservationPolicy.ChildArguments,WorkingDirectory=Environment.SystemDirectory,UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,RedirectStandardInput=false,RedirectStandardOutput=false,RedirectStandardError=false};
   retainedOriginal=new Process{StartInfo=psi};state["startIntent"]=true;state["startAttempted"]=false;Save(Path.Combine(run,"00-start-intent.json"),state);
   startAttempted=true;state["startAttempted"]=true;bool returned=retainedOriginal.Start();started=returned;state["startReturned"]=returned;Require(returned,"Process.Start did not return a confirmed created child");childPid=retainedOriginal.Id;IntPtr original=retainedOriginal.Handle;state["createdPid"]=childPid;state["originalCreatedProcessHandle"]=original.ToInt64();Save(Path.Combine(run,"01-created.json"),state);
   retainedOriginal.PriorityClass=ProcessPriorityClass.BelowNormal;state["prioritySetToBelowNormal"]=true;
   IntPtr candidate;ClearError(0);bool duplicated=DuplicateHandle(GetCurrentProcess(),original,GetCurrentProcess(),out candidate,ObservationPolicy.Access,false,0);int duplicateError=Marshal.GetLastWin32Error();
   if(duplicated){if(candidate!=IntPtr.Zero&&candidate.ToInt64()!=-1&&candidate!=original){retainedDuplicate=candidate;copyValue=candidate.ToInt64();}else duplicateUnconfirmed=true;}
   state["duplicateSucceeded"]=duplicated;state["duplicateNativeErrorCode"]=duplicateError;
   if(!duplicated){state["untrustedDuplicateOutput"]=candidate.ToInt64();throw new InvalidOperationException("DuplicateHandle failed; no ownership inferred from its output");}
   if(duplicateUnconfirmed){state["unconfirmedSuccessfulDuplicateOutput"]=candidate.ToInt64();Retain(state,run,"Successful duplication did not yield a distinct usable reference");}state["ownedDuplicate"]=copyValue;
   live=Query("requested-live");state["live"]=live;Save(Path.Combine(run,"02-live.json"),live);
   if(!WaitNatural(state,timer,run))Retain(state,run,"Original Process did not prove natural exit within the finite observation budget");
   post=Query("after-natural-exit");state["afterExit"]=post;Save(Path.Combine(run,"04-after-exit.json"),post);
   ObservationPolicy.Validate(live,post,childPid,copyValue);comparison=true;state["comparisonPreconditionsMet"]=true;
  }catch(Exception e){failure=e.ToString();state["failure"]=failure;}
  // No finally drops unknown references. The only fallback is the one natural
  // wait on the original created Process; no PID-based reopen or second child.
  if(duplicateUnconfirmed)Retain(state,run,"Successful duplicate output ownership is unconfirmed");
  if(startAttempted&&!started)Retain(state,run,"Start was attempted but its created-process ownership is unconfirmed");
  if(started&&!naturalExit){if(!waitAttempted){try{WaitNatural(state,timer,run);}catch(Exception e){state["naturalWaitError"]=e.ToString();}}if(!naturalExit)Retain(state,run,"Natural exit remains unproved; keep original Process and duplicate");}
  if(retainedDuplicate!=IntPtr.Zero){ClearError(0);bool closed=CloseHandle(retainedDuplicate);int error=Marshal.GetLastWin32Error();if(closed)retainedDuplicate=IntPtr.Zero;state["duplicateCloseSucceeded"]=closed;state["duplicateCloseNativeErrorCode"]=error;if(!closed)Retain(state,run,"Owned duplicate close failed; no retry");state["duplicateClosed"]=true;}
  if(retainedOriginal!=null){Require(!started||naturalExit,"Do not dispose an unconfirmed live original Process");try{retainedOriginal.Dispose();retainedOriginal=null;state["originalProcessDisposeCompleted"]=true;}catch(Exception e){state["originalDisposeError"]=e.ToString();Retain(state,run,"Original Process disposal did not complete");}}
  state["observationBundles"]=observations;state["elapsedMs"]=timer.ElapsedMilliseconds;state["retainedOriginalProcess"]=false;state["retainedDuplicate"]=0;
  state["comparisonCompleted"]=comparison&&failure==null&&observations==2&&naturalExit&&(bool)state["duplicateClosed"]&&(bool)state["originalProcessDisposeCompleted"];
  if(post!=null&&post.ContainsKey("image")){var image=(Dictionary<string,object>)post["image"];state["postExitImageQuerySucceeded"]=image["success"];state["postExitImageNativeErrorCode"]=image["nativeErrorCode"];}
  state["interpretation"]="Comparison completion does not mean the post-exit image API succeeded; raw success/error and other facts are separate.";
  Save(Path.Combine(run,"05-cleanup.json"),state);Save(Path.Combine(run,"result.json"),state);
  Console.WriteLine(Json.Serialize(new{resultPath=Path.Combine(run,"result.json"),comparisonCompleted=state["comparisonCompleted"],postExitImageQuerySucceeded=state.ContainsKey("postExitImageQuerySucceeded")?state["postExitImageQuerySucceeded"]:null,terminationRequested=false}));return (bool)state["comparisonCompleted"]?0:1;
 }
 static int Main(string[] args){try{if(args.Length==1&&args[0]=="--selftest-observation")return ObservationPolicyChecks.Run();if(args.Length==1&&args[0]=="--execute-reviewed-comparison")return Execute();Console.WriteLine("Default is not executable. Use the readonly launcher plan; explicit reviewed comparison required.");return 2;}catch(Exception e){Console.Error.WriteLine(e);if(currentState!=null&&(retainedDuplicate!=IntPtr.Zero||duplicateUnconfirmed||(startAttempted&&(!started||retainedOriginal!=null))))Retain(currentState,currentRun,"Unexpected failure while original ownership remains retained");return 1;}}
}
