#requires -Version 5.1
param()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Fresh system x64 PS5.1 required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$build=Join-Path $repo 'artifacts\exit-image-observation-20261114\build1';$results=Join-Path $repo 'artifacts\exit-image-observation-20261114\results1';$prep=Join-Path $repo 'artifacts\exit-image-prep-20261114'
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Require([bool]$Value,[string]$Message){if(-not $Value){throw $Message}}
function Save-New([string]$Path,$Value){$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 30));$f=[IO.File]::Open($Path,'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}}
Require (-not(Test-Path -LiteralPath $build) -and -not(Test-Path -LiteralPath $results)) 'Unique new build and unexecuted results required'
$helper=Join-Path $PSScriptRoot 'SourceProcess.psm1';Require ((Hash $helper) -ceq 'ce2a95b4674847d02625de2dac258427223fe753e15e1aa1c3dd118046349e9c') 'Established SOURCE process helper differs'
Require ((Hash (Join-Path $PSScriptRoot 'Diagnostic.manifest')) -ceq 'cec569aa3a7447734c64467a6a91e314413a9bf4ae45bb00a7632f4eb4cd9fd0') 'Known asInvoker manifest differs'
$child='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';Require ((Hash $child) -ceq 'd8f182560210d43baaf767d482ad1dc1207372522e91413b9d5e515a875e552d') 'Exact system PowerShell image differs'
$basis=@((Join-Path $repo 'artifacts\aa-cdb-native-control-preparation-20261113\bq29552\actual-result.json'),(Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\build-cdb-owned-wait2-pumpcapture1\source\CdbLeaseNative.cs'))
$basisRows=@($basis|ForEach-Object{[ordered]@{path=$_;sha256=(Hash $_);bytes=(Get-Item -LiteralPath $_).Length}})
Require ($basisRows[1].sha256 -ceq 'f76d1c6f72f46fa4f34e869ba6cb06ebe0f2adc03515fa60ee4dd9285a4418d8') 'Frozen same-API source basis differs'
Import-Module $helper -Force -DisableNameChecking
[void][IO.Directory]::CreateDirectory((Join-Path $build 'source'))
$sources=@(Get-ChildItem -LiteralPath $PSScriptRoot -File|ForEach-Object{[ordered]@{path=$_.Name;sha256=(Hash $_.FullName);bytes=$_.Length}}|Sort-Object path);Require ($sources.Count -eq 7) 'Expected seven observation-only sources'
$parse=@();foreach($f in $sources){$p=Join-Path $PSScriptRoot $f.path;[IO.File]::Copy($p,(Join-Path $build ('source\'+$f.path)),$false);if($f.path -match '\.ps(m)?1$'){$t=$null;$e=$null;$null=[Management.Automation.Language.Parser]::ParseFile($p,[ref]$t,[ref]$e);$parse+=@([ordered]@{path=$f.path;errors=@($e|ForEach-Object{$_.ToString()})})}}
Save-New (Join-Path $build 'source-parse.json') $parse;Require (@($parse|Where-Object{@($_.errors).Count -ne 0}).Count -eq 0) 'PS5.1 source parse errors'
Save-New (Join-Path $build 'readonly-basis.json') $basisRows
$csc='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe';Require ((Hash $csc) -ceq 'eca02e6b15cde93009a59a3d129d5a77fb5008f2e1cf62cf573b6737c747ecc3') 'Known Framework compiler differs'
$exe=Join-Path $build 'ExitImageProbe.exe'
$compileArguments=@('/nologo','/target:exe','/platform:x64','/warn:4','/warnaserror+','/r:System.Web.Extensions.dll',('/out:'+$exe),('/win32manifest:'+(Join-Path $build 'source\Diagnostic.manifest')))
$compileArguments+=@('Probe.cs','ObservationPolicy.cs','ObservationPolicy.Tests.cs'|ForEach-Object{Join-Path $build ('source\'+$_)})
$compile=Invoke-FixtureSourceProcess -File $csc -Arguments $compileArguments -Directory $build -Record (Join-Path $build 'compile-process.json') -BoundMs 30000
Require ($compile.exitCode -eq 0 -and $compile.stdout -eq '' -and $compile.stderr -eq '') 'Observation SOURCE compile must be warning/error free'
$pure=Invoke-FixtureSourceProcess -File $exe -Arguments @('--selftest-observation') -Directory $build -Record (Join-Path $build 'pure-process.json') -BoundMs 15000
$answer=$pure.stdout|ConvertFrom-Json;Require ($pure.exitCode -eq 0 -and $pure.stderr -eq '' -and $answer.checks -eq 16 -and $answer.failed -eq 0 -and $answer.childStarted -eq $false -and $answer.nativeQueryExecuted -eq $false) 'Sixteen synthetic comparison controls required'
Save-New (Join-Path $build 'pure-result.json') $answer
$plan=& (Join-Path $PSScriptRoot 'Run-Observation.ps1');Require ($plan.willExecute -eq $false -and $plan.maximumChildren -eq 1 -and $plan.observationBundles -eq 2 -and $plan.duplicateAccess -ceq '0x101040') 'Readonly finite plan differs';Save-New (Join-Path $build 'readonly-plan.json') $plan
foreach($f in $sources){Require ((Hash (Join-Path $PSScriptRoot $f.path)) -ceq $f.sha256 -and (Hash (Join-Path $build ('source\'+$f.path))) -ceq $f.sha256) 'Source changed during preparation'}
foreach($f in $basisRows){Require ((Hash $f.path) -ceq $f.sha256 -and (Get-Item -LiteralPath $f.path).Length -eq $f.bytes) 'Old basis/evidence changed'}
Require (-not(Test-Path -LiteralPath $results)) 'SOURCE checks created actual observation results'
$files=@(Get-ChildItem -LiteralPath $build -File -Recurse|ForEach-Object{[ordered]@{path=$_.FullName.Substring($build.Length+1).Replace('\','/');sha256=(Hash $_.FullName);bytes=$_.Length}}|Sort-Object path)
$manifest=[ordered]@{schema=1;scope='one original Process / one exact self-duplicate / live-exit image observation; SOURCE only';sourceBuildOnly=$true;actualChildStarted=$false;actualNativeQueryExecuted=$false;productionChanged=$false;maximumChildren=1;maximumObservationBundles=2;childPath=$child;childSha256=(Hash $child);childCommand='[Threading.Thread]::Sleep(1500)';duplicateRights=0x101040;duplicateOptions=0;duplicateInherit=$false;probeProcessTerminationImplemented=$false;runtimeUsesSourceSupervisor=$false;timeoutRetainsReferences=$true;pidReopenImplemented=$false;runtimeControlIpcCreated=$false;debuggerImplemented=$false;compilerSha256=(Hash $csc);runtimeCommandExecuted='--selftest-observation only';pureChecks=16;files=$files}
Save-New (Join-Path $build 'manifest.json') $manifest
foreach($f in $manifest.files){$p=Join-Path $build $f.path;Require ((Hash $p) -ceq $f.sha256 -and (Get-Item -LiteralPath $p).Length -eq $f.bytes) 'Producer member readback differs'}
$readback=[ordered]@{sourceBuildOnly=$true;actualChildStarted=$false;actualNativeQueryExecuted=$false;package=$build;manifestSha256=(Hash (Join-Path $build 'manifest.json'));membersVerified=$files.Count;sourceMembersVerified=$sources.Count;pureChecks=16;pureFailed=0;compilerPid=$compile.pid;compilerCreationFileTime=$compile.creationFileTime;purePid=$pure.pid;pureCreationFileTime=$pure.creationFileTime;oldBasisPreserved=$true;resultsRootExists=$false;allSourceProcessesNaturallyExited=$true}
Save-New (Join-Path $prep 'build1-producer-readback.json') $readback
[pscustomobject]$readback|ConvertTo-Json -Depth 10
