using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
internal static class ObservationPolicyChecks {
 static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
 static Dictionary<string,object> D(params object[] pairs){var d=new Dictionary<string,object>();for(int i=0;i<pairs.Length;i+=2)d.Add((string)pairs[i],pairs[i+1]);return d;}
 static Dictionary<string,object> Sample(bool live,bool imageSuccess,int imageError){return D("handle",100,"sequence",live?1:2,"pid",D("success",true,"value",42),"times",D("success",true,"createdFileTime",1000L,"exitFileTime",live?0L:2000L),"wait0",D("success",true,"value",live?258:0),"exitCode",D("success",true,"value",live?259:0),"rights",D("success",true,"ntStatus",0,"returnedBytes",56,"grantedAccess",0x101040),"handleFlags",D("success",true,"value",0),"image",D("success",imageSuccess,"nativeErrorCode",imageError,"immediateErrorCapture",true,"path",imageSuccess?ObservationPolicy.ChildImage:null));}
 internal static int Run(){
  int checks=0;var live=Sample(true,true,0);
  foreach(var post in new[]{Sample(false,true,0),Sample(false,false,31),Sample(false,false,0)}){ObservationPolicy.Validate(live,post,42,100);checks++;string before=Json.Serialize(post);ObservationPolicy.Validate(live,post,42,100);if(Json.Serialize(post)!=before)throw new InvalidOperationException("Comparison rewrote raw facts");checks++;}
  var faults=new Dictionary<string,Action<Dictionary<string,object>>>{
   {"wrong-pid",r=>ObservationPolicy.Map(r,"pid")["value"]=43},
   {"wrong-creation",r=>ObservationPolicy.Map(r,"times")["createdFileTime"]=1001L},
   {"not-exited",r=>ObservationPolicy.Map(r,"wait0")["value"]=258},
   {"wrong-exit",r=>ObservationPolicy.Map(r,"exitCode")["value"]=1},
   {"wrong-grant",r=>ObservationPolicy.Map(r,"rights")["grantedAccess"]=0x101000},
   {"inherited",r=>ObservationPolicy.Map(r,"handleFlags")["value"]=1},
   {"image-error-not-saved",r=>ObservationPolicy.Map(r,"image").Remove("nativeErrorCode")},
   {"not-immediate",r=>ObservationPolicy.Map(r,"image")["immediateErrorCapture"]=false},
   {"different-handle",r=>r["handle"]=101},
   {"extra-observation",r=>r["sequence"]=3}
  };
  foreach(var fault in faults){var post=Sample(false,false,31);fault.Value(post);bool refused=false;try{ObservationPolicy.Validate(live,post,42,100);}catch(InvalidOperationException){refused=true;}if(!refused)throw new InvalidOperationException("Bad comparison accepted: "+fault.Key);checks++;}
  Console.WriteLine(Json.Serialize(new{scope="synthetic same-handle observation preservation only",checks=checks,failed=0,childStarted=false,nativeQueryExecuted=false}));return 0;
 }
}
