using System;
using System.Collections.Generic;
internal static class ObservationPolicy {
 internal const uint Access=0x101040;
 internal const string ChildImage=@"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe";
 internal const string ChildSha="d8f182560210d43baaf767d482ad1dc1207372522e91413b9d5e515a875e552d";
 internal const string ChildArguments="-NoProfile -NonInteractive -Command \"[Threading.Thread]::Sleep(1500)\"";
 static void Need(bool okay,string message){if(!okay)throw new InvalidOperationException(message);}
 internal static Dictionary<string,object> Map(Dictionary<string,object> row,string key){object value;Need(row.TryGetValue(key,out value)&&value is Dictionary<string,object>,"Missing object: "+key);return (Dictionary<string,object>)value;}
 static long Number(Dictionary<string,object> row,string key){object value;Need(row.TryGetValue(key,out value)&&(value is int||value is uint||value is long),"Missing number: "+key);return Convert.ToInt64(value);}
 static bool Flag(Dictionary<string,object> row,string key){object value;Need(row.TryGetValue(key,out value)&&value is bool,"Missing boolean: "+key);return (bool)value;}
 static void Basic(Dictionary<string,object> row,int pid,long handle,bool live){
  Need(Number(row,"handle")==handle&&Number(row,"sequence")== (live?1:2),"Same retained duplicate / exact two observation bundles required");
  var p=Map(row,"pid");Need(Flag(p,"success")&&Number(p,"value")==pid,"PID observation differs");
  var times=Map(row,"times");Need(Flag(times,"success")&&Number(times,"createdFileTime")>0,"Creation observation unavailable");
  var wait=Map(row,"wait0");Need(Flag(wait,"success")&&Number(wait,"value")== (live?258:0),"Live/exit Wait0 observation differs");
  var exit=Map(row,"exitCode");Need(Flag(exit,"success")&&Number(exit,"value")== (live?259:0),"Sleep child live/natural exit code differs");
  var rights=Map(row,"rights");Need(Flag(rights,"success")&&Number(rights,"ntStatus")==0&&Number(rights,"returnedBytes")==56&&Number(rights,"grantedAccess")==Access,"Exact duplicate grant differs");
  var flags=Map(row,"handleFlags");Need(Flag(flags,"success")&&(Number(flags,"value")&1)==0,"Duplicate inheritance differs");
  var image=Map(row,"image");Flag(image,"success");Number(image,"nativeErrorCode");Need(Flag(image,"immediateErrorCapture"),"Image result lost its immediate native error");
 }
 internal static void Validate(Dictionary<string,object> live,Dictionary<string,object> exited,int pid,long handle){
  Need(pid>0&&handle>0,"Created child and owned duplicate required");Basic(live,pid,handle,true);Basic(exited,pid,handle,false);
  var before=Map(live,"times");var after=Map(exited,"times");Need(Number(before,"createdFileTime")==Number(after,"createdFileTime")&&Number(before,"exitFileTime")==0&&Number(after,"exitFileTime")>=Number(after,"createdFileTime"),"Same creation and natural exit FILETIME required");
  var firstImage=Map(live,"image");Need(Flag(firstImage,"success")&&String.Equals(Convert.ToString(firstImage["path"]),ChildImage,StringComparison.OrdinalIgnoreCase),"Live image was not verified");
  var finalImage=Map(exited,"image");
  // A failed post-exit image lookup is an observation, never a reason to erase
  // the successful PID/time/wait/exit/rights fields or invent an image result.
  if(Flag(finalImage,"success"))Need(String.Equals(Convert.ToString(finalImage["path"]),ChildImage,StringComparison.OrdinalIgnoreCase),"Successful post-exit image differs");
 }
}
