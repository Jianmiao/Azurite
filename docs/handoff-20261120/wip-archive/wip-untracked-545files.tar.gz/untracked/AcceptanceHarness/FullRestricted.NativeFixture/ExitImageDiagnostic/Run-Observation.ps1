#requires -Version 5.1
param([switch]$Execute,[string]$ReviewedPackageSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$build=Join-Path $repo 'artifacts\exit-image-observation-20261114\build1';$results=Join-Path $repo 'artifacts\exit-image-observation-20261114\results1'
if(-not $Execute){[pscustomobject]@{willExecute=$false;diagnosticOnly=$true;maximumChildren=1;child='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';arguments='-NoProfile -NonInteractive -Command "[Threading.Thread]::Sleep(1500)"';hidden=$true;priority='BelowNormal';duplicateAccess='0x101040';duplicateOptions=0;duplicateInherited=$false;observationBundles=2;ordinaryBudgetMs=8000;timeoutAction='retain original Process and duplicate; no further query or termination';pidReopen=$false;ipcCreated=$false;debuggerUsed=$false;aaStarted=$false;productionChanged=$false};return}
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Fresh system x64 PS5.1 launcher required'}
if(Test-Path -LiteralPath $results){throw 'Unique actual observation results already exist; do not retry'}
if($ReviewedPackageSha256 -cnotmatch '^[a-f0-9]{64}$' -or (Get-FileHash -LiteralPath (Join-Path $build 'manifest.json')).Hash.ToLowerInvariant() -cne $ReviewedPackageSha256){throw 'Exact separately reviewed package digest required'}
$m=Get-Content -LiteralPath (Join-Path $build 'manifest.json') -Raw|ConvertFrom-Json
foreach($f in $m.files){$p=Join-Path $build $f.path;if((Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant() -cne $f.sha256 -or (Get-Item -LiteralPath $p).Length -ne $f.bytes){throw 'Observation package member differs'}}
if((Get-FileHash -LiteralPath $PSCommandPath).Hash -cne (Get-FileHash -LiteralPath (Join-Path $build 'source\Run-Observation.ps1')).Hash){throw 'Executed launcher differs from frozen source'}
# Root retains the outer Process and streams. Do not invoke this entry through
# the SOURCE/pure supervisor, which has different timeout termination semantics.
& (Join-Path $build 'ExitImageProbe.exe') --execute-reviewed-comparison
if($LASTEXITCODE -ne 0){throw 'Observation did not complete its exact comparison; preserve raw facts and ownership evidence'}
