using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace Azurite.Restricted {
 // Fixed fixture handoff reader. No JavaScriptSerializer or native operation.
 internal static class FixturePreResumeRecord {
  const int Limit=65536;
  static readonly UTF8Encoding StrictUtf8=new UTF8Encoding(false,true);
  static readonly string[] Names={"fixtureOnly","productionTargetExecuted","runId","bootstrapPid","bootstrapStartUtc","childPid","jobHandle","desktopHandle","processHandle","calls","nativeEvidence","desktopLeaseAcknowledged"};
  static void Require(bool value,string message){if(!value)throw new InvalidOperationException("Pre-resume record: "+message);}
  internal static Dictionary<string,object> Read(string path){
   Require(!String.IsNullOrEmpty(path)&&Path.GetFullPath(path)==path,"canonical file path required");
   string cursor=path;while(!String.IsNullOrEmpty(cursor)){FileAttributes attributes=File.GetAttributes(cursor);Require((attributes&FileAttributes.ReparsePoint)==0,"reparse ancestry refused");cursor=Path.GetDirectoryName(cursor);}
   var before=new FileInfo(path);Require(before.Exists&&(before.Attributes&FileAttributes.Directory)==0&&before.Length>1&&before.Length<=Limit,"ordinary bounded file required");
   byte[] bytes;
   using(var input=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)){
    Require(input.Length==before.Length&&input.Length<=Limit,"file length changed");bytes=new byte[(int)input.Length];int offset=0;
    while(offset<bytes.Length){int count=input.Read(bytes,offset,bytes.Length-offset);Require(count>0,"short file read");offset+=count;}
    Require(input.ReadByte()==-1&&input.Length==bytes.Length,"file changed during read");
    var after=new FileInfo(path);Require(after.Exists&&after.Length==before.Length&&after.LastWriteTimeUtc==before.LastWriteTimeUtc&&(after.Attributes&FileAttributes.ReparsePoint)==0,"file metadata changed during read");
   }
   return Parse(bytes);
  }
  static string Scalar(XmlDictionaryReader reader,string expectedType){Require(reader.GetAttribute("type")==expectedType,"wrong JSON scalar type for "+reader.LocalName);return reader.ReadElementContentAsString();}
  static bool Boolean(XmlDictionaryReader reader,bool expected){string raw=Scalar(reader,"boolean");Require(raw==(expected?"true":"false"),"fixture Boolean differs");return expected;}
  static long PositiveInteger(XmlDictionaryReader reader,long maximum){string raw=Scalar(reader,"number");Require(Regex.IsMatch(raw,"\\A[0-9]+\\z"),"integer JSON number required");long value;Require(Int64.TryParse(raw,NumberStyles.None,CultureInfo.InvariantCulture,out value)&&value>0&&value<=maximum,"positive integer outside exact range");return value;}
  static bool White(char value){return value==' '||value=='\t'||value=='\r'||value=='\n';}
  // JsonReader may finish a root at EOF without its closing delimiter. Check
  // only framing here; JSON token/type validation remains with JsonReader.
  static void RequireCompleteObject(string text){
   int start=0;while(start<text.Length&&White(text[start]))start++;Require(start<text.Length&&text[start]=='{',"complete JSON root object required");
   var nesting=new Stack<char>();bool quoted=false,escape=false,closed=false;
   for(int i=start;i<text.Length;i++){
    char c=text[i];if(closed){Require(White(c),"trailing JSON data");continue;}
    if(quoted){if(escape){escape=false;continue;}if(c=='\\'){escape=true;continue;}if(c=='"')quoted=false;continue;}
    if(c=='"'){quoted=true;continue;}if(c=='{'||c=='['){nesting.Push(c);Require(nesting.Count<=64,"JSON nesting exceeds bound");continue;}
    if(c=='}'||c==']'){Require(nesting.Count>0&&nesting.Pop()==(c=='}'?'{':'['),"mismatched JSON framing");if(nesting.Count==0)closed=true;}
   }
   Require(closed&&!quoted&&!escape&&nesting.Count==0,"truncated JSON framing");
  }
  internal static Dictionary<string,object> Parse(byte[] bytes){
   Require(bytes!=null&&bytes.Length>1&&bytes.Length<=Limit,"JSON bytes exceed bound");
   string text;try{text=StrictUtf8.GetString(bytes);}catch(DecoderFallbackException e){throw new InvalidOperationException("Pre-resume record: invalid UTF8",e);}RequireCompleteObject(text);
   try{
    var quotas=new XmlDictionaryReaderQuotas{MaxDepth=64,MaxStringContentLength=Limit,MaxArrayLength=Limit,MaxBytesPerRead=Limit,MaxNameTableCharCount=Limit};
    using(var reader=JsonReaderWriterFactory.CreateJsonReader(bytes,0,bytes.Length,StrictUtf8,quotas,null)){
     Require(reader.MoveToContent()==XmlNodeType.Element&&reader.LocalName=="root"&&reader.GetAttribute("type")=="object","JSON root object required");
     var seen=new HashSet<string>(StringComparer.Ordinal);var result=new Dictionary<string,object>(StringComparer.Ordinal);reader.ReadStartElement();
     while(reader.MoveToContent()==XmlNodeType.Element){
      string name=reader.LocalName;Require(Array.IndexOf(Names,name)>=0&&seen.Add(name),"unknown or duplicate field "+name);
      switch(name){
       case "fixtureOnly":Boolean(reader,true);break;
       case "productionTargetExecuted":Boolean(reader,false);break;
       case "runId":string id=Scalar(reader,"string");Require(Regex.IsMatch(id,"\\A[a-f0-9]{32}\\z"),"canonical run ID required");result.Add(name,id);break;
       case "bootstrapStartUtc":string time=Scalar(reader,"string");DateTime utc;Require(DateTime.TryParseExact(time,"yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'",CultureInfo.InvariantCulture,DateTimeStyles.AssumeUniversal|DateTimeStyles.AdjustToUniversal,out utc)&&utc.ToString("o",CultureInfo.InvariantCulture)==time,"canonical UTC roundtrip timestamp required");result.Add(name,time);break;
       case "bootstrapPid":case "childPid":result.Add(name,(int)PositiveInteger(reader,Int32.MaxValue));break;
       case "jobHandle":case "desktopHandle":case "processHandle":result.Add(name,PositiveInteger(reader,Int64.MaxValue));break;
       case "desktopLeaseAcknowledged":result.Add(name,Boolean(reader,true));break;
       case "calls":Require(reader.GetAttribute("type")=="array","calls must be an array");reader.Skip();break;
       case "nativeEvidence":Require(reader.GetAttribute("type")=="object","nativeEvidence must be an object");reader.Skip();break;
       default:throw new InvalidOperationException("Pre-resume record: unhandled field");
      }
     }
     Require(seen.Count==12&&result.Count==8,"exact twelve-field record required");reader.ReadEndElement();Require(reader.MoveToContent()==XmlNodeType.None,"trailing JSON data");return result;
    }
   }catch(InvalidOperationException){throw;}catch(Exception e){throw new InvalidOperationException("Pre-resume record: malformed JSON",e);}
  }
 }
}
