param([string]$Repo,[string]$BuildDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $Repo 'AcceptanceHarness\FullRestricted.NativeFixture\FixtureRules.psm1') -Force -DisableNameChecking
function Clone($x){$p=@{InputObject=($x|ConvertTo-Json -Depth 80);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$p.DateKind='String'};ConvertFrom-Json @p}
$id='a'*32;$package='b'*64
if([string]::IsNullOrEmpty($BuildDirectory)){$BuildDirectory=Join-Path $Repo 'artifacts\aa-fr-native-lifecycle-fixture\build-cleanup9974-qual1'}
$lineage=[pscustomobject]@{'RestrictedCliNative.cs'='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921';'RestrictedCliFullRestricted.cs'='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533'}
$monitor=Read-FixtureJson (Join-Path $BuildDirectory 'serialization-ps51-monitor.json')
$child=[ordered]@{runId=$id;scenario='normal';pid=42;stdHandles=@(10,11,12)}
$nativeEvidence=[ordered]@{actualTokenVerified=$true;exactOwnedJobVerified=$true;outerDesktopLeaseAcknowledged=$true;creationFlags=0x08084404;resumeCalls=1;resumeVerified=$true;pipeHandlesBeforeCreate=@(0..5|ForEach-Object{[ordered]@{handle=10+$_;flags=$(if($_-lt3){1}else{0});fileType=3}});fullDesktopMonitor=$monitor}
$native=[ordered]@{Process=[ordered]@{Pid=42;CleanupVerified=$true;ExitCode=0;Stdout=('FIXTURE_STDOUT '+$id+' '+[char]0x20ac+[char]10);Stderr=('FIXTURE_STDERR '+$id+' '+[char]::ConvertFromUtf32(0x1f31f)+[char]10);FullDesktopMonitorEvidence=$monitor};StreamsComplete=$true;NativeHandlesClosed=$true;Evidence=$nativeEvidence}
$outer=[ordered]@{Pid=40;ExitCode=0;CleanupVerified=$true;DirectProcessExited=$true;JobDrained=$true;RemainingOwnedProcesses=0;JobObserved=$true;DesktopLeaseObserved=$true;DesktopLeaseClosed=$true;DesktopLeaseRetained=$false;FullJobObserverClosed=$true;FullJobObserverRetained=$false;StreamCaptureComplete=$true;TimedOut=$false;WindowViolation=$false;OutputLimitExceeded=$false;Error=$null;FullDesktopMonitorEvidence=$monitor}
# This object exists only in this pure test. It is never written as a receipt.
$receipt=Clone ([ordered]@{schema=1;fixtureOnly=$true;productionTargetExecuted=$false;scenario='normal';passed=$true;cleanupVerified=$true;error=$null;packageSha256=$package;runId=$id;nativeSourceLineage=$lineage;child=$child;native=$native;outer=$outer})
Assert-FixtureNormalReceipt $receipt $package $lineage
$checks=1
foreach($fault in @('package','source','scenario','run','outerCleanup','innerCleanup','monitor','resume','childPid','streams','nativeClosed')){
 Assert-FixtureNormalReceipt (Clone $receipt) $package $lineage
 $bad=Clone $receipt
 switch($fault){
 'package' {$bad.packageSha256='c'*64}
 'source' {$bad.nativeSourceLineage.'RestrictedCliFullRestricted.cs'='0'*64}
 'scenario' {$bad.scenario='bootstrap-exit'}
 'run' {$bad.runId='d'*32}
 'outerCleanup' {$bad.outer.CleanupVerified=$false}
 'innerCleanup' {$bad.native.Process.CleanupVerified=$false}
 'monitor' {$bad.outer.FullDesktopMonitorEvidence.failedCount=1}
 'resume' {$bad.native.Evidence.resumeCalls=2}
 'childPid' {$bad.child.pid=99}
 'streams' {$bad.native.StreamsComplete=$false}
 'nativeClosed' {$bad.native.NativeHandlesClosed=$false}
 }
 $denied=$false;try{Assert-FixtureNormalReceipt $bad $package $lineage}catch{$denied=$true}
 if(-not $denied){throw ('Gate accepted mutation '+$fault)};$checks++
}
# Receipt/control transport checks remain synthetic and in-memory; no receipt is saved.
$receiptBytes=[Text.UTF8Encoding]::new($false).GetBytes(($receipt|ConvertTo-Json -Depth 80 -Compress))
$hash=[Security.Cryptography.SHA256]::Create();try{$receiptSha=([BitConverter]::ToString($hash.ComputeHash($receiptBytes))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()}
$round=ConvertFrom-FixtureNormalReceiptBytes $receiptBytes $receiptSha $package $lineage
if($round.runId -cne $id){throw 'Receipt exact bytes roundtrip failed'};$checks++
foreach($fault in @('digest','bytes','package','base64-control')){
 $badBytes=[byte[]]$receiptBytes.Clone();$badDigest=$receiptSha;$badPackage=$package
 if($fault -eq 'digest'){$badDigest='0'*64};if($fault -eq 'bytes'){$badBytes[0]=0};if($fault -eq 'package'){$badPackage='c'*64}
 if($fault -eq 'base64-control'){$badBytes=[Convert]::FromBase64String([Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('{}')))}
 $denied=$false;try{$null=ConvertFrom-FixtureNormalReceiptBytes $badBytes $badDigest $badPackage $lineage}catch{$denied=$true};if(-not $denied){throw ('Byte gate accepted '+$fault)};$checks++
}
$protectedControl=Clone ([ordered]@{fixtureOnly=$true;productionTargetExecuted=$false;runId=('d'*32);scenario='bootstrap-exit';packageSha256=$package;productionSources=$lineage;normalReceiptBase64=[Convert]::ToBase64String($receiptBytes);normalReceiptSha256=$receiptSha;normalReceiptPath=('C:\pure-test\evidence\'+$id+'\result.json')})
$bootstrapReceipt=ConvertFrom-FixtureNormalReceiptBytes ([Convert]::FromBase64String($protectedControl.normalReceiptBase64)) $protectedControl.normalReceiptSha256 $protectedControl.packageSha256 $protectedControl.productionSources
if($bootstrapReceipt.runId -cne $id){throw 'Protected control exact prerequisite failed'};$checks++
$evidenceRoot=Join-Path $Repo 'artifacts\aa-fr-native-lifecycle-fixture\evidence'
foreach($relative in @(('archive\'+$id+'\result.json'),($id+'\wrong.json'),('..\'+$id+'\result.json'))){
 $caught=$false;try{$null=Read-FixtureNormalReceipt (Join-Path $evidenceRoot $relative) $receiptSha $package $lineage $evidenceRoot}catch{if($_.Exception.Message -cne 'Fixture failed: normal receipt exact evidence run/result.json path required'){throw};$caught=$true};if(-not $caught){throw 'Wrong prerequisite path admitted'};$checks++
}
$caught=$false;try{Assert-FixtureCleanupOrdering $null $outer $id}catch{$caught=$true};if(-not $caught){throw 'Missing cleanup trace accepted'};$checks++
# Existing true normal result is used only for size measurement and negative cross-package admission.
$oldPath=Join-Path $Repo 'artifacts\aa-fr-native-lifecycle-fixture\evidence\7f254491c867412498c49fd5b8fdcc2e\result.json'
if((Get-FixtureHash $oldPath) -cne '76c2d6407e1c698bf354db1ab46fb6cd1967c916f5bbe930927b68da9e07ed27'){throw 'Actual prior normal sizing sample changed'}
$oldBytes=[IO.File]::ReadAllBytes($oldPath)
$denied=$false;try{$null=ConvertFrom-FixtureNormalReceiptBytes $oldBytes '76c2d6407e1c698bf354db1ab46fb6cd1967c916f5bbe930927b68da9e07ed27' $package $lineage}catch{$denied=$true};if(-not $denied){throw 'Actual old-package normal admitted as new package'};$checks++
$protectedControl.normalReceiptBase64=[Convert]::ToBase64String($oldBytes)
$sizingBytes=[Text.Encoding]::UTF8.GetByteCount(($protectedControl|ConvertTo-Json -Depth 80 -Compress))
if($sizingBytes -ge 1048576){throw 'Expected control exceeds existing bound'};$checks++
[ordered]@{scope='synthetic data only normal receipt positive and mutation controls';passed=$true;checks=$checks;host=$PSVersionTable.PSVersion.ToString();actualReceiptProduced=$false;nativeCalled=$false;processStarted=$false;packageDigestSynthetic=$true;priorActualResultUsedForSizingOnly=$true;priorResultBytes=$oldBytes.Length;sizingControlBytes=$sizingBytes;controlBoundBytes=1048576;protectedControlRoundtripPassed=$true}|ConvertTo-Json
