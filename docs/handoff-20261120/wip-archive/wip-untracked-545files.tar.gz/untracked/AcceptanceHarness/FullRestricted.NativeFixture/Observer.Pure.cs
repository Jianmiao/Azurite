using System;using System.Collections.Generic;using Azurite.Restricted;
public static class ObserverDraftPure {
 static int checks;static void Check(bool b,string why){checks++;if(!b)throw new Exception(why);}
 static FullDesktopIdentity Identity(uint access){return new FullDesktopIdentity{Handle=1234,Name="AzuriteFullCli_"+new string('a',32),Type="Desktop",Owner="S-1-5-21-1-2-3-1001",CurrentOwner="S-1-5-21-1-2-3-1001",RightsQueryStatus=0,GrantedAccess=access,Inherited=false};}
 static LifecycleFixture.ObserverSample Sample(){return new LifecycleFixture.ObserverSample{runId=new string('a',32),bootstrapPid=40,childPid=42,activeBefore=1,activeAfter=1,sampleBeforeQpc=1,monitorBeforeQpc=2,monitorAfterQpc=3,sampleAfterQpc=4,qpcFrequency=100,desktopHandle=1234,bootstrapWaitBefore=0,bootstrapWaitAfter=0,childWaitBefore=258,childWaitAfter=258,observerDesktopHeld=true,monitorCompleted=true,visibleOwnedWindow=false};}
 public static int Main(){try{
  string id=new string('a',32);LifecycleFixture.ValidateObserverDesktop(Identity(0x20001),new IntPtr(1234),id);Check(true,"minimal rights pass pure validator");
  foreach(uint rights in new uint[]{1,0x20000,0x20003,0xf01ff,0}){bool denied=false;try{LifecycleFixture.ValidateObserverDesktop(Identity(rights),new IntPtr(1234),id);}catch{denied=true;}Check(denied,"missing/excess rights reject");}
  foreach(string fault in new[]{"owner","query","inherit","handle","name"}){var i=Identity(0x20001);if(fault=="owner")i.Owner="wrong";if(fault=="query")i.RightsQueryStatus=-1;if(fault=="inherit")i.Inherited=true;if(fault=="handle")i.Handle=44;if(fault=="name")i.Name="Default";bool denied=false;try{LifecycleFixture.ValidateObserverDesktop(i,new IntPtr(1234),id);}catch{denied=true;}Check(denied,"identity "+fault);}
  Check(LifecycleFixture.Qualifies(Sample(),id,40,42),"bracketed actual-shaped sample accepted");
  foreach(string fault in new[]{"run","bootstrapPid","childPid","bootstrapBefore","bootstrapAfter","childBefore","childAfter","activeBefore","activeAfter","held","handle","monitor","visible","frequency","beforeOrder","afterOrder"}){
   var s=Sample();switch(fault){case "run":s.runId="wrong";break;case "bootstrapPid":s.bootstrapPid=41;break;case "childPid":s.childPid=43;break;case "bootstrapBefore":s.bootstrapWaitBefore=258;break;case "bootstrapAfter":s.bootstrapWaitAfter=258;break;case "childBefore":s.childWaitBefore=0;break;case "childAfter":s.childWaitAfter=0;break;case "activeBefore":s.activeBefore=0;break;case "activeAfter":s.activeAfter=0;break;case "held":s.observerDesktopHeld=false;break;case "handle":s.desktopHandle=0;break;case "monitor":s.monitorCompleted=false;break;case "visible":s.visibleOwnedWindow=true;break;case "frequency":s.qpcFrequency=0;break;case "beforeOrder":s.monitorBeforeQpc=0;break;case "afterOrder":s.monitorAfterQpc=5;break;}
   Check(!LifecycleFixture.Qualifies(s,id,40,42),"sample refusal "+fault);
  }
  Console.WriteLine("{\"scope\":\"observer draft pure identity and interval predicates only\",\"nativeCallsExecuted\":false,\"passed\":true,\"checks\":"+checks+"}");return 0;
 }catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
