# Full-restricted native lifecycle fixture: build-structured1 candidate

This candidate uses fixed C lab `artifacts/aa-fr-native-lifecycle-fixture/lab-structured1` and immutable package `build-structured1`. The prior `build-observer1`, its evidence and its existing successful lab remain untouched. Source/build/pure preparation does not qualify a new native lifecycle or grant AA admission.

The production source pair is FullRestricted `3316bec4aafd2cafe16f3e156c492722ea1bfc72263dd5da2508864dc3039f86` and shared Native `f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921`; CurrentAccount `495efe99ea5f32330d7a1b25148d9cd637a508a83fac93b5037a0db1dcb45ea9` is separately pinned as a controller dependency. The generated full source still changes exactly two string constants (fixed lab and harmless executable), with all method, constructor and accessor text unchanged.

Actual execution requires a fresh x64 PS7 outer controller. It directly loads the fixture DLL and calls the production outer pump in that PS7 process; the bootstrap remains the existing system x64 PS5.1 child. Only that child's inherited PSModulePath is removed so it can initialize its native Desktop modules. No global environment value is changed. Default invocation without Execute is a plan.

Run exactly one actual normal case after package review. Bootstrap-exit then requires the exact final successful normal receipt path/hash from this same package and production lineage. The existing protected Base64 original-byte prerequisite, normal receipt checks, token/Job/std-handle/EOF checks, full monitor evidence, 0x20001 observer permission and QPC-bracket qualification remain. An old package receipt does not qualify this candidate.

The separately disclosed fixture observer now reads its bounded pre-resume JSON through a small strict managed reader compatible with Framework and PS7. It requires the original twelve top-level fields/types and projects only the eight fields Observe consumes. PS5.1 inner bootstrap serialization/deserialization and instrumented process flow remain unchanged. Production monitor policy is not changed by this fixture adaptation.

Both hosts' pure serialization tests invoke the production structured monitor directly in the current host with a fake native API. PS7 no longer delegates that check to a Framework executable. The package also contains direct-host pre-resume reader checks, the existing source-linked core/ownership/monitor and observer tests, and the original ACL and same-package normal prerequisite tests. No test creates a passed actual lifecycle receipt.

Root must use the final package manifest digest reported by the builder and independent review. No native fixture, AA, F or registry action is performed merely by building this package. Root owns the actual normal and same-package bootstrap-exit runs.
