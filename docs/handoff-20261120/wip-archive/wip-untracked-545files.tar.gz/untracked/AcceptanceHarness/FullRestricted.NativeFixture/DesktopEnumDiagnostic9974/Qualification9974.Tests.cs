using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;
internal static class Qualification9974Checks {
 static int checks,failed;
 static readonly List<string> failures=new List<string>();
 static void Check(bool ok,string name){checks++;if(!ok){failed++;failures.Add(name);}}
 static bool Refuses(Action action){try{action();return false;}catch(InvalidOperationException){return true;}}
 internal static int Run(){
  var images=Qualification9974.Images();Check(images.Length==2,"exact-two-images");
  Check(images[0].Version=="10.0.26100.9818"&&images[0].Hash=="4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91"&&images[0].Rva==0x2a9a0,"user32-current-fixed-pin");
  Check(images[1].Version=="10.0.26100.9974"&&images[1].Hash=="5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc"&&images[1].Rva==0x1610,"win32u-current-fixed-pin");
  foreach(var spec in images){
   string path=@"C:\Windows\System32\"+spec.Name;
   var row=Qualification9974.Describe(spec,path,path.ToUpperInvariant(),spec.Hash,spec.Version,spec.Rva,false,"raw-display-not-fixed","raw-product","fixture-language");
   Check(!Refuses(()=>Qualification9974.Validate(row,true)),spec.Name+"-exact-loaded-positive");
   Check((string)row["rawFileVersion"]=="raw-display-not-fixed"&&(string)row["fixedFileVersion"]==spec.Version,spec.Name+"-raw-preserved-not-validator");
   foreach(string field in new[]{"pathMatch","hashMatch","fixedVersionMatch","exportMatch","nonReparseMatch"}){
    var bad=new Dictionary<string,object>(row);bad[field]=false;Check(Refuses(()=>Qualification9974.Validate(bad,true)),spec.Name+"-reject-"+field);
   }
   var missing=Qualification9974.Describe(spec,path,null,spec.Hash,spec.Version,-1,false,null,null,null);
   Check(!Refuses(()=>Qualification9974.Validate(missing,false)),spec.Name+"-disk-only-defers-unloaded");
   Check(Refuses(()=>Qualification9974.Validate(missing,true)),spec.Name+"-reject-unloaded-before-call");
  }
  var cases=Qualification9974.Measurements();Check(cases.Length==3,"three-pairs-per-route");
  Check(cases.Count(x=>x.Capacity==1&&x.Seed==0x1BADB002)==1,"old-capacity1-sentinel-preserved");
  Check(cases.Count(x=>x.Capacity==64&&x.Seed==0x1BADB002)==1,"old-capacity64-sentinel-preserved");
  Check(cases.Count(x=>x.Capacity==64&&x.Seed==0)==1,"new-capacity64-zero-present");
  Check(cases.All(x=>x.Capacity==1||x.Capacity==64),"no-unbounded-capacity");
  Check(cases.Select(x=>x.Capacity+":"+x.Seed).Distinct().Count()==cases.Length,"unique-case-identities");
  Check(4*cases.Length==12&&24+2*4*cases.Length==48,"exact-12-pairs-48-top-level-calls");
  Console.WriteLine(new JavaScriptSerializer().Serialize(new{scope="9974 exact-image policy and finite measurement matrix only",checks=checks,failed=failed,failures=failures.ToArray(),nativeExecuted=false,desktopApisCalled=false,old79Rerun=false}));return failed==0?0:1;
 }
#if QUALIFICATION_PURE
 static int Main(){return Run();}
#endif
}
