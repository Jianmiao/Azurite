#requires -Version 5.1
param()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Fresh system x64 PS5.1 required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$build=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-9974-build2'
$prior=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-build7'
$results=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-9974-results2'
$prep=Join-Path $repo 'artifacts\desktop9974-prep-20261114'
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Require([bool]$Value,[string]$Message){if(-not $Value){throw $Message}}
function Save-New([string]$Path,$Value){$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 30));$f=[IO.File]::Open($Path,'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}}
Require (-not(Test-Path -LiteralPath $build)) 'Unique new SOURCE build already exists; preserve it'
Require (-not(Test-Path -LiteralPath $results)) 'SOURCE preparation must precede any new diagnostic run'
$production=[ordered]@{'RestrictedCliFullRestricted.cs'='37d89b1942d74c4faae42365f6d5b302fe50b5d98135c6ad5bc36cbe98afe0c5';'RestrictedCliNative.cs'='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'}
foreach($name in $production.Keys){Require ((Hash (Join-Path $repo ('tools\headless\'+$name))) -ceq $production[$name]) 'Current production source pin differs'}
Require ((Hash (Join-Path $prior 'manifest.json')) -ceq 'e28cba75e883b23cd76755954544c0fc109476425f4063941aa4d6755e3e5e30') 'Old build7 manifest drift'
$old=Get-Content -LiteralPath (Join-Path $prior 'manifest.json') -Raw|ConvertFrom-Json
foreach($f in $old.files){$path=Join-Path $prior $f.path;Require ((Hash $path) -ceq $f.sha256 -and (Get-Item -LiteralPath $path).Length -eq $f.bytes) 'Old build7 member differs'}
$helper=Join-Path $PSScriptRoot 'SourceProcess.psm1'
Require ((Hash $helper) -ceq 'ce2a95b4674847d02625de2dac258427223fe753e15e1aa1c3dd118046349e9c') 'Reused SOURCE process helper differs'
Require ((Hash (Join-Path $PSScriptRoot 'NativeEnumeration.c')) -ceq '98ec6117c3aaaaa59ac59146a5392a7405d1c37808222018cf03e843bc1e4fc0') 'Reused native C source differs'
$red=Get-Content -LiteralPath (Join-Path $prep 'red\test-process.json') -Raw|ConvertFrom-Json
$redResult=$red.stdout|ConvertFrom-Json
Require ($red.exitCode -eq 1 -and $redResult.failed -eq 4 -and $redResult.nativeExecuted -eq $false) 'Actual four-failure pure RED required'
Require ((Hash (Join-Path $prep 'red\Qualification9974.Tests.cs')) -ceq (Hash (Join-Path $PSScriptRoot 'Qualification9974.Tests.cs'))) 'RED and GREEN policy tests differ'
Import-Module $helper -Force -DisableNameChecking
[void][IO.Directory]::CreateDirectory((Join-Path $build 'source'))
$sourceRows=@(Get-ChildItem -LiteralPath $PSScriptRoot -File|ForEach-Object{[ordered]@{path=$_.Name;sha256=(Hash $_.FullName);bytes=$_.Length}}|Sort-Object path)
Require ($sourceRows.Count -eq 8) 'Expected eight isolated diagnostic source members including the application manifest'
$parse=@();foreach($row in $sourceRows){$path=Join-Path $PSScriptRoot $row.path;[IO.File]::Copy($path,(Join-Path $build ('source\'+$row.path)),$false);if($row.path -match '\.ps(m)?1$'){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);$parse+=@([ordered]@{path=$row.path;errors=@($errors|ForEach-Object{$_.ToString()})})}}
Save-New (Join-Path $build 'source-parse.json') $parse
Require (@($parse|Where-Object{@($_.errors).Count -ne 0}).Count -eq 0) 'PS5.1 diagnostic source parse failed'
foreach($name in $production.Keys){[IO.File]::Copy((Join-Path $repo ('tools\headless\'+$name)),(Join-Path $build ('source\'+$name)),$false)}
[IO.File]::Copy((Join-Path $prior 'NativeEnumeration.dll'),(Join-Path $build 'NativeEnumeration.dll'),$false)
[IO.File]::Copy((Join-Path $prior 'native-imports.txt'),(Join-Path $build 'native-imports-reused.txt'),$false)
$csc='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
Require ((Hash $csc) -ceq $old.cscSha256) 'Established Framework compiler differs'
$exe=Join-Path $build 'DesktopEnumDiagnostic.exe'
$arguments=@('/nologo','/target:exe','/platform:x64','/warn:4','/warnaserror+','/r:System.Web.Extensions.dll',('/out:'+$exe),('/win32manifest:'+(Join-Path $build 'source\Diagnostic.manifest')))
$arguments+=@('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs','Diagnostic.cs','Qualification9974.cs','Qualification9974.Tests.cs'|ForEach-Object{Join-Path $build ('source\'+$_)})
$compile=Invoke-FixtureSourceProcess -File $csc -Arguments $arguments -Directory $build -Record (Join-Path $build 'managed-compile-process.json') -BoundMs 30000
Require ($compile.exitCode -eq 0 -and $compile.stderr -eq '' -and $compile.stdout -eq '') 'Managed diagnostic compile must finish without warnings/errors'
$pure=Invoke-FixtureSourceProcess -File $exe -Arguments @('--selftest-9974') -Directory $build -Record (Join-Path $build 'pure-9974-process.json') -BoundMs 15000
Require ($pure.exitCode -eq 0 -and $pure.stderr -eq '') 'New finite pure checks failed'
$pureRows=@($pure.stdout -split '\r?\n'|Where-Object{$_ -ne ''}|ForEach-Object{$_|ConvertFrom-Json})
Require ($pureRows.Count -eq 2 -and $pureRows[0].checks -eq 28 -and $pureRows[1].checks -eq 19 -and @($pureRows|Where-Object{$_.failed -ne 0 -or $_.nativeExecuted -ne $false -or $_.desktopApisCalled -ne $false}).Count -eq 0) 'Exact 28+19 pure outcomes missing'
Save-New (Join-Path $build 'pure-9974-result.json') $pureRows
$dry=& (Join-Path $PSScriptRoot 'Run-Diagnostic.ps1')
Require ($dry.willExecute -eq $false -and $dry.maxMeasurements -eq 48 -and $dry.additionalNativeLists -eq 12 -and $dry.additionalPairedEnumerations -eq 12) 'New launcher dry plan differs'
Save-New (Join-Path $build 'launcher-dry-plan.json') $dry
foreach($row in $sourceRows){Require ((Hash (Join-Path $PSScriptRoot $row.path)) -ceq $row.sha256 -and (Hash (Join-Path $build ('source\'+$row.path))) -ceq $row.sha256) 'Source changed during build'}
foreach($name in $production.Keys){Require ((Hash (Join-Path $repo ('tools\headless\'+$name))) -ceq $production[$name] -and (Hash (Join-Path $build ('source\'+$name))) -ceq $production[$name]) 'Production source changed during build'}
Require ((Hash (Join-Path $build 'NativeEnumeration.dll')) -ceq '11e26ce29fc773c707be44d27bd2dc078949c6ffdb4a90cf6d35deea49fdcec8') 'Reused native shim differs'
Require (-not(Test-Path -LiteralPath $results)) 'SOURCE preparation created diagnostic results'
$files=@(Get-ChildItem -LiteralPath $build -File -Recurse|ForEach-Object{[ordered]@{path=$_.FullName.Substring($build.Length+1).Replace('\','/');sha256=(Hash $_.FullName);bytes=$_.Length}}|Sort-Object path)
$manifest=[ordered]@{schema=1;diagnosticOnly=$true;sourceBuildOnly=$true;nativeExecuted=$false;desktopApisExecuted=$false;productionQualificationGranted=$false;productionSources=$production;priorManifestSha256=(Hash (Join-Path $prior 'manifest.json'));nativeShimRecompiled=$false;reusedNativeShim=[ordered]@{path=(Join-Path $prior 'NativeEnumeration.dll');sha256=(Hash (Join-Path $build 'NativeEnumeration.dll'));sourceSha256=(Hash (Join-Path $PSScriptRoot 'NativeEnumeration.c'));oldMemberCount=$old.files.Count};csc=$csc;cscSha256=(Hash $csc);compileAttempts=1;runtimeCommandExecuted='--selftest-9974 only';requestedMeasurementCommand='--execute-reviewed-diagnostic';maxMeasurements=48;nativeListPairs=12;pureChecks=47;old79ChecksRerun=$false;old5NativePureChecksRerun=$false;redEvidencePath=(Join-Path $prep 'red\test-process.json');redEvidenceSha256=(Hash (Join-Path $prep 'red\test-process.json'));files=$files}
Save-New (Join-Path $build 'manifest.json') $manifest
foreach($f in $manifest.files){$path=Join-Path $build $f.path;Require ((Hash $path) -ceq $f.sha256 -and (Get-Item -LiteralPath $path).Length -eq $f.bytes) 'New producer member readback differs'}
foreach($f in $old.files){$path=Join-Path $prior $f.path;Require ((Hash $path) -ceq $f.sha256 -and (Get-Item -LiteralPath $path).Length -eq $f.bytes) 'Protected build7 changed'}
$readback=[ordered]@{sourceBuildOnly=$true;nativeExecuted=$false;build=$build;manifestSha256=(Hash (Join-Path $build 'manifest.json'));membersVerified=$files.Count;sourceMembersVerified=$sourceRows.Count;oldBuild7MembersVerified=$old.files.Count;productionSources=$production;nativeShimRecompiled=$false;desktopResultsCreated=$false;pureChecks=47;pureFailed=0;compilerPid=$compile.pid;compilerCreationFileTime=$compile.creationFileTime;purePid=$pure.pid;pureCreationFileTime=$pure.creationFileTime;allProcessesNaturallyExited=$true;executeCalled=$false}
Save-New (Join-Path $prep 'build2-producer-readback.json') $readback
[pscustomobject]$readback|ConvertTo-Json -Depth 10
