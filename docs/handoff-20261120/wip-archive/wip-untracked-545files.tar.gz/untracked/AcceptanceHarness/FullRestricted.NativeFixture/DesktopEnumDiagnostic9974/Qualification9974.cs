using System;
using System.Collections.Generic;
internal static class Qualification9974 {
 internal sealed class Image {internal string Name,Hash,Version,Export;internal long Rva;}
 internal sealed class Measurement {internal uint Capacity,Seed;}
 internal static Image[] Images(){return new[]{
  new Image{Name="user32.dll",Hash="4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91",Version="10.0.26100.9818",Export="EnumDesktopWindows",Rva=0x2a9a0},
  new Image{Name="win32u.dll",Hash="5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc",Version="10.0.26100.9974",Export="NtUserBuildHwndList",Rva=0x1610}};}
 internal static Measurement[] Measurements(){return new[]{new Measurement{Capacity=1,Seed=0x1BADB002},new Measurement{Capacity=64,Seed=0x1BADB002},new Measurement{Capacity=64,Seed=0}};}
 internal static Dictionary<string,object> Describe(Image spec,string expectedPath,string loadedPath,string hash,string fixedVersion,long offset,bool reparse,string rawFileVersion,string rawProductVersion,string language){
  return new Dictionary<string,object>{{"name",spec.Name},{"path",loadedPath},{"expectedPath",expectedPath},{"sha256",hash},{"expectedSha256",spec.Hash},{"fixedFileVersion",fixedVersion},{"expectedFixedFileVersion",spec.Version},{"rawFileVersion",rawFileVersion},{"rawProductVersion",rawProductVersion},{"language",language},{"export",spec.Export},{"exportOffset",offset},{"expectedExportOffset",spec.Rva},{"reparse",reparse},{"pathMatch",String.Equals(loadedPath,expectedPath,StringComparison.OrdinalIgnoreCase)},{"hashMatch",hash==spec.Hash},{"fixedVersionMatch",fixedVersion==spec.Version},{"exportMatch",offset==spec.Rva},{"nonReparseMatch",!reparse},{"loadedInspectionDeferred",loadedPath==null}};
 }
 internal static void Validate(Dictionary<string,object> row,bool requireLoaded){
  if(!(bool)row["hashMatch"]||!(bool)row["fixedVersionMatch"]||!(bool)row["nonReparseMatch"])throw new InvalidOperationException("9974 diagnostic disk identity refused: "+row["name"]);
  bool loaded=row["path"]!=null;
  if((requireLoaded&&!loaded)||(loaded&&(!(bool)row["pathMatch"]||!(bool)row["exportMatch"])))throw new InvalidOperationException("9974 diagnostic loaded identity refused: "+row["name"]);
 }
}
