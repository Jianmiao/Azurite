param([Parameter(Mandatory)][string]$BuildDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $BuildDirectory 'source\FixtureRules.psm1') -Force -DisableNameChecking
$count=0
function Copy-PureSample($Value){$params=@{InputObject=($Value|ConvertTo-Json -Depth 30);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$params.DateKind='String'};ConvertFrom-Json @params}
function Check($Ok,[string]$Why){$script:count++;if(-not $Ok){throw "Pure check failed: $Why"}}
function Refuse([scriptblock]$Action,[string]$Why){$ready=Get-Variable monitor -ErrorAction SilentlyContinue;if($null -ne $ready -and $null -ne $ready.Value){Assert-FixtureMonitorEvidence (Copy-PureSample $ready.Value) $c.runId};$caught=$false;try{& $Action}catch{$caught=$true};Check $caught $Why}
$equiv=Read-FixtureJson (Join-Path $BuildDirectory 'equivalence.json')
Check ($equiv.transformReversible -and $equiv.allMethodBodiesTextIdentical -and $equiv.changedTokens.Count -eq 2 -and $equiv.sharedNativeSourceByteIdentical -and $equiv.maxPathLength -lt 250) 'constant-only accepted source equivalence'
$assembly=[Reflection.Assembly]::LoadFrom((Join-Path $BuildDirectory 'AzuriteLifecycle.FixtureOnly.dll'))
$pump=$assembly.GetType('Azurite.Restricted.ProcessPump',$true)
Check ($pump.GetMethod('RunBootstrapFullRestricted').GetParameters().Count -eq 7) 'same public outer method signature'
$fixture=$assembly.GetType('Azurite.Restricted.LifecycleFixture',$true)
Check ($fixture.GetProperty('Lab').GetValue($null,$null) -ceq (Get-FixtureLab) -and $fixture.GetProperty('Target').GetValue($null,$null).EndsWith('\install\AzuriteLifecycleProbe.exe')) 'fixture constants fixedC and harmless basename'
$c=[pscustomobject]@{runId=('a'*32);scenario='normal';userSid='S-1-5-21-1-2-3-1001';logonSid='S-1-5-5-1-2';session=1;integrityRid=8192;mandatoryPolicy=3}
$e=[pscustomobject]@{schema=1;fixtureOnly=$true;productionTargetExecuted=$false;runId=$c.runId;scenario=$c.scenario;pid=42;userSid=$c.userSid;logonSid=$c.logonSid;session=1;integrityRid=8192;integrityAttributes=96;mandatoryPolicy=3;elevated=0;appContainer=0;tokenType=1;isRestricted=$true;usersAttributes=7;restrictedSidCount=3;restrictingSids=@($c.logonSid,'S-1-1-0','S-1-5-32-545');privilege='SeChangeNotifyPrivilege';privilegeEnabled=$true;desktop=('AzuriteFullCli_'+$c.runId);anyJobMembership=$true;exactJobClaimedByChild=$false;stdHandles=@(10,11,12);stdTypes=@(3,3,3);stdFlags=@(1,1,1);stdinEof=$true;streamsWritten=$true}
Assert-FixtureChild $e $c;Check $true 'complete child observations'
foreach($name in @('runId','userSid','logonSid','desktop','privilege')){$bad=Copy-PureSample $e;$bad.$name='wrong';Refuse {Assert-FixtureChild $bad $c} $name}
foreach($name in @('stdinEof','isRestricted','streamsWritten','privilegeEnabled')){$bad=Copy-PureSample $e;$bad.$name=$false;Refuse {Assert-FixtureChild $bad $c} $name}
$bad=Copy-PureSample $e;$bad.exactJobClaimedByChild=$true;Refuse {Assert-FixtureChild $bad $c} 'child cannot claim exactJob from anyJob'
$n=[pscustomobject]@{actualTokenVerified=$true;exactOwnedJobVerified=$true;outerDesktopLeaseAcknowledged=$true;creationFlags=0x08084404;pipeHandlesBeforeCreate=@(0..5|ForEach-Object{[pscustomobject]@{handle=(10+$_);flags=$(if($_ -lt 3){1}else{0});fileType=3}})}
Assert-FixtureNativeEvidence $n $e;Check $true 'parent queried endpoints correlate to child'
$bad=Copy-PureSample $n;$bad.pipeHandlesBeforeCreate[0].handle=99;Refuse {Assert-FixtureNativeEvidence $bad $e} 'handle mismatch cannot qualify'
$outer=[pscustomobject]@{Pid=40;ExitCode=0;CleanupVerified=$true;DirectProcessExited=$true;JobDrained=$true;RemainingOwnedProcesses=0;JobObserved=$true;DesktopLeaseObserved=$true;DesktopLeaseClosed=$true;DesktopLeaseRetained=$false;FullJobObserverClosed=$true;FullJobObserverRetained=$false;StreamCaptureComplete=$true;TimedOut=$false;WindowViolation=$false;OutputLimitExceeded=$false;Error=$null}
Assert-FixtureOuter $outer normal;Check $true 'normal realresult predicate'
$outer.ExitCode=73;Assert-FixtureOuter $outer bootstrap-exit;Check $true 'expected nonzero is scenario not AA success'
$outer.CleanupVerified=$false;Refuse {Assert-FixtureOuter $outer bootstrap-exit} 'cleanup failure never passes';$outer.CleanupVerified=$true
$stdout='FIXTURE_STDOUT '+$c.runId+' '+[char]0x20ac+[char]10;$stderr='FIXTURE_STDERR '+$c.runId+' '+[char]::ConvertFromUtf32(0x1f31f)+[char]10
Assert-FixtureCaptured $stdout $stderr $c.runId;Check $true 'split UTF8 expected captured text'
Refuse {Assert-FixtureCaptured ($stdout+'extra') $stderr $c.runId} 'flood/extra bytes not accepted'
$bridgePath=Join-Path $BuildDirectory 'FixtureSerialization.PureBridge.exe'
$hostLabel=if($PSVersionTable.PSVersion.Major -eq 5){'ps51'}else{'ps7'}
$bridge=[Reflection.Assembly]::LoadFrom($bridgePath);$bridgeType=$bridge.GetType('FixtureSerializationPureBridge',$true)
$monitor=$bridgeType.GetMethod('Create').Invoke($null,[object[]]@())
Check ($monitor.first.imagePins.GetType().FullName -ceq 'System.Object[]') 'this host directly runs production structured monitor returning exact object[]'
$mode='Direct '+$PSVersionTable.PSEdition+' '+$PSVersionTable.PSVersion.ToString()+' production monitor invocation with pure native API; no Framework child substitution'
Write-FixtureJson (Join-Path $BuildDirectory ('serialization-'+$hostLabel+'-monitor.json')) $monitor
$roundtrip=Read-FixtureJson (Join-Path $BuildDirectory ('serialization-'+$hostLabel+'-monitor.json'))
Check ($roundtrip.first.imagePins -is [array] -and $roundtrip.first.imagePins.Count -eq 2 -and $roundtrip.last.imagePins -is [array]) 'Write-FixtureJson Read-FixtureJson exact nested array survives without value/Count wrapper'
Assert-FixtureMonitorEvidence $roundtrip $c.runId;Check $true 'real production object shape through exact fixture writer reader predicate'
Write-FixtureJson (Join-Path $BuildDirectory ('serialization-'+$hostLabel+'-provenance.json')) ([ordered]@{schema=1;mode=$mode;nativeCallsExecuted=$false;productionCodeExecuted='FullDesktopMonitor.Run; FullDesktopMonitorSession.Snapshot; FullDesktopImagePolicy.Describe/Validate; direct structured image records';nativeApi='pure fake';writer='Write-FixtureJson';reader='Read-FixtureJson';predicate='Assert-FixtureMonitorEvidence';roundtripPassed=$true;imagePinsArray=$true;imagePinsCount=2;bridgeSha256=(Get-FixtureHash $bridgePath);host=$PSVersionTable.PSVersion.ToString();directHostInvocation=$true;frameworkChildSubstitution=$false})
$monitor=$roundtrip
$positiveClone=Copy-PureSample $monitor;Assert-FixtureMonitorEvidence $positiveClone $c.runId;Check $true 'pure clone preserves successful timestamp/array shape before negative mutations'
Assert-FixtureMonitorEvidence $monitor $c.runId;Check $true 'actual monitor evidence predicate positive'
Refuse {Assert-FixtureMonitorEvidence $null $c.runId} 'missing monitor evidence cannot be defaultpass'
foreach($field in @('emptyCount','failedCount','pinnedImageIdentity')){$bad=Copy-PureSample $monitor;if($field -ceq 'emptyCount'){$bad.$field=0}elseif($field -ceq 'failedCount'){$bad.$field=1}else{$bad.$field='unknown'};Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} ('monitor '+$field)}
foreach($field in @('usedPath','expectedName')){$bad=Copy-PureSample $monitor;$bad.first.$field='wrong';Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} ('monitor first '+$field)}
$bad=Copy-PureSample $monitor;$bad.last.list.first=0;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'monitor nullsentinel rejected'
$bad=Copy-PureSample $monitor;$bad.last.identityAfter.grantedAccess=0;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'monitor rightsquery evidence required'
$bad=Copy-PureSample $monitor;$bad.last.enumeration.callbackError='failed';Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'monitor callbackfailure cannotpass'
foreach($field in @('name','path','expectedPath','sha256','expectedSha256','fixedFileVersion','expectedFixedFileVersion','rawFileVersion','rawProductVersion','language')){
 $bad=Copy-PureSample $monitor;$bad.first.imagePins[0].$field=if($field -in @('rawFileVersion','rawProductVersion','language')){''}else{'wrong'}
 Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} ('image pin field '+$field)
}
foreach($field in @('exportOffset','expectedExportOffset')){$bad=Copy-PureSample $monitor;$bad.first.imagePins[0].$field=0;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} ('image pin numeric '+$field)}
foreach($field in @('pathMatch','hashMatch','fixedVersionMatch','exportMatch','nonReparseMatch')){$bad=Copy-PureSample $monitor;$bad.last.imagePins[1].$field=$false;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} ('image pin flag '+$field)}
$bad=Copy-PureSample $monitor;$bad.first.imagePins[0].reparse=$true;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'image reparse refused'
$bad=Copy-PureSample $monitor;$bad.first.imagePins=[pscustomobject]@{value=$bad.first.imagePins;Count=2};Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'value Count imagePins wrapper refused'
$bad=Copy-PureSample $monitor;$bad.last.imagePins=@($bad.last.imagePins[1],$bad.last.imagePins[0]);Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'image rows cannot reorder'
$bad=Copy-PureSample $monitor;$bad.last.imagePins=@($bad.last.imagePins[0],$bad.last.imagePins[0]);Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'duplicate image cannot stand in for win32u'
$bad=Copy-PureSample $monitor;$bad.first.imagePins[0].fixedVersionMatch=1;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'numeric true substitute refused'
$bad=Copy-PureSample $monitor;$bad.first.imagePins[0].exportOffset='174496';Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'string offset substitute refused'
foreach($index in @(0,1)){foreach($field in @('name','sha256','expectedSha256','fixedFileVersion','expectedFixedFileVersion')){$bad=Copy-PureSample $monitor;$bad.first.imagePins[$index].$field=$true;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} ('Boolean image text '+$index+'/'+$field)}}
$bad=Copy-PureSample $monitor;$bad.pinnedImageIdentity=$true;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'combined identity must be string'
$bad=Copy-PureSample $monitor;$bad.first.imagePins[1].sha256='ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4';Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'old win32u9818 hash rejected'
$bad=Copy-PureSample $monitor;$bad.last.imagePins[1].fixedFileVersion='10.0.26100.9818';Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} 'old win32u9818 version rejected'
foreach($index in @(0,1)){$bad=Copy-PureSample $monitor;$bad.last.imagePins[$index].fixedFileVersion=$bad.last.imagePins[1-$index].fixedFileVersion;Refuse {Assert-FixtureMonitorEvidence $bad $c.runId} ('cross image fixed version '+$index)}
$displayChanged=Copy-PureSample $monitor;$displayChanged.first.imagePins[0].rawFileVersion='10.0.26100.9949 (WinBuild.160101.0800)';Assert-FixtureMonitorEvidence $displayChanged $c.runId;Check $true 'localized display string variation is evidence only with fixed9818 exact'
foreach($name in @('Build-Fixture.ps1','Run-Fixture.ps1','FixtureBootstrap.ps1','FixtureRules.psm1','Test-Fixture.ps1')){$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile((Join-Path $BuildDirectory ('source\'+$name)),[ref]$tokens,[ref]$errors);Check ($errors.Count -eq 0) ('parse '+$name)}
[pscustomobject]@{scope='fixture pure predicates parser and metadata only';fixtureOnly=$true;productionTargetExecuted=$false;childExecuted=$false;passed=$true;checks=$count;host=$PSVersionTable.PSVersion.ToString()}|ConvertTo-Json -Compress
