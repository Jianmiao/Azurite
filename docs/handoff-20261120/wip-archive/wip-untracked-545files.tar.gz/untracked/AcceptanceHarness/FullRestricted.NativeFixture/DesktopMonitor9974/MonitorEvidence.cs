using System;
using System.Collections.Generic;
using System.IO;
internal static class MonitorEvidence {
 internal const string UserSha="4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91",WinSha="5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc";
 internal const string PinIdentity="user32.dll|10.0.26100.9818|"+UserSha+"|EnumDesktopWindows:0x2a9a0;win32u.dll|10.0.26100.9974|"+WinSha+"|NtUserBuildHwndList:0x1610";
 internal const string WrongName="AzuriteFullCli_00000000000000000000000000000000";
 static void Need(bool value,string message){if(!value)throw new InvalidOperationException("Monitor qualification: "+message);}
 internal static object V(Dictionary<string,object> row,string key){object value;Need(row!=null&&row.TryGetValue(key,out value),"missing "+key);return row[key];}
 internal static Dictionary<string,object> M(Dictionary<string,object> row,string key){var value=V(row,key) as Dictionary<string,object>;Need(value!=null,"object "+key);return value;}
 static string S(Dictionary<string,object> row,string key){var value=V(row,key) as string;Need(!String.IsNullOrEmpty(value),"string "+key);return value;}
 static long N(Dictionary<string,object> row,string key){object value=V(row,key);Need(value is int||value is long||value is uint||value is short||value is byte,"number "+key);return Convert.ToInt64(value);}
 static bool B(Dictionary<string,object> row,string key){object value=V(row,key);Need(value is bool,"boolean "+key);return (bool)value;}
 static void Identity(Dictionary<string,object> value,long handle,string name,string owner){
  Need(N(value,"handle")==handle&&S(value,"name")==name&&S(value,"type")=="Desktop","exact owned desktop identity");
  Need(S(value,"owner")==owner&&S(value,"currentOwner")==owner&&!B(value,"inherited")&&N(value,"rightsQueryStatus")==0&&N(value,"grantedAccess")==0xF01FF,"owner/full rights/noninheritance");
 }
 static void Images(Dictionary<string,object> observation,string systemDirectory){
  var rows=V(observation,"imagePins") as object[];Need(rows!=null&&rows.Length==2,"two image pins");
  for(int i=0;i<2;i++){
   var row=rows[i] as Dictionary<string,object>;Need(row!=null,"image row");
   string name=i==0?"user32.dll":"win32u.dll",hash=i==0?UserSha:WinSha,version=i==0?"10.0.26100.9818":"10.0.26100.9974";long rva=i==0?0x2a9a0:0x1610;
   string path=Path.Combine(systemDirectory,name);
   Need(S(row,"name")==name&&String.Equals(S(row,"path"),path,StringComparison.OrdinalIgnoreCase)&&String.Equals(S(row,"expectedPath"),path,StringComparison.OrdinalIgnoreCase),"System32 image path");
   Need(S(row,"sha256")==hash&&S(row,"expectedSha256")==hash&&S(row,"fixedFileVersion")==version&&S(row,"expectedFixedFileVersion")==version&&N(row,"exportOffset")==rva&&N(row,"expectedExportOffset")==rva&&!B(row,"reparse"),"exact new image identity");
   foreach(string field in new[]{"pathMatch","hashMatch","fixedVersionMatch","exportMatch","nonReparseMatch"})Need(B(row,field),"image comparison "+field);
   V(row,"rawFileVersion");V(row,"rawProductVersion");V(row,"language");
  }
 }
 internal static void Validate(Dictionary<string,object> row,bool negative,long handle,string actualName,string expectedName,string owner,int pid,string systemDirectory){
  Need(pid>0&&handle>0&&actualName!=WrongName,"actual PID/handle and distinct negative name");
  Need(N(row,"handle")==handle&&S(row,"expectedName")==expectedName,"call inputs");
  var ids=V(row,"watchedPids") as object[];Need(ids!=null&&ids.Length==1&&Convert.ToInt64(ids[0])==pid,"actual probe PID watched");
  var session=M(row,"session");Need(N(session,"normalCount")==0&&N(session,"emptyCount")== (negative?0:1)&&N(session,"failedCount")== (negative?1:0)&&N(session,"boundedStoredObservations")==1,"one exact production-session observation");
  var first=M(session,"first");var last=M(session,"last");Need(S(first,"observedUtc")==S(last,"observedUtc"),"same single stored observation");
  foreach(var observation in new[]{first,last}){
   Need(N(observation,"handle")==handle&&S(observation,"expectedName")==expectedName,"session call identity");
   var enumeration=M(observation,"enumeration");Need(!B(enumeration,"returned")&&N(enumeration,"error")==0&&N(enumeration,"callbacks")==0&&!B(enumeration,"visible")&&V(enumeration,"callbackError")==null,"actual false-zero-no-callback eligibility");
   Identity(M(observation,"identityBefore"),handle,actualName,owner);
   if(negative){
    Need(expectedName==WrongName&&S(observation,"usedPath")=="failed"&&S(observation,"error").Contains("Full desktop identity/name/type/owner/read-rights proof failed"),"wrong-name identity refusal");
    Need(!observation.ContainsKey("list")&&!observation.ContainsKey("identityAfter")&&!observation.ContainsKey("imagePins")&&!observation.ContainsKey("foregroundOwned"),"negative stopped before pin/list/foreground");
   }else{
    Need(expectedName==actualName&&S(observation,"usedPath")=="pinned-empty","actual production fallback path");
    Identity(M(observation,"identityAfter"),handle,actualName,owner);Images(observation,systemDirectory);
    var list=M(observation,"list");Need(N(list,"status")==0&&N(list,"lastError")==0&&N(list,"capacity")==64&&N(list,"needed")==1&&N(list,"first")==1&&B(list,"guardsIntact")&&B(list,"tailIntact"),"exact production list result");
    Need(!B(observation,"foregroundOwned")&&!B(observation,"violation"),"actual foreground and visibility checks");
   }
  }
  if(negative){var error=M(row,"exception");Need(!B(row,"returned")&&V(row,"violation")==null&&S(error,"type")=="System.InvalidOperationException"&&S(error,"message")=="Full desktop identity/name/type/owner/read-rights proof failed"&&V(session,"pinnedImageIdentity")==null,"negative is exact expected failure");}
  else Need(B(row,"returned")&&!B(row,"violation")&&V(row,"exception")==null&&S(session,"pinnedImageIdentity")==PinIdentity,"normal return with exact pin identity");
 }
}
