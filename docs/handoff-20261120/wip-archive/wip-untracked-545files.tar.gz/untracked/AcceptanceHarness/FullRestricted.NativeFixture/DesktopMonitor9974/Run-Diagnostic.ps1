#requires -Version 5.1
param([switch]$Execute,[string]$ReviewedPackageSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$build=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-monitor-9974-build1'
if(-not $Execute){[pscustomobject]@{diagnosticOnly=$true;willExecute=$false;productionMonitorOverloadParameters=4;usesActualNativeFullDesktopMonitor=$true;usesFakeApi=$false;maximumMonitorCalls=3;newDesktopCount=1;positiveRoutes=@('created-full-rights','duplicate-full-rights');negativeRoute='wrong-name-on-owned-original';watchedPidSource='actual-probe-process';readObjectsOnlyPositive=$false;createsWindows=$false;switchesDesktops=$false;attachesDesktop=$false;createsChild=$false;createsJob=$false;restrictsToken=$false;changesFilesystemAcl=$false;productionPinAdopted=$false};return}
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Root diagnostic launcher requires fresh system x64 PS5.1'}
if($ReviewedPackageSha256 -cnotmatch '^[a-f0-9]{64}$' -or (Get-FileHash -LiteralPath (Join-Path $build 'manifest.json')).Hash.ToLowerInvariant() -cne $ReviewedPackageSha256){throw 'Independently reviewed exact package digest required'}
$m=Get-Content -LiteralPath (Join-Path $build 'manifest.json') -Raw|ConvertFrom-Json
foreach($f in $m.files){$p=Join-Path $build $f.path;if((Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant() -cne $f.sha256 -or (Get-Item -LiteralPath $p).Length -ne $f.bytes){throw 'Reviewed monitor package member differs'}}
if((Get-FileHash -LiteralPath $PSCommandPath).Hash -cne (Get-FileHash -LiteralPath (Join-Path $build 'source\Run-Diagnostic.ps1')).Hash){throw 'Executed launcher differs from frozen source'}
# Root owns this explicit native run and its process/streams. No pure supervisor
# or automatic parent/child termination is introduced by this entry.
& (Join-Path $build 'DesktopMonitor9974.exe') --execute-reviewed-monitor
if($LASTEXITCODE -ne 0){throw 'Actual monitor diagnostic failed; retain raw observations and cleanup evidence'}
