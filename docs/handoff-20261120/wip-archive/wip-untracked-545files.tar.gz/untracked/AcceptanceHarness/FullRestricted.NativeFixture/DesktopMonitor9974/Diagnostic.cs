using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using Azurite.Restricted;
internal static class DesktopMonitor9974 {
 const string OutputRoot=@"C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\desktop-monitor-9974-results1";
 static readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=1048576};
 static readonly List<object> retained=new List<object>();
 static readonly List<string> cleanupFailures=new List<string>();
 static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
 [StructLayout(LayoutKind.Sequential)]struct Sa{public int Size;public IntPtr Descriptor;[MarshalAs(UnmanagedType.Bool)]public bool Inherit;}
 [StructLayout(LayoutKind.Sequential)]struct ObjectBasic{public uint Attributes,GrantedAccess,HandleCount,PointerCount;[MarshalAs(UnmanagedType.ByValArray,SizeConst=10)]public uint[] Reserved;}
 [StructLayout(LayoutKind.Sequential)]struct UserFlags{public int Inherit,Reserved;public uint Flags;}
 [DllImport("kernel32.dll")]static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr handle);
 [DllImport("kernel32.dll")]static extern uint GetCurrentThreadId();
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr source,IntPtr destinationProcess,out IntPtr duplicate,uint rights,bool inherit,uint options);
 [DllImport("kernel32.dll")]static extern IntPtr LocalFree(IntPtr pointer);
 [DllImport("ntdll.dll")]static extern int NtQueryObject(IntPtr handle,int kind,out ObjectBasic info,uint length,out uint needed);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool ConvertStringSecurityDescriptorToSecurityDescriptorW(string text,uint revision,out IntPtr descriptor,out uint bytes);
 [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateDesktopW(string name,IntPtr device,IntPtr mode,uint flags,uint access,ref Sa attributes);
 [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr OpenDesktopW(string name,uint flags,bool inherit,uint access);
 [DllImport("user32.dll",SetLastError=true)]static extern bool CloseDesktop(IntPtr handle);
 [DllImport("user32.dll",SetLastError=true)]static extern IntPtr OpenInputDesktop(uint flags,bool inherit,uint access);
 [DllImport("user32.dll")]static extern IntPtr GetThreadDesktop(uint thread);
 [DllImport("user32.dll")]static extern IntPtr GetProcessWindowStation();
 [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool GetUserObjectInformationW(IntPtr h,int index,StringBuilder text,uint size,out uint needed);
 [DllImport("user32.dll",EntryPoint="GetUserObjectInformationW",SetLastError=true)]static extern bool UserObjectFlags(IntPtr h,int index,out UserFlags flags,uint bytes,out uint needed);
 interface IOriginalTokenQuery {
  int Open(out IntPtr token);Dictionary<string,object> Read(IntPtr token,Dictionary<string,object> capture);int Close(IntPtr token);
 }
 sealed class AcceptedOriginalTokenQuery:IOriginalTokenQuery {
  public int Open(out IntPtr token){bool okay=FullRestrictedToken.OpenProcessToken(GetCurrentProcess(),8,out token);return okay?0:Marshal.GetLastWin32Error();}
  public Dictionary<string,object> Read(IntPtr token,Dictionary<string,object> capture){return FullRestrictedToken.Read(token,capture);}
  public int Close(IntPtr token){if(CloseHandle(token))return 0;int error=Marshal.GetLastWin32Error();return error==0?-1:error;}
 }
 static Dictionary<string,object> ReadOriginalToken(IOriginalTokenQuery api,Dictionary<string,object> evidence,List<object> retainedReferences){
  IntPtr token=IntPtr.Zero;Exception primary=null;string closeFailure=null;Dictionary<string,object> actual=null;
  var capture=new Dictionary<string,object>();evidence["source"]="accepted-FullRestrictedToken.Read+ValidateOriginal";evidence["requestedAccess"]=8;evidence["snapshot"]=capture;evidence["restrictedTokenCreated"]=false;
  try{
   int error=api.Open(out token);evidence["openError"]=error;evidence["acquiredHandle"]=token.ToInt64().ToString("X");
   Require(error==0&&token!=IntPtr.Zero,"Open current original token failed; nativeError="+error);
   actual=api.Read(token,capture);Require(actual!=null,"Original token reader returned null snapshot");evidence["snapshot"]=actual;
   FullRestrictedToken.ValidateOriginal(actual);
   object user,logon,session;
   Require(actual.TryGetValue("user_sid",out user)&&user is string&&!String.IsNullOrEmpty((string)user),"Original user SID missing");
   Require(actual.TryGetValue("logon_sid",out logon)&&logon is string&&System.Text.RegularExpressions.Regex.IsMatch((string)logon,@"^S-1-5-5-\d+-\d+$"),"Original reader must return one actual Logon SID string");
   Require(actual.TryGetValue("session_id",out session)&&(session is int||session is uint||session is long)&&Convert.ToInt64(session)>=0,"Original session field missing or malformed");
   evidence["validated"]=true;
  }catch(Exception e){primary=e;evidence["readError"]=e.ToString();evidence["validated"]=false;}
  finally{
   if(token!=IntPtr.Zero){int error=-1;try{error=api.Close(token);}catch(Exception e){closeFailure=e.ToString();}
    evidence["closeAttempted"]=true;evidence["closeError"]=error;evidence["closed"]=error==0&&closeFailure==null;
    if(error!=0||closeFailure!=null){if(closeFailure==null)closeFailure="Close original-token query handle failed; nativeError="+error;evidence["closeFailure"]=closeFailure;evidence["retained"]=true;retainedReferences.Add(new{role="original-token-query",handle=token,error=error,exception=closeFailure});}
   }else{evidence["closeAttempted"]=false;evidence["closed"]=false;}
  }
  if(primary!=null||closeFailure!=null)throw new InvalidOperationException("Original token observation failed; read="+(primary==null?"none":primary.Message)+"; close="+(closeFailure??"none"),primary);
  return actual;
 }
 static Dictionary<string,object> Info(IntPtr handle){
  var r=new Dictionary<string,object>{{"handle",handle.ToInt64().ToString("X")}};
  foreach(var pair in new[]{new{Index=2,Name="name"},new{Index=3,Name="type"}}){
   uint needed;var text=new StringBuilder(512);bool ok=GetUserObjectInformationW(handle,pair.Index,text,1024,out needed);int e=ok?0:Marshal.GetLastWin32Error();
   r[pair.Name]=new{success=ok,error=e,value=ok?text.ToString():null,needed=needed};
  }
  UserFlags flags;uint bytes;bool flagOkay=UserObjectFlags(handle,1,out flags,(uint)Marshal.SizeOf(typeof(UserFlags)),out bytes);
  r["flags"]=new{success=flagOkay,error=flagOkay?0:Marshal.GetLastWin32Error(),inherit=flags.Inherit,flags=flags.Flags,needed=bytes};
  ObjectBasic basic;uint returned;int status=NtQueryObject(handle,0,out basic,(uint)Marshal.SizeOf(typeof(ObjectBasic)),out returned);
  r["queriedRights"]=new{ntStatus=status,success=status>=0,grantedAccess=status>=0?(object)basic.GrantedAccess:null,requestedReadObjectsPresent=status>=0?(object)((basic.GrantedAccess&1)!=0):null,returned=returned};
  return r;
 }
 static void CloseOwned(ref IntPtr handle,string role,List<object> closes){
  if(handle==IntPtr.Zero)return;IntPtr value=handle;bool okay=CloseDesktop(value);int error=okay?0:Marshal.GetLastWin32Error();
  closes.Add(new{role=role,handle=value.ToInt64().ToString("X"),success=okay,error=error});
  if(!okay){retained.Add(new{role=role,handle=value,error=error});cleanupFailures.Add("CloseDesktop "+role+" failed; nativeError="+error);}
  handle=IntPtr.Zero; /* ownership moved to retained on failure; never retry close */
 }
 static object Context(List<object> closes,string phase){
  IntPtr input=OpenInputDesktop(0,false,1);int error=input==IntPtr.Zero?Marshal.GetLastWin32Error():0;object info=input==IntPtr.Zero?null:Info(input);
  CloseOwned(ref input,"input-observer-"+phase,closes);
  return new{threadId=GetCurrentThreadId(),threadDesktopBorrowed=Info(GetThreadDesktop(GetCurrentThreadId())),processWindowStationBorrowed=Info(GetProcessWindowStation()),inputDesktop=new{openError=error,info=info}};
 }
 static void CompleteReport(Dictionary<string,object> report,string failure,List<string> cleanupErrors,int remaining,int measurements,long elapsed){
  string finalFailure=failure;
  if(cleanupErrors.Count>0)finalFailure=(finalFailure??String.Empty)+(finalFailure==null?String.Empty:"; ")+String.Join("; ",cleanupErrors);
  if(remaining>0&&finalFailure==null)finalFailure="Owned references retained without successful cleanup: "+remaining;
  report["finalFailure"]=finalFailure;report["cleanupErrors"]=cleanupErrors.ToArray();report["elapsedMs"]=elapsed;report["retainedOwnedReferences"]=remaining;report["completedMeasurements"]=measurements;report["diagnosticCompleted"]=finalFailure==null&&remaining==0;report["resultInterpretation"]="Measurements only; no native monitor acceptance rule is changed";
 }
 static void Observe(Dictionary<string,object> report,List<object> observations,string route,IntPtr handle,int pid,string actualName,string expectedName,string owner,bool negative){
  Require(observations.Count<3,"Exactly three bounded monitor calls maximum");
  var session=new FullDesktopMonitorSession();bool returned=false,violation=false;Exception failure=null;
  report["productionMonitorCallAttempted"]=true;
  try{violation=WindowProbe.HasVisibleOnDesktop(handle,new[]{pid},expectedName,session);returned=true;}
  catch(Exception e){failure=e;}
  var row=new Dictionary<string,object>{{"route",route},{"handle",handle.ToInt64()},{"expectedName",expectedName},{"watchedPids",new[]{pid}},{"returned",returned},{"violation",returned?(object)violation:null},{"exception",failure==null?null:(object)new{type=failure.GetType().FullName,message=failure.Message,text=failure.ToString()}},{"session",session.Snapshot()},{"expectedOutcomeMatched",false}};
  observations.Add(row); // Save the raw real session, including a failed call, before interpretation.
  var detached=(Dictionary<string,object>)json.DeserializeObject(json.Serialize(row));
  MonitorEvidence.Validate(detached,negative,handle.ToInt64(),actualName,expectedName,owner,pid,Environment.SystemDirectory);
  row["expectedOutcomeMatched"]=true;
 }
 static int Execute(){
  string id=Guid.NewGuid().ToString("N"),name="AzuriteFullCli_"+id,run=Path.Combine(OutputRoot,id);Directory.CreateDirectory(run);
  var report=new Dictionary<string,object>{{"schema",1},{"diagnosticOnly",true},{"originalFullSha256","37d89b1942d74c4faae42365f6d5b302fe50b5d98135c6ad5bc36cbe98afe0c5"},{"candidateFullSha256","cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533"},{"sharedSha256","f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921"},{"id",id},{"requestedDesktopName",name},{"productionMonitorCallAttempted",false},{"productionPinAdopted",false},{"maximumMonitorCalls",3},{"qualificationObservationsMatched",false}};
  var observations=new List<object>();var closes=new List<object>();report["monitorObservations"]=observations;report["closes"]=closes;
  IntPtr direct=IntPtr.Zero,duplicate=IntPtr.Zero,sd=IntPtr.Zero;Mutex mutex=null;bool held=false;string failure=null;
  var watch=Stopwatch.StartNew();ProcessPriorityClass priority=Process.GetCurrentProcess().PriorityClass;
  try{
   Require(name!=MonitorEvidence.WrongName,"Fresh name must differ from fixed negative expected name");
   mutex=new Mutex(false,@"Global\AzuriteRestrictedCli-AA");try{held=mutex.WaitOne(0);}catch(AbandonedMutexException){held=true;}Require(held,"Existing diagnostic/AA mutex is held");
   Require(Process.GetProcessesByName("AzureArchive").Length==0&&Process.GetProcessesByName("AzuriteLifecycleProbe").Length==0,"Actual AA/probe must be absent");
   int pid;using(var process=Process.GetCurrentProcess()){pid=process.Id;report["probeProcess"]=new{pid=pid,creationFileTime=process.StartTime.ToUniversalTime().ToFileTimeUtc()};}
   var tokenEvidence=new Dictionary<string,object>();report["originalTokenRead"]=tokenEvidence;
   var original=ReadOriginalToken(new AcceptedOriginalTokenQuery(),tokenEvidence,retained);string user=(string)original["user_sid"],logon=(string)original["logon_sid"];
   report["userSid"]=user;report["logonSid"]=logon;report["sessionId"]=original["session_id"];
   report["before"]=Context(closes,"before");
   IntPtr existing=OpenDesktopW(name,0,false,1);int absence=existing==IntPtr.Zero?Marshal.GetLastWin32Error():0;
   if(existing!=IntPtr.Zero){CloseOwned(ref existing,"unexpected-existing",closes);throw new InvalidOperationException("Diagnostic desktop name already exists");}
   Require(absence==2,"Fresh desktop absence not proven; error="+absence);report["absenceError"]=absence;
   string sddl="O:"+user+"D:P(A;;0xF01FF;;;"+user+")(A;;0xF01FF;;;"+logon+")";report["descriptorIntent"]=sddl;
   uint bytes;Require(ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl,1,out sd,out bytes),"Build same descriptor intent");
   var attributes=new Sa{Size=Marshal.SizeOf(typeof(Sa)),Descriptor=sd,Inherit=false};
   direct=CreateDesktopW(name,IntPtr.Zero,IntPtr.Zero,0,0xF01FF,ref attributes);int createError=direct==IntPtr.Zero?Marshal.GetLastWin32Error():0;report["createError"]=createError;Require(direct!=IntPtr.Zero,"CreateDesktop error="+createError);
   report["afterCreateContext"]=Context(closes,"after-create");report["direct"]=Info(direct);
   Require(DuplicateHandle(GetCurrentProcess(),direct,GetCurrentProcess(),out duplicate,0,false,2),"Duplicate same-access diagnostic desktop");Require(duplicate!=IntPtr.Zero&&duplicate!=direct,"Distinct owned duplicate required");report["duplicateSameAccess"]=Info(duplicate);
   Process.GetCurrentProcess().PriorityClass=ProcessPriorityClass.BelowNormal;
   Observe(report,observations,"created-full-rights",direct,pid,name,name,user,false);Require(watch.ElapsedMilliseconds<10000,"Production monitor diagnostic deadline");
   Observe(report,observations,"duplicate-full-rights",duplicate,pid,name,name,user,false);Require(watch.ElapsedMilliseconds<10000,"Production monitor diagnostic deadline");
   Observe(report,observations,"wrong-name-negative",direct,pid,name,MonitorEvidence.WrongName,user,true);Require(watch.ElapsedMilliseconds<10000,"Production monitor diagnostic deadline");
   report["afterMeasurementsContext"]=Context(closes,"after-measurements");Require(observations.Count==3,"Incomplete actual monitor matrix");report["qualificationObservationsMatched"]=true;
  }catch(Exception e){failure=e.ToString();report["failure"]=new{type=e.GetType().FullName,message=e.Message,hresult=e.HResult,nativeErrorCode=e is Win32Exception?(object)((Win32Exception)e).NativeErrorCode:null,stack=e.StackTrace};}
  finally{
   CloseOwned(ref duplicate,"owned-duplicate",closes);CloseOwned(ref direct,"owned-created",closes);
   try{report["afterCleanupContext"]=Context(closes,"after-cleanup");}catch(Exception e){cleanupFailures.Add("Final desktop context: "+e.ToString());}
   if(sd!=IntPtr.Zero){bool freed=LocalFree(sd)==IntPtr.Zero;int error=freed?0:Marshal.GetLastWin32Error();closes.Add(new{role="owned-security-descriptor",success=freed,error=error});if(!freed){retained.Add(sd);cleanupFailures.Add("LocalFree security descriptor failed; nativeError="+error);}}
   try{Process.GetCurrentProcess().PriorityClass=priority;}catch(Exception e){cleanupFailures.Add("Priority restore: "+e.ToString());}
   if(mutex!=null){try{if(held){mutex.ReleaseMutex();held=false;}}catch(Exception e){cleanupFailures.Add("Mutex release: "+e.ToString());retained.Add(mutex);}if(!held)try{mutex.Dispose();}catch(Exception e){cleanupFailures.Add("Mutex dispose: "+e.ToString());retained.Add(mutex);}}
   CompleteReport(report,failure,cleanupFailures,retained.Count,observations.Count,watch.ElapsedMilliseconds);report["completedMonitorCalls"]=observations.Count;
   byte[] data=new UTF8Encoding(false).GetBytes(json.Serialize(report));using(var fs=new FileStream(Path.Combine(run,"result.json"),FileMode.CreateNew,FileAccess.Write,FileShare.Read)){fs.Write(data,0,data.Length);fs.Flush(true);}
  }
  Console.WriteLine(json.Serialize(new{diagnosticOnly=true,resultPath=Path.Combine(run,"result.json"),completed=(bool)report["diagnosticCompleted"],finalFailure=report["finalFailure"],productionPinAdopted=false}));
  return (bool)report["diagnosticCompleted"]?0:1;
 }
 static int Main(string[] args){try{if(args.Length==1&&args[0]=="--selftest-monitor-evidence")return MonitorEvidenceChecks.Run();if(args.Length==1&&args[0]=="--execute-reviewed-monitor")return Execute();Console.WriteLine("Only --selftest-monitor-evidence or separately reviewed --execute-reviewed-monitor is supported.");return 2;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
