using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
internal static class MonitorEvidenceChecks {
 const string Name="AzuriteFullCli_11111111111111111111111111111111",Owner="S-1-5-21-1-2-3-1001",SystemDirectory=@"C:\Windows\System32";
 static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
 static Dictionary<string,object> D(params object[] pairs){var d=new Dictionary<string,object>();for(int i=0;i<pairs.Length;i+=2)d.Add((string)pairs[i],pairs[i+1]);return d;}
 static Dictionary<string,object> Id(long handle){return D("handle",handle,"name",Name,"type","Desktop","owner",Owner,"currentOwner",Owner,"rightsQueryStatus",0,"grantedAccess",0xF01FF,"inherited",false);}
 static object[] Pins(){var values=new object[2];for(int i=0;i<2;i++){string n=i==0?"user32.dll":"win32u.dll",h=i==0?MonitorEvidence.UserSha:MonitorEvidence.WinSha,v=i==0?"10.0.26100.9818":"10.0.26100.9974";int o=i==0?0x2a9a0:0x1610;values[i]=D("name",n,"path",SystemDirectory+"\\"+n,"expectedPath",SystemDirectory+"\\"+n,"sha256",h,"expectedSha256",h,"fixedFileVersion",v,"expectedFixedFileVersion",v,"exportOffset",o,"expectedExportOffset",o,"reparse",false,"pathMatch",true,"hashMatch",true,"fixedVersionMatch",true,"exportMatch",true,"nonReparseMatch",true,"rawFileVersion","raw preserved","rawProductVersion","raw preserved","language","fixture");}return values;}
 static Dictionary<string,object> Sample(bool negative,long handle){
  string expected=negative?MonitorEvidence.WrongName:Name;
  var observation=D("observedUtc","2026-11-14T00:00:00Z","handle",handle,"expectedName",expected,"enumeration",D("returned",false,"error",0,"callbacks",0,"visible",false,"callbackError",null),"identityBefore",Id(handle),"usedPath",negative?"failed":"pinned-empty");
  if(negative)observation.Add("error","System.InvalidOperationException: Full desktop identity/name/type/owner/read-rights proof failed");
  else{observation.Add("identityAfter",Id(handle));observation.Add("imagePins",Pins());observation.Add("list",D("status",0,"lastError",0,"capacity",64,"needed",1,"first",1,"guardsIntact",true,"tailIntact",true));observation.Add("foregroundOwned",false);observation.Add("violation",false);}
  return D("handle",handle,"expectedName",expected,"watchedPids",new object[]{42},"returned",!negative,"violation",negative?(object)null:false,"exception",negative?(object)D("type","System.InvalidOperationException","message","Full desktop identity/name/type/owner/read-rights proof failed"):null,"session",D("normalCount",0,"emptyCount",negative?0:1,"failedCount",negative?1:0,"boundedStoredObservations",1,"first",observation,"last",observation,"pinnedImageIdentity",negative?null:MonitorEvidence.PinIdentity));
 }
 static Dictionary<string,object> Clone(Dictionary<string,object> value){return (Dictionary<string,object>)Json.DeserializeObject(Json.Serialize(value));}
 static Dictionary<string,object> First(Dictionary<string,object> row){return MonitorEvidence.M(MonitorEvidence.M(row,"session"),"first");}
 static void Validate(Dictionary<string,object> row,bool negative,long handle){MonitorEvidence.Validate(row,negative,handle,Name,negative?MonitorEvidence.WrongName:Name,Owner,42,SystemDirectory);}
 internal static int Run(){
  int checks=0;Validate(Clone(Sample(false,100)),false,100);checks++;Validate(Clone(Sample(false,200)),false,200);checks++;Validate(Clone(Sample(true,100)),true,100);checks++;
  var faults=new Dictionary<string,Action<Dictionary<string,object>>>{
   {"old-two-parameter-no-session",r=>r.Remove("session")},
   {"normal-path-not-qualified",r=>MonitorEvidence.M(r,"session")["emptyCount"]=0},
   {"wrong-pid",r=>r["watchedPids"]=new object[]{99}},
   {"actual-call-did-not-return",r=>r["returned"]=false},
   {"enum-true",r=>MonitorEvidence.M(First(r),"enumeration")["returned"]=true},
   {"enum-error",r=>MonitorEvidence.M(First(r),"enumeration")["error"]=5},
   {"callback",r=>MonitorEvidence.M(First(r),"enumeration")["callbacks"]=1},
   {"identity-owner",r=>MonitorEvidence.M(First(r),"identityBefore")["owner"]="wrong"},
   {"readobjects-only",r=>MonitorEvidence.M(First(r),"identityBefore")["grantedAccess"]=1},
   {"post-handle-changed",r=>MonitorEvidence.M(First(r),"identityAfter")["handle"]=200},
   {"old-win32u-hash",r=>((Dictionary<string,object>)((object[])First(r)["imagePins"])[1])["sha256"]="old"},
   {"old-fixed-version",r=>((Dictionary<string,object>)((object[])First(r)["imagePins"])[1])["fixedFileVersion"]="10.0.26100.9818"},
   {"list-error",r=>MonitorEvidence.M(First(r),"list")["lastError"]=5},
   {"null-first",r=>MonitorEvidence.M(First(r),"list")["first"]=0},
   {"wrong-count",r=>MonitorEvidence.M(First(r),"list")["needed"]=2},
   {"tail-changed",r=>MonitorEvidence.M(First(r),"list")["tailIntact"]=false},
   {"foreground-owned",r=>First(r)["foregroundOwned"]=true}
  };
  foreach(var fault in faults){var row=Clone(Sample(false,100));fault.Value(row);bool refused=false;try{Validate(row,false,100);}catch(InvalidOperationException){refused=true;}if(!refused)throw new InvalidOperationException("Pure monitor evidence fault accepted: "+fault.Key);checks++;}
  foreach(string fault in new[]{"missing-failed-session","unexpected-list","unexpected-exception"}){var row=Clone(Sample(true,100));if(fault=="missing-failed-session")MonitorEvidence.M(row,"session")["failedCount"]=0;else if(fault=="unexpected-list")First(row)["list"]=D("status",0);else MonitorEvidence.M(row,"exception")["type"]="System.IO.IOException";bool refused=false;try{Validate(row,true,100);}catch(InvalidOperationException){refused=true;}if(!refused)throw new InvalidOperationException("Pure negative control accepted: "+fault);checks++;}
  Console.WriteLine(Json.Serialize(new{scope="new actual-monitor evidence validator only; synthetic observations",checks=checks,failed=0,nativeExecuted=false,productionMonitorCalled=false,desktopApisCalled=false}));return 0;
 }
}
