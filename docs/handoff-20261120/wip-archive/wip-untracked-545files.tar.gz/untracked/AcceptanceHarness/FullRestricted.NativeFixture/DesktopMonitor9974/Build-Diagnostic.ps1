#requires -Version 5.1
param()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Fresh system x64 PS5.1 required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$build=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-monitor-9974-build1'
$results=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-monitor-9974-results1'
$prep=Join-Path $repo 'artifacts\desktop-monitor9974-prep-20261114'
$prior=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-9974-build2'
$raw=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-9974-results2\ba7f3db124f547d79c02d62be6820a4c\result.json'
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Hash-Bytes([byte[]]$Bytes){$sha=[Security.Cryptography.SHA256]::Create();try{[BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}}
function Require([bool]$Value,[string]$Message){if(-not $Value){throw $Message}}
function Save-New([string]$Path,$Value){$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 30));$f=[IO.File]::Open($Path,'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}}
Require (-not(Test-Path -LiteralPath $build)) 'Unique monitor SOURCE build already exists; preserve it'
Require (-not(Test-Path -LiteralPath $results)) 'New monitor results must not exist before source preparation'
$full=Join-Path $repo 'tools\headless\RestrictedCliFullRestricted.cs';$shared=Join-Path $repo 'tools\headless\RestrictedCliNative.cs'
$baseFull='37d89b1942d74c4faae42365f6d5b302fe50b5d98135c6ad5bc36cbe98afe0c5';$baseShared='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921';$candidate='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533'
Require ((Hash $full) -ceq $baseFull -and (Hash $shared) -ceq $baseShared) 'Production Full/Shared pins changed'
Require ((Hash (Join-Path $prior 'manifest.json')) -ceq '47fc8dce82bef8233ce946d7a4d2528828f2f415d76a9a5ff243eeb3b0525a52') 'Raw diagnostic parent drift'
$old=Get-Content -LiteralPath (Join-Path $prior 'manifest.json') -Raw|ConvertFrom-Json
foreach($f in $old.files){$path=Join-Path $prior $f.path;Require ((Hash $path) -ceq $f.sha256 -and (Get-Item -LiteralPath $path).Length -eq $f.bytes) 'Frozen raw diagnostic member differs'}
Require ((Hash $raw) -ceq 'fcedb6a7f635489dba468a4212ff79bcc85545c0e489dc70251ed8af45950cbf') 'Measured9974 RAW evidence changed'
$actual=Get-Content -LiteralPath $raw -Raw|ConvertFrom-Json
Require ($actual.diagnosticCompleted -eq $true -and $actual.requalificationPatternMatched -eq $true -and $actual.completedMeasurements -eq 24 -and $actual.completedNativeListPairs -eq 12 -and $actual.retainedOwnedReferences -eq 0 -and @($actual.cleanupErrors).Count -eq 0) 'Required completed RAW qualification missing'
$overlay=Join-Path $prep 'overlay\RestrictedCliFullRestricted.cs';$overlayRecord=Join-Path $prep 'pin-overlay.json'
Require ((Hash $overlay) -ceq $candidate -and (Hash $overlayRecord) -ceq 'b40115b39b185023e99e4c1753bdbbb118ac74dd84744d29ab7c40a41d824575') 'Proposed pin overlay drift'
$delta=Get-Content -LiteralPath $overlayRecord -Raw|ConvertFrom-Json;Require ($delta.changes.Count -eq 3 -and $delta.normalization -ceq 'none; byte replacements only') 'Exactly three raw pin replacements required'
$reverse=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($overlay));for($i=$delta.changes.Count-1;$i -ge 0;$i--){$change=$delta.changes[$i];Require (([regex]::Matches($reverse,[regex]::Escape($change.new))).Count -eq 1) 'Overlay reverse target is not unique';$reverse=$reverse.Replace($change.new,$change.old)}
Require ((Hash-Bytes ([Text.Encoding]::UTF8.GetBytes($reverse))) -ceq $baseFull) 'Overlay reverse bytes differ from exact Full37d'
$helper=Join-Path $PSScriptRoot 'SourceProcess.psm1';Require ((Hash $helper) -ceq 'ce2a95b4674847d02625de2dac258427223fe753e15e1aa1c3dd118046349e9c') 'Established process helper differs'
Require ((Hash (Join-Path $PSScriptRoot 'Diagnostic.manifest')) -ceq 'cec569aa3a7447734c64467a6a91e314413a9bf4ae45bb00a7632f4eb4cd9fd0') 'Reviewed Windows10/asInvoker manifest differs'
Import-Module $helper -Force -DisableNameChecking
[void][IO.Directory]::CreateDirectory((Join-Path $build 'source'));[void][IO.Directory]::CreateDirectory((Join-Path $build 'baseline'))
$sourceRows=@(Get-ChildItem -LiteralPath $PSScriptRoot -File|ForEach-Object{[ordered]@{path=$_.Name;sha256=(Hash $_.FullName);bytes=$_.Length}}|Sort-Object path);Require ($sourceRows.Count -eq 7) 'Expected seven monitor-only source members'
$parse=@();foreach($row in $sourceRows){$path=Join-Path $PSScriptRoot $row.path;[IO.File]::Copy($path,(Join-Path $build ('source\'+$row.path)),$false);if($row.path -match '\.ps(m)?1$'){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);$parse+=@([ordered]@{path=$row.path;errors=@($errors|ForEach-Object{$_.ToString()})})}}
Save-New (Join-Path $build 'source-parse.json') $parse;Require (@($parse|Where-Object{@($_.errors).Count -ne 0}).Count -eq 0) 'PS5.1 parse failed'
[IO.File]::Copy($overlay,(Join-Path $build 'source\RestrictedCliFullRestricted.cs'),$false);[IO.File]::Copy($shared,(Join-Path $build 'source\RestrictedCliNative.cs'),$false);[IO.File]::Copy($full,(Join-Path $build 'baseline\RestrictedCliFullRestricted.cs'),$false)
foreach($name in @('pin-overlay.json','helper-reuse.json')){[IO.File]::Copy((Join-Path $prep $name),(Join-Path $build $name),$false)}
$csc='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe';Require ((Hash $csc) -ceq $old.cscSha256) 'Framework compiler differs'
$exe=Join-Path $build 'DesktopMonitor9974.exe'
$arguments=@('/nologo','/target:exe','/platform:x64','/warn:4','/warnaserror+','/r:System.Web.Extensions.dll',('/out:'+$exe),('/win32manifest:'+(Join-Path $build 'source\Diagnostic.manifest')))
$arguments+=@('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs','Diagnostic.cs','MonitorEvidence.cs','MonitorEvidence.Tests.cs'|ForEach-Object{Join-Path $build ('source\'+$_)})
$compile=Invoke-FixtureSourceProcess -File $csc -Arguments $arguments -Directory $build -Record (Join-Path $build 'managed-compile-process.json') -BoundMs 30000
Require ($compile.exitCode -eq 0 -and $compile.stderr -eq '' -and $compile.stdout -eq '') 'Managed compile must finish without warnings/errors'
$pure=Invoke-FixtureSourceProcess -File $exe -Arguments @('--selftest-monitor-evidence') -Directory $build -Record (Join-Path $build 'pure-monitor-evidence-process.json') -BoundMs 15000
$pureResult=$pure.stdout|ConvertFrom-Json
Require ($pure.exitCode -eq 0 -and $pure.stderr -eq '' -and $pureResult.checks -eq 23 -and $pureResult.failed -eq 0 -and $pureResult.nativeExecuted -eq $false -and $pureResult.productionMonitorCalled -eq $false -and $pureResult.desktopApisCalled -eq $false) 'New 23 pure evidence checks missing'
Save-New (Join-Path $build 'pure-monitor-evidence-result.json') $pureResult
$dry=& (Join-Path $PSScriptRoot 'Run-Diagnostic.ps1');Require ($dry.willExecute -eq $false -and $dry.maximumMonitorCalls -eq 3 -and $dry.productionMonitorOverloadParameters -eq 4 -and $dry.newDesktopCount -eq 1) 'Default readonly plan differs';Save-New (Join-Path $build 'launcher-dry-plan.json') $dry
foreach($row in $sourceRows){Require ((Hash (Join-Path $PSScriptRoot $row.path)) -ceq $row.sha256 -and (Hash (Join-Path $build ('source\'+$row.path))) -ceq $row.sha256) 'Source changed during compilation'}
Require ((Hash $full) -ceq $baseFull -and (Hash $shared) -ceq $baseShared -and (Hash $overlay) -ceq $candidate) 'Source/overlay preservation failed'
Require (-not(Test-Path -LiteralPath $results)) 'Pure preparation created native monitor results'
$files=@(Get-ChildItem -LiteralPath $build -File -Recurse|ForEach-Object{[ordered]@{path=$_.FullName.Substring($build.Length+1).Replace('\','/');sha256=(Hash $_.FullName);bytes=$_.Length}}|Sort-Object path)
$manifest=[ordered]@{schema=1;scope='proposed production pin overlay and actual four-parameter monitor harness; SOURCE only';sourceBuildOnly=$true;nativeExecuted=$false;productionMonitorExecuted=$false;productionPinAdopted=$false;productionQualificationGranted=$false;originalFullSha256=$baseFull;candidateFullSha256=$candidate;sharedSha256=$baseShared;pinOverlaySha256=(Hash $overlayRecord);pinChanges=3;reverseByteIdentical=$true;rawEvidenceSha256=(Hash $raw);priorRawPackageSha256=(Hash (Join-Path $prior 'manifest.json'));productionMonitorOverloadParameters=4;maximumMonitorCalls=3;newDesktopCount=1;nativeEnumerationShimUsed=$false;compiler=$csc;compilerSha256=(Hash $csc);runtimeCommandExecuted='--selftest-monitor-evidence only';pureChecks=23;oldGroupsRerun=$false;files=$files}
Save-New (Join-Path $build 'manifest.json') $manifest
foreach($f in $manifest.files){$path=Join-Path $build $f.path;Require ((Hash $path) -ceq $f.sha256 -and (Get-Item -LiteralPath $path).Length -eq $f.bytes) 'Producer member readback differs'}
foreach($f in $old.files){$path=Join-Path $prior $f.path;Require ((Hash $path) -ceq $f.sha256 -and (Get-Item -LiteralPath $path).Length -eq $f.bytes) 'Frozen raw diagnostic changed'}
$readback=[ordered]@{sourceBuildOnly=$true;nativeExecuted=$false;productionMonitorExecuted=$false;productionPinAdopted=$false;package=$build;manifestSha256=(Hash (Join-Path $build 'manifest.json'));membersVerified=$files.Count;sourceMembersVerified=$sourceRows.Count;priorRawMembersVerified=$old.files.Count;originalFullSha256=(Hash $full);candidateFullSha256=(Hash $overlay);sharedSha256=(Hash $shared);pureChecks=23;pureFailed=0;compilerPid=$compile.pid;compilerCreationFileTime=$compile.creationFileTime;purePid=$pure.pid;pureCreationFileTime=$pure.creationFileTime;allProcessesNaturallyExited=$true;resultsRootExists=$false}
Save-New (Join-Path $prep 'build1-producer-readback.json') $readback
[pscustomobject]$readback|ConvertTo-Json -Depth 10
