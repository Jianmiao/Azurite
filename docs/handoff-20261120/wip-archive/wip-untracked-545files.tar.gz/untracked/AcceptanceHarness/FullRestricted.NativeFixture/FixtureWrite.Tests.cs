using System;
using System.Collections.Generic;
using System.IO;
using Azurite.Restricted;
public static class FixtureWritePureTests {
 static readonly string Id=new string('a',32);
 static LifecycleFixture.ObserverSample Sample(){return new LifecycleFixture.ObserverSample{runId=Id,bootstrapPid=40,childPid=42,activeBefore=1,activeAfter=1,sampleBeforeQpc=9007199254740993L,monitorBeforeQpc=9007199254740994L,monitorAfterQpc=9007199254740995L,sampleAfterQpc=9007199254740996L,qpcFrequency=10000000,desktopHandle=1234,bootstrapWaitBefore=0,bootstrapWaitAfter=0,childWaitBefore=258,childWaitAfter=258,observerDesktopHeld=true,monitorCompleted=true,visibleOwnedWindow=false};}
 public static object Cases(){
  var sample=Sample();
  var monitor=new Dictionary<string,object>{{"first",new Dictionary<string,object>{{"imagePins",new object[]{new Dictionary<string,object>{{"name","user32.dll"},{"ok",true}},new Dictionary<string,object>{{"name","win32u.dll"},{"ok",true}}}}}},{"count",1},{"failures",new string[0]}};
  var permission=new Dictionary<string,object>{{"requestedAccess",0x20001U},{"inherit",false},{"identity",new{handle=1234L,name="AzuriteFullCli_"+Id,type="Desktop",owner="test-only",currentOwner="test-only",rightsQueryStatus=0,grantedAccess=0x20001U,inherited=false}}};
  var observation=new LifecycleFixture.Observation{Verified=true,ObservedDescendantAfterBootstrapExit=true,NoVisibleOwnedWindow=true,Error=null,BootstrapPid=40,ChildPid=42,RunId=Id,DesktopPermission=permission,FullDesktopMonitorEvidence=monitor,QualifyingMonitorEvidence=monitor,QualifyingSample=sample};
  observation.Samples.Add(sample);observation.Closes.Add(new{role="child-query",value=1234L,closed=true,error=0,qpc=9007199254740997L});
  return new Dictionary<string,object>{
   {"observation",observation},
   {"empty-observation",new LifecycleFixture.Observation{RunId=Id,Error="expected failure: \"quoted\" \\ slash\n\t\u4e2d\u6587 \u20ac \U0001f31f"}},
   {"pre-resume",new{fixtureOnly=true,productionTargetExecuted=false,runId=Id,bootstrapPid=40,bootstrapStartUtc="2026-11-12T14:40:01.1646645Z",childPid=42,jobHandle=10L,desktopHandle=11L,processHandle=12L,calls=new[]{"ReadOriginalAndDerive","PrepareStreams"},nativeEvidence=monitor,desktopLeaseAcknowledged=true}},
   {"observer-armed",new{fixtureOnly=true,runId=Id,exactJobVerified=true,bootstrapPid=40,childPid=42,observationOnly=true,desktopPermission=permission,fullDesktopMonitor=monitor}},
   {"resume",new{fixtureOnly=true,runId=Id,childPid=42,previousCount=1U,calls=new[]{"Resume"}}},
   {"self-exit",new{fixtureOnly=true,productionTargetExecuted=false,runId=Id,bootstrapPid=40,childPid=42,stdout="FIXTURE_STDOUT "+Id+" \u20ac\n",stderr="FIXTURE_STDERR "+Id+" \U0001f31f\n",nativeEvidence=monitor,calls=new[]{"Monitor"},selfExitCode=73,childEntryObserved=true}},
   {"self-exit-failure",new{fixtureOnly=true,runId=Id,error="Pure synthetic failure"}}
  };
 }
 public static Dictionary<string,object> Run(string host){
  string directory=Path.Combine(LifecycleFixture.Lab,"runs","restricted-"+Id,host);Directory.CreateDirectory(directory);
  var outcomes=new List<object>();var cases=(Dictionary<string,object>)Cases();int passed=0;
  foreach(var pair in cases){string path=Path.Combine(directory,pair.Key+".json");try{LifecycleFixture.Write(path,pair.Value);passed++;outcomes.Add(new Dictionary<string,object>{{"case",pair.Key},{"passed",true},{"path",path}});}catch(Exception e){outcomes.Add(new Dictionary<string,object>{{"case",pair.Key},{"passed",false},{"error",e.ToString()},{"fileExists",File.Exists(path)}});}}
  var negatives=new List<object>();int denied=0;
  var cycle=new Dictionary<string,object>();cycle.Add("cycle",cycle);
  object deep="leaf";for(int i=0;i<102;i++)deep=new object[]{deep};
  var numericKey=new System.Collections.Hashtable();numericKey.Add(1,"bad key");
  var invalid=new Dictionary<string,object>{{"cycle",cycle},{"depth",deep},{"unsupported",new Version(1,2)},{"non-string-key",numericKey},{"size",new string('x',1048577)}};
  foreach(var pair in invalid){string path=Path.Combine(directory,"deny-"+pair.Key+".json");bool rejected=false;string error=null;try{LifecycleFixture.Write(path,pair.Value);}catch(Exception e){rejected=true;error=e.Message;}bool ok=rejected&&!File.Exists(path);if(ok)denied++;negatives.Add(new Dictionary<string,object>{{"case",pair.Key},{"passed",ok},{"error",error},{"fileExists",File.Exists(path)}});}
  string outside=Path.Combine(LifecycleFixture.Lab,"outside-"+host+".json");bool outsideRejected=false;try{LifecycleFixture.Write(outside,"outside");}catch{outsideRejected=true;}bool outsideOk=outsideRejected&&!File.Exists(outside);if(outsideOk)denied++;negatives.Add(new Dictionary<string,object>{{"case","outside-path"},{"passed",outsideOk}});
  string existing=Path.Combine(directory,"observation.json");bool noOverwrite=false;if(File.Exists(existing)){string before=File.ReadAllText(existing);try{LifecycleFixture.Write(existing,"overwrite");}catch(IOException){noOverwrite=File.ReadAllText(existing)==before;}}if(noOverwrite)denied++;negatives.Add(new Dictionary<string,object>{{"case","no-overwrite"},{"passed",noOverwrite}});
  return new Dictionary<string,object>{{"scope","actual fixture Write with pure DTO and anonymous records"},{"passed",passed==cases.Count&&denied==7},{"caseCount",cases.Count},{"passedCount",passed},{"outcomes",outcomes},{"negativeCount",7},{"negativePassed",denied},{"negatives",negatives},{"nativeCallsExecuted",false},{"productionTargetExecuted",false}};
 }
}
