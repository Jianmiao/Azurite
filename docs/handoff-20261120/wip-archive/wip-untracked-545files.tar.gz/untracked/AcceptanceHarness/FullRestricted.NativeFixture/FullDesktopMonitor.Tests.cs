using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Azurite.Restricted;
internal static class FullDesktopMonitorTests {
 static int count;static readonly List<string> failures=new List<string>();
 static void Check(bool okay,string why){count++;if(!okay)failures.Add(why);}
 static void Refuse(Action operation,string why){bool failed=false;try{operation();}catch{failed=true;}Check(failed,why);}
 static readonly IntPtr Desktop=new IntPtr(1234);static readonly string Name="AzuriteFullCli_"+new string('a',32);
 static int Main(string[] args){
  try{
   var positive=new Fake();bool passed=false;try{passed=!FullDesktopMonitor.Run(positive,Desktop,new[]{7},Name);}catch(Exception e){failures.Add("verified measured empty observation rejected: "+e.Message);}
   Check(passed,"same production empty observation accepts only qualified fixture");
   Check(String.Join(",",positive.Order)=="enumerate,identity,pins,list,identity,foreground","empty branch exact order");
   var ordinary=new Fake();ordinary.E.Returned=true;ordinary.E.Callbacks=1;ordinary.E.Visible=true;Check(FullDesktopMonitor.Run(ordinary,Desktop,new[]{7},Name),"normal nonempty visible result");Check(ordinary.ListCalls==0&&ordinary.PinCalls==0&&ordinary.IdentityCalls==0,"ordinary successful enumeration avoids undocumented call");
   var foreground=new Fake();foreground.Foreground=true;Check(FullDesktopMonitor.Run(foreground,Desktop,new[]{7},Name),"foreground owned violation still detected after exact empty");
   foreach(string mutation in new[]{"enum-error","callback-count","callback-exception-false","callback-exception-true","visible-false-result","pin-failure","wrong-name","wrong-type","wrong-owner","no-rights","query-failure","inherited-handle","handle-drift","owner-drift","negative-status","overflow","zero-needed","terminator-zero","terminator-other","guard","tail","last-error","capacity","foreground-query"}){
    var fake=new Fake();fake.Mutation=mutation;
    switch(mutation){
     case "enum-error":fake.E.Error=6;break;case "callback-count":fake.E.Callbacks=1;break;
     case "callback-exception-false":fake.E.CallbackError=new Exception("owner query failed");break;
     case "callback-exception-true":fake.E.Returned=true;fake.E.CallbackError=new Exception("callback failed despite true");break;
     case "visible-false-result":fake.E.Visible=true;break;
     case "wrong-name":fake.Identity.Name="AzuriteFullCli_"+new string('b',32);break;
     case "wrong-type":fake.Identity.Type="WindowStation";break;case "wrong-owner":fake.Identity.Owner="other";break;
     case "no-rights":fake.Identity.GrantedAccess=0;break;case "query-failure":fake.Identity.RightsQueryStatus=-1;break;
     case "inherited-handle":fake.Identity.Inherited=true;break;case "negative-status":fake.List.Status=unchecked((int)0xc0000008);break;
     case "overflow":fake.List.Needed=65;break;case "zero-needed":fake.List.Needed=0;break;
     case "terminator-zero":fake.List.First=0;break;case "terminator-other":fake.List.First=2;break;
     case "guard":fake.List.GuardsIntact=false;break;case "tail":fake.List.TailIntact=false;break;
     case "last-error":fake.List.LastError=5;break;case "capacity":fake.List.Capacity=1;break;
    }
    Refuse(()=>FullDesktopMonitor.Run(fake,Desktop,new[]{7},Name),"reject "+mutation);
    if(mutation=="pin-failure"||mutation=="wrong-name"||mutation=="no-rights"||mutation=="query-failure"||mutation=="enum-error"||mutation.StartsWith("callback",StringComparison.Ordinal))Check(fake.ListCalls==0,"no undocumented call after "+mutation);
   }
   var invalid=new Fake();Refuse(()=>FullDesktopMonitor.Run(invalid,new IntPtr(-1),new[]{7},Name),"negative handle rejected before native API");Check(invalid.Order.Count==0,"no negative handle probe in production");
   var noName=new Fake();Refuse(()=>FullDesktopMonitor.Run(noName,Desktop,new[]{7},"Default"),"borrowed/default name cannot use empty exception");
   foreach(string fault in new[]{"path","hash","version","offset","reparse"}){
    Refuse(()=>FullDesktopImagePolicy.Validate("user32.dll",fault=="path"?@"C:\elsewhere\user32.dll":@"C:\Windows\System32\user32.dll",@"C:\Windows\System32\user32.dll",fault=="hash"?"wrong":"expected","expected",fault=="version"?"10.0.99999":"10.0.26100.9818","10.0.26100.9818",fault=="offset"?0:0x2a9a0,0x2a9a0,fault=="reparse"),"actual pin validator refuses "+fault);
   }
   FullDesktopImagePolicy.Validate("user32.dll",@"C:\Windows\System32\user32.dll",@"C:\Windows\System32\user32.dll","expected","expected","10.0.26100.9818","10.0.26100.9818",0x2a9a0,0x2a9a0,false);Check(true,"actual pin validator accepts exact path/hash/version/export");
   foreach(string raw in new[]{"10.0.26100.8117 (WinBuild.160101.0800)","10.0.26100.9949 (WinBuild.160101.0800)"}){
    var row=FullDesktopImagePolicy.Describe("user32.dll",@"C:\Windows\System32\user32.dll",@"C:\Windows\System32\user32.dll","expected","expected","10.0.26100.9818","10.0.26100.9818",0x2a9a0,0x2a9a0,false,raw,"product raw","observed language");
    bool accepted=false;try{FullDesktopImagePolicy.Validate(row);accepted=true;}catch{}
    Check((string)row["rawFileVersion"]==raw&&(string)row["fixedFileVersion"]=="10.0.26100.9818"&&(bool)row["fixedVersionMatch"],"actual raw localized and fixed values both retained");
    Check(accepted,"host localized version must not reject identical fixed9818 bytes: "+raw);
   }
   foreach(string wrong in new[]{"11.0.26100.9818","10.1.26100.9818","10.0.26101.9818","10.0.26100.9949","10.0.26100.8117","10.0.26100.9818 (WinBuild)",""}){
    var row=FullDesktopImagePolicy.Describe("user32.dll","path","path","hash","hash",wrong,"10.0.26100.9818",1,1,false,"10.0.26100.9949 (WinBuild.160101.0800)");
    bool failed=false;try{FullDesktopImagePolicy.Validate(row);}catch(Exception e){failed=e.Message.Contains("actual-versus-expected=")&&e.Message.Contains("fixedVersionMatch");}
    Check(failed&&!(bool)row["fixedVersionMatch"],"fixed numeric version exact and failure contains actual/expected: "+wrong);
   }
   var pinFail=new Fake{Mutation="pin-failure"};var pinSession=new FullDesktopMonitorSession();Refuse(()=>FullDesktopMonitor.Run(pinFail,Desktop,new[]{7},Name,pinSession),"pin failure retained without list");
   Check(((Dictionary<string,object>)pinSession.Snapshot()["last"]).ContainsKey("imagePins")&&pinFail.ListCalls==0,"failure serializes available image pin observations before refusal");
   var session=new FullDesktopMonitorSession();for(int i=0;i<1000;i++)FullDesktopMonitor.Run(new Fake(),Desktop,new[]{7},Name,session);
   var repeated=session.Snapshot();Check(Convert.ToInt64(repeated["emptyCount"])==1000&&Convert.ToInt32(repeated["boundedStoredObservations"])==2,"per-monitor evidence bounded after1000polls");
   Check(new JavaScriptSerializer().Serialize(repeated).Length<6000,"serialized monitor history remains bounded");
   var other=new FullDesktopMonitorSession();Check(Convert.ToInt64(other.Snapshot()["emptyCount"])==0&&other.Snapshot()["first"]==null,"new monitor/run cannot inherit counters");
   var failure=new Fake{Mutation="foreground-query"};Refuse(()=>FullDesktopMonitor.Run(failure,Desktop,new[]{7},Name,other),"foreground failure afterlist denied");
   var failureEvidence=other.Snapshot();Check(Convert.ToInt64(failureEvidence["emptyCount"])==0&&Convert.ToInt64(failureEvidence["failedCount"])==1&&((Dictionary<string,object>)failureEvidence["last"]).ContainsKey("list"),"fallback counted only afterforeground and failure keeps actual list evidence");
   var normalSession=new FullDesktopMonitorSession();var normalFake=new Fake();normalFake.E.Returned=true;FullDesktopMonitor.Run(normalFake,Desktop,new[]{7},Name,normalSession);
   Check(Convert.ToInt64(normalSession.Snapshot()["normalCount"])==1&&normalSession.Snapshot()["pinnedImageIdentity"]==null,"ordinary enumeration recorded without inventedpins");
   var parallel=new FullDesktopMonitorSession();Task.WaitAll(Task.Factory.StartNew(()=>{for(int i=0;i<100;i++)FullDesktopMonitor.Run(new Fake(),Desktop,new[]{7},Name,parallel);}),Task.Factory.StartNew(()=>{for(int i=0;i<100;i++)FullDesktopMonitor.Run(new Fake(),Desktop,new[]{7},Name,parallel);}));
   Check(Convert.ToInt64(parallel.Snapshot()["emptyCount"])==200&&Convert.ToInt32(parallel.Snapshot()["boundedStoredObservations"])==2,"per-monitor concurrent observations serialized withoutlostcounter");
   Check(args.Length==1,"actual retained runtime result argument required");
   if(args.Length==1)ReplayActualMeasurement(args[0]);
  }catch(Exception e){failures.Add(e.ToString());}
  Console.WriteLine("{\"scope\":\"actual full-only monitor coordinator with fake API; no native calls\",\"checks\":"+count+",\"passed\":"+(failures.Count==0?"true":"false")+",\"failureCount\":"+failures.Count+"}");
  foreach(string f in failures)Console.WriteLine("FAIL "+f);return failures.Count==0?0:1;
 }
 static void ReplayActualMeasurement(string path){
  byte[] bytes=File.ReadAllBytes(path);string hash;using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();
  Check(hash=="96447880b1e0aaffc51b5793e64c83179a762229937ded14b47cfbcca3b35631","exact frozen actual native-list measurement bytes");
  var root=new JavaScriptSerializer{MaxJsonLength=1048576}.Deserialize<Dictionary<string,object>>(Encoding.UTF8.GetString(bytes));
  var rows=(System.Collections.IList)root["nativeListPairs"];int positives=0,negatives=0,oneCapacityRefusals=0;
  foreach(Dictionary<string,object> row in rows){
   var raw=(Dictionary<string,object>)row["raw"];var slots=(System.Collections.IList)raw["Slots"];string route=(string)row["route"];
   var fake=new Fake();fake.List.Status=unchecked((int)Convert.ToUInt32(raw["StatusBits"]));fake.List.LastError=0; // Native API preserved the seed; production clears it before its call.
   fake.List.Capacity=Convert.ToUInt32(raw["Capacity"]);fake.List.Needed=Convert.ToUInt32(raw["Needed"]);fake.List.First=Convert.ToInt64(slots[0]);fake.List.GuardsIntact=Convert.ToInt32(raw["GuardBeforeOkay"])==1&&Convert.ToInt32(raw["GuardAfterOkay"])==1;fake.List.TailIntact=Convert.ToInt32(raw["TailUnchanged"])==1;
   var en=(Dictionary<string,object>)raw["Enumeration"];
   Check(Convert.ToUInt32(raw["ListError"])==(route=="invalid-minus-one-query-negative"?6u:Convert.ToUInt32(raw["Seed"])),"actual list error seed preservation established before cleared-error replay");
   fake.E.Returned=(bool)en["ReturnedValue"];fake.E.Callbacks=Convert.ToInt32(en["CallbackCount"]);
   Check(Convert.ToUInt32(en["ReturnedError"])==(route=="invalid-minus-one-query-negative"?6u:Convert.ToUInt32(en["InputError"])),"actual paired error semantics preserved");
   if(route=="invalid-minus-one-query-negative"){fake.E.Error=6;Refuse(()=>FullDesktopMonitor.Run(fake,Desktop,new[]{7},Name),"actual invalid handle row denied");Check(fake.ListCalls==0,"actual invalid error never reaches fallback");negatives++;}
   else{
    Check(fake.List.Status==0&&fake.List.Needed==1&&fake.List.First==1&&fake.List.GuardsIntact&&fake.List.TailIntact,"actual valid measurement is one terminator value1, not null");
    if(fake.List.Capacity==1){Refuse(()=>FullDesktopMonitor.Run(fake,Desktop,new[]{7},Name),"actual cap1 is diagnostic evidence not production buffer");oneCapacityRefusals++;}
    else{Check(!FullDesktopMonitor.Run(fake,Desktop,new[]{7},Name),"actual cap64 retained record satisfies production empty observation");positives++;}
   }
  }
  Check(positives==3&&oneCapacityRefusals==3&&negatives==2,"all six valid and two invalid recorded rows checked");
 }
 sealed class Fake:IFullDesktopMonitorApi {
  internal readonly List<string> Order=new List<string>();internal int ListCalls,PinCalls,IdentityCalls;internal bool Foreground;internal string Mutation;
  internal FullDesktopEnumeration E=new FullDesktopEnumeration{Returned=false,Error=0,Callbacks=0};
  internal FullDesktopIdentity Identity=new FullDesktopIdentity{Handle=1234,Name=Name,Type="Desktop",Owner="user",CurrentOwner="user",GrantedAccess=0xf01ff,RightsQueryStatus=0,Inherited=false};
  internal FullDesktopEmptyList List=new FullDesktopEmptyList{Status=0,LastError=0,Capacity=64,Needed=1,First=1,GuardsIntact=true,TailIntact=true};
  public FullDesktopEnumeration Enumerate(IntPtr h,int[] ids){Order.Add("enumerate");return E;}
  public FullDesktopIdentity ReadIdentity(IntPtr h){Order.Add("identity");IdentityCalls++;if(IdentityCalls==2){if(Mutation=="handle-drift")Identity.Handle=888;if(Mutation=="owner-drift")Identity.Owner="other";}return Identity;}
  public string RequirePinnedImages(){Order.Add("pins");PinCalls++;if(Mutation=="pin-failure")throw new Exception("unknown system image");return "fake-reviewed-system-images";}
  public string ImagePinEvidenceJson(){return "[]";}
  public object[] ImagePinEvidence(){return new object[0];}
  public FullDesktopEmptyList ReadEmptyList(IntPtr h){Order.Add("list");ListCalls++;return List;}
  public bool ForegroundOwned(int[] ids){Order.Add("foreground");if(Mutation=="foreground-query")throw new Exception("foreground query failed");return Foreground;}
 }
}
