param([Parameter(Mandatory)][string]$AssemblyPath,[Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(Test-Path -LiteralPath $OutputPath){throw 'Preserve previous writer test result'}
$assembly=[Reflection.Assembly]::LoadFrom($AssemblyPath)
$type=$assembly.GetType('FixtureWritePureTests',$true)
$result=$type.GetMethod('Run').Invoke($null,[object[]]@('ps'+$PSVersionTable.PSVersion.Major))
$result['host']=$PSVersionTable.PSVersion.ToString()
$result['framework']=[Runtime.InteropServices.RuntimeInformation]::FrameworkDescription
$result['assemblySha256']=(Get-FileHash -LiteralPath $AssemblyPath -Algorithm SHA256).Hash.ToLowerInvariant()
$result['directHostInvocation']=$true;$result['frameworkChildSubstitution']=$false
$parsedChecks=0
foreach($case in $result['outcomes']){
 if(-not $case['passed']){continue}
 $bytes=[IO.File]::ReadAllBytes($case['path']);if($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191){throw 'Unexpected UTF8 BOM'}
 $text=[Text.UTF8Encoding]::new($false,$true).GetString($bytes)
 $options=@{InputObject=$text;ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$options.DateKind='String'}
 $value=ConvertFrom-Json @options
 if($case['case'] -ceq 'observation'){
  if($value.QualifyingSample.sampleBeforeQpc -ne 9007199254740993 -or $value.Samples.Count -ne 1 -or $value.Closes.Count -ne 1 -or $value.FullDesktopMonitorEvidence.first.imagePins.Count -ne 2 -or $value.DesktopPermission.identity.inherited -isnot [bool] -or $null -ne $value.Error){throw 'DTO graph lost number, array, Boolean or null identity'}
 }
 if($case['case'] -ceq 'empty-observation'){
  if($value.Samples -isnot [array] -or $value.Samples.Count -ne 0 -or $value.Closes -isnot [array] -or $value.Closes.Count -ne 0 -or $null -ne $value.QualifyingSample -or $value.Error -notmatch 'expected failure'){throw 'Empty DTO graph lost empty-array/null/error shape'}
 }
 if($case['case'] -ceq 'pre-resume'){
  if(@($value.PSObject.Properties).Count -ne 12 -or $value.calls -isnot [array] -or $value.calls.Count -ne 2 -or $value.bootstrapStartUtc -cne '2026-11-12T14:40:01.1646645Z'){throw 'Anonymous pre-resume schema changed'}
 }
 $parsedChecks++
}
$result['independentParsedCases']=$parsedChecks
[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 25),[Text.UTF8Encoding]::new($false))
$result|ConvertTo-Json -Depth 10
if(-not $result['passed']){throw 'Actual fixture Write failed'}
