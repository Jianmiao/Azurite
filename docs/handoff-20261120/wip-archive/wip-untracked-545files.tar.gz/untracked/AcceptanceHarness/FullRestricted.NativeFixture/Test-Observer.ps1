param([Parameter(Mandatory)][string]$OutputDirectory)
Set-StrictMode -Version Latest;$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
$count=0
function Check($b,[string]$why){$script:count++;if(-not $b){throw ('Observer draft pure failed: '+$why)}}
function Clone($x){$p=@{InputObject=($x|ConvertTo-Json -Depth 40);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$p.DateKind='String'};ConvertFrom-Json @p}
function Refuse([scriptblock]$call,[string]$why){Assert-FixtureObservation (Clone $observer) $outer $entry;$caught=$false;try{& $call}catch{$caught=$true};Check $caught $why}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$monitor=Read-FixtureJson (Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\build-monitor2-fix1\serialization-ps51-monitor.json')
# Existing pure fake-native sample only. No actual successful normal receipt is generated.
$id='a'*32
foreach($s in @($monitor.first,$monitor.last)){foreach($i in @($s.identityBefore,$s.identityAfter)){$i.grantedAccess=0x20001}}
$identity=Clone $monitor.first.identityBefore
$sample=[ordered]@{runId=$id;bootstrapPid=40;childPid=42;activeBefore=1;activeAfter=1;sampleBeforeQpc=1;monitorBeforeQpc=2;monitorAfterQpc=3;sampleAfterQpc=4;qpcFrequency=100;desktopHandle=1234;bootstrapWaitBefore=0;bootstrapWaitAfter=0;childWaitBefore=258;childWaitAfter=258;observerDesktopHeld=$true;monitorCompleted=$true;visibleOwnedWindow=$false}
$observer=[ordered]@{RunId=$id;Verified=$true;ObservedDescendantAfterBootstrapExit=$true;NoVisibleOwnedWindow=$true;BootstrapPid=40;ChildPid=42;Error=$null;DesktopPermission=[ordered]@{requestedAccess=0x20001;inherit=$false;options=0;sourceHandle=5678;returnedHandle=1234;duplicateSucceeded=$true;duplicateError=0;identity=$identity};FullDesktopMonitorEvidence=$monitor;QualifyingMonitorEvidence=$monitor;QualifyingSample=$sample;Samples=@($sample);Closes=@(@('private-desktop-query',1234),@('child-query',45),@('job-query',46),@('bootstrap-query',47))|ForEach-Object {[ordered]@{role=$_[0];value=$_[1];closed=$true;error=0;qpc=5}}}
$observer=Clone $observer;$outer=[pscustomobject]@{Pid=40};$entry=[pscustomobject]@{pid=42;runId=$id}
Assert-FixtureObservation $observer $outer $entry;Check $true 'complete pure observer data'
foreach($rights in @(1,0x20000,0x20003,0xf01ff)){$b=Clone $observer;$b.DesktopPermission.identity.grantedAccess=$rights;Refuse {Assert-FixtureObservation $b $outer $entry} ('exact rights '+$rights)}
foreach($field in @('requestedAccess','duplicateError','returnedHandle','sourceHandle')){$b=Clone $observer;$b.DesktopPermission.$field=if($field -eq 'duplicateError'){5}else{0};Refuse {Assert-FixtureObservation $b $outer $entry} ('permission '+$field)}
$b=Clone $observer;$b.DesktopPermission.identity.rightsQueryStatus=-1;Refuse {Assert-FixtureObservation $b $outer $entry} 'failed owner/query evidence'
$b=Clone $observer;$b.DesktopPermission.identity.owner='wrong';Refuse {Assert-FixtureObservation $b $outer $entry} 'wrong owner'
foreach($field in @('FullDesktopMonitorEvidence','QualifyingMonitorEvidence','QualifyingSample')){$b=Clone $observer;$b.$field=$null;Refuse {Assert-FixtureObservation $b $outer $entry} ('missing full session '+$field)}
$b=Clone $observer;$b.FullDesktopMonitorEvidence.failedCount=1;Refuse {Assert-FixtureObservation $b $outer $entry} 'failed monitor'
$b=Clone $observer;$b.QualifyingMonitorEvidence.last.identityAfter.grantedAccess=1;Refuse {Assert-FixtureObservation $b $outer $entry} 'qualifying monitor missing readcontrol'
foreach($field in @('bootstrapWaitBefore','bootstrapWaitAfter','childWaitBefore','childWaitAfter','activeBefore','activeAfter','bootstrapPid','childPid','desktopHandle')){$b=Clone $observer;$b.QualifyingSample.$field=if($field -like 'bootstrapWait*'){258}else{0};Refuse {Assert-FixtureObservation $b $outer $entry} ('sample '+$field)}
foreach($field in @('observerDesktopHeld','monitorCompleted')){$b=Clone $observer;$b.QualifyingSample.$field=$false;Refuse {Assert-FixtureObservation $b $outer $entry} ('sample '+$field)}
$b=Clone $observer;$b.QualifyingSample.runId='wrong';Refuse {Assert-FixtureObservation $b $outer $entry} 'sample wrong run'
$b=Clone $observer;$b.QualifyingSample.visibleOwnedWindow=$true;Refuse {Assert-FixtureObservation $b $outer $entry} 'sample visible violation'
$b=Clone $observer;$b.QualifyingSample.monitorAfterQpc=6;Refuse {Assert-FixtureObservation $b $outer $entry} 'monitor time after sample'
$b=Clone $observer;$b.Closes[0].closed=$false;Refuse {Assert-FixtureObservation $b $outer $entry} 'failed desktop close'
$b=Clone $observer;$b.Closes[0].qpc=3;Refuse {Assert-FixtureObservation $b $outer $entry} 'desktop closed before qualifying monitor finished'
$b=Clone $observer;$b.Closes[1].role='private-desktop-query';Refuse {Assert-FixtureObservation $b $outer $entry} 'duplicate close role'
$b=Clone $observer;$b.ObservedDescendantAfterBootstrapExit=$false;Refuse {Assert-FixtureObservation $b $outer $entry} 'missing real interval'
$b=Clone $observer;$b.RunId='wrong';Refuse {Assert-FixtureObservation $b $outer $entry} 'wrong observer run'
$lineage=[pscustomobject]@{'RestrictedCliNative.cs'='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921';'RestrictedCliFullRestricted.cs'='3316bec4aafd2cafe16f3e156c492722ea1bfc72263dd5da2508864dc3039f86'}
Refuse {Assert-FixtureNormalReceipt $null ('b'*64) $lineage} 'no normal receipt cannot execute'
$failed=Read-FixtureJson (Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\evidence\022de7b6af1f4f35be3860d906306a36\result.json')
Refuse {Assert-FixtureNormalReceipt $failed $failed.packageSha256 $lineage} 'actual failed022 never satisfies normal receipt'
foreach($file in @('Run-Fixture.ps1','FixtureBootstrap.ps1','FixtureRules.psm1')){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot $file),[ref]$tokens,[ref]$errors);Check ($errors.Count -eq 0) ('AST '+$file)}
$record=[ordered]@{scope='integrated observer pure predicates and source AST; synthetic observer data only';checks=$count;passed=$true;normalPassReceiptCreated=$false;nativeCallsExecuted=$false;host=$PSVersionTable.PSVersion.ToString()}
Write-FixtureJson (Join-Path $OutputDirectory ('rules-pure-'+$PSVersionTable.PSVersion.Major+'.json')) $record
$record|ConvertTo-Json -Compress
