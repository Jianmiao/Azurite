param([Parameter(Mandatory)][string]$BuildDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$path=Join-Path $BuildDirectory 'FixturePreResume.Pure.dll'
$assembly=[Reflection.Assembly]::LoadFrom($path);$type=$assembly.GetType('Azurite.Restricted.FixturePreResumeRecordTests',$true)
$value=$type.GetMethod('Run').Invoke($null,[object[]]@())
if(-not $value['passed']){throw 'Pre-resume managed reader tests failed'}
$sample=Join-Path $BuildDirectory 'actual-pre-resume-schema.json'
if((Get-FileHash $sample).Hash.ToLowerInvariant() -cne '168e4dbdec02e686b4772114fb210f0388cb13af999012e17029999e9c14168d'){throw 'Historical schema sample drift'}
$reader=$assembly.GetType('Azurite.Restricted.FixturePreResumeRecord',$true).GetMethod('Read',[Reflection.BindingFlags]'NonPublic,Static')
$actual=$reader.Invoke($null,[object[]]@($sample.ToString()))
if($actual.Count -ne 8 -or $actual['runId'] -cne '1d42099bab8d482b9ee16c7650ca2bab' -or $actual['bootstrapStartUtc'] -cne '2026-11-12T14:40:01.1646645Z' -or -not $actual['desktopLeaseAcknowledged']){throw 'Historical actual schema projection differs'}
$result=[ordered]@{scope='direct-host bounded pre-resume record reader only';passed=$true;checks=$value['checks'];details=$value;historicalSchemaSampleOnly=$true;historicalEightFieldProjection=$actual;newLifecycleEvidenceProduced=$false;host=$PSVersionTable.PSVersion.ToString();framework=[Runtime.InteropServices.RuntimeInformation]::FrameworkDescription;assemblySha256=(Get-FileHash $path).Hash.ToLowerInvariant();nativeCalled=$false;fixtureExecuted=$false;frameworkChildSubstitution=$false}
$out=Join-Path $BuildDirectory ('pre-resume-reader-'+$PSVersionTable.PSVersion.Major+'.json')
if(Test-Path -LiteralPath $out){throw 'Result already exists'}
[IO.File]::WriteAllText($out,($result|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false));[pscustomobject]$result|ConvertTo-Json -Depth 6
