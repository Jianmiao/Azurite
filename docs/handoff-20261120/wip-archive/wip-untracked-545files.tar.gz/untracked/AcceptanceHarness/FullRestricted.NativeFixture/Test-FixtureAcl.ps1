param([Parameter(Mandatory)][string]$SourceDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $SourceDirectory 'FixtureAcl.psm1') -Force -DisableNameChecking
$count=0
function Check($Okay,[string]$Message){$script:count++;if(-not $Okay){throw "ACL pure control: $Message"}}
function Refuse([scriptblock]$Action,[string]$Message){$failed=$false;try{& $Action|Out-Null}catch{$failed=$true};Check $failed $Message}
$sid='S-1-5-21-222280291-4039000738-1914192245-1001';$logon='S-1-5-5-111-222'
$path='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\lab-cleanup9974-qual1'
$beforeSddl='O:'+ $sid+'G:'+$sid+'D:AI(A;OICIID;0x1200a9;;;S-1-5-21-222280291-4039000738-1914192245-1005)(A;OICIID;FA;;;SY)(A;OICIID;FA;;;BA)(A;OICIID;FA;;;'+$sid+')'
$template='O:'+ $sid+'D:P(A;OICI;FA;;;'+$sid+')(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;;0x1200a9;;;'+$logon+')'
$expected=New-FixtureExpectedDescriptor $template $beforeSddl
$reportedShape='O:'+ $sid+'G:'+$sid+'D:PAI(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;;0x1200a9;;;'+$logon+')(A;OICI;FA;;;'+$sid+')'
$reported=[Security.AccessControl.RawSecurityDescriptor]::new($reportedShape).GetSddlForm([Security.AccessControl.AccessControlSections]'Owner,Group,Access')
Check ($reported -cne $expected) 'old Set-Acl versus raw target exact-text failure reproduced'
$sd=[Security.AccessControl.RawSecurityDescriptor]::new($expected)
Check (([int]$sd.ControlFlags -band 0x1000) -ne 0 -and ([int]$sd.ControlFlags -band 0x400) -eq 0) 'expected P and non-AI fixed independently of live result'
Check ($sd.Owner.Value -ceq $sid -and $sd.Group.Value -ceq $sid -and $sd.DiscretionaryAcl.Count -eq 4) 'owner/group preserved and exactly4approvedACEs'
Check ($sd.DiscretionaryAcl[0].SecurityIdentifier.Value -ceq $sid -and $sd.DiscretionaryAcl[3].SecurityIdentifier.Value -ceq $logon -and $sd.DiscretionaryAcl[3].AccessMask -eq 0x1200a9 -and [int]$sd.DiscretionaryAcl[3].AceFlags -eq 0) 'declared order and Logon mask retained without broadening'
Refuse {New-FixtureExpectedDescriptor ($template.Replace($sid,'S-1-5-21-1-2-3-1001')) $beforeSddl} 'wrongowner is not adopted'
Refuse {New-FixtureExpectedDescriptor ($template.Replace('D:P','G:SYD:P')) $beforeSddl} 'group cannot be changed'
Refuse {New-FixtureExpectedDescriptor ($template.Replace('D:P','D:PAI')) $beforeSddl} 'AI template cannot be silently permitted'
$baseline=[pscustomobject]@{path=$path;identity=('a'*32);owner=$sid;directory=$true;volume='fixture-volume';reparse=$false;sddl=$beforeSddl;rawDescriptor='fixture-before-bytes'}
foreach($mode in @('success','persist-failed','setter-failed','wrong-identity','reordered','auto-inherited')){
 $state=@{before=$baseline;mode=$mode;calls=[Collections.Generic.List[string]]::new();sets=0;expected=$null}
 $backend={param($action,$a)
  $state.calls.Add($action)
  switch($action){
   Observe {if($state.sets -eq 0){return $state.before};$after=$state.before|ConvertTo-Json|ConvertFrom-Json;$after.sddl=$state.expected;if($state.mode -ceq 'wrong-identity'){$after.identity='b'*32};if($state.mode -ceq 'reordered'){$after.sddl=$reported};if($state.mode -ceq 'auto-inherited'){$after.sddl=$after.sddl.Replace('D:P','D:PAI')};return $after}
   PreserveBefore {if($state.mode -ceq 'persist-failed'){throw 'durable before evidence failed'};if($a.before.sddl -cne $beforeSddl -or $a.expectedSddl -cne $expected){throw 'Preservation arguments differ'}}
   SetDescriptor {$state.sets++;if($a.identity -cne $baseline.identity -or $a.beforeSddl -cne $beforeSddl -or $a.expectedSddl -cne $expected){throw 'Same-handle setter arguments differ'};if($state.mode -ceq 'setter-failed'){throw 'native setter refused drift'};$state.expected=$a.expectedSddl}
  }
 }.GetNewClosure()
 if($mode -ceq 'success'){$after=Invoke-FixtureDescriptorChange $path $template $true $backend;Check ($after.sddl -ceq $expected -and ($state.calls -join ',') -ceq 'Observe,PreserveBefore,SetDescriptor,Observe') 'production change order and strictreadback'}
 else{Refuse {Invoke-FixtureDescriptorChange $path $template $true $backend} ('refuse '+$mode);if($mode -ceq 'persist-failed'){Check ($state.sets -eq 0) 'no mutation if preservation failed'}else{Check ($state.sets -eq 1) 'no retry on setter/readback failure'}}
}
$script:outsideCalls=0
Refuse {Invoke-FixtureDescriptorChange $path $template $false {param($action,$a)$script:outsideCalls++}} 'old failed lab cannot be adopted as newlycreated'
Refuse {Invoke-FixtureDescriptorChange 'C:\Windows' $template $true {param($action,$a)$script:outsideCalls++}} 'ancestor mutation forbidden'
Check ($script:outsideCalls -eq 0) 'scope failures precede backend calls'
$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile((Join-Path $SourceDirectory 'FixtureAcl.psm1'),[ref]$tokens,[ref]$errors);Check ($errors.Count -eq 0) 'ACL module syntax'
[pscustomobject]@{scope='same production fixture ACL coordinator with fake backend only';oldFailureReproduced=$true;reportedDescriptorShape=$reported;expectedDescriptor=$expected;liveDescriptorAdopted=$false;nativeCallsExecuted=$false;permissionChanges=$false;passed=$true;checks=$count;host=$PSVersionTable.PSVersion.ToString()}|ConvertTo-Json -Compress
