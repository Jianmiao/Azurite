#requires -Version 7.0
[CmdletBinding()]
param()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$base=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture';$build=Join-Path $base 'build-cleanup9974-qual1'
if(Test-Path -LiteralPath $build){throw 'Build output already exists; preserve it and use a reviewed new build revision.'}
[void][IO.Directory]::CreateDirectory((Join-Path $build 'generated'));[void][IO.Directory]::CreateDirectory((Join-Path $build 'source'))
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save([string]$Path,[string]$Text){[IO.File]::WriteAllText($Path,($Text.Replace(([string][char]13+[char]10),[string][char]10).TrimEnd()+[char]10),[Text.UTF8Encoding]::new($false))}
$pins=@{ 'RestrictedCliNative.cs'='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921';'RestrictedCliFullRestricted.cs'='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533' }
foreach($name in $pins.Keys){if((Hash (Join-Path $repo ('tools\headless\'+$name))) -cne $pins[$name]){throw 'Accepted native source pin differs'}}
$controllerDependencies=[ordered]@{'CurrentAccountCli.psm1'='495efe99ea5f32330d7a1b25148d9cd637a508a83fac93b5037a0db1dcb45ea9'}
foreach($name in $controllerDependencies.Keys){$path=Join-Path $repo ('tools\headless\'+$name);if((Hash $path) -cne $controllerDependencies[$name]){throw 'Accepted controller dependency drift'};[IO.File]::Copy($path,(Join-Path $build ('source\'+$name)))}
$lab=Join-Path $base 'lab-cleanup9974-qual1';$full=[IO.File]::ReadAllText((Join-Path $repo 'tools\headless\RestrictedCliFullRestricted.cs'))
$oldLab='Lab=@"F:\AzuriteLabs\Editor-20261108-normal"';$newLab='Lab=@"'+$lab+'"';$oldExe='Executable=Lab+@"\install\AzureArchive.exe"';$newExe='Executable=Lab+@"\install\AzuriteLifecycleProbe.exe"'
foreach($needle in @($oldLab,$oldExe)){if(([regex]::Matches($full,[regex]::Escape($needle))).Count -ne 1){throw 'Fixture transform replacement count differs'}}
$generated=$full.Replace($oldLab,$newLab).Replace($oldExe,$newExe)
if($generated.Replace($newLab,$oldLab).Replace($newExe,$oldExe) -cne $full){throw 'Transformation altered more than the two constants'}
$roslyn='Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree' -as [type]
if(-not $roslyn){Add-Type -Path (Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll');Add-Type -Path (Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll')}
$oldTree=[Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($full);$newTree=[Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($generated)
foreach($tree in @($oldTree,$newTree)){if(@($tree.GetDiagnostics()|Where-Object Severity -EQ Error).Count){throw 'CSharp syntax error in equivalence inputs'}}
$oldTokens=@($oldTree.GetRoot().DescendantTokens());$newTokens=@($newTree.GetRoot().DescendantTokens());if($oldTokens.Count -ne $newTokens.Count){throw 'Token count changed'}
$changed=[Collections.Generic.List[object]]::new();for($i=0;$i -lt $oldTokens.Count;$i++){if($oldTokens[$i].RawKind -ne $newTokens[$i].RawKind){throw 'Token kind changed'};if($oldTokens[$i].Text -cne $newTokens[$i].Text){$changed.Add([ordered]@{index=$i;kind=$oldTokens[$i].RawKind;oldText=$oldTokens[$i].Text;newText=$newTokens[$i].Text})}}
if($changed.Count -ne 2){throw 'Exactly two constant string tokens must change'}
$oldBodies=@($oldTree.GetRoot().DescendantNodes()|Where-Object{$_ -is [Microsoft.CodeAnalysis.CSharp.Syntax.BaseMethodDeclarationSyntax] -or $_ -is [Microsoft.CodeAnalysis.CSharp.Syntax.AccessorDeclarationSyntax]}|ForEach-Object{$_.ToFullString()})
$newBodies=@($newTree.GetRoot().DescendantNodes()|Where-Object{$_ -is [Microsoft.CodeAnalysis.CSharp.Syntax.BaseMethodDeclarationSyntax] -or $_ -is [Microsoft.CodeAnalysis.CSharp.Syntax.AccessorDeclarationSyntax]}|ForEach-Object{$_.ToFullString()})
if(($oldBodies -join [char]0) -cne ($newBodies -join [char]0)){throw 'Accepted method/constructor/accessor text changed'}
Save (Join-Path $build 'generated\RestrictedCliFullRestricted.cs') $generated
[IO.File]::Copy((Join-Path $repo 'tools\headless\RestrictedCliNative.cs'),(Join-Path $build 'generated\RestrictedCliNative.cs'))
Save (Join-Path $build 'generated\FixtureTarget.h') ('#define FIXTURE_LAB L"'+$lab.Replace('\','\\')+'"')
$sourceNames=@('Build-Fixture.ps1','Run-Fixture.ps1','FixtureBootstrap.ps1','FixtureRules.psm1','FixtureAcl.psm1','Test-FixtureAcl.ps1','FixtureSupport.cs','FixtureWrite.Tests.cs','Test-FixtureWrite.ps1','FixturePreResumeRecord.cs','FixturePreResumeRecord.Tests.cs','Test-PreResumeReader.ps1','FixtureSerialization.PureBridge.cs','LifecycleProbe.c','FixturePolicy.h','FixturePolicy.Tests.c','Test-Fixture.ps1','Test-Observer.ps1','Test-NormalReceipt.ps1','Test-CleanupOrdering.ps1','Observer.Pure.cs')
foreach($name in $sourceNames){[IO.File]::Copy((Join-Path $PSScriptRoot $name),(Join-Path $build ('source\'+$name)))}
$sample=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\desktop-enum-diagnostic-results\f495b2cbc85d4f6d93a69fc169489809\result.json'
if((Hash $sample) -cne '96447880b1e0aaffc51b5793e64c83179a762229937ded14b47cfbcca3b35631'){throw 'Accepted actual native-list sample changed'}
Copy-Item -LiteralPath $sample -Destination (Join-Path $build 'actual-list-result.json')
$imageSample=Join-Path $repo '.superpowers\sdd\azurite-authoring-20261108\freeze2-image-only-072f29a3e2264e198bac6c8ade8b2e26.json'
if((Hash $imageSample) -cne '788e7ee66ce9a669b50f485d35361c19491af16148c57b4154b68a84abf098c0'){throw 'Root actual image-only sample changed'}
Copy-Item -LiteralPath $imageSample -Destination (Join-Path $build 'actual-image-pin-result.json')
$preResumeSample=Join-Path $base 'lab\runs\restricted-1d42099bab8d482b9ee16c7650ca2bab\output\pre-resume.json'
if((Hash $preResumeSample) -cne '168e4dbdec02e686b4772114fb210f0388cb13af999012e17029999e9c14168d'){throw 'Retained actual pre-resume schema sample changed'}
Copy-Item -LiteralPath $preResumeSample -Destination (Join-Path $build 'actual-pre-resume-schema.json')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'FullDesktopMonitor.Tests.cs') -Destination (Join-Path $build 'source\FullDesktopMonitor.Tests.cs')
$helperBase=Join-Path $repo 'artifacts\aa-fr-transition-preparation\integration-20261110-01\helper-build1'
$helperDll=Join-Path $helperBase 'FullRestrictedStageFileSecurity.dll'
if((Hash $helperDll) -cne 'eef4c21387daef216ef7bcc7870b331e123d69e7be852498adcd07f253ef4c8f'){throw 'Qualified controller file/security helper pin differs'}
[IO.File]::Copy($helperDll,(Join-Path $build 'FullRestrictedStageFileSecurity.dll'))
[IO.File]::Copy((Join-Path $helperBase 'FullRestrictedStageFileSecurity.cs'),(Join-Path $build 'source\FullRestrictedStageFileSecurity.cs'))
[IO.File]::Copy((Join-Path $helperBase 'build.json'),(Join-Path $build 'file-security-helper-build.json'))
$proof=[ordered]@{schema=1;fixtureOnly=$true;productionTargetExecuted=$false;lab=$lab;maxPathLength=($lab+'\runs\restricted-'+('a'*32)+'\tooling\RestrictedCliBootstrap.ps1').Length;productionSources=$pins;transformReversible=$true;tokens=$oldTokens.Count;changedTokens=$changed.ToArray();methodConstructorAccessorCount=$oldBodies.Count;allMethodBodiesTextIdentical=$true;sharedNativeSourceByteIdentical=$true;observerGlueSeparate=$true;roslyn=[Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree].Assembly.FullName}
Save (Join-Path $build 'equivalence.json') ($proof|ConvertTo-Json -Depth 10)
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe';$framework=Split-Path -Parent $csc
& $csc /nologo /target:library /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll ('/out:'+(Join-Path $build 'AzuriteLifecycle.FixtureOnly.dll')) (Join-Path $build 'generated\RestrictedCliNative.cs') (Join-Path $build 'generated\RestrictedCliFullRestricted.cs') (Join-Path $build 'source\FixtureSupport.cs') (Join-Path $build 'source\FixturePreResumeRecord.cs') 2>&1|Tee-Object -FilePath (Join-Path $build 'managed-build.log')
if($LASTEXITCODE -ne 0){throw 'Fixture managed build failed'}
$vcvars='C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
$lines=@('@echo off','setlocal',('call "'+$vcvars+'"'),'if errorlevel 1 exit /b 1',('where cl.exe > "'+$build+'\compiler-path.txt"'),
 ('cl.exe /nologo /TC /std:c11 /W4 /WX /MT /O2 /GS /guard:cf /DUNICODE /D_UNICODE /I"'+$build+'\generated" /I"'+$build+'\source" /Fo:"'+$build+'\LifecycleProbe.obj" /Fe:"'+$build+'\AzuriteLifecycleProbe.exe" "'+$build+'\source\LifecycleProbe.c" /link /MACHINE:X64 /SUBSYSTEM:WINDOWS /ENTRY:wmainCRTStartup /DYNAMICBASE /NXCOMPAT /HIGHENTROPYVA /guard:cf /MAP:"'+$build+'\child.map" kernel32.lib'),
 'if errorlevel 1 exit /b 1',('cl.exe /nologo /TC /std:c11 /W4 /WX /MT /O2 /Fo:"'+$build+'\FixturePolicy.Tests.obj" /Fe:"'+$build+'\FixturePolicy.Tests.exe" "'+$build+'\source\FixturePolicy.Tests.c" /link /MACHINE:X64 /SUBSYSTEM:CONSOLE kernel32.lib'),
 'if errorlevel 1 exit /b 1',('dumpbin /imports "'+$build+'\AzuriteLifecycleProbe.exe" > "'+$build+'\child-imports.txt"'),'exit /b %errorlevel%')
[IO.File]::WriteAllText((Join-Path $build 'build-native.cmd'),(($lines -join ([string][char]13+[char]10))+[char]13+[char]10),[Text.Encoding]::ASCII)
& $env:ComSpec /d /c (Join-Path $build 'build-native.cmd') 2>&1|Tee-Object -FilePath (Join-Path $build 'native-build.log')
if($LASTEXITCODE -ne 0){throw 'Harmless child build failed'}
& (Join-Path $build 'FixturePolicy.Tests.exe') 2>&1|Tee-Object -FilePath (Join-Path $build 'native-pure-tests.json')
if($LASTEXITCODE -ne 0){throw 'Child pure predicate tests failed'}
# The harmless child executable is deliberately NOT executed here.
$buildRecord=[ordered]@{fixtureOnly=$true;childExecuted=$false;compiler=(Get-Content (Join-Path $build 'compiler-path.txt')|Select-Object -First 1);csc=$csc;cscSha256=(Hash $csc);referenceSha256=(Hash (Join-Path $framework 'System.Web.Extensions.dll'));additionalReferences=@('System.Runtime.Serialization.dll','System.Xml.dll')|ForEach-Object{[ordered]@{name=$_;sha256=(Hash (Join-Path $framework $_))}};vcvarsSha256=(Hash $vcvars);nativeFlags='/TC /std:c11 /W4 /WX /MT /O2 /GS /guard:cf /SUBSYSTEM:WINDOWS /ENTRY:wmainCRTStartup';childSha256=(Hash (Join-Path $build 'AzuriteLifecycleProbe.exe'));fixtureAssemblySha256=(Hash (Join-Path $build 'AzuriteLifecycle.FixtureOnly.dll'));outerHost='direct x64 PS7';controllerDependencies=$controllerDependencies}
$buildRecord.compilerSha256=Hash $buildRecord.compiler
Save (Join-Path $build 'build-provenance.json') ($buildRecord|ConvertTo-Json -Depth 6)
foreach($test in @(@('FullRestrictedNative.Tests.cs','Core'),@('FullRestrictedOwnership.Tests.cs','Ownership'))){
 $source=Join-Path $repo ('Tests\headless\'+$test[0]);Copy-Item -LiteralPath $source -Destination (Join-Path $build ('source\'+$test[0]))
 & $csc /nologo /target:exe /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll ('/out:'+(Join-Path $build ($test[1]+'.PureTests.exe'))) (Join-Path $build 'generated\RestrictedCliNative.cs') (Join-Path $build 'generated\RestrictedCliFullRestricted.cs') $source 2>&1|Tee-Object -FilePath (Join-Path $build ($test[1]+'.pure-build.log'))
 if($LASTEXITCODE -ne 0){throw 'Accepted source-linked pure test build failed'}
 & (Join-Path $build ($test[1]+'.PureTests.exe')) 2>&1|Tee-Object -FilePath (Join-Path $build ($test[1]+'.pure-result.json'))
 if($LASTEXITCODE -ne 0){throw 'Accepted source-linked pure regression failed'}
}
& $csc /nologo /target:exe /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll ('/out:'+(Join-Path $build 'Monitor.PureTests.exe')) (Join-Path $build 'generated\RestrictedCliNative.cs') (Join-Path $build 'generated\RestrictedCliFullRestricted.cs') (Join-Path $build 'source\FullDesktopMonitor.Tests.cs') 2>&1|Tee-Object -FilePath (Join-Path $build 'Monitor.pure-build.log')
if($LASTEXITCODE -ne 0){throw 'Accepted full monitor pure test compile failed'}
& (Join-Path $build 'Monitor.PureTests.exe') (Join-Path $build 'actual-list-result.json') 2>&1|Tee-Object -FilePath (Join-Path $build 'Monitor.pure-result.json')
if($LASTEXITCODE -ne 0){throw 'Accepted full monitor actual-data/pure tests failed'}
& $csc /nologo /target:exe /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll ('/out:'+(Join-Path $build 'FixtureSerialization.PureBridge.exe')) (Join-Path $build 'generated\RestrictedCliNative.cs') (Join-Path $build 'generated\RestrictedCliFullRestricted.cs') (Join-Path $build 'source\FixtureSerialization.PureBridge.cs') 2>&1|Tee-Object -FilePath (Join-Path $build 'serialization-build.log')
if($LASTEXITCODE -ne 0){throw 'Production serialization pure bridge compile failed'}
& (Join-Path $PSScriptRoot 'Test-Fixture.ps1') -BuildDirectory $build 2>&1|Tee-Object -FilePath (Join-Path $build 'managed-pure-ps7.log')
if(-not $?){throw 'Fixture pure tests failed'}
& (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-Fixture.ps1') -BuildDirectory $build 2>&1|Tee-Object -FilePath (Join-Path $build 'managed-pure-ps51.log')
if($LASTEXITCODE -ne 0){throw 'PS5.1 fixture pure tests failed'}
& (Join-Path $PSScriptRoot 'Test-FixtureAcl.ps1') -SourceDirectory (Join-Path $build 'source') 2>&1|Tee-Object -FilePath (Join-Path $build 'acl-pure-ps7.log')
if(-not $?){throw 'Fixture ACL pure controls failed'}
& (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-FixtureAcl.ps1') -SourceDirectory (Join-Path $build 'source') 2>&1|Tee-Object -FilePath (Join-Path $build 'acl-pure-ps51.log')
if($LASTEXITCODE -ne 0){throw 'PS5.1 fixture ACL pure controls failed'}
& $csc /nologo /target:exe /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll ('/out:'+(Join-Path $build 'Observer.Pure.exe')) (Join-Path $build 'generated\RestrictedCliNative.cs') (Join-Path $build 'generated\RestrictedCliFullRestricted.cs') (Join-Path $build 'source\FixtureSupport.cs') (Join-Path $build 'source\FixturePreResumeRecord.cs') (Join-Path $build 'source\Observer.Pure.cs') 2>&1|Tee-Object -FilePath (Join-Path $build 'observer-pure-build.log')
if($LASTEXITCODE -ne 0){throw 'Observer pure build failed'}
& (Join-Path $build 'Observer.Pure.exe') 2>&1|Tee-Object -FilePath (Join-Path $build 'observer-pure-result.json')
if($LASTEXITCODE -ne 0){throw 'Observer pure identity/interval failed'}
& (Join-Path $PSScriptRoot 'Test-Observer.ps1') -OutputDirectory $build 2>&1|Tee-Object -FilePath (Join-Path $build 'observer-rules-ps7.log')
if(-not $?){throw 'PS7 observer predicates failed'}
& (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-Observer.ps1') -OutputDirectory $build 2>&1|Tee-Object -FilePath (Join-Path $build 'observer-rules-ps51.log')
if($LASTEXITCODE -ne 0){throw 'PS5.1 observer predicates failed'}
& (Join-Path $PSScriptRoot 'Test-NormalReceipt.ps1') -Repo $repo 2>&1|Tee-Object -FilePath (Join-Path $build 'normal-gate-ps7.json')
if(-not $?){throw 'PS7 same-package normal gate failed'}
& (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-NormalReceipt.ps1') -Repo $repo 2>&1|Tee-Object -FilePath (Join-Path $build 'normal-gate-ps51.json')
if($LASTEXITCODE -ne 0){throw 'PS5.1 same-package normal gate failed'}
& $csc /nologo /target:library /platform:x64 /warn:4 /warnaserror+ /r:System.Runtime.Serialization.dll /r:System.Xml.dll ('/out:'+(Join-Path $build 'FixturePreResume.Pure.dll')) (Join-Path $build 'source\FixturePreResumeRecord.cs') (Join-Path $build 'source\FixturePreResumeRecord.Tests.cs') 2>&1|Tee-Object -FilePath (Join-Path $build 'pre-resume-pure-build.log')
if($LASTEXITCODE -ne 0){throw 'Bounded pre-resume reader pure build failed'}
& (Join-Path $PSScriptRoot 'Test-PreResumeReader.ps1') -BuildDirectory $build 2>&1|Tee-Object -FilePath (Join-Path $build 'pre-resume-pure-ps7.log')
if(-not $?){throw 'Direct PS7 pre-resume reader pure checks failed'}
& (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-PreResumeReader.ps1') -BuildDirectory $build 2>&1|Tee-Object -FilePath (Join-Path $build 'pre-resume-pure-ps51.log')
if($LASTEXITCODE -ne 0){throw 'Direct PS5.1 pre-resume reader pure checks failed'}
& (Join-Path $PSScriptRoot 'Test-CleanupOrdering.ps1') -OutputDirectory $build -MonitorPath (Join-Path $build 'serialization-ps51-monitor.json') 2>&1|Tee-Object -FilePath (Join-Path $build 'cleanup-ordering-ps7.log')
if(-not $?){throw 'Direct PS7 cleanup ordering consumer failed'}
& (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-CleanupOrdering.ps1') -OutputDirectory $build -MonitorPath (Join-Path $build 'serialization-ps51-monitor.json') 2>&1|Tee-Object -FilePath (Join-Path $build 'cleanup-ordering-ps51.log')
if($LASTEXITCODE -ne 0){throw 'Direct PS5.1 cleanup ordering consumer failed'}
# The exact fixture writer is exercised in both hosts using pure DTO/anonymous
# values. Its separate test Lab never creates a lifecycle-run admission.
$writerLab=Join-Path $base 'write-tests-cleanup9974-qual1'
if(Test-Path -LiteralPath $writerLab){throw 'Preserve previous writer test Lab'}
$writerSource=Join-Path $build 'generated\FixtureWrite.Pure.FullRestricted.cs'
Save $writerSource ($generated.Replace($newLab,('Lab=@"'+$writerLab+'"')))
& $csc /nologo /target:library /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll ('/out:'+(Join-Path $build 'FixtureWrite.Pure.dll')) (Join-Path $build 'generated\RestrictedCliNative.cs') $writerSource (Join-Path $build 'source\FixtureSupport.cs') (Join-Path $build 'source\FixturePreResumeRecord.cs') (Join-Path $build 'source\FixtureWrite.Tests.cs') 2>&1|Tee-Object -FilePath (Join-Path $build 'writer-pure-build.log')
if($LASTEXITCODE -ne 0){throw 'Fixture writer pure build failed'}
& (Join-Path $PSScriptRoot 'Test-FixtureWrite.ps1') -AssemblyPath (Join-Path $build 'FixtureWrite.Pure.dll') -OutputPath (Join-Path $build 'writer-pure-ps7.json') 2>&1|Tee-Object -FilePath (Join-Path $build 'writer-pure-ps7.log')
if(-not $?){throw 'Direct PS7 fixture writer checks failed'}
& (Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe') -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-FixtureWrite.ps1') -AssemblyPath (Join-Path $build 'FixtureWrite.Pure.dll') -OutputPath (Join-Path $build 'writer-pure-ps51.json') 2>&1|Tee-Object -FilePath (Join-Path $build 'writer-pure-ps51.log')
if($LASTEXITCODE -ne 0){throw 'Direct PS5.1 fixture writer checks failed'}
$writer7=Get-Content (Join-Path $build 'writer-pure-ps7.json') -Raw|ConvertFrom-Json
$writer5=Get-Content (Join-Path $build 'writer-pure-ps51.json') -Raw|ConvertFrom-Json
$writerFiles=@(foreach($record in $writer7.outcomes){$other=@($writer5.outcomes|Where-Object case -CEQ $record.case);if($other.Count -ne 1 -or (Hash $record.path) -cne (Hash $other[0].path)){throw 'Fixture writer host byte equivalence failed'};[ordered]@{case=$record.case;sha256=(Hash $record.path);ps7=$record.path;ps51=$other[0].path}})
Save (Join-Path $build 'writer-host-byte-equivalence.json') ($writerFiles|ConvertTo-Json -Depth 4)
$files=@(Get-ChildItem -LiteralPath $build -File -Recurse|ForEach-Object{[ordered]@{path=$_.FullName.Substring($build.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Hash $_.FullName)}})
Save (Join-Path $build 'manifest.json') ([ordered]@{schema=1;fixtureOnly=$true;productionTargetExecuted=$false;runtimeAllowed=$false;evidenceProtocol='cleanup-ordering.v1';externalLiveDescendantIntervalClaimed=$false;lab=$lab;productionSources=$pins;controllerDependencies=$controllerDependencies;outerHost='direct x64 PS7';files=$files}|ConvertTo-Json -Depth 10)
[pscustomobject]@{built=$true;childExecuted=$false;manifestSha256=(Hash (Join-Path $build 'manifest.json'));path=$build}
