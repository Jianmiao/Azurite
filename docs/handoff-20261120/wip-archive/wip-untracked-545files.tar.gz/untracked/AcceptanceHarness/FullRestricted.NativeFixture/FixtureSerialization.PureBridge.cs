using System;using System.Collections.Generic;using System.Web.Script.Serialization;using Azurite.Restricted;
public static class FixtureSerializationPureBridge {
 public const string RunId="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
 public const string Pin="user32.dll|10.0.26100.9818|4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91|EnumDesktopWindows:0x2a9a0;win32u.dll|10.0.26100.9974|5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc|NtUserBuildHwndList:0x1610";
 public static Dictionary<string,object> Create(){
  var session=new FullDesktopMonitorSession();FullDesktopMonitor.Run(new Fake(),new IntPtr(1234),new[]{42},"AzuriteFullCli_"+RunId,session);
  var monitor=session.Snapshot();var first=(Dictionary<string,object>)monitor["first"];
  if(first["imagePins"].GetType()!=typeof(object[])||((object[])first["imagePins"]).Length!=2)throw new InvalidOperationException("Production structured evidence did not return exact object[2]");
  return monitor;
 }
 public static string ImagePinsType(Dictionary<string,object> monitor){return ((Dictionary<string,object>)monitor["first"])["imagePins"].GetType().FullName;}
 public static int Main(){try{var monitor=Create();Console.WriteLine(new JavaScriptSerializer().Serialize(new{scope="pure fake native API with real production monitor and JavaScriptSerializer object graph",nativeCallsExecuted=false,imagePinsType=ImagePinsType(monitor),monitor=monitor}));return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
 sealed class Fake:IFullDesktopMonitorApi {
  public FullDesktopEnumeration Enumerate(IntPtr h,int[] ids){return new FullDesktopEnumeration{Returned=false,Error=0,Callbacks=0,Visible=false,CallbackError=null};}
  public FullDesktopIdentity ReadIdentity(IntPtr h){return new FullDesktopIdentity{Handle=h.ToInt64(),Name="AzuriteFullCli_"+RunId,Type="Desktop",Owner="S-1-5-21-1-2-3-1001",CurrentOwner="S-1-5-21-1-2-3-1001",RightsQueryStatus=0,GrantedAccess=0xf01ff,Inherited=false};}
  public string RequirePinnedImages(){return Pin;}
  public string ImagePinEvidenceJson(){return new JavaScriptSerializer().Serialize(ImagePinEvidence());}
  public object[] ImagePinEvidence(){
   var rows=new List<Dictionary<string,object>>();
   rows.Add(FullDesktopImagePolicy.Describe("user32.dll",@"C:\Windows\System32\USER32.dll",@"C:\Windows\system32\user32.dll","4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91","4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91","10.0.26100.9818","10.0.26100.9818",0x2a9a0,0x2a9a0,false,"10.0.26100.8117 (WinBuild.160101.0800)","10.0.26100.8117","en-US pure sample"));
   rows.Add(FullDesktopImagePolicy.Describe("win32u.dll",@"C:\Windows\System32\win32u.dll",@"C:\Windows\system32\win32u.dll","5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc","5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc","10.0.26100.9974","10.0.26100.9974",0x1610,0x1610,false,"10.0.26100.9818 (WinBuild.160101.0800)","10.0.26100.9818","en-US pure sample"));
   foreach(var row in rows)FullDesktopImagePolicy.Validate(row);
   return rows.ConvertAll<object>(row=>row).ToArray();
  }
  public FullDesktopEmptyList ReadEmptyList(IntPtr h){return new FullDesktopEmptyList{Status=0,LastError=0,Capacity=64,Needed=1,First=1,GuardsIntact=true,TailIntact=true};}
  public bool ForegroundOwned(int[] ids){return false;}
 }
}
