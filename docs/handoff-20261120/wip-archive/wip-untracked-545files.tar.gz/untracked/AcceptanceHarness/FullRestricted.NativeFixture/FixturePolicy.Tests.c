#include <stdio.h>
#include "FixturePolicy.h"
int main(void){uint32_t n;int c=0;
#define CHECK(x) do{c++;if(!(x)){printf("FAIL:%d\n",c);return 1;}}while(0)
 CHECK(fixture_run_id("0123456789abcdef0123456789abcdef"));CHECK(!fixture_run_id("ABC"));CHECK(!fixture_run_id("0123456789abcdef0123456789abcdeg"));
 CHECK(fixture_u32("4294967295",&n)&&n==UINT32_MAX);CHECK(!fixture_u32("4294967296",&n));CHECK(!fixture_u32("-1",&n));
 CHECK(fixture_case("normal"));CHECK(fixture_case("bootstrap-exit"));CHECK(!fixture_case("arbitrary"));
 CHECK(fixture_sid("S-1-5-5-1-2"));CHECK(!fixture_sid("S-1-5-\"bad"));
 CHECK(fixture_full_set(3,1,1,1));CHECK(!fixture_full_set(4,1,1,1));CHECK(!fixture_full_set(3,1,0,1));
 CHECK(fixture_inherited(8192,3,8192,3));CHECK(!fixture_inherited(4096,3,8192,3));CHECK(!fixture_inherited(8192,4,8192,4));
 printf("{\"scope\":\"pure child parsing and token predicates only\",\"passed\":true,\"checks\":%d}\n",c);return 0;
}
