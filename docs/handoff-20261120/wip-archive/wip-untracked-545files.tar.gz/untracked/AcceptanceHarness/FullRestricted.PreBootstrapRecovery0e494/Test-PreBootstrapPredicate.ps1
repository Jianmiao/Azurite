param([string]$PolicyPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not $PolicyPath){$PolicyPath=Join-Path $PSScriptRoot 'PreBootstrap.Policy.ps1'}
if(-not [IO.File]::Exists($PolicyPath)){throw 'RED: exact pre-bootstrap refusal predicate is not implemented'}
function Assert-Preservation($value,[string]$message){if(-not $value){throw $message}}
. $PolicyPath
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$run='0e494be63f3248ffb7bd7bbd040987f8'
function Json([string]$p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -DateKind String}
$final=Json (Join-Path $repo 'artifacts\aa-fr-capabilities-runtime\12eaedb7b439456387bbce0b6d3ec828\controller-final.json')
$sequence=Json (Join-Path $repo ('artifacts\aa-fr-capabilities-sequence\run-'+$run+'\sequence-result.json'))
$child=Json (Join-Path $repo ('artifacts\aa-fr-capabilities-sequence\run-'+$run+'\Runtime-child-result.json'))
$ownership=Json (Join-Path $repo ('artifacts\aa-fr-capabilities-sequence\run-'+$run+'\Runtime-child-ownership.json'))
$supervisor=Json (Join-Path $repo ('artifacts\aa-actual-handoff-next-20261114\run-'+$run+'\qualification10-supervision\process-state.json'))
function Clone($v){$v|ConvertTo-Json -Depth 30|ConvertFrom-Json -DateKind String}
$passed=0;$failed=0
function Check([string]$name,[scriptblock]$body){try{& $body;$script:passed++;Write-Output ('PASS '+$name)}catch{$script:failed++;Write-Output ('FAIL '+$name+': '+$_.Exception.Message)}}
function Refuses([scriptblock]$body){$no=$false;try{& $body}catch{$no=$true};Assert-Preservation $no 'expected refusal'}
Check 'exact actual refusal and original terminal correlate' {$p=Assert-ExactPreBootstrapRefusal $final $child $ownership $sequence $supervisor;Assert-Preservation ($p.evidenceClass -ceq 'source-correlated-no-attempt' -and $p.nativeCountersCaptured -eq $false -and $p.nativeCleanupVerified -eq $false) 'inference was relabeled telemetry'}
Check 'arbitrary MissingMethod is not no-attempt proof' {$x=Clone $final;$x.primaryError='MissingMethodException elsewhere';Refuses {Assert-ExactPreBootstrapRefusal $x $child $ownership $sequence $supervisor}}
Check 'null result alone is not no-attempt proof' {$x=Clone $final;$x.primaryError='unrelated failure';Refuses {Assert-ExactPreBootstrapRefusal $x $child $ownership $sequence $supervisor}}
Check 'different run refuses' {$x=Clone $final;$x.runId='1'*32;Refuses {Assert-ExactPreBootstrapRefusal $x $child $ownership $sequence $supervisor}}
Check 'retained runtime lease refuses' {$x=Clone $final;$x.leaseHeld=$true;Refuses {Assert-ExactPreBootstrapRefusal $x $child $ownership $sequence $supervisor}}
Check 'unterminated original child refuses' {$x=Clone $ownership;$x.exitConfirmed=$false;Refuses {Assert-ExactPreBootstrapRefusal $final $child $x $sequence $supervisor}}
Check 'supervisor kill is not natural closure' {$x=Clone $supervisor;$x.terminatedBySupervisor=$true;Refuses {Assert-ExactPreBootstrapRefusal $final $child $ownership $sequence $x}}
Check 'baseline collector is not runtime supervisor' {$x=Clone $supervisor;$x.pid=9696;$x.exitCode=0;Refuses {Assert-ExactPreBootstrapRefusal $final $child $ownership $sequence $x}}
Check 'multiple runtime attempts refuse' {$x=Clone $sequence;$x.runtimeAttemptCount=2;Refuses {Assert-ExactPreBootstrapRefusal $final $child $ownership $x $supervisor}}
Check 'invented Pump is refused' {$x=Clone $final;$x.result=[pscustomobject]@{outer=[pscustomobject]@{NoProcessCreated=$true}};Refuses {Assert-ExactPreBootstrapRefusal $x $child $ownership $sequence $supervisor}}
[pscustomobject]@{scope='SOURCE-only-exact-actual-prebootstrap-predicate';passed=$passed;failed=$failed;mutationsAreInMemory=$true;FReadPerformed=$false;FWritePerformed=$false;nativeExecuted=$false}|ConvertTo-Json -Compress
if($failed){exit 1}
