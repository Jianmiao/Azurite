$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$folder=Join-Path $repo 'artifacts\aa-prebootstrap-recovery-0e494\recovery-source1';$parameters=Get-Content (Join-Path $folder 'plan-parameters.json') -Raw|ConvertFrom-Json -DateKind String
$out=Join-Path $folder 'entry-negatives';if(Test-Path $out){throw 'Fresh negative evidence required'};[void][IO.Directory]::CreateDirectory($out)
Import-Module (Join-Path $repo 'AcceptanceHarness\FullRestricted.CdbOwnedWaitFixture\SourceProcess.psm1') -Force
$hostPath='C:\Users\21294\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
function Hash([string]$p){return (Get-FileHash $p).Hash.ToLowerInvariant()}
function Save([string]$p,$value){[IO.File]::WriteAllText($p,($value|ConvertTo-Json -Depth 95),[Text.UTF8Encoding]::new($false));return [pscustomobject]@{path=$p;sha256=Hash $p;bytes=(Get-Item $p).Length}}
function MutatedData([string]$name,[string]$role,[scriptblock]$mutation){$manifest=Get-Content $parameters.RecoveryEvidencePath -Raw|ConvertFrom-Json -DateKind String;$entry=@($manifest.files|Where-Object role -CEQ $role)[0];$data=Get-Content $entry.path -Raw|ConvertFrom-Json -DateKind String;& $mutation $data;$pin=Save (Join-Path $out ($name+'-data.json')) $data;$entry.path=$pin.path;$entry.sha256=$pin.sha256;$entry.bytes=$pin.bytes;$manifest|Add-Member testOnlySimulated $true;return Save (Join-Path $out ($name+'-manifest.json')) $manifest}
$checks=[Collections.Generic.List[object]]::new()
function Reject([string]$name,[string]$pattern,$dataPin,[string]$sourceSha,[bool]$apply){
 if(-not $dataPin){$dataPin=[pscustomobject]@{path=$parameters.RecoveryEvidencePath;sha256=$parameters.ExpectedRecoveryEvidenceSha256}}
 if(-not $sourceSha){$sourceSha=$parameters.ExpectedAdapterManifestSha256}
 $arguments=@('-NoProfile','-File',$parameters.EntryPath,'-AdapterManifestPath',$parameters.AdapterManifestPath,'-ExpectedAdapterManifestSha256',$sourceSha,'-RecoveryEvidencePath',$dataPin.path,'-ExpectedRecoveryEvidenceSha256',$dataPin.sha256)
 $never=Join-Path $out ($name+'-must-not-be-created');if($apply){$arguments+=@('-Apply','-EvidenceDirectory',$never)}
 $record=Join-Path $out ($name+'-process.json');$result=Invoke-FixtureSourceProcess -File $hostPath -Arguments $arguments -Record $record -Directory $repo -BoundMs 120000
 if($result.exitCode -ne 1 -or $result.timedOut -or $result.terminatedOwnedPureChild -or (($result.stderr+$result.stdout) -notlike $pattern) -or (Test-Path $never)){throw ('Wrong negative outcome '+$name+': '+$result.stderr)}
 $checks.Add([pscustomobject]@{name=$name;processPath=$record;processSha256=Hash $record;exitCode=$result.exitCode;expectedRefusal=$pattern;recoveryEvidenceDirectoryCreated=$false;nativePhaseReached=$false})
}
Reject 'missing-fresh-before-apply' '*Fresh independent shared comparison after preservation and within five minutes is required before Apply*' $null $null $true
Reject 'wrong-source-authority' '*Pinned C input drift*' $null ('a'*64) $false
Reject 'wrong-data-digest' '*Pinned C input drift*' ([pscustomobject]@{path=$parameters.RecoveryEvidencePath;sha256=('b'*64)}) $null $false
$bad=MutatedData 'unclosed-preservation' Preservation {param($d)$d.releaseSucceeded=$false};Reject 'unclosed-preservation' '*Actual preservation is incomplete*' $bad $null $false
$bad=MutatedData 'native-proof-invented' Preservation {param($d)$d.originalRuntimeCleanupVerified=$true};Reject 'native-proof-invented' '*claims native/application success*' $bad $null $false
$bad=MutatedData 'unknown-extra' Comparison {param($d)$template=@($d.currentObjects|Where-Object {$_.path -like '*\prelaunch-delta.json'})[0]|ConvertTo-Json -Depth 20|ConvertFrom-Json -DateKind String;$template.path=$template.path.Replace('shared-state\prelaunch-delta.json','control\lease-offer.json');$template.finalPath=$template.path;$template.identity='e'*32;$d.currentObjects+=,$template};Reject 'unknown-extra' '*Unexpected runtime extra in no-attempt branch*' $bad $null $false
$bad=MutatedData 'current-control-identity' Comparison {param($d)$object=@($d.currentObjects|Where-Object {$_.path.EndsWith('\control',[StringComparison]::Ordinal)})[0];$object.identity='f'*32};Reject 'current-control-identity' '*Closed recovery identity/descriptor drift*' $bad $null $false
$summary=[ordered]@{scope='SOURCE-only-actual-recovery-entry-rejections';passed=$checks.Count;failed=0;checks=$checks.ToArray();originalActualDataUnchanged=$true;mutatedDataIsExplicitTestCopy=$true;FReadPerformed=$false;FWritePerformed=$false;nativePhaseReached=$false}
$pin=Save (Join-Path $out 'result.json') $summary;$summary|ConvertTo-Json -Depth 6 -Compress
