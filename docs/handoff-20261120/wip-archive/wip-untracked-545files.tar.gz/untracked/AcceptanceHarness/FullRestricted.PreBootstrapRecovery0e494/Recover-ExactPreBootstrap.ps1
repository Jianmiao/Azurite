[CmdletBinding()]
param([Parameter(Mandatory)][string]$AdapterManifestPath,[Parameter(Mandatory)][string]$ExpectedAdapterManifestSha256,[Parameter(Mandatory)][string]$RecoveryEvidencePath,[Parameter(Mandatory)][string]$ExpectedRecoveryEvidenceSha256,[switch]$Apply,[string]$EvidenceDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$adapterRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
function Read-AdapterC([string]$Path,[string]$Sha,[long]$Maximum=8388608){
 $full=[IO.Path]::GetFullPath($Path);if($full -cne $Path -or -not $full.StartsWith($adapterRepo+'\',[StringComparison]::Ordinal) -or $Sha -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Exact externally pinned C input required'}
 $cursor=$full;while($cursor){$i=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'C input reparse ancestry refused'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
 $f=[IO.File]::Open($full,'Open','Read','Read');try{if($f.Length -gt $Maximum){throw 'C input bound exceeded'};$h=[Security.Cryptography.SHA256]::Create();try{$digest=([BitConverter]::ToString($h.ComputeHash($f))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()};if($digest -cne $Sha){throw ('Pinned C input drift: '+$Path)};$f.Position=0;$m=[IO.MemoryStream]::new();try{$f.CopyTo($m);return ,$m.ToArray()}finally{$m.Dispose()}}finally{$f.Dispose()}
}
$adapter=([Text.Encoding]::UTF8.GetString((Read-AdapterC $AdapterManifestPath $ExpectedAdapterManifestSha256 131072))|ConvertFrom-Json -DateKind String)
$required=@('Entry','Binder','RecoveryPolicy','PreservationEntry','PreservationManifest','RecoveryModule','ClosedRules','TokenDll','TokenSharedSource','TokenFullSource')
if($adapter.schema -ne 1 -or $adapter.scope -cne 'exact-run0e-prebootstrap-recovery-adapter-source' -or $adapter.runId -cne '0e494be63f3248ffb7bd7bbd040987f8' -or @($adapter.files).Count -ne $required.Count){throw 'Exact run0e recovery adapter closure required'}
$recoverySources=@{};foreach($pin in $adapter.files){if($pin.role -cnotin $required -or $recoverySources.ContainsKey($pin.role)){throw 'Unknown/duplicate adapter source role'};$bytes=Read-AdapterC $pin.path $pin.sha256;if($bytes.Length -ne $pin.bytes){throw 'Adapter source length differs'};$recoverySources[$pin.role]=[pscustomobject]@{pin=$pin;bytes=$bytes}}
if($recoverySources.Entry.pin.path -cne $PSCommandPath -or $recoverySources.RecoveryPolicy.pin.path -cne (Join-Path $PSScriptRoot 'PreBootstrap.RecoveryPolicy.ps1') -or $recoverySources.PreservationEntry.pin.path -cne (Join-Path $PSScriptRoot 'Preserve-ExactPreBootstrap.ps1') -or $recoverySources.PreservationManifest.pin.sha256 -cne '945a8f9bb1c300e115ecda2e74885030e07943c77f026c029d38c3264f0c540b'){throw 'Selected adapter path/preservation authority differs'}
if($recoverySources.RecoveryModule.pin.sha256 -cne 'bcb2a4b551e61f69672ff91cad7fd902bba828fe11770f12645af6f811dd6c02' -or $recoverySources.ClosedRules.pin.sha256 -cne '9fcd280a3f9ef0d8f11b56fabf43a4cbef5db65b1d6f89b404a75e39743170c9'){throw 'Original recovery coordinator/shared validators changed'}
# Reuse the fixed public C-only preservation Plan to validate actual refusal,
# exact source order and the original preparation graph. No Capture is passed.
$null=. $recoverySources.PreservationEntry.pin.path -SourceManifestPath $recoverySources.PreservationManifest.pin.path -ExpectedSourceManifestSha256 $recoverySources.PreservationManifest.pin.sha256
$preservationBase=$spec;$preservationPackage=$package
$script:RecoveryRepo=$adapterRepo;$script:RecoveryRoot=$preservationBase.LabRoot;$script:RecoveryRun=$preservationBase.RunId;$script:RecoveryOwner=$preservationBase.OwnerSid;$script:RecoveryVolume=$preservationBase.Volume;$script:RecoveryRetained=[Collections.Generic.List[object]]::new();$script:RecoveryTokenType=$null
# Load verified original function definitions, not the old hard-coded planner or
# entry point. Their coordinator/mutation/physical backend bodies are unchanged.
Import-PinnedDefinitions $recoverySources.RecoveryModule.bytes @() @('Get-AzuritePreparationRecoveryPlan','Complete-RecoveryPostNativePlan','Assert-RecoveryPostNativeDrain','Invoke-AzuritePreparationRecovery','Read-RecoverySourceBindings')
Import-PinnedDefinitions $recoverySources.ClosedRules.bytes @('ConvertTo-ClosedRecoveryUtcInstant','Assert-ClosedRecoveryDelta','Assert-ClosedFreshSharedResult','Assert-ClosedRecoveryIdentity','Compare-ClosedArchivedShared') @()
Import-PinnedDefinitions $recoverySources.RecoveryPolicy.bytes @() @()
$tokenPins=Get-RecoveryTokenPins
foreach($pair in @(@('TokenDll','RestrictedCliNative.dll'),@('TokenSharedSource','RestrictedCliNative.cs'),@('TokenFullSource','RestrictedCliFullRestricted.cs'))){$actual=$recoverySources[$pair[0]].pin;$expected=$tokenPins[$pair[1]];Assert-Recovery ($actual.path -ceq $expected.path -and $actual.sha256 -ceq $expected.sha256) 'Actual recovery token reader is not the original qualified source'}
$dataManifest=ConvertFrom-RecoveryJson (Read-AdapterC $RecoveryEvidencePath $ExpectedRecoveryEvidenceSha256 131072)
$dataNames=@('Preservation','Comparison','Inventory','Archive','Important','PreservationInputs');$optional=@('SharedResult','SharedComparison','SharedAfter')
Assert-Recovery ($dataManifest.schema -eq 1 -and $dataManifest.scope -ceq 'exact-run0e-prebootstrap-recovery-actual-evidence' -and $dataManifest.runId -ceq $script:RecoveryRun -and $dataManifest.adapterManifestSha256 -ceq $ExpectedAdapterManifestSha256 -and @($dataManifest.files).Count -in @(6,9)) 'Actual recovery data manifest scope/source binding differs'
$data=@{};$dataPins=@{};foreach($pin in $dataManifest.files){Assert-Recovery ($pin.role -cin ($dataNames+$optional) -and -not $data.ContainsKey($pin.role)) 'Unknown/duplicate actual data role';$bytes=Read-AdapterC $pin.path $pin.sha256 67108864;Assert-Recovery ($bytes.Length -eq $pin.bytes) 'Actual data length differs';$data[$pin.role]=ConvertFrom-RecoveryJson $bytes;$dataPins[$pin.role]=$pin}
foreach($name in $dataNames){Assert-Recovery ($data.ContainsKey($name)) 'Missing completed preservation record'}
foreach($name in $optional){Assert-Recovery ($data.ContainsKey($name) -eq $data.ContainsKey('SharedResult')) 'Fresh shared result/comparison/after must be supplied together'}
$recoverySpec=Get-ExactPreBootstrapRecoverySpec $preservationBase $data $dataPins $RecoveryEvidencePath $ExpectedRecoveryEvidenceSha256
if(-not $Apply){[pscustomobject]@{scope=$recoverySpec.Scope;evidenceMode=$recoverySpec.EvidenceMode;runId=$recoverySpec.RunId;originalCount=$recoverySpec.Original.Count;capturedCurrentCount=@($data.Comparison.currentObjects).Count;currentExpectedCount=$recoverySpec.Prepared.Count;createdCount=$recoverySpec.Created.Count;actualRuntimeExtras=$recoverySpec.Created.Count-32;payloadRestores=$recoverySpec.PayloadRestores.Count;descriptorRestores=$recoverySpec.DescriptorRestores.Count;pendingExpectedState=$recoverySpec.ExpectedPendingState;aaCreationStatus=$recoverySpec.AaCreationStatus;nativeCleanupVerified=$false;noAttemptEvidence=$recoverySpec.NoAttemptEvidence;sharedEvidenceFreshForApply=$recoverySpec.SharedEvidenceFreshForApply;willReadF=$false;willWriteF=$false;willLaunch=$false;runtimeAllowed=$false}|ConvertTo-Json -Depth 8;return}
Assert-Recovery ($PSVersionTable.PSEdition -ceq 'Core' -and $PSVersionTable.PSVersion.Major -ge 7 -and [Environment]::Is64BitProcess -and -not ('Azurite.Stage.FileSecurity' -as [type])) 'Apply requires a fresh x64 PS7 without metadata helper'
Assert-RecoveryPostNativeFresh $recoverySpec ([datetimeoffset]::UtcNow)
Assert-RecoveryCPath $EvidenceDirectory $false;Assert-Recovery (-not [IO.Directory]::Exists($EvidenceDirectory) -and -not [IO.File]::Exists($EvidenceDirectory)) 'Fresh C recovery evidence directory required'
$helper=ConvertFrom-RecoveryJson $preservationPackage.HelperBuild.bytes
Assert-Recovery ($helper.scope -ceq 'controller-file-security-helper-build' -and $helper.exitCode -eq 0 -and $helper.sourceSha256 -ceq $preservationPackage.HelperSource.pin.sha256 -and $helper.assemblySha256 -ceq $preservationPackage.FileHelper.pin.sha256 -and $helper.moduleSha256 -ceq $preservationPackage.HelperModule.pin.sha256) 'Original recovery metadata helper binding differs'
Initialize-RecoveryTokenReader $recoverySources.TokenDll.bytes
$identity=Get-RecoveryIdentity;Assert-Recovery ($identity.ownerSid -ceq $recoverySpec.OwnerSid -and $identity.logonSid -ceq $recoverySpec.LogonSid) 'Actual recovery account/logon differs from preparation'
[void][Reflection.Assembly]::Load([byte[]]$preservationPackage.FileHelper.bytes);[Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal
Assert-Recovery ($null -ne [Azurite.Stage.FileSecurity].GetMethod('DeleteEmptyDirectory') -and $null -ne [Azurite.Stage.FileSecurity].GetMethod('ArchiveFile')) 'Pinned helper lacks the original inverse primitives'
$state=@{Spec=$recoverySpec;RecoveryId=[guid]::NewGuid().ToString('N');EvidenceDirectory=$EvidenceDirectory;ArchiveDirectory=(Join-Path $EvidenceDirectory 'archive');Mutex=$null;Locks=@{};Held=$false;JournalStream=$null};$outcome=$null
try{
 Lock-RecoveryAncestry $state $EvidenceDirectory $false;[void][IO.Directory]::CreateDirectory($EvidenceDirectory);Lock-RecoveryAncestry $state $EvidenceDirectory $true;[void][IO.Directory]::CreateDirectory($state.ArchiveDirectory);Lock-RecoveryAncestry $state $state.ArchiveDirectory $true
 $state.JournalStream=[IO.FileStream]::new((Join-Path $EvidenceDirectory 'journal.jsonl'),[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read)
 Write-RecoveryCRecord (Join-Path $EvidenceDirectory 'source-bindings.json') ([pscustomobject]@{adapter=$adapter;adapterManifestSha256=$ExpectedAdapterManifestSha256;preservationManifestSha256=$recoverySources.PreservationManifest.pin.sha256;runId=$recoverySpec.RunId;recoveryId=$state.RecoveryId;newRecoveryAuthority=$true;oldRuntimeApprovalReused=$false;noAttemptEvidence=$recoverySpec.NoAttemptEvidence})
 $outcome=Invoke-RecoveryCoordinator $recoverySpec (New-RecoveryPhysicalBackend) $state;$outcome|ConvertTo-Json -Depth 12
}finally{
 if($state.Held -or $script:RecoveryRetained.Count -gt 0 -or ($outcome -and $outcome.LeaseHeld)){try{[Console]::Error.WriteLine('Recovery ownership remains uncertain; original host retained.')}finally{[Threading.Thread]::Sleep([Threading.Timeout]::Infinite)}}
 if($state.JournalStream){$state.JournalStream.Dispose()};foreach($handle in $state.Locks.Values){$handle.Dispose()};$state.Locks.Clear()
}
if(-not $outcome -or -not $outcome.Success){exit 1}
