[CmdletBinding()]
param([Parameter(Mandatory)][string]$SourceManifestPath,[Parameter(Mandatory)][string]$ExpectedSourceManifestSha256,[switch]$Capture,[string]$OutputDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$script:PreservationRepo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$script:PreservationRetained=[Collections.Generic.List[object]]::new()
function Read-FixedCBytes([string]$Path,[string]$Sha,[long]$Limit=8388608){
 $full=[IO.Path]::GetFullPath($Path);if($full -cne $Path -or -not $full.StartsWith($script:PreservationRepo+'\',[StringComparison]::Ordinal) -or $Sha -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Exact pinned C-workspace source required'}
 $cursor=$full;while($cursor){$item=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop;if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'C source reparse ancestry refused'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
 $stream=[IO.File]::Open($Path,'Open','Read','Read');try{if($stream.Length -gt $Limit){throw 'C source exceeds bound'};$hash=[Security.Cryptography.SHA256]::Create();try{$actual=([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()};if($actual -cne $Sha){throw ('Fixed source/evidence drift: '+$Path)};$stream.Position=0;$memory=[IO.MemoryStream]::new();try{$stream.CopyTo($memory);return ,$memory.ToArray()}finally{$memory.Dispose()}}finally{$stream.Dispose()}
}
function Import-PinnedDefinitions([byte[]]$Bytes,[string[]]$Only,[string[]]$Exclude){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput([Text.Encoding]::UTF8.GetString($Bytes),[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Pinned source parse failure'}
 foreach($definition in $ast.EndBlock.Statements){if($definition -is [Management.Automation.Language.FunctionDefinitionAst] -and ($Only.Count -eq 0 -or $definition.Name -cin $Only) -and $definition.Name -cnotin $Exclude){. ([scriptblock]::Create('function script:'+$definition.Name+$definition.Extent.Text.Substring(('function '+$definition.Name).Length)))}}
}
$manifest=([Text.Encoding]::UTF8.GetString((Read-FixedCBytes $SourceManifestPath $ExpectedSourceManifestSha256 131072))|ConvertFrom-Json -DateKind String)
$roles=@('Entry','Policy','PreserveBase','PreserveWrapper','FileHelper','HelperSource','HelperBuild','HelperModule','RuntimeFinal','RuntimeChild','RuntimeOwnership','SequenceResult','SupervisorOutcome','SupervisorSource','RootFailureReadback','IndependentReview','NativeDll','FullSource','SharedSource','RuntimeSource','Control','Observations','PreparationResult','BeforeImages','ReceiptBundle','LeaseRelease','RuntimeInputSources','SequenceSources')
if($manifest.schema -ne 1 -or $manifest.scope -cne 'exact-run0e-prebootstrap-preservation-source-and-evidence' -or $manifest.runId -cne '0e494be63f3248ffb7bd7bbd040987f8' -or @($manifest.files).Count -ne $roles.Count){throw 'Exact run0e source/evidence manifest required'}
$package=@{};foreach($pin in $manifest.files){if($pin.role -cnotin $roles -or $package.ContainsKey($pin.role)){throw 'Unknown/duplicate package role'};$bytes=Read-FixedCBytes $pin.path $pin.sha256;if($bytes.Length -ne $pin.bytes){throw 'Pinned source length differs'};$package[$pin.role]=[pscustomobject]@{pin=$pin;bytes=$bytes}}
if($package.Entry.pin.path -cne $PSCommandPath -or $package.Policy.pin.path -cne (Join-Path $PSScriptRoot 'PreBootstrap.Policy.ps1')){throw 'Executing entry/policy differs from pinned source'}
if($package.PreserveBase.pin.sha256 -cne 'cf5b627dc99f3d97bcbf6773c3bfe2a4e16839e341b126949460749d52c8a4d5' -or $package.PreserveWrapper.pin.sha256 -cne '8254aca6d1903125039e5789fcb7a46a5bdffe0e91e56f047472f685829bca5d'){throw 'Original preservation coordinator/wrapper drift'}
# All source bytes are verified before loading any policy/helper function.
Import-PinnedDefinitions $package.PreserveBase.bytes @() @('Get-FailedCapabilitiesPreservationPlan','Invoke-FailedCapabilitiesPreservation')
Import-PinnedDefinitions $package.PreserveWrapper.bytes @('Assert-Preservation9cPending','New-Preservation9cBackend') @()
Import-PinnedDefinitions $package.Policy.bytes @() @()
$spec=Get-ExactPreBootstrapPreservationSpec $package
$spec|Add-Member SourceManifestPath $SourceManifestPath;$spec|Add-Member SourceManifestSha256 $ExpectedSourceManifestSha256
if(-not $Capture){[pscustomobject]@{scope='exact-run0e-prebootstrap-preservation-plan';runId=$spec.RunId;originalCount=$spec.Original.Count;preparedCount=$spec.Prepared.Count;beforeCreatedCount=32;pendingExpectedState='runtime-pending';allowedRuntimeExtraNames=$spec.AllowedRuntimeExtraNames;runtimeExtrasEnumerated=$false;noAttemptEvidence=$spec.NoAttemptEvidence;sourceManifestSha256=$ExpectedSourceManifestSha256;willReadF=$false;willWriteF=$false;willRestore=$false;willLaunch=$false}|ConvertTo-Json -Depth 8;return}
Assert-Preservation ($PSVersionTable.PSEdition -ceq 'Core' -and $PSVersionTable.PSVersion.Major -ge 7 -and [Environment]::Is64BitProcess -and -not ('Azurite.Stage.FileSecurity' -as [type])) 'Capture requires fresh x64 PS7 without preloaded metadata helper'
$output=[IO.Path]::GetFullPath($OutputDirectory);Assert-Preservation ([IO.Path]::GetDirectoryName($output) -ceq (Join-Path $script:PreservationRepo 'artifacts\aa-fr-closed-failed-preservation') -and -not [IO.Directory]::Exists($output) -and -not [IO.File]::Exists($output)) 'Capture requires fresh child of original C preservation root'
Assert-PreservationCPath $output $false
$helper=ConvertFrom-PreservationJson $package.HelperBuild.bytes
Assert-Preservation ($helper.scope -ceq 'controller-file-security-helper-build' -and $helper.exitCode -eq 0 -and $helper.assemblySha256 -ceq $package.FileHelper.pin.sha256 -and $helper.sourceSha256 -ceq $package.HelperSource.pin.sha256 -and $helper.moduleSha256 -ceq $package.HelperModule.pin.sha256) 'Existing metadata helper build binding differs'
[void][Reflection.Assembly]::Load([byte[]]$package.FileHelper.bytes);[Diagnostics.Process]::GetCurrentProcess().PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal
$state=@{Spec=$spec;Prepared=(New-PreservationMap $spec.Prepared);Observed=@{};ReviewedWrapper=(New-Preservation9cBackend);Inner=(New-PreservationPhysicalBackend);ArchiveReader={param($archive) Read-PreservationPinnedC $archive.destination $archive.sha256 16384};EvidenceDirectory=$output;ArchiveDirectory=(Join-Path $output 'archive');Locks=@{};Mutex=$null;Held=$false;JournalSequence=0}
$result=$null
try{
 Lock-PreservationAncestry $state $output $false;[void][IO.Directory]::CreateDirectory($output);Lock-PreservationAncestry $state $output $true;[void][IO.Directory]::CreateDirectory($state.ArchiveDirectory);Lock-PreservationAncestry $state $state.ArchiveDirectory $true
 $result=Invoke-PreservationCoordinator $spec (New-PreBootstrapPreservationBackend) $state
 $result|ConvertTo-Json -Depth 12
}finally{
 if($state.Held -or $script:PreservationRetained.Count -gt 0){try{[Console]::Error.WriteLine('Preservation lease remains uncertain; original host retained.')}finally{[Threading.Thread]::Sleep([Threading.Timeout]::Infinite)}}
 foreach($handle in $state.Locks.Values){$handle.Dispose()};$state.Locks.Clear()
}
if(-not $result -or -not $result.preserved){exit 1}
