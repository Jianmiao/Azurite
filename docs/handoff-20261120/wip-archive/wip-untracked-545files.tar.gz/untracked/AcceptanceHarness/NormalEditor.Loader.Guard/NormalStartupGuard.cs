using BepInEx.Bootstrap;
using BepInEx.Preloader.Core.Patching;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Azurite.NormalEditor.Loader.Guard;

[PatcherPluginInfo("lab.azurite.normal-editor.guard","Azurite Normal Editor Startup Guard PREPARATION ONLY","0.1.0")]
public sealed class NormalStartupGuard : BasePatcher
{
    // No Core/Policy type occurs in this assembly's fields, signatures, static
    // initializer, or references. BCL bootstrap resolves exact default-ALC files.
    private static Type? runtime;
    private static Harmony? harmony;
    private static MethodInfo? execute;
    public override void Finalizer()
    {
        if(!GuardBootstrap.IsOwnChild())return;
        try{
            var inputs=GuardBootstrap.Prepare();runtime=inputs.Core.GetType("Azurite.NormalEditor.Loader.NormalGuardRuntime",true)!;
            Call("Arm",inputs.ManifestPath,inputs.PreparationSha256);InstallExecuteHooks();
        }catch(Exception error){Abort(error);}
    }
    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void InstallExecuteHooks()
    {
        execute=typeof(BaseChainloader<BasePlugin>).GetMethod("Execute",BindingFlags.Public|BindingFlags.Instance,null,Type.EmptyTypes,null)??throw new MissingMethodException("Pinned chainloader Execute is absent.");
        if(Harmony.GetPatchInfo(execute)?.Owners.Any()==true)throw new InvalidOperationException("Guard Execute seam already has another owner.");
        harmony=new Harmony("lab.azurite.normal-editor.guard");
        harmony.Patch(execute,prefix:new HarmonyMethod(typeof(NormalStartupGuard),nameof(BeforeExecute)),postfix:new HarmonyMethod(typeof(NormalStartupGuard),nameof(AfterExecute)),finalizer:new HarmonyMethod(typeof(NormalStartupGuard),nameof(AfterExecuteFinalizer)));Verify();
    }
    private static void Verify()
    {
        var info=Harmony.GetPatchInfo(execute!)??throw new InvalidOperationException("Guard chainloader hook absent.");
        bool Exact(IEnumerable<Patch> patches,string name){var all=patches.ToArray();return all.Length==1&&all[0].owner==harmony!.Id&&all[0].PatchMethod.DeclaringType==typeof(NormalStartupGuard)&&all[0].PatchMethod.Name==name;}
        if(!Exact(info.Prefixes,nameof(BeforeExecute))||!Exact(info.Postfixes,nameof(AfterExecute))||!Exact(info.Finalizers,nameof(AfterExecuteFinalizer))||info.Transpilers.Any()||info.ILManipulators.Any())throw new InvalidOperationException("Guard chainloader hook content/ownership changed.");
    }
    private static void BeforeExecute(){try{Verify();Call("EnterExecute");}catch(Exception error){Abort(error);}}
    private static void AfterExecute(){try{Verify();Call("Complete",new object?[]{null});}catch(Exception error){Abort(error);}}
    private static Exception? AfterExecuteFinalizer(Exception? __exception){try{Verify();Call("Complete",new object?[]{__exception});}catch(Exception error){Abort(error);}return __exception;}
    // Loader reflects the unique already-loaded Guard. It never loads a second copy.
    public static object GetSession(){Verify();return runtime?.GetProperty("Current",BindingFlags.Public|BindingFlags.Static)?.GetValue(null)??throw new InvalidOperationException("Normal Guard runtime is absent.");}
    private static void Call(string name,params object?[] args)=>(runtime??throw new InvalidOperationException("Guard runtime is absent.")).GetMethod(name,BindingFlags.Public|BindingFlags.Static)!.Invoke(null,args);
    private static void Abort(Exception error)=>GuardBootstrap.AbortOwnChild(error.GetBaseException().Message);
}
