using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Win32.SafeHandles;

namespace Azurite.NormalEditor.Loader.Guard;

internal static class GuardBootstrap
{
    private const string Lab=@"F:\AzuriteLabs\Editor-20261108-normal";
    private const string Plugins=@"BepInEx\plugins\AzuriteNormalEditorPreparation";
    private const string Guard=@"BepInEx\patchers\AzuriteNormalEditorPreparation\Azurite.NormalEditor.Loader.Guard.PreparationOnly.dll";
    private static readonly List<FileStream> retained=new();
    private static readonly Dictionary<string,SafeFileHandle> retainedAncestors=new(StringComparer.OrdinalIgnoreCase);
    private static readonly string[] pluginNames={"Azurite.EditorIsolation.Policy.LabOnly","Azurite.NormalEditor.Policy.PreparationOnly","Azurite.NormalEditor.Adapter.Core.PreparationOnly","Azurite.NormalEditor.Adapter.Host.PreparationOnly","Azurite.NormalEditor.Entry.Core.PreparationOnly","Azurite.NormalEditor.Entry.Host.PreparationOnly","Azurite.NormalEditor.Entry.Evidence.PreparationOnly","Azurite.CacheRoot.Core.LabOnly","Azurite.NormalEditor.Loader.Core.PreparationOnly","Azurite.NormalEditor.Loader.Routes.PreparationOnly","Azurite.NormalEditor.Loader.PreparationOnly"};
    private static readonly Dictionary<string,string> earlyPins=new(){
        [@"BepInEx\core\BepInEx.Core.dll"]="352aacc2d5356489a00891f76db28b6463c81d25bcb02f90035171a669b7e35b",
        [@"BepInEx\core\BepInEx.Preloader.Core.dll"]="ec168752c9a885d9fe035370ac2dbd8b52b91b24cb60fbc425cfcbee5436dae9",
        [@"BepInEx\core\BepInEx.Unity.IL2CPP.dll"]="62c8246a3076bfe459ec80c482381228d0eb1dde3434fe97ae5255fef406fe72",
        [@"BepInEx\core\0Harmony.dll"]="6c898933b52149e8bcf6722305c7e4d94add47c9e53b364096f91721624c0877",
        [Plugins+@"\Azurite.EditorIsolation.Policy.LabOnly.dll"]="2f6297caec213d87464efad1a387230e40943b89eb71333fb65c8e03dc0d7653",
        [Plugins+@"\Azurite.NormalEditor.Policy.PreparationOnly.dll"]="9030d49768ad4a8d773eaf2751a2293241f6f2ee65f0695ca742a8cf2bb0f3e6",
        [Plugins+@"\Azurite.NormalEditor.Adapter.Core.PreparationOnly.dll"]="c492fcc53f915b3cce361391772e08a186ac203e54aa61ff762606a8268bb53b",
        [Plugins+@"\Azurite.NormalEditor.Adapter.Host.PreparationOnly.dll"]="501893e88775505ee570588556591e5b0b5d0c49bd6fb497d573f3d0ba7a2f80",
        [Plugins+@"\Azurite.NormalEditor.Entry.Core.PreparationOnly.dll"]="1d518f2a4f4e558779f998344ed9307dae2bc04bbe465ed9bd41594d6e5dae51",
        [Plugins+@"\Azurite.NormalEditor.Entry.Host.PreparationOnly.dll"]="933f10572c43d1b4775744d58031a5b57e2c960e285f746641d5988216796396",
        [Plugins+@"\Azurite.NormalEditor.Entry.Evidence.PreparationOnly.dll"]="9cd8534ddb2eb8d17500e7ec6923d90c7421dcf505f3d90ef8acea70463a340a",
        [Plugins+@"\Azurite.CacheRoot.Core.LabOnly.dll"]="32ac8c188e676779c371d628c96c493ec8f7866da04e17e014a92f97895c8ed7"};
    internal sealed record Prepared(Assembly Core,string ManifestPath,string PreparationSha256);
    internal static bool IsOwnChild(){using var p=Process.GetCurrentProcess();return Same(p.MainModule?.FileName,Path.Combine(Lab,"install","AzureArchive.exe"));}
    internal static Prepared Prepare()
    {
        if(!IsOwnChild())throw new InvalidOperationException("Not the exact normal child.");string install=Path.Combine(Lab,"install");
        if(!Same(typeof(GuardBootstrap).Assembly.Location,Path.Combine(install,Guard)))throw new InvalidOperationException("Guard loaded outside its fixed patcher path.");
        UniqueLoaded(typeof(GuardBootstrap).Assembly.GetName().Name!,Path.Combine(install,Guard));
        string manifest=Environment.GetEnvironmentVariable("AZURITE_EDITOR_ISOLATION_MANIFEST")??throw new InvalidOperationException("Normal manifest environment missing.");
        string expected=Environment.GetEnvironmentVariable("AZURITE_NORMAL_EDITOR_PREPARATION_SHA256")??throw new InvalidOperationException("External preparation SHA missing.");
        string run=Path.GetDirectoryName(manifest)??"";string id=Path.GetFileName(run);
        if(!Guid.TryParseExact(id,"D",out var guid)||guid.ToString("D")!=id||!Same(manifest,Path.Combine(Lab,"runs",id,"manifest.json")))throw new InvalidOperationException("Manifest is not the exact normal GUID run.");
        string record=Path.Combine(run,"normal-preparation.json");var data=Pin(record,expected,65536);using var json=JsonDocument.Parse(data);UniqueProperties(json.RootElement);var root=json.RootElement;
        if(root.GetProperty("Version").GetInt32()!=1||root.GetProperty("RunId").GetString()!=id)throw new InvalidOperationException("Preparation run identity differs.");
        _=Pin(manifest,root.GetProperty("ManifestSha256").GetString()!,16384);
        var list=root.GetProperty("Files").EnumerateArray().ToArray();if(list.Length>64)throw new InvalidOperationException("Unbounded deployment table.");
        var pins=new Dictionary<string,(string Hash,long Bytes)>(StringComparer.OrdinalIgnoreCase);
        foreach(var row in list){string relative=row.GetProperty("RelativePath").GetString()!;if(Path.IsPathRooted(relative)||relative.Contains('/')||relative.Contains(':')||relative.Split('\\').Any(x=>x.Length==0||x is "." or "..")||!pins.TryAdd(relative,(row.GetProperty("Sha256").GetString()!,row.GetProperty("Bytes").GetInt64())))throw new InvalidOperationException("Unsafe/duplicate deployment pin.");}
        foreach(var item in earlyPins)if(!pins.TryGetValue(item.Key,out var value)||value.Hash!=item.Value)throw new InvalidOperationException("Early pinned dependency differs: "+item.Key);
        foreach(string relative in earlyPins.Keys.Concat(pluginNames.Select(n=>Path.Combine(Plugins,n+".dll"))).Append(Guard).Distinct(StringComparer.OrdinalIgnoreCase)){
            if(!pins.TryGetValue(relative,out var pin))throw new InvalidOperationException("Required early dependency absent.");_=Pin(Path.Combine(install,relative),pin.Hash,536870912,pin.Bytes);
        }
        foreach(string name in new[]{"BepInEx.Core","BepInEx.Preloader.Core","BepInEx.Unity.IL2CPP","0Harmony"})UniqueLoaded(name,Path.Combine(install,"BepInEx","core",name+".dll"));
        Assembly? core=null;
        foreach(string name in pluginNames){string path=Path.Combine(install,Plugins,name+".dll");var existing=AppDomain.CurrentDomain.GetAssemblies().Where(a=>a.GetName().Name==name).ToArray();if(existing.Length==0)AssemblyLoadContext.Default.LoadFromAssemblyPath(path);var loaded=UniqueLoaded(name,path);if(name=="Azurite.NormalEditor.Loader.Core.PreparationOnly")core=loaded;}
        return new(core??throw new InvalidOperationException("Loader Core not resolved."),manifest,expected);
    }
    private static Assembly UniqueLoaded(string name,string path)
    {var found=AppDomain.CurrentDomain.GetAssemblies().Where(a=>a.GetName().Name==name).ToArray();if(found.Length!=1||AssemblyLoadContext.GetLoadContext(found[0])!=AssemblyLoadContext.Default||!Same(found[0].Location,path))throw new InvalidOperationException("Duplicate/foreign loaded dependency: "+name);return found[0];}
    private static byte[] Pin(string path,string hash,int max,long? exact=null)
    {
        if(hash is null||hash.Length!=64||!hash.All(c=>c is >= '0' and <= '9' or >= 'a' and <= 'f'))throw new InvalidOperationException("Invalid explicit bootstrap digest.");Safe(path);RetainAncestors(path);
        var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read);try{
            if(stream.Length<=0||stream.Length>max||exact is long bytes&&bytes!=stream.Length)throw new InvalidOperationException("Bootstrap file length differs.");
            if(!GetFileInformationByHandle(stream.SafeFileHandle,out var identity)||identity.Links!=1)throw new InvalidOperationException("Bootstrap file is not a single-link original.");
            using var sha=SHA256.Create();if(Convert.ToHexString(sha.ComputeHash(stream)).ToLowerInvariant()!=hash)throw new InvalidOperationException("Bootstrap file pin drift.");stream.Position=0;
            byte[] result=Array.Empty<byte>();if(max<=65536){result=new byte[checked((int)stream.Length)];int offset=0;while(offset<result.Length){int n=stream.Read(result,offset,result.Length-offset);if(n==0)throw new EndOfStreamException();offset+=n;}stream.Position=0;}
            retained.Add(stream);return result;
        }catch{stream.Dispose();throw;}
    }
    private static void Safe(string path)
    {if(!Path.IsPathFullyQualified(path)||path.Length<3||path[1]!=':'||path.Contains('/')||path.AsSpan(2).Contains(':')||!Same(Path.GetFullPath(path),path)||path.Split('\\').Skip(1).Any(p=>p is "." or ".."||p.EndsWith(' ')||p.EndsWith('.')))throw new InvalidOperationException("Noncanonical bootstrap path.");for(string? p=path;p is not null;p=Path.GetDirectoryName(p))if((File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0)throw new InvalidOperationException("Reparse bootstrap path.");}
    private static void UniqueProperties(JsonElement e){if(e.ValueKind==JsonValueKind.Object){var names=new HashSet<string>(StringComparer.Ordinal);foreach(var p in e.EnumerateObject()){if(!names.Add(p.Name))throw new InvalidOperationException("Duplicate preparation field.");UniqueProperties(p.Value);}}else if(e.ValueKind==JsonValueKind.Array)foreach(var p in e.EnumerateArray())UniqueProperties(p);}
    private static void RetainAncestors(string path)
    {
        var chain=new Stack<string>();for(string? p=Path.GetDirectoryName(path);p is not null;p=Path.GetDirectoryName(p))chain.Push(p);
        while(chain.Count>0){string p=chain.Pop();if(retainedAncestors.ContainsKey(p))continue;var h=CreateFileW(p,0,3,IntPtr.Zero,3,0x02000000,IntPtr.Zero);if(h.IsInvalid){h.Dispose();throw new IOException("Cannot retain bootstrap ancestor identity.");}retainedAncestors.Add(p,h);}
    }
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]private static extern SafeFileHandle CreateFileW(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
    private static bool Same(string? a,string? b)=>a is not null&&b is not null&&string.Equals(a,b,StringComparison.OrdinalIgnoreCase);
    [StructLayout(LayoutKind.Sequential)]private struct FileIdentity {public uint Attributes;public System.Runtime.InteropServices.ComTypes.FILETIME Creation,Access,Write;public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
    [DllImport("kernel32.dll",SetLastError=true)][return:MarshalAs(UnmanagedType.Bool)]private static extern bool GetFileInformationByHandle(SafeFileHandle handle,out FileIdentity info);
    [DllImport("kernel32.dll",ExactSpelling=true)]private static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll",ExactSpelling=true,SetLastError=true)][return:MarshalAs(UnmanagedType.Bool)]private static extern bool TerminateProcess(IntPtr process,uint code);
    internal static void AbortOwnChild(string reason)
    {if(!IsOwnChild())throw new InvalidOperationException("Cannot abort a foreign child: "+reason);TerminateProcess(GetCurrentProcess(),86);Environment.FailFast("Exact own-child normal startup abort failed: "+reason);}
}
