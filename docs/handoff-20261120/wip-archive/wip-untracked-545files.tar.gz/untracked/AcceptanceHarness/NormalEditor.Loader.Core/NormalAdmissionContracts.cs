using Azurite.NormalEditor.Adapter;

namespace Azurite.NormalEditor.Loader;

public sealed record NormalOwnerIdentity(int ProcessId,long ProcessCreationFileTime,int ManagedThreadId,uint NativeThreadId,string ExecutablePath,string LoaderAssemblyPath);
public sealed record NormalHostObservation(NormalOwnerIdentity Identity,IReadOnlyList<string> Arguments,bool CliActive,bool CliTransportPresent);
// This pre-native observation deliberately has no CliActive field. Absence of
// a native observation is never represented as a fabricated false value.
public sealed record NormalProcessObservation(NormalOwnerIdentity Identity,IReadOnlyList<string> Arguments,bool CliTransportPresent);

// The live implementation reads the actual current process/threads/argv and
// rechecks immutable prepared inputs. Tests supply explicit observation doubles.
public interface INormalAdmissionEnvironment
{
    NormalHostObservation Observe();
    NormalProcessObservation ObserveProcess();
    void RequireUnchanged();
}

public interface INormalGuardLink
{
    void RequireArmed(string manifestSha256);
    void RequireCompleted(string manifestSha256);
    void RequireStartupWindow(string manifestSha256);
    void RoutesReady(string manifestSha256,IReadOnlyCollection<string> routes);
}
