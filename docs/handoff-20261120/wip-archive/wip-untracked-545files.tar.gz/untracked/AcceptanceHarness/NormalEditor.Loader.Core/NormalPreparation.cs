using Azurite.EditorIsolation;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace Azurite.NormalEditor.Loader;

public sealed record NormalPreparedFile(string RelativePath,long Bytes,string Sha256);
public sealed record NormalResourceFacts(NormalResourcePreparation Preparation,string FilesJournalPath,string FilesJournalSha256);
public sealed record NormalPreparationFacts(int Version,string RunId,string ManifestSha256,string ExpectedNativeSettingsPath,NormalPreparedFile[] Files,NormalResourceFacts Resources);

public sealed class NormalPreparation : IDisposable
{
    private readonly Dictionary<string,(FileStream Stream,SafeFileHandle Handle,string Hash,long Bytes)> files=new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string,SafeFileHandle> directories=new(StringComparer.OrdinalIgnoreCase);
    private bool disposed;
    private NormalPreparation(){}
    public BoundManifest BoundManifest {get;private set;}=null!;
    public RunManifest Manifest {get;private set;}=null!;
    public NormalPreparationFacts Facts {get;private set;}=null!;
    public string EvidenceSha256 {get;private set;}="";
    public static NormalPreparation ReadAt(string approvedLabRoot,string manifestPath,string preparationSha256)
    {
        var result=new NormalPreparation();try{result.Read(approvedLabRoot,manifestPath,preparationSha256);return result;}catch{result.Dispose();throw;}
    }
    private void Read(string root,string manifestPath,string hash)
    {
        BoundManifest=BoundManifest.ReadAt(root,manifestPath);Manifest=BoundManifest.Parse();
        Require(Manifest.Mode=="normalObserverCatalogOnly","Only the normal catalog observer mode is eligible.");
        string preparation=Path.Combine(BoundManifest.RunRoot,"normal-preparation.json");
        Hold(manifestPath,BoundManifest.Sha256,16384);Hold(preparation,hash,65536);EvidenceSha256=hash;
        Exact(Json(manifestPath,16384),"Version","RunId","Mode","LabRoot","RunRoot","InstallRoot","SeedSha256","ControlSha256");
        var raw=ReadBytes(preparation,65536);var json=Parse(raw);Exact(json,"Version","RunId","ManifestSha256","ExpectedNativeSettingsPath","Files","Resources");
        Facts=JsonSerializer.Deserialize<NormalPreparationFacts>(raw)??throw new InvalidDataException("Missing normal preparation.");
        Shape(json,JsonSerializer.SerializeToElement(Facts));
        Require(Facts.Version==1&&Facts.RunId==Manifest.RunId&&Facts.ManifestSha256==BoundManifest.Sha256,"Preparation differs from the bound manifest identity.");
        Require(!string.IsNullOrWhiteSpace(Facts.ExpectedNativeSettingsPath)&&Facts.ExpectedNativeSettingsPath.Length<=32768&&!Facts.ExpectedNativeSettingsPath.Contains('\0'),"Actual constructor settings string is missing.");
        Require(Facts.Files is not null&&Facts.Files.Length is >0 and <=64,"Deployment facts are absent or unbounded.");var unique=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var file in Facts.Files!){Require(file is not null&&unique.Add(file.RelativePath),"Duplicate deployment file identity.");var path=Relative(Manifest.InstallRoot,file!.RelativePath);Require(file.Bytes>0&&file.Bytes<=536870912,"Deployment file size is invalid.");Hold(path,file.Sha256,536870912,file.Bytes);}
        Require(Facts.Resources is not null&&Facts.Resources.Preparation is not null,"Resource preparation facts absent.");ResourceInputs(Facts.Resources!);
        // This is deliberately performed only once. Native SaveTask may later
        // replace the run settings; it does not modify any held immutable input.
        Manifest.Validate(manifestPath);RequireUnchanged();
    }
    private void ResourceInputs(NormalResourceFacts value)
    {
        var r=value.Preparation;var paths=Manifest.Paths;Require(r.RequiredBundleCount is >0 and <=20000&&r.BundleBytes is >0 and <=17179869184,"Resource bundle bound differs.");
        foreach(var path in new[]{r.ContractPath,r.BundleManifestPath,r.OfflineRoot})Require(RunPaths.Below(path,paths.Lab)&&!RunPaths.Below(path,paths.Run)&&!RunPaths.Below(path,paths.Install),"Resource inputs must be in the separate prepared lab tree.");
        Require(RunPaths.Same(r.InstalledCatalogPath,Path.Combine(paths.Install,"AzureArchive_Data","StreamingAssets","aa","catalog.json"))&&RunPaths.Same(r.InstalledSettingsPath,Path.Combine(paths.Install,"AzureArchive_Data","StreamingAssets","aa","settings.json")),"Installed catalog/settings target differs.");
        Require(RunPaths.Same(Path.GetDirectoryName(r.OfflineCatalogPath),r.OfflineRoot)&&RunPaths.Same(Path.GetDirectoryName(r.CatalogHashPath),r.OfflineRoot)&&RunPaths.Same(r.MaterializationPath,Path.Combine(r.OfflineRoot,".azurite-staging","complete.json"))&&RunPaths.Same(value.FilesJournalPath,Path.Combine(r.OfflineRoot,".azurite-staging","files.jsonl")),"Offline payload/receipt locations differ.");
        Hold(r.ContractPath,r.ContractSha256,262144);Hold(r.BundleManifestPath,r.BundleManifestSha256,67108864);Hold(r.MaterializationPath,r.MaterializationSha256,1048576);Hold(value.FilesJournalPath,value.FilesJournalSha256,16777216);
        Hold(r.InstalledCatalogPath,r.CatalogSha256,67108864);Hold(r.OfflineCatalogPath,r.CatalogSha256,67108864);Hold(r.CatalogHashPath,r.CatalogHashSha256,256);Hold(r.InstalledSettingsPath,r.InstalledSettingsSha256,1048576);
        var contract=Json(r.ContractPath,262144);var completed=Json(r.MaterializationPath,1048576);var identity=completed.GetProperty("identity");
        string contractId=Text(contract,"contract_id");Require(!string.IsNullOrWhiteSpace(contractId)&&Text(completed,"contract_id")==contractId&&Text(identity,"contract_id")==contractId,"Materialization contract identity differs.");
        Require(Text(contract,"catalog_sha256")==r.CatalogSha256&&Text(contract,"catalog_hash_file_sha256")==r.CatalogHashSha256&&Text(contract,"bundle_payload_manifest_sha256")==r.BundleManifestSha256&&Number(contract,"required_bundle_count")==r.RequiredBundleCount&&Number(contract,"bundle_bytes")==r.BundleBytes,"Selected resource contract differs from preparation facts.");
        Require(Encoding.UTF8.GetString(ReadBytes(r.CatalogHashPath,256))==Text(contract,"catalog_hash_text"),"Catalog hash bytes/text differ.");
        var installed=contract.GetProperty("unchanged_executable_and_settings_files").EnumerateArray().Where(x=>Text(x,"RelativePath")==@"AzureArchive_Data\StreamingAssets\aa\settings.json").ToArray();
        Require(installed.Length==1&&Text(installed[0],"SHA256")==r.InstalledSettingsSha256&&Number(installed[0],"Bytes")==files[r.InstalledSettingsPath].Bytes,"Installed settings are not the selected resource settings.");
        Require(Number(completed,"schema")==1&&Text(completed,"status")=="staged_not_activated_not_native_accepted"&&completed.GetProperty("resource_set_complete").ValueKind==JsonValueKind.True&&completed.GetProperty("resource_contract_activated").ValueKind==JsonValueKind.False&&completed.GetProperty("normal_runtime_accepted").ValueKind==JsonValueKind.False&&completed.GetProperty("runtimeAllowed").ValueKind==JsonValueKind.False,"Materialization is not a complete original staged record.");
        Require(RunPaths.Same(Text(completed,"destination"),r.OfflineRoot)&&RunPaths.Same(Text(identity,"lab_root"),paths.Lab)&&Text(identity,"manifest_sha256")==r.BundleManifestSha256&&Text(identity,"proposal_sha256")==r.ContractSha256&&Text(identity,"staged_catalog_sha256")==r.CatalogSha256&&Text(identity,"staged_catalog_hash_file_sha256")==r.CatalogHashSha256,"Materialization was produced for a different lab/payload/contract.");
        Require(Text(completed,"files_journal_sha256")==value.FilesJournalSha256&&Number(completed,"files_journal_bytes")==files[value.FilesJournalPath].Bytes&&completed.GetProperty("errors").ValueKind==JsonValueKind.Array&&completed.GetProperty("errors").GetArrayLength()==0&&completed.GetProperty("preservation_before").GetRawText()==completed.GetProperty("preservation_after").GetRawText(),"Materialization journal/preservation/error evidence differs.");
        var expected=new Dictionary<string,(long Bytes,string Hash)>(StringComparer.OrdinalIgnoreCase);long bundleBytes=0;var payload=Json(r.BundleManifestPath,67108864);Require(payload.ValueKind==JsonValueKind.Array&&payload.GetArrayLength()==r.RequiredBundleCount,"Full payload manifest count differs.");
        foreach(var item in payload.EnumerateArray()){
            string relative=Text(item,"relative_path"),path=Relative(r.OfflineRoot,relative);long bytes=Number(item,"bytes");string sha=Text(item,"sha256");Require(bytes>0&&bytes<=1073741824&&Text(item,"status")=="full_payload_sha256_match"&&expected.TryAdd(relative,(bytes,sha)),"Duplicate or invalid bundle manifest item.");Hold(path,sha,1073741824,bytes);bundleBytes=checked(bundleBytes+bytes);
        }
        Require(bundleBytes==r.BundleBytes,"Actual bundle length sum differs.");
        foreach(var path in new[]{r.OfflineCatalogPath,r.CatalogHashPath})Require(expected.TryAdd(Path.GetFileName(path),(files[path].Bytes,files[path].Hash)),"Payload/catalog name collision.");
        int sequence=0;long total=0;var observed=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var line in Encoding.UTF8.GetString(ReadBytes(value.FilesJournalPath,16777216)).Split('\n',StringSplitOptions.RemoveEmptyEntries)){
            Require(Encoding.UTF8.GetByteCount(line)<=8192,"Materialization journal line exceeds bound.");var entry=Parse(Encoding.UTF8.GetBytes(line));string relative=Text(entry,"path");
            Require(Number(entry,"sequence")==++sequence&&observed.Add(relative)&&expected.TryGetValue(relative,out _),"Materialization journal sequence or membership differs.");var item=expected[relative];Require(Number(entry,"bytes")==item.Bytes&&Text(entry,"source_sha256")==item.Hash&&Text(entry,"destination_sha256")==item.Hash,"Materialization source/destination readback differs.");total=checked(total+item.Bytes);
        }
        Require(sequence==expected.Count&&Number(completed,"required_files")==sequence&&Number(completed,"verified_files")==sequence&&Number(completed,"payload_bytes")==total&&Number(completed,"verified_bytes")==total,"Materialization completion totals differ.");
    }
    private void Hold(string path,string hash,long maximum,long? exact=null)
    {
        Require(Hash(hash),"Explicit SHA-256 identity is missing.");RunPaths.RequireSafeExisting(path);LockAncestors(path);WindowsFileIdentity.RequireSingleLink(path);
        if(files.TryGetValue(path,out var previous)){Require(previous.Hash==hash&&(!exact.HasValue||previous.Bytes==exact.Value),"Conflicting input pins.");return;}
        // Retain the immutable handle, not one 64-KiB read buffer per bundle.
        var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read,1,FileOptions.SequentialScan);
        try{Require(stream.Length>0&&stream.Length<=maximum&&(!exact.HasValue||stream.Length==exact.Value),"Pinned input length differs: "+Path.GetFileName(path));using var algorithm=SHA256.Create();Require(Convert.ToHexString(algorithm.ComputeHash(stream)).ToLowerInvariant()==hash,"Pinned input SHA differs: "+Path.GetFileName(path));stream.Position=0;files.Add(path,(stream,stream.SafeFileHandle,hash,stream.Length));}catch{stream.Dispose();throw;}
    }
    private byte[] ReadBytes(string path,int max)
    {var stream=files[path].Stream;Require(stream.Length<=max,"JSON/read input bound exceeded.");stream.Position=0;var bytes=new byte[checked((int)stream.Length)];stream.ReadExactlyCompat(bytes);stream.Position=0;return bytes;}
    private JsonElement Json(string path,int max)=>Parse(ReadBytes(path,max));
    private static JsonElement Parse(byte[] bytes){using var doc=JsonDocument.Parse(bytes,new JsonDocumentOptions{MaxDepth=32});Unique(doc.RootElement);return doc.RootElement.Clone();}
    private static void Unique(JsonElement value){if(value.ValueKind==JsonValueKind.Object){var keys=new HashSet<string>(StringComparer.Ordinal);foreach(var p in value.EnumerateObject()){Require(keys.Add(p.Name),"Duplicate JSON property.");Unique(p.Value);}}else if(value.ValueKind==JsonValueKind.Array)foreach(var item in value.EnumerateArray())Unique(item);}
    private static void Exact(JsonElement value,params string[] keys)=>Require(value.ValueKind==JsonValueKind.Object&&value.EnumerateObject().Select(p=>p.Name).ToHashSet(StringComparer.Ordinal).SetEquals(keys),"Unknown/missing preparation property.");
    private static void Shape(JsonElement actual,JsonElement model)
    {
        Require(actual.ValueKind==model.ValueKind,"Preparation value shape differs.");
        if(actual.ValueKind==JsonValueKind.Object){Exact(actual,model.EnumerateObject().Select(p=>p.Name).ToArray());foreach(var p in model.EnumerateObject())Shape(actual.GetProperty(p.Name),p.Value);}
        else if(actual.ValueKind==JsonValueKind.Array){Require(actual.GetArrayLength()==model.GetArrayLength(),"Preparation array shape differs.");int i=0;foreach(var value in model.EnumerateArray())Shape(actual[i++],value);}
    }
    private static string Text(JsonElement e,string key)=>e.GetProperty(key).GetString()??throw new InvalidDataException("Missing string: "+key);
    private static long Number(JsonElement e,string key)=>e.GetProperty(key).GetInt64();
    private static string Relative(string root,string value)
    {Require(!string.IsNullOrWhiteSpace(value)&&!Path.IsPathRooted(value)&&!value.Contains(':')&&!value.Split('/','\\').Any(x=>x.Length==0||x is "." or ".."||x.EndsWith('.')||x.EndsWith(' ')),"Unsafe relative input path.");string path=Path.Combine(root,value.Replace('/',Path.DirectorySeparatorChar));Require(RunPaths.Below(path,root),"Input escapes root.");return path;}
    private static bool Hash(string? hash)=>hash is not null&&hash.Length==64&&hash.All(c=>c is >= '0' and <= '9' or >= 'a' and <= 'f')&&hash.Any(c=>c!='0');
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]private static extern SafeFileHandle CreateFileW(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
    private void LockAncestors(string path)
    {
        var chain=new Stack<string>();for(string? p=Path.GetDirectoryName(path);p is not null;p=Path.GetDirectoryName(p))chain.Push(p);
        while(chain.Count>0){string p=chain.Pop();if(directories.ContainsKey(p))continue;var handle=CreateFileW(p,0,3,IntPtr.Zero,3,0x02000000,IntPtr.Zero);if(handle.IsInvalid){handle.Dispose();throw new IOException("Unable to retain input ancestor identity.");}directories.Add(p,handle);}
    }
    public void RequireUnchanged()
    {
        if(disposed)throw new ObjectDisposedException(nameof(NormalPreparation));
        // Open share-read-only files and non-delete-sharing directory handles
        // retain exact bytes and ancestor identity, without rehashing 6 GiB on
        // every native callback or confusing a legal settings save with drift.
        foreach(var pair in directories)Require(!pair.Value.IsClosed&&!pair.Value.IsInvalid,"Prepared directory identity was released.");
        foreach(var item in files.Values)Require(item.Stream.CanRead&&!item.Handle.IsClosed&&!item.Handle.IsInvalid,"Prepared immutable input handle was released.");
    }
    public void Dispose(){if(disposed)return;disposed=true;foreach(var f in files.Values)f.Stream.Dispose();foreach(var d in directories.Values.Reverse())d.Dispose();}
    private static void Require(bool value,string reason){if(!value)throw new InvalidDataException(reason);}
}

internal static class BoundedStreamRead
{
    internal static void ReadExactlyCompat(this Stream stream,byte[] bytes){int offset=0;while(offset<bytes.Length){int read=stream.Read(bytes,offset,bytes.Length-offset);if(read==0)throw new EndOfStreamException("Bounded prepared input ended early.");offset+=read;}}
}
