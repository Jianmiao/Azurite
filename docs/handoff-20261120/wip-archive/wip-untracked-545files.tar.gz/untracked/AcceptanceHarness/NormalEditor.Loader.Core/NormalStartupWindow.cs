using Azurite.EditorIsolation;

namespace Azurite.NormalEditor.Loader;

public sealed class NormalStartupWindow : INormalGuardLink
{
    private readonly StartupGuardState state=new();
    private readonly NormalOwnerIdentity owner;
    private readonly Func<uint> nativeThread;
    private bool entered,completed;
    private int inCall;
    private string? failure;
    public NormalStartupWindow(string manifestSha256,NormalOwnerIdentity owner,Func<uint> nativeThread)
    {this.owner=owner??throw new ArgumentNullException(nameof(owner));this.nativeThread=nativeThread??throw new ArgumentNullException(nameof(nativeThread));state.Arm(manifestSha256);}
    public void EnterExecute()=>Run(()=>{Require(!entered&&!completed,"Duplicate chainloader continuation.");entered=true;});
    public void Complete(Exception? error)=>Run(()=>{
        if(error is not null)throw new InvalidOperationException("Chainloader failed before native startup could resume.",error);
        Require(entered,"Chainloader completion lacked its original entry.");
        if(completed)return;state.Complete(null);completed=true;
    });
    public void RequireArmed(string hash)=>Run(()=>state.RequireArmed(hash));
    public void RequireCompleted(string hash)=>Run(()=>{state.RequireCompleted(hash);Require(completed,"Chainloader completion is absent.");});
    public void RequireStartupWindow(string hash)=>Run(()=>{state.RequireArmed(hash);Window();});
    public void RoutesReady(string hash,IReadOnlyCollection<string> routes)=>Run(()=>{Window();state.RoutesReady(hash,routes);});
    private void Window()=>Require(entered&&!completed,"Actual chainloader Execute continuation is not held.");
    private void Run(Action action)
    {
        if(Environment.ProcessId!=owner.ProcessId||Environment.CurrentManagedThreadId!=owner.ManagedThreadId){Reject("Foreign guard owner process/thread.");throw new InvalidOperationException(failure);}
        if(Interlocked.CompareExchange(ref inCall,1,0)!=0){Reject("Reentrant guard observation.");throw new InvalidOperationException(failure);}
        try{Require(Volatile.Read(ref failure) is null,"Guard previously refused: "+failure);Require(nativeThread()==owner.NativeThreadId,"Actual native guard thread changed.");action();Require(Volatile.Read(ref failure) is null,"Guard was concurrently refused: "+failure);}
        catch(Exception error){Reject(error.Message);throw;}
        finally{Volatile.Write(ref inCall,0);}
    }
    private void Reject(string reason)=>Interlocked.CompareExchange(ref failure,reason,null);
    private static void Require(bool value,string why){if(!value)throw new InvalidOperationException(why);}
}
