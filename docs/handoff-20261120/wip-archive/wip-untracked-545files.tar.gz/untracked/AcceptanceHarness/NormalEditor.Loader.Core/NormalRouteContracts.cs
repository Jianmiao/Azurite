using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Entry;

namespace Azurite.NormalEditor.Loader;

// Data, not authority. The loader's real reader validates these exact pinned
// preparation/materialization inputs before issuing the one route context.
public sealed record NormalResourcePreparation(
    string ContractPath,
    string ContractSha256,
    string InstalledCatalogPath,
    string OfflineCatalogPath,
    string CatalogSha256,
    string InstalledSettingsPath,
    string InstalledSettingsSha256,
    string OfflineRoot,
    string CatalogHashPath,
    string CatalogHashSha256,
    string BundleManifestPath,
    string BundleManifestSha256,
    string MaterializationPath,
    string MaterializationSha256,
    int RequiredBundleCount,
    long BundleBytes);

public sealed record NormalRouteContext(
    AdapterBinding Binding,
    string ManifestSha256,
    NormalResourcePreparation Resources,
    Action<string> Reject,
    IFatalSink Fatal,
    Func<long> BoundSettingsOwner)
{
    // Synchronous assertion of the actual guarded Execute continuation only;
    // it does not attest unrelated native workers or cache/backend safety.
    public Action<AdapterBinding> RequireStartupWindow {get;init;} = _ => throw new InvalidOperationException("Startup window assertion absent.");
}

public interface INormalRoutes
{
    // Publish only after all hooks of a category pass ownership verification.
    // Exact categories: cache/workspace/discovery/offline/addressSet/addressClear/addressEvaluate.
    IReadOnlyCollection<string> InstalledRoutes { get; }
    void Register(NormalRouteContext context);
    void RequireResourceEntry(AdapterBinding binding,long resource,NativeSettings settings);
    // Consume already recorded facts only; called from catalog-ready recording.
    void RequireCatalogClosure(AdapterBinding binding,CatalogEvidence observation);
    // Keep containment hooks installed; do not call native cleanup or Seal.
    void RequireShutdownSafe(AdapterBinding binding);
}
