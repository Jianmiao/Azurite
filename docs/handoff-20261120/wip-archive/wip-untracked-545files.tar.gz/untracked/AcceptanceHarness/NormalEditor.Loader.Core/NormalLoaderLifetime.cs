using Azurite.NormalEditor.Adapter;
using Azurite.NormalEditor.Entry;
using Azurite.NormalEditor.Entry.Evidence;

namespace Azurite.NormalEditor.Loader;

public sealed class NormalLoaderLifetime
{
    private readonly AdapterBinding binding;
    private readonly NormalEntryAdmission admission;
    private readonly NormalOwnerIdentity owner;
    private readonly NormalResourcePreparation resources;
    private readonly INormalRoutes routes;
    private readonly INormalGuardLink guard;
    private readonly IFatalSink fatal;
    private readonly string manifestSha256;
    private readonly CatalogClockAnchor clock;
    private readonly CatalogEvidenceWriter writer;
    private readonly Action<AdapterBinding,IAdapterAdmission> registerAdapter;
    private readonly Action<AdapterBinding,IAdapterAdmission,Action<CatalogEvidence>,CatalogClockAnchor> registerCatalog;
    private readonly Func<bool> closeCatalog;
    private static readonly object Retired=new();
    private object? decision;
    private int inCall;
    private bool attempted,registered,closed;
    public NormalLoaderLifetime(AdapterBinding binding,NormalEntryAdmission admission,NormalOwnerIdentity owner,NormalResourcePreparation resources,INormalRoutes routes,INormalGuardLink guard,IFatalSink fatal,string manifestSha256,CatalogClockAnchor clock,CatalogEvidenceWriter writer,Action<AdapterBinding,IAdapterAdmission> registerAdapter,Action<AdapterBinding,IAdapterAdmission,Action<CatalogEvidence>,CatalogClockAnchor> registerCatalog,Func<bool> closeCatalog)
    {
        this.binding=binding??throw new ArgumentNullException(nameof(binding));this.admission=admission??throw new ArgumentNullException(nameof(admission));this.owner=owner??throw new ArgumentNullException(nameof(owner));this.resources=resources??throw new ArgumentNullException(nameof(resources));
        this.routes=routes??throw new ArgumentNullException(nameof(routes));this.guard=guard??throw new ArgumentNullException(nameof(guard));this.fatal=fatal??throw new ArgumentNullException(nameof(fatal));this.manifestSha256=manifestSha256;this.clock=clock??throw new ArgumentNullException(nameof(clock));this.writer=writer??throw new ArgumentNullException(nameof(writer));
        this.registerAdapter=registerAdapter??throw new ArgumentNullException(nameof(registerAdapter));this.registerCatalog=registerCatalog??throw new ArgumentNullException(nameof(registerCatalog));this.closeCatalog=closeCatalog??throw new ArgumentNullException(nameof(closeCatalog));
    }
    public bool Registered=>registered&&Failure is null;
    public bool Closed=>closed&&Failure is null;
    public string? Failure=>(Volatile.Read(ref decision) as Refusal)?.Reason??admission.Failure;
    public void Register()
    {
        Enter();try{
            Require(!attempted,"Normal loader registration is single-use.");attempted=true;PreNativeContext();
            guard.RequireStartupWindow(manifestSha256);
            routes.Register(new(binding,manifestSha256,resources,Reject,fatal,()=>admission.BoundSettingsOwner){RequireStartupWindow=supplied=>{
                try{Require(OnOwner()&&ReferenceEquals(supplied,binding),"Startup window belongs to a different owner/binding.");PreNativeContext();guard.RequireStartupWindow(manifestSha256);}
                catch(Exception error){Reject(error.Message);throw;}
            }});Healthy();
            Context(false);registerAdapter(binding,admission);Context(false);
            var ids=routes.InstalledRoutes.ToArray();var required=new[]{"cache","workspace","discovery","offline","addressSet","addressClear","addressEvaluate"};
            Require(ids.Length==required.Length&&ids.ToHashSet(StringComparer.Ordinal).SetEquals(required),"Normal route installation is incomplete.");
            registerCatalog(binding,admission,Record,clock);Context(false);
            // The five adapter categories are contributed only after actual Register returns.
            guard.RoutesReady(manifestSha256,ids.Concat(new[]{"awake","read","write","fallback","resources"}).ToArray());Healthy();registered=true;
        }catch(Exception error){Reject(error.Message);fatal.Terminate("Normal loader registration failed: "+error.Message);throw new InvalidOperationException(Failure,error);}
        finally{Volatile.Write(ref inCall,0);}
    }
    public void Record(CatalogEvidence evidence)
    {
        // Entry.Host retires its producer before Close succeeds. Delayed delivery
        // after the same atomic retirement decision must not reopen/poison a seal.
        if(ReferenceEquals(Volatile.Read(ref decision),Retired))return;
        Enter();try{
            Require(registered,"Catalog evidence preceded complete loader registration.");Context(true);ArgumentNullException.ThrowIfNull(evidence);
            var stamp=evidence.Stamp;Require(evidence.RunId==binding.Policy.RunId&&stamp is not null&&stamp.RunId==binding.Policy.RunId&&stamp.ProcessId==owner.ProcessId&&stamp.ManagedThreadId==owner.ManagedThreadId&&stamp.NativeThreadId==owner.NativeThreadId,"Foreign catalog evidence identity.");
            if(evidence.Kind=="catalog-ready")routes.RequireCatalogClosure(binding,evidence);
            Context(true);writer.Record(evidence);Healthy();
            if(evidence.Kind=="catalog-failed")Reject(evidence.Failure??"Catalog observer failed.");
        }catch(Exception error){Reject(error.Message);throw new InvalidOperationException(Failure,error);}
        finally{Volatile.Write(ref inCall,0);}
    }
    public bool Close()
    {
        // A foreign close has no authority to call any owner observer or writer.
        if(!OnOwner()||ReferenceEquals(Volatile.Read(ref decision),Retired))return false;
        bool entered=false;
        try{
            Enter();entered=true;Require(registered,"Normal close requires completed loader registration.");Context(true);
            routes.RequireShutdownSafe(binding);Context(true);
            Require(closeCatalog(),"CatalogEntryHost refused owner-thread normal Close.");Healthy();
            // A foreign/reentrant Record may win before this commit; it then
            // makes sealing impossible even when the close delegate returns true.
            Require(Interlocked.CompareExchange(ref decision,Retired,null) is null,"Catalog delivery raced with normal close commit.");
            writer.Seal();writer.Dispose();closed=true;return true;
        }catch(Exception error){Reject(error.Message);return false;}
        finally{if(entered)Volatile.Write(ref inCall,0);}
    }
    private bool OnOwner()=>Environment.ProcessId==owner.ProcessId&&Environment.CurrentManagedThreadId==owner.ManagedThreadId;
    private void Enter()
    {
        if(!OnOwner()){Reject("Foreign loader lifetime process/thread.");throw new InvalidOperationException(Failure);}
        if(Interlocked.CompareExchange(ref inCall,1,0)!=0){Reject("Reentrant loader registration/evidence/close.");throw new InvalidOperationException(Failure);}
    }
    private void Context(bool completed){Healthy();guard.RequireArmed(manifestSha256);if(completed)guard.RequireCompleted(manifestSha256);admission.RequireInstallation(binding);Healthy();}
    private void PreNativeContext(){Healthy();guard.RequireArmed(manifestSha256);admission.RequirePreNativeInstallation(binding);Healthy();}
    private void Healthy()=>Require(Failure is null,"Normal loader lifetime already failed: "+Failure);
    private void Reject(string reason){Interlocked.CompareExchange(ref decision,new Refusal(reason),null);admission.Revoke(reason);}
    private sealed record Refusal(string Reason);
    private static void Require(bool condition,string reason){if(!condition)throw new InvalidOperationException(reason);}
}
