using Azurite.NormalEditor.Adapter;
using Azurite.EditorIsolation;

namespace Azurite.NormalEditor.Loader;

public sealed class NormalEntryAdmission : IAdapterAdmission
{
    private readonly AdapterBinding binding;
    private readonly string manifestSha256;
    private readonly NormalOwnerIdentity owner;
    private readonly NormalResourcePreparation resources;
    private readonly INormalAdmissionEnvironment environment;
    private readonly INormalRoutes routes;
    private readonly INormalGuardLink guard;
    private readonly Action<RouteRecord> audit;
    private string? failure;
    private int inCall;
    private long candidateOwner,boundOwner;
    private RouteRecord? pending;
    private bool intentRecorded;
    public NormalEntryAdmission(AdapterBinding binding,string manifestSha256,string evidenceSha256,NormalOwnerIdentity owner,NormalResourcePreparation resources,INormalAdmissionEnvironment environment,INormalRoutes routes,INormalGuardLink guard,Action<RouteRecord> audit)
    {
        this.binding=binding??throw new ArgumentNullException(nameof(binding));this.owner=owner??throw new ArgumentNullException(nameof(owner));
        this.resources=resources??throw new ArgumentNullException(nameof(resources));this.environment=environment??throw new ArgumentNullException(nameof(environment));
        this.routes=routes??throw new ArgumentNullException(nameof(routes));this.guard=guard??throw new ArgumentNullException(nameof(guard));this.audit=audit??throw new ArgumentNullException(nameof(audit));
        Require(Hash(manifestSha256)&&Hash(evidenceSha256)&&Hash(binding.HostAssemblySha256)&&Hash(binding.CoreAssemblySha256),"Missing exact preparation/deployment evidence identity.");
        Require(owner.ProcessId==binding.Policy.ProcessId&&owner.NativeThreadId==binding.Policy.NativeThreadId&&owner.ProcessCreationFileTime>0&&owner.ManagedThreadId>0,"Owner identity differs from the bound normal adapter.");
        Require(RunPaths.Same(owner.ExecutablePath,Path.Combine(binding.Policy.Paths.Install,"AzureArchive.exe"))&&RunPaths.Same(owner.LoaderAssemblyPath,Path.Combine(binding.Policy.Paths.Install,InstallationAuthority.AdapterSubdirectory,"Azurite.NormalEditor.Loader.PreparationOnly.dll")),"Loader/executable identity is outside the bound installation.");
        this.manifestSha256=manifestSha256;EvidenceSha256=evidenceSha256;
    }
    public string EvidenceSha256 {get;}
    public string? Failure=>Volatile.Read(ref failure);
    public long BoundSettingsOwner=>Failure is null?Interlocked.Read(ref boundOwner):0;
    // Native/foreign refusal must never enter a writer or the owner evidence lock.
    public void Revoke(string reason)=>Interlocked.CompareExchange(ref failure,string.IsNullOrWhiteSpace(reason)?"Normal admission revoked.":reason,null);
    public void RequireInstallation(AdapterBinding supplied)=>Run(supplied,false,()=>{});
    public void RequirePreNativeInstallation(AdapterBinding supplied)=>Run(supplied,false,()=>{},nativeObservation:false);
    public void RequireCallback(AdapterBinding supplied,CallbackKind kind,long instance)=>Run(supplied,true,()=>{
        Require(Enum.IsDefined(typeof(CallbackKind),kind)&&instance>0,"Unknown callback kind or absent native instance.");
        if(kind==CallbackKind.Awake){Require(candidateOwner==0||candidateOwner==instance,"Settings Awake owner changed.");candidateOwner=instance;}
        else if(kind is CallbackKind.Write or CallbackKind.Coroutine)Require(candidateOwner>0&&instance==candidateOwner,"Settings callback owner differs.");
    });
    public void RequireRouting(AdapterBinding supplied,RouteRecord intent)=>Run(supplied,true,()=>{
        Require(pending is null,"A prior routing audit is still incomplete.");
        Require(intent is not null&&intent.After is null&&candidateOwner>0&&intent.Before.Owner==candidateOwner,"Routing lacks the bound Awake owner or is not an intent.");
        Require(intent!.Before.Data==0&&!intent.Before.Ready&&!intent.Before.Dirty&&!intent.Before.CliActive&&!intent.Before.TransportPresent,"Routing must preserve the actual pristine, non-CLI native owner.");
        bool settings=intent.Field=="settingFilePath",workspace=intent.Field=="_cachedWorkspacePath";
        Require((settings||workspace)&&RunPaths.Same(intent.Target,settings?binding.Policy.Paths.Settings:binding.Policy.Paths.Workspace),"Only the two fixed run fields may be routed.");
        Require(intent.Stage==RouteStage.Awake||(intent.Stage==RouteStage.InitReadYield&&settings&&intent.Before.SettingsPath==binding.ExpectedNativeSettingsPath),"Routing stage or actual native default string differs.");
        pending=intent;intentRecorded=false;
    });
    public void RecordRouting(RouteRecord record)=>Run(binding,true,()=>{
        Require(pending is not null&&record is not null&&(record with{After=null})==pending,"Routing audit lacks the exact pending intent.");
        if(record!.After is null){Require(!intentRecorded,"Duplicate routing intent audit.");audit(record);CheckContext(true);Healthy();intentRecorded=true;return;}
        Require(intentRecorded,"Routing after preceded its intent audit.");
        var after=record.After;
        var restored=record.Field=="settingFilePath"?after with{SettingsPath=record.Before.SettingsPath}:after with{CachedWorkspace=record.Before.CachedWorkspace};
        Require(restored==record.Before&&(record.Field=="settingFilePath"?after.SettingsPath:after.CachedWorkspace)==record.Target,"Actual routing after changed an unauthorized field or missed its target.");
        audit(record);CheckContext(true);Healthy();
        if(record.Stage==RouteStage.Awake){Require(boundOwner==0||boundOwner==record.Before.Owner,"Verified settings owner changed.");Interlocked.Exchange(ref boundOwner,record.Before.Owner);}
        pending=null;intentRecorded=false;
    });
    public void RequireResources(AdapterBinding supplied,long resource,NativeSettings settings)=>Run(supplied,true,()=>{
        Require(resource>0&&BoundSettingsOwner>0&&settings.Owner==BoundSettingsOwner&&!settings.CliActive&&!settings.TransportPresent,"Resource entry lacks the verified normal settings owner.");
        // Do not require Ready: original OnReady invokes Initialize before the flag store.
        routes.RequireResourceEntry(binding,resource,settings);
    });
    public void AssertPermitted(NormalBinding supplied,NormalStep step,SettingsObservation observation)=>Run(binding,true,()=>{
        Require(ReferenceEquals(supplied,binding.Policy)&&Enum.IsDefined(typeof(NormalStep),step),"Policy binding or step differs.");
        Require(observation.RunId==supplied.RunId&&observation.Generation==supplied.Generation&&observation.ProcessId==owner.ProcessId&&observation.NativeThreadId==owner.NativeThreadId&&candidateOwner>0&&observation.Owner==candidateOwner,"Policy observation belongs to a different run/generation/native owner.");
        // Original NormalSettingsLifecycle alone owns init/save/readiness ordering.
    });
    private void Run(AdapterBinding supplied,bool completed,Action action,bool nativeObservation=true)
    {
        if(Environment.ProcessId!=owner.ProcessId||Environment.CurrentManagedThreadId!=owner.ManagedThreadId){Revoke("Foreign actual normal admission process/thread.");throw new InvalidOperationException(Failure);}
        if(Interlocked.CompareExchange(ref inCall,1,0)!=0){Revoke("Reentrant normal admission callback.");throw new InvalidOperationException(Failure);}
        try{Healthy();Require(ReferenceEquals(supplied,binding),"Admission is bound to a different AdapterBinding object.");CheckContext(completed,nativeObservation);action();CheckContext(completed,nativeObservation);Healthy();}
        catch(Exception e){Revoke(e.Message);throw new InvalidOperationException(Failure,e);}
        finally{Volatile.Write(ref inCall,0);}
    }
    private void CheckContext(bool completed,bool nativeObservation=true)
    {
        Healthy();guard.RequireArmed(manifestSha256);if(completed)guard.RequireCompleted(manifestSha256);
        IReadOnlyList<string> arguments;
        if(nativeObservation){var actual=environment.Observe();Healthy();Require(actual is not null&&actual.Identity==owner&&!actual.CliActive&&!actual.CliTransportPresent,"Actual normal host identity or CLI context changed.");arguments=actual!.Arguments;}
        else{var actual=environment.ObserveProcess();Healthy();Require(actual is not null&&actual.Identity==owner&&!actual.CliTransportPresent,"Actual pre-native process/transport identity changed.");arguments=actual!.Arguments;}
        RequireLaunchArguments(arguments,binding.Policy.Paths,owner.ExecutablePath,resources.OfflineRoot);environment.RequireUnchanged();Healthy();
    }
    public static void RequireLaunchArguments(IReadOnlyList<string> arguments,RunPaths paths,string executable,string offlineRoot)
    {
        Require(arguments is not null,"Actual normal launch arguments are unavailable.");
        int start=arguments!.Count>0&&RunPaths.Same(arguments[0],executable)?1:0;var seen=new HashSet<string>(StringComparer.Ordinal);
        for(int i=start;i<arguments.Count;i++){
            string value=arguments[i];Require(seen.Add(value),"Duplicate normal launch option.");
            if(value is "-batchmode" or "-nographics" or "-disableaudio")continue;
            Require(value is "-logFile" or "--aap-offline-resources","Unbound normal launch option.");
            Require(++i<arguments.Count,"Normal launch option lacks its actual value.");
            Require(RunPaths.Same(arguments[i],value=="-logFile"?Path.Combine(paths.Output,"unity.log"):offlineRoot),"Actual normal log/offline resource path differs.");
        }
        Require(seen.SetEquals(new[]{"-batchmode","-nographics","-disableaudio","-logFile","--aap-offline-resources"}),"Normal headless/NoSound/offline argument set is incomplete.");
    }
    private void Healthy()=>Require(Failure is null,"Normal admission is already revoked: "+Failure);
    private static bool Hash(string? text)=>text is not null&&text.Length==64&&text.All(c=>c is >= '0' and <= '9' or >= 'a' and <= 'f')&&text.Any(c=>c!='0');
    private static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
