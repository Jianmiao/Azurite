using Azurite.NormalEditor.Adapter;
using Azurite.EditorIsolation;
using System.Reflection;
using System.Runtime.Loader;

namespace Azurite.NormalEditor.Loader;

public static class NormalDeployment
{
    public const string GuardRelativePath=@"BepInEx\patchers\AzuriteNormalEditorPreparation\Azurite.NormalEditor.Loader.Guard.PreparationOnly.dll";
    public static readonly IReadOnlyList<string> PluginNames=Array.AsReadOnly(new[]{"Azurite.EditorIsolation.Policy.LabOnly","Azurite.NormalEditor.Policy.PreparationOnly","Azurite.NormalEditor.Adapter.Core.PreparationOnly","Azurite.NormalEditor.Adapter.Host.PreparationOnly","Azurite.NormalEditor.Entry.Core.PreparationOnly","Azurite.NormalEditor.Entry.Host.PreparationOnly","Azurite.NormalEditor.Entry.Evidence.PreparationOnly","Azurite.CacheRoot.Core.LabOnly","Azurite.NormalEditor.Loader.Core.PreparationOnly","Azurite.NormalEditor.Loader.Routes.PreparationOnly","Azurite.NormalEditor.Loader.PreparationOnly"});
    public static IReadOnlyDictionary<string,string?> RequiredFiles {get;}=CreateFiles();
    private static IReadOnlyDictionary<string,string?> CreateFiles()
    {
        var result=HostContract.Files.ToDictionary(p=>p.Key.Replace('/','\\'),p=>(string?)p.Value,StringComparer.OrdinalIgnoreCase);
        result.Add("AzureArchive.exe","260fc3ecc5f38dab5230ba624a52e495708d861196dda72486c1250760fe6eff");
        result.Add(@"BepInEx\interop\Unity.ResourceManager.dll","deb4598e5eb03b0dae8f165016fff8ded4445542f8926330b249e969e40608f6");
        result.Add(@"BepInEx\interop\Il2Cppmscorlib.dll","07ac56bc73cafaaf853010a1a2418beb47ceaa792c2cec0fc8692db65f90491a");
        result.Add(@"BepInEx\core\Il2CppInterop.Common.dll","070e04f2276a8963a6d2a7eb52d43b644f3ae9aa3816c34541124d3862f1b37f");
        string[] frozen={BindingCatalog.LegacyPolicyHash,BindingCatalog.NormalPolicyHash,"c492fcc53f915b3cce361391772e08a186ac203e54aa61ff762606a8268bb53b","501893e88775505ee570588556591e5b0b5d0c49bd6fb497d573f3d0ba7a2f80","1d518f2a4f4e558779f998344ed9307dae2bc04bbe465ed9bd41594d6e5dae51","933f10572c43d1b4775744d58031a5b57e2c960e285f746641d5988216796396","9cd8534ddb2eb8d17500e7ec6923d90c7421dcf505f3d90ef8acea70463a340a","32ac8c188e676779c371d628c96c493ec8f7866da04e17e014a92f97895c8ed7"};
        for(int i=0;i<PluginNames.Count;i++)result.Add(Path.Combine(InstallationAuthority.AdapterSubdirectory,PluginNames[i]+".dll"),i<frozen.Length?frozen[i]:null);
        result.Add(GuardRelativePath,null);return new System.Collections.ObjectModel.ReadOnlyDictionary<string,string?>(result);
    }
    public static void RequireMap(IEnumerable<NormalPreparedFile> files)
    {
        var rows=files.ToArray();if(rows.Length!=RequiredFiles.Count||rows.Select(f=>f.RelativePath).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=rows.Length)throw new InvalidOperationException("Incomplete/duplicate normal deployment file map.");
        foreach(var row in rows)if(!RequiredFiles.TryGetValue(row.RelativePath,out var known)||known is not null&&row.Sha256!=known)throw new InvalidOperationException("Unselected normal deployment component: "+row.RelativePath);
    }
    public static void RequireLoaded(string install,IEnumerable<string> names)
    {
        foreach(string name in names){var found=AppDomain.CurrentDomain.GetAssemblies().Where(a=>a.GetName().Name==name).ToArray();string relative=PluginNames.Contains(name)?Path.Combine(InstallationAuthority.AdapterSubdirectory,name+".dll"):name=="Azurite.NormalEditor.Loader.Guard.PreparationOnly"?GuardRelativePath:Path.Combine("BepInEx","core",name+".dll");
            if(found.Length!=1||AssemblyLoadContext.GetLoadContext(found[0])!=AssemblyLoadContext.Default||!RunPaths.Same(found[0].Location,Path.Combine(install,relative)))throw new InvalidOperationException("Duplicate or foreign normal assembly identity: "+name);
        }
    }
}
