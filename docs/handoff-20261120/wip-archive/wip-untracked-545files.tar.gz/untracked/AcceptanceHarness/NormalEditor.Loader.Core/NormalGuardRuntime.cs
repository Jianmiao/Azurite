using Azurite.EditorIsolation;
using Azurite.NormalEditor.Adapter;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Azurite.NormalEditor.Loader;

// Reached only through the uniquely loaded F guard after its BCL-only bootstrap
// has pinned this assembly and both original Policy identities.
public static class NormalGuardRuntime
{
    private static NormalGuardSession? session;
    private static int attempted;
    public static void Arm(string manifestPath,string preparationSha256)
    {
        if(Interlocked.Exchange(ref attempted,1)!=0)throw new InvalidOperationException("Duplicate normal Guard bootstrap.");
        using var process=Process.GetCurrentProcess();string install=Path.Combine(InstallationAuthority.ApprovedLabRoot,"install");string executable=process.MainModule?.FileName??throw new InvalidOperationException("Actual executable identity missing.");
        if(!RunPaths.Same(executable,Path.Combine(install,"AzureArchive.exe")))throw new InvalidOperationException("Guard is outside its exact normal child.");
        NormalDeployment.RequireLoaded(install,NormalDeployment.PluginNames.Concat(new[]{"Azurite.NormalEditor.Loader.Guard.PreparationOnly","BepInEx.Core","BepInEx.Preloader.Core","BepInEx.Unity.IL2CPP","0Harmony"}));
        var prepared=NormalPreparation.ReadAt(InstallationAuthority.ApprovedLabRoot,manifestPath,preparationSha256);
        try{
            NormalDeployment.RequireMap(prepared.Facts.Files);
            NormalEntryAdmission.RequireLaunchArguments(Environment.GetCommandLineArgs(),prepared.Manifest.Paths,executable,prepared.Facts.Resources.Preparation.OfflineRoot);
            if(!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("AZUREARCHIVE_CLI_DIRECTORY")))throw new InvalidOperationException("Normal guard cannot arm with CLI transport present.");
            var owner=new NormalOwnerIdentity(process.Id,process.StartTime.ToUniversalTime().ToFileTimeUtc(),Environment.CurrentManagedThreadId,NativeThreadId(),executable,Path.Combine(install,InstallationAuthority.AdapterSubdirectory,"Azurite.NormalEditor.Loader.PreparationOnly.dll"));
            session=new NormalGuardSession(prepared,owner,new NormalStartupWindow(prepared.BoundManifest.Sha256,owner,NativeThreadId));
        }catch{prepared.Dispose();throw;}
    }
    public static NormalGuardSession Current=>session??throw new InvalidOperationException("Normal guard has not armed.");
    public static void EnterExecute()=>Current.EnterExecute();
    public static void Complete(Exception? failure)=>Current.Complete(failure);
    [DllImport("kernel32.dll",EntryPoint="GetCurrentThreadId",ExactSpelling=true)]public static extern uint NativeThreadId();
}

public sealed class NormalGuardSession : INormalGuardLink,IFatalSink
{
    private readonly NormalStartupWindow window;
    private readonly CorrelatedEvidence evidence;
    private int loaderTaken;
    internal NormalGuardSession(NormalPreparation prepared,NormalOwnerIdentity owner,NormalStartupWindow window)
    {Preparation=prepared;Owner=owner;this.window=window;evidence=new CorrelatedEvidence(prepared.BoundManifest,"editor-isolation-guardian.jsonl");evidence.Emit("normal-guard-armed",new{owner.ProcessId,owner.ProcessCreationFileTime,owner.ManagedThreadId,owner.NativeThreadId,prepared.EvidenceSha256,nativeStartupProved=false});}
    public NormalPreparation Preparation {get;}
    public NormalOwnerIdentity Owner {get;}
    public void ClaimLoader()
    {RequireStartupWindow(Preparation.BoundManifest.Sha256);if(Interlocked.Exchange(ref loaderTaken,1)!=0)throw new InvalidOperationException("Duplicate normal loader invocation.");}
    public void EnterExecute(){window.EnterExecute();evidence.Emit("normal-chainloader-enter",new{continuationHeld=true,nativeWorkersExcluded=false});}
    public void Complete(Exception? failure){window.Complete(failure);evidence.Emit("normal-chainloader-return-admitted",new{nativeStartupMayResume=true,normalReadinessProved=false});}
    public void RequireArmed(string hash){Preparation.RequireUnchanged();window.RequireArmed(hash);}
    public void RequireCompleted(string hash){Preparation.RequireUnchanged();window.RequireCompleted(hash);}
    public void RequireStartupWindow(string hash){Preparation.RequireUnchanged();window.RequireStartupWindow(hash);}
    public void RoutesReady(string hash,IReadOnlyCollection<string> routes){window.RoutesReady(hash,routes);evidence.Emit("normal-hooks-installed",new{routes,nativeHitsProved=false});}
    public void Terminate(string reason)
    {
        using var current=Process.GetCurrentProcess();
        if(current.Id!=Owner.ProcessId||current.StartTime.ToUniversalTime().ToFileTimeUtc()!=Owner.ProcessCreationFileTime||!RunPaths.Same(current.MainModule?.FileName,Owner.ExecutablePath)||!RunPaths.Same(Owner.ExecutablePath,Path.Combine(InstallationAuthority.ApprovedLabRoot,"install","AzureArchive.exe")))throw new InvalidOperationException("Abort cannot target a foreign/unapproved child.");
        // A foreign refusal must not enter the owner evidence writer lock.
        if(Environment.CurrentManagedThreadId==Owner.ManagedThreadId){try{evidence.Emit("normal-guard-abort",new{reason});evidence.Flush();}catch{}}
        OwnProcessAbort.Terminate(86);
    }
}
