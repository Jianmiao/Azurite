# Normal preparation facts v1

This is an input schema for a future Root-owned normal experiment. No actual normal record is included in this SOURCE implementation. A staging receipt is evidence of staged bytes, not permission or proof of native acceptance.

The approved installation remains `F:\AzuriteLabs\Editor-20261108-normal\install`. A run uses the existing eight-field `runs\GUID-D\manifest.json` and 26-field fresh settings/control seeds. The exact manifest path is supplied by `AZURITE_EDITOR_ISOLATION_MANIFEST`. Its sibling `normal-preparation.json` is bounded to 64 KiB, and its expected lowercase SHA-256 comes from `AZURITE_NORMAL_EDITOR_PREPARATION_SHA256`. The bootstrap validates that external digest before parsing the file.

The preparation JSON has exactly these root properties; unknown and duplicate properties are rejected recursively:

| Property | Meaning |
| --- | --- |
| `Version` | Integer 1. |
| `RunId` | Exact GUID-D matching the bound manifest and directory. |
| `ManifestSha256` | SHA-256 of the original bounded manifest bytes. |
| `ExpectedNativeSettingsPath` | Externally verified original native constructor string; not discovered by reading daily settings. |
| `Files` | Exact deployment map: entries have `RelativePath`, positive `Bytes`, lowercase `Sha256`. |
| `Resources` | Object containing `Preparation`, `FilesJournalPath`, `FilesJournalSha256`. |

`Files` must exactly match `NormalDeployment.RequiredFiles`. Paths are relative to the fixed install directory. Original Host, interop, Policy, Adapter, Entry, Evidence and pure CacheRoot.Core hashes remain fixed. The four new component hashes (Loader.Core, Loader.Routes, Loader and Guard) must match the final independently reviewed deployment. The record includes the Guard under `BepInEx\patchers\AzuriteNormalEditorPreparation`; all eleven plugin dependencies share `BepInEx\plugins\AzuriteNormalEditorPreparation`. It does not place a second Policy/Core copy in patchers. CacheRoot.Core is the original decoder/pins library, SHA `32ac8c188e676779c371d628c96c493ec8f7866da04e17e014a92f97895c8ed7`; the old E/CLI Binding/Prepare entry is not loaded or invoked.

`Resources.Preparation` has the existing `NormalResourcePreparation` fields: `ContractPath`, `ContractSha256`, `InstalledCatalogPath`, `OfflineCatalogPath`, `CatalogSha256`, `InstalledSettingsPath`, `InstalledSettingsSha256`, `OfflineRoot`, `CatalogHashPath`, `CatalogHashSha256`, `BundleManifestPath`, `BundleManifestSha256`, `MaterializationPath`, `MaterializationSha256`, `RequiredBundleCount`, `BundleBytes`.

The contract and full bundle manifest live in a separate prepared lab tree, outside both the run and install. `OfflineRoot` is another separate lab input tree. Installed inputs are exactly `AzureArchive_Data\StreamingAssets\aa\catalog.json` and `settings.json`. The offline catalog/hash are direct offline-root leaves. Completion and journal are exactly `OfflineRoot\.azurite-staging\complete.json` and `files.jsonl`.

The reader verifies the actual contract fields, installed and offline catalog hashes, settings pin, hash-file bytes/text, full bundle manifest, every actual payload hash/length, and every original source/destination journal row. It verifies completion identity (contract, lab, proposal and full manifest hashes), sequence/count/byte totals, identical preservation records and zero errors. Completion must retain `staged_not_activated_not_native_accepted`, `resource_set_complete=true`, and original `resource_contract_activated/normal_runtime_accepted/runtimeAllowed=false`. These are descriptive inputs; they are never converted into an allow flag. Prior native success is not required for the first experiment.

File handles remain share-read-only, and ancestor directories remain open without delete sharing, retaining the selected bytes and path identities. The first bounded preparation pass hashes all selected payload bytes. Callback checks inspect the retained handles instead of rehashing the multi-gigabyte resource set. This startup cost and handle count have not been measured on the target host.

Fresh seed validation occurs once before native startup. The held immutable files exclude mutable run settings and their SafeSave sidecars; frozen Policy continues to validate their native lifecycle and control-seed invariants.

Registration first checks actual process/creation/thread, argv, transport absence, immutable inputs, and the held Guard Execute continuation without touching generated native classes. This observation has no `CliActive` field. After Routes installs its native first-use guards, full admission reads the actual CLI backing field, then the original Adapter and Entry register. Only exact twelve-category completion allows the Guard to release the original chainloader continuation.

`NormalLoaderPlugin.Close()` is an explicit owner-thread integration point. It never requests native Quit. It calls existing Entry close, and only a true result permits the original Evidence writer to Seal/Dispose. Ready/Record do not call Close. Actual owner-thread invocation, process exit, normal cache pre-use safety and native consumer hits remain later acceptance facts.
