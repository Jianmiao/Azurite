Set-StrictMode -Version Latest
$script:FixtureLab='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\lab'
function Get-FixtureLab {return $script:FixtureLab}
function Assert-Fixture($Condition,[string]$Message){if(-not $Condition){throw "Fixture failed: $Message"}}
function Get-FixtureHash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read-FixtureJson([string]$Path,[int]$Limit=1048576){
 $i=Get-Item -LiteralPath $Path -Force;Assert-Fixture (-not $i.PSIsContainer -and -not($i.Attributes -band [IO.FileAttributes]::ReparsePoint) -and $i.Length -gt 1 -and $i.Length -le $Limit) 'JSON type/bound'
 $params=@{InputObject=[IO.File]::ReadAllText($Path);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$params.DateKind='String'};ConvertFrom-Json @params
}
function Write-FixtureJson([string]$Path,$Value){$b=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 80 -Compress));Assert-Fixture ($b.Length -le 1048576) 'JSON write bound';$s=[IO.FileStream]::new($Path,'CreateNew','Write','Read');try{$s.Write($b,0,$b.Length);$s.Flush($true)}finally{$s.Dispose()}}
function New-FixtureStart([string]$File,[string]$Arguments,[string]$Working){$p=[Diagnostics.ProcessStartInfo]::new();$p.FileName=$File;$p.Arguments=$Arguments;$p.WorkingDirectory=$Working;$p.UseShellExecute=$false;$p.CreateNoWindow=$true;$p.RedirectStandardOutput=$true;$p.RedirectStandardError=$true;return $p}
function Assert-FixtureChild($Entry,$Control){
 Assert-Fixture ($Entry.schema -eq 1 -and $Entry.fixtureOnly -eq $true -and $Entry.productionTargetExecuted -eq $false -and $Entry.runId -ceq $Control.runId -and $Entry.scenario -ceq $Control.scenario -and $Entry.pid -gt 0) 'actual child correlation'
 Assert-Fixture ($Entry.userSid -ceq $Control.userSid -and $Entry.logonSid -ceq $Control.logonSid -and $Entry.session -eq $Control.session -and $Entry.integrityRid -eq $Control.integrityRid -and $Entry.integrityAttributes -eq 96 -and $Entry.mandatoryPolicy -eq $Control.mandatoryPolicy -and $Entry.elevated -eq 0 -and $Entry.appContainer -eq 0 -and $Entry.tokenType -eq 1 -and $Entry.isRestricted -eq $true) 'actual child identity/inherited policy'
 Assert-Fixture ($Entry.restrictedSidCount -eq 3 -and @($Entry.restrictingSids).Count -eq 3 -and (($Entry.restrictingSids|Sort-Object) -join '|') -ceq ((@($Control.logonSid,'S-1-1-0','S-1-5-32-545')|Sort-Object) -join '|') -and ($Entry.usersAttributes -band 4) -and -not($Entry.usersAttributes -band 16) -and $Entry.privilege -ceq 'SeChangeNotifyPrivilege' -and $Entry.privilegeEnabled -eq $true) 'actual child FR1 SID/privilege contract'
 Assert-Fixture ($Entry.desktop -ceq ('AzuriteFullCli_'+$Control.runId) -and $Entry.anyJobMembership -eq $true -and $Entry.exactJobClaimedByChild -eq $false) 'actual private desktop and correctly limited Job claim'
 Assert-Fixture (@($Entry.stdHandles).Count -eq 3 -and @($Entry.stdHandles|Select-Object -Unique).Count -eq 3 -and @($Entry.stdHandles|Where-Object{$_ -le 0}).Count -eq 0 -and @($Entry.stdTypes).Count -eq 3 -and @($Entry.stdTypes|Where-Object{$_ -ne 3}).Count -eq 0 -and @($Entry.stdFlags).Count -eq 3 -and @($Entry.stdFlags|Where-Object{-not($_ -band 1)}).Count -eq 0 -and $Entry.stdinEof -eq $true -and $Entry.streamsWritten -eq $true) 'actual standard endpoint directions/EOF'
}
function Assert-FixtureNativeEvidence($Evidence,$Entry){
 Assert-Fixture ($Evidence.actualTokenVerified -eq $true -and $Evidence.exactOwnedJobVerified -eq $true -and $Evidence.outerDesktopLeaseAcknowledged -eq $true -and $Evidence.creationFlags -eq 0x08084404) 'actual suspended token/exact Job/pre-resume desktop'
 Assert-Fixture (@($Evidence.pipeHandlesBeforeCreate).Count -eq 6) 'six real queried pipe endpoints'
 $children=@($Evidence.pipeHandlesBeforeCreate|Select-Object -First 3);for($i=0;$i -lt 3;$i++){Assert-Fixture ($children[$i].handle -eq $Entry.stdHandles[$i] -and $children[$i].flags -band 1 -and $children[$i].fileType -eq 3) 'parent HANDLE_LIST and child endpoint identity'}
 foreach($p in @($Evidence.pipeHandlesBeforeCreate|Select-Object -Skip 3)){Assert-Fixture (-not($p.flags -band 1)) 'parent endpoints noninherited'}
}
function Assert-FixtureOuter($Outer,[string]$Scenario){
 Assert-Fixture ($Outer.CleanupVerified -eq $true -and $Outer.DirectProcessExited -eq $true -and $Outer.JobDrained -eq $true -and $Outer.RemainingOwnedProcesses -eq 0 -and $Outer.JobObserved -eq $true -and $Outer.DesktopLeaseObserved -eq $true -and $Outer.DesktopLeaseClosed -eq $true -and $Outer.DesktopLeaseRetained -eq $false -and $Outer.FullJobObserverClosed -eq $true -and $Outer.FullJobObserverRetained -eq $false -and $Outer.StreamCaptureComplete -eq $true) 'actual outer cleanup/lease release'
 Assert-Fixture (-not $Outer.TimedOut -and -not $Outer.WindowViolation -and -not $Outer.OutputLimitExceeded -and [string]::IsNullOrEmpty($Outer.Error)) 'outer deadline/window/output/error'
 Assert-Fixture ($Outer.ExitCode -eq $(if($Scenario -ceq 'normal'){0}else{73})) 'exact finite scenario exit'
}
function Assert-FixtureCaptured([string]$Stdout,[string]$Stderr,[string]$RunId){Assert-Fixture ($Stdout -ceq ("FIXTURE_STDOUT "+$RunId+" "+[char]0x20ac+[char]10) -and $Stderr -ceq ("FIXTURE_STDERR "+$RunId+" "+[char]::ConvertFromUtf32(0x1f31f)+[char]10)) 'actual captured split UTF8 text'}
function Assert-FixtureImagePins($Pins){
 Assert-Fixture ($Pins -is [array] -and $Pins.Count -eq 2) 'imagePins must be exact two-row JSON array, never value/Count wrapper'
 $expected=@(@('user32.dll','4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91',[long]0x2a9a0),@('win32u.dll','ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4',[long]0x1610))
 $fields=@('name','path','expectedPath','sha256','expectedSha256','fixedFileVersion','expectedFixedFileVersion','rawFileVersion','rawProductVersion','language','exportOffset','expectedExportOffset','reparse','pathMatch','hashMatch','fixedVersionMatch','exportMatch','nonReparseMatch')
 for($i=0;$i -lt 2;$i++){
  $row=$Pins[$i];Assert-Fixture ($null -ne $row) 'image pin row missing'
  $names=if($row -is [Collections.IDictionary]){@($row.Keys)}else{@($row.PSObject.Properties.Name)}
  Assert-Fixture ($names.Count -eq $fields.Count -and @($fields|Where-Object {$names -cnotcontains $_}).Count -eq 0) 'image pin actual/expected field shape differs'
  $path='C:\Windows\System32\'+$expected[$i][0]
  Assert-Fixture ($row.name -ceq $expected[$i][0] -and $row.path -is [string] -and $row.expectedPath -is [string] -and [string]::Equals($row.path,$path,[StringComparison]::OrdinalIgnoreCase) -and [string]::Equals($row.expectedPath,$path,[StringComparison]::OrdinalIgnoreCase)) 'actual and expected loaded image paths must be exact pinned System32 files'
  Assert-Fixture ($row.sha256 -ceq $expected[$i][1] -and $row.expectedSha256 -ceq $expected[$i][1] -and $row.fixedFileVersion -ceq '10.0.26100.9818' -and $row.expectedFixedFileVersion -ceq '10.0.26100.9818') 'actual/expected image hash and fixed version must match reviewed bytes'
  Assert-Fixture (($row.exportOffset -is [int] -or $row.exportOffset -is [long]) -and ($row.expectedExportOffset -is [int] -or $row.expectedExportOffset -is [long]) -and $row.exportOffset -eq $expected[$i][2] -and $row.expectedExportOffset -eq $expected[$i][2]) 'actual/expected loaded export offsets must match'
  foreach($flag in @('pathMatch','hashMatch','fixedVersionMatch','exportMatch','nonReparseMatch')){Assert-Fixture ($row.$flag -is [bool] -and $row.$flag -eq $true) ('actual image pin flag '+$flag)}
  Assert-Fixture ($row.reparse -is [bool] -and $row.reparse -eq $false) 'actual image file must be nonreparse'
  foreach($raw in @('rawFileVersion','rawProductVersion','language')){Assert-Fixture ($row.$raw -is [string] -and -not [string]::IsNullOrWhiteSpace($row.$raw)) ('raw observed image metadata '+$raw+' required without a localized string whitelist')}
 }
}
function Assert-FixtureMonitorEvidence($Monitor,[string]$RunId){
 $pin='user32.dll|10.0.26100.9818|4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91|EnumDesktopWindows:0x2a9a0;win32u.dll|10.0.26100.9818|ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4|NtUserBuildHwndList:0x1610'
 Assert-Fixture ($null -ne $Monitor -and $Monitor.emptyCount -gt 0 -and $Monitor.normalCount -eq 0 -and $Monitor.failedCount -eq 0 -and $Monitor.boundedStoredObservations -in @(1,2) -and $Monitor.pinnedImageIdentity -ceq $pin) 'actual pinned-empty monitor use/counters/version required, not default values'
 foreach($observation in @($Monitor.first,$Monitor.last)){
  Assert-FixtureImagePins $observation.imagePins
  Assert-Fixture ($null -ne $observation -and $observation.usedPath -ceq 'pinned-empty' -and $observation.expectedName -ceq ('AzuriteFullCli_'+$RunId) -and $observation.handle -gt 0 -and $observation.observedUtc -match 'Z$' -and $observation.foregroundOwned -eq $false -and $observation.violation -eq $false) 'real run-correlated completed monitor observation'
  Assert-Fixture ($observation.enumeration.returned -eq $false -and $observation.enumeration.error -eq 0 -and $observation.enumeration.callbacks -eq 0 -and $observation.enumeration.visible -eq $false -and $null -eq $observation.enumeration.callbackError) 'measured false/zero/zero-callback monitor input'
  Assert-Fixture ($observation.list.status -eq 0 -and $observation.list.lastError -eq 0 -and $observation.list.capacity -eq 64 -and $observation.list.needed -eq 1 -and $observation.list.first -eq 1 -and $observation.list.guardsIntact -eq $true -and $observation.list.tailIntact -eq $true) 'actual bounded status/count/sentinel1 observation'
  foreach($identity in @($observation.identityBefore,$observation.identityAfter)){
   Assert-Fixture ($identity.handle -eq $observation.handle -and $identity.name -ceq $observation.expectedName -and $identity.type -ceq 'Desktop' -and $identity.owner -ceq $identity.currentOwner -and $identity.owner -match '^S-1-5-21-' -and $identity.rightsQueryStatus -eq 0 -and ($identity.grantedAccess -band 1) -eq 1 -and $identity.inherited -eq $false) 'actual owned desktop identity/readrights before/after'
  }
 }
}
function Assert-FixtureObserverMonitor($Monitor,[string]$RunId,[long]$Handle){
 Assert-FixtureMonitorEvidence $Monitor $RunId
 foreach($sample in @($Monitor.first,$Monitor.last)){
  Assert-Fixture ($sample.handle -eq $Handle) 'observer monitor must use exact duplicated handle'
  foreach($identity in @($sample.identityBefore,$sample.identityAfter)){Assert-Fixture ($identity.grantedAccess -eq 0x20001) 'observer monitor grants exactly readobjects plus readcontrol'}
 }
}
function Assert-FixtureObservation($Observer,$Outer,$Entry){
 $id=$Entry.runId
 Assert-Fixture ($Observer.RunId -ceq $id -and $Observer.Verified -eq $true -and $Observer.ObservedDescendantAfterBootstrapExit -eq $true -and $Observer.NoVisibleOwnedWindow -eq $true -and $Observer.BootstrapPid -eq $Outer.Pid -and $Observer.ChildPid -eq $Entry.pid -and [string]::IsNullOrEmpty($Observer.Error)) 'actual correlated descendant interval observed'
 $permission=$Observer.DesktopPermission;$identity=$permission.identity
 Assert-Fixture ($permission.requestedAccess -eq 0x20001 -and $permission.inherit -eq $false -and $permission.options -eq 0 -and $permission.duplicateSucceeded -eq $true -and $permission.duplicateError -eq 0 -and $permission.returnedHandle -gt 0 -and $permission.sourceHandle -gt 0) 'minimal desktop duplicate request and actual success required'
 Assert-Fixture ($identity.handle -eq $permission.returnedHandle -and $identity.name -ceq ('AzuriteFullCli_'+$id) -and $identity.type -ceq 'Desktop' -and $identity.owner -ceq $identity.currentOwner -and $identity.owner -match '^S-1-5-21-' -and $identity.rightsQueryStatus -eq 0 -and $identity.grantedAccess -eq 0x20001 -and $identity.inherited -eq $false) 'actual duplicate identity owner rights and noninheritance required'
 Assert-FixtureObserverMonitor $Observer.FullDesktopMonitorEvidence $id $identity.handle
 Assert-FixtureObserverMonitor $Observer.QualifyingMonitorEvidence $id $identity.handle
 $sample=$Observer.QualifyingSample
 Assert-Fixture ($null -ne $sample -and $sample.runId -ceq $id -and $sample.bootstrapPid -eq $Outer.Pid -and $sample.childPid -eq $Entry.pid -and $sample.desktopHandle -eq $identity.handle -and $sample.observerDesktopHeld -eq $true -and $sample.monitorCompleted -eq $true -and $sample.visibleOwnedWindow -eq $false) 'qualifying sample must contain actual completed monitor on correlated reference'
 Assert-Fixture ($sample.bootstrapWaitBefore -eq 0 -and $sample.bootstrapWaitAfter -eq 0 -and $sample.childWaitBefore -eq 258 -and $sample.childWaitAfter -eq 258 -and $sample.activeBefore -gt 0 -and $sample.activeAfter -gt 0) 'bootstrap exited child alive and Job active both before and after monitor'
 Assert-Fixture ($sample.qpcFrequency -gt 0 -and $sample.sampleBeforeQpc -le $sample.monitorBeforeQpc -and $sample.monitorBeforeQpc -le $sample.monitorAfterQpc -and $sample.monitorAfterQpc -le $sample.sampleAfterQpc) 'monotonic monitor-bracket sample timing'
 Assert-Fixture ($Observer.Samples.Count -le 1024) 'observer sample history bounded'
 $roles=@('private-desktop-query','child-query','job-query','bootstrap-query')
 Assert-Fixture ($Observer.Closes.Count -eq 4) 'exactly four checked observer closes'
 foreach($role in $roles){$closed=@($Observer.Closes|Where-Object {$_.role -ceq $role});Assert-Fixture ($closed.Count -eq 1 -and $closed[0].closed -eq $true -and $closed[0].error -eq 0 -and $closed[0].value -gt 0 -and $closed[0].qpc -ge $sample.sampleAfterQpc) 'checked close after qualifying sample';if($role -ceq 'private-desktop-query'){Assert-Fixture ($closed[0].value -eq $identity.handle) 'actual observed desktop closed after snapshot'}}
}
function Assert-FixtureNormalReceipt($Receipt,[string]$PackageSha256,$ProductionSources){
 Assert-Fixture ($Receipt.schema -eq 1 -and $Receipt.fixtureOnly -eq $true -and $Receipt.productionTargetExecuted -eq $false -and $Receipt.scenario -ceq 'normal' -and $Receipt.passed -eq $true -and $Receipt.cleanupVerified -eq $true -and [string]::IsNullOrEmpty($Receipt.error) -and $Receipt.packageSha256 -ceq $PackageSha256 -and $Receipt.runId -cmatch '^[a-f0-9]{32}$') 'actual normal successful same-package final receipt required'
 foreach($name in @('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs')){Assert-Fixture ($Receipt.nativeSourceLineage.$name -ceq $ProductionSources.$name) 'normal receipt production lineage differs'}
 Assert-FixtureOuter $Receipt.outer normal
 Assert-Fixture ($Receipt.child.runId -ceq $Receipt.runId -and $Receipt.child.scenario -ceq 'normal' -and $Receipt.child.pid -eq $Receipt.native.Process.Pid -and $Receipt.native.Process.CleanupVerified -eq $true -and $Receipt.native.Process.ExitCode -eq 0 -and $Receipt.native.StreamsComplete -eq $true -and $Receipt.native.NativeHandlesClosed -eq $true -and $Receipt.native.Evidence.resumeCalls -eq 1 -and $Receipt.native.Evidence.resumeVerified -eq $true) 'actual normal child and native completion evidence required'
 Assert-FixtureNativeEvidence $Receipt.native.Evidence $Receipt.child
 Assert-FixtureCaptured $Receipt.native.Process.Stdout $Receipt.native.Process.Stderr $Receipt.runId
 Assert-FixtureMonitorEvidence $Receipt.outer.FullDesktopMonitorEvidence $Receipt.runId
 Assert-FixtureMonitorEvidence $Receipt.native.Process.FullDesktopMonitorEvidence $Receipt.runId
 Assert-FixtureMonitorEvidence $Receipt.native.Evidence.fullDesktopMonitor $Receipt.runId
 Assert-Fixture (($Receipt.native.Process.FullDesktopMonitorEvidence|ConvertTo-Json -Depth 30 -Compress) -ceq ($Receipt.native.Evidence.fullDesktopMonitor|ConvertTo-Json -Depth 30 -Compress)) 'normal receipt inner monitor evidence must agree'
}
Export-ModuleMember -Function Get-FixtureLab,Assert-Fixture,Get-FixtureHash,Read-FixtureJson,Write-FixtureJson,New-FixtureStart,Assert-FixtureChild,Assert-FixtureNativeEvidence,Assert-FixtureOuter,Assert-FixtureCaptured,Assert-FixtureObservation,Assert-FixtureMonitorEvidence,Assert-FixtureImagePins,Assert-FixtureObserverMonitor,Assert-FixtureNormalReceipt
