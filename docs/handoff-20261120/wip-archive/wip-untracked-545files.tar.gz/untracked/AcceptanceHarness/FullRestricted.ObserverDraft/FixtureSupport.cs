using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
namespace Azurite.Restricted {
 // Separately compiled observation glue. No copy of a native spawn method.
 public static class LifecycleFixture {
  const int RuntimeMs=10000;static readonly List<object> retained=new List<object>();
  static readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=1048576,RecursionLimit=100};
  public static string Lab{get{return FullRestrictedContract.Lab;}}
  public static string Target{get{return FullRestrictedContract.Executable;}}
  static string Run(string id){FullRestrictedContract.Require(System.Text.RegularExpressions.Regex.IsMatch(id??"","^[a-f0-9]{32}$"),"Invalid fixture run");return Lab+@"\runs\restricted-"+id;}
  static void Require(bool value,string why){FullRestrictedContract.Require(value,why);}
  public static void Write(string path,object value){Require(path.StartsWith(Lab+@"\runs\restricted-",StringComparison.Ordinal)&&path.Length<250,"Fixture record path outside fixed run");byte[] data=new UTF8Encoding(false).GetBytes(json.Serialize(value));Require(data.Length<=1048576,"Fixture record bound");using(var fs=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.Read)){fs.Write(data,0,data.Length);fs.Flush(true);}}
  static Dictionary<string,object> Read(string path){var f=new FileInfo(path);Require(f.Exists&&f.Length>1&&f.Length<=65536&&(f.Attributes&FileAttributes.ReparsePoint)==0,"Fixture proof bound/type");return json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path,new UTF8Encoding(false,true)));}
  static IntPtr PrivateHandle(FullRestrictedSpawn api,string name){Require(name=="desktop","Only fixed observation field permitted");return (IntPtr)typeof(FullRestrictedSpawn).GetField(name,BindingFlags.NonPublic|BindingFlags.Instance).GetValue(api);}
  static string Capture(FullRestrictedSpawn api,string name){Require(name=="output"||name=="error","Only fixed capture field permitted");return ((BoundedPipeCapture)typeof(FullRestrictedSpawn).GetField(name,BindingFlags.NonPublic|BindingFlags.Instance).GetValue(api)).Snapshot();}
  static void Entry(Dictionary<string,object> proof,string id,int pid){Require((string)proof["runId"]==id&&Convert.ToInt32(proof["pid"])==pid&&(bool)proof["fixtureOnly"]&&!(bool)proof["productionTargetExecuted"]&&(bool)proof["stdinEof"]&&(bool)proof["streamsWritten"],"Child entry proof does not correlate");}
  public static FullRestrictedPumpResult RunInstrumented(ProcessStartInfo info,OwnedJob job,string id,string argumentsHash){
   string run=Run(id);FullRestrictedContract.ValidateRequest(id,run,"capabilities",info.FileName,info.Arguments,info.EnvironmentVariables["AZUREARCHIVE_CLI_DIRECTORY"],info.EnvironmentVariables["BEPINEX_GAME_ASSEMBLY_PATH"]);
   Require(info.WorkingDirectory==Lab+@"\install"&&String.IsNullOrEmpty(info.UserName)&&!info.UseShellExecute&&info.CreateNoWindow&&info.RedirectStandardOutput&&info.RedirectStandardError,"Fixture startup contract");
   var api=new FullRestrictedSpawn(info,RuntimeMs,job,id,run,argumentsHash,262144,new[]{run+@"\request",run+@"\output"},4194304);
   var wrapper=new ObservedOperations(api,job,id,run);var outcome=FullRestrictedCoordinator.Run(wrapper);
   api.Result.Process.Error=outcome.Error;api.Result.Process.CleanupError=outcome.CleanupError;api.Result.Process.CleanupVerified=outcome.CleanupVerified&&api.Result.NativeHandlesClosed;api.Result.Evidence["coordinatorStages"]=outcome.Stages;api.Result.Evidence["resumeCalls"]=outcome.ResumeCalls;api.Result.Evidence["resumeVerified"]=outcome.ResumeVerified;
   return api.Result;
  }
  sealed class ObservedOperations:IFullRestrictedOperations {
   readonly FullRestrictedSpawn api;readonly OwnedJob job;readonly string id,run;readonly List<string> calls=new List<string>();
   internal ObservedOperations(FullRestrictedSpawn native,OwnedJob owned,string value,string directory){api=native;job=owned;id=value;run=directory;}
   void Mark(string s){calls.Add(s);}
   public void ReadOriginalAndDerive(){Mark("ReadOriginalAndDerive");api.ReadOriginalAndDerive();}
   public void AcquireDesktopLease(){Mark("AcquireDesktopLease");api.AcquireDesktopLease();}
   public void CreateSuspended(){Mark("CreateSuspended");api.CreateSuspended();}
   public void ValidateActualToken(){Mark("ValidateActualToken");api.ValidateActualToken();}
   public void ValidateExactJob(){Mark("ValidateExactJob");api.ValidateExactJob();}
   public void PrepareStreams(){Mark("PrepareStreams");api.PrepareStreams();Write(run+@"\output\pre-resume.json",new{fixtureOnly=true,productionTargetExecuted=false,runId=id,bootstrapPid=Process.GetCurrentProcess().Id,bootstrapStartUtc=Process.GetCurrentProcess().StartTime.ToUniversalTime().ToString("o"),childPid=api.Result.Process.Pid,jobHandle=job.FullHandle.ToInt64(),desktopHandle=PrivateHandle(api,"desktop").ToInt64(),processHandle=api.Result.Evidence["partialProcessHandle"],calls=calls.ToArray(),nativeEvidence=api.Result.Evidence,desktopLeaseAcknowledged=api.Result.DesktopLeaseAcknowledged});}
   public uint Resume(){Mark("Resume");uint previous=api.Resume();Write(run+@"\output\resume.json",new{fixtureOnly=true,runId=id,childPid=api.Result.Process.Pid,previousCount=previous,calls=calls.ToArray()});return previous;}
   public void Monitor(){Mark("Monitor");
    Task.Factory.StartNew(()=>{
     var timer=Stopwatch.StartNew();try{
      string entry=run+@"\request\entry.json",armed=run+@"\output\observer-armed.json";
      while(timer.ElapsedMilliseconds<5000){if(File.Exists(entry)&&File.Exists(armed)){var proof=Read(entry);Entry(proof,id,api.Result.Process.Pid);var ack=Read(armed);Require((string)ack["runId"]==id&&(bool)ack["exactJobVerified"],"Fixture observer did not verify exact owned references");
        Thread.Sleep(60);string stdout=Capture(api,"output"),stderr=Capture(api,"error");
        Require(stdout=="FIXTURE_STDOUT "+id+" \u20ac\n"&&stderr=="FIXTURE_STDERR "+id+" \U0001f31f\n","Actual native capture lacks expected split UTF8");
        Write(run+@"\output\before-self-exit.json",new{fixtureOnly=true,productionTargetExecuted=false,runId=id,bootstrapPid=Process.GetCurrentProcess().Id,childPid=api.Result.Process.Pid,stdout=stdout,stderr=stderr,nativeEvidence=api.Result.Evidence,calls=calls.ToArray(),selfExitCode=73,childEntryObserved=true});
        Environment.Exit(73);return;
       }Thread.Sleep(5);}
      throw new TimeoutException("No real correlated child entry and observer ACK before self-exit deadline");
     }catch(Exception e){try{Write(run+@"\output\self-exit-failure.json",new{fixtureOnly=true,runId=id,error=e.ToString()});}finally{Environment.Exit(74);}}
    },CancellationToken.None,TaskCreationOptions.LongRunning,TaskScheduler.Default);
    api.Monitor();
   }
   public bool Cleanup(){Mark("Cleanup");return api.Cleanup();}
   public void Close(){Mark("Close");api.Close();}
  }
  public sealed class Observation {public bool Verified,ObservedDescendantAfterBootstrapExit,NoVisibleOwnedWindow;public string Error;public int BootstrapPid,ChildPid;public string RunId;public object DesktopPermission,FullDesktopMonitorEvidence,QualifyingMonitorEvidence;public ObserverSample QualifyingSample;public List<object> Samples=new List<object>();public List<object> Closes=new List<object>();}
  internal const uint ObserverDesktopAccess=0x20001;
  public sealed class ObserverSample {
   public string runId;public int bootstrapPid,childPid,activeBefore,activeAfter;public long sampleBeforeQpc,monitorBeforeQpc,monitorAfterQpc,sampleAfterQpc,qpcFrequency,desktopHandle;public uint bootstrapWaitBefore,childWaitBefore,bootstrapWaitAfter,childWaitAfter;public bool observerDesktopHeld,monitorCompleted,visibleOwnedWindow;
  }
  internal static void ValidateObserverDesktop(FullDesktopIdentity value,IntPtr handle,string id){FullDesktopMonitor.ValidateIdentity(value,handle,"AzuriteFullCli_"+id);Require(value.GrantedAccess==ObserverDesktopAccess,"Observer duplicate must grant exactly DESKTOP_READOBJECTS|READ_CONTROL");}
  internal static bool Qualifies(ObserverSample s,string id,int bootstrapPid,int childPid){return s!=null&&s.runId==id&&s.bootstrapPid==bootstrapPid&&s.childPid==childPid&&s.bootstrapWaitBefore==0&&s.bootstrapWaitAfter==0&&s.childWaitBefore==258&&s.childWaitAfter==258&&s.activeBefore>0&&s.activeAfter>0&&s.observerDesktopHeld&&s.desktopHandle>0&&s.monitorCompleted&&!s.visibleOwnedWindow&&s.qpcFrequency>0&&s.sampleBeforeQpc<=s.monitorBeforeQpc&&s.monitorBeforeQpc<=s.monitorAfterQpc&&s.monitorAfterQpc<=s.sampleAfterQpc;}
  static object ObserverIdentity(FullDesktopIdentity value){return new{handle=value.Handle,name=value.Name,type=value.Type,owner=value.Owner,currentOwner=value.CurrentOwner,rightsQueryStatus=value.RightsQueryStatus,grantedAccess=value.GrantedAccess,inherited=value.Inherited};}
  static uint WaitObserved(IntPtr handle){uint result=WaitForSingleObject(handle,0);if(result==UInt32.MaxValue)throw new Win32Exception(Marshal.GetLastWin32Error());Require(result==0||result==258,"Unexpected process wait state");return result;}
  public sealed class ObservedOuter {public PumpResult Outer;public Observation Observation;public bool ReturnedWithinBound;public string Error;}
  [StructLayout(LayoutKind.Sequential)]struct Accounting{public long User,Kernel,PeriodUser,PeriodKernel;public uint Faults,Total,Active,Terminated;}
  [DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
  [DllImport("kernel32.dll")]static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr handle,IntPtr targetProcess,out IntPtr target,uint access,bool inherit,uint options);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool IsProcessInJob(IntPtr process,IntPtr job,out bool inside);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool QueryInformationJobObject(IntPtr job,int kind,out Accounting info,uint size,out uint returned);
  [DllImport("kernel32.dll",SetLastError=true)]static extern uint WaitForSingleObject(IntPtr handle,uint ms);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr handle);
  [DllImport("kernel32.dll",SetLastError=true)]static extern uint GetProcessId(IntPtr handle);
  [DllImport("user32.dll",SetLastError=true)]static extern bool CloseDesktop(IntPtr handle);
  [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool GetUserObjectInformationW(IntPtr handle,int index,StringBuilder name,uint bytes,out uint needed);
  static void Win(bool b,string why){if(!b)throw new Win32Exception(Marshal.GetLastWin32Error(),why);}
  static IntPtr Duplicate(IntPtr process,long source,uint rights){IntPtr value;Win(DuplicateHandle(process,new IntPtr(source),GetCurrentProcess(),out value,rights,false,0),"Duplicate observed owned reference");return value;}
  static bool Exited(IntPtr handle){uint n=WaitForSingleObject(handle,0);if(n==UInt32.MaxValue)throw new Win32Exception(Marshal.GetLastWin32Error());return n==0;}
  static int Active(IntPtr job){Accounting a;uint n;Win(QueryInformationJobObject(job,1,out a,(uint)Marshal.SizeOf(typeof(Accounting)),out n),"Observed Job accounting");return checked((int)a.Active);}
  static void CloseObserved(ref IntPtr handle,string role,bool desktop,Observation result){if(handle==IntPtr.Zero)return;IntPtr value=handle;bool closed=desktop?CloseDesktop(value):CloseHandle(value);int error=closed?0:Marshal.GetLastWin32Error();result.Closes.Add(new{role=role,value=value.ToInt64(),closed=closed,error=error,qpc=Stopwatch.GetTimestamp()});if(!closed){result.Error=(result.Error??"")+" Observer close failed: "+role+" error="+error;lock(retained)retained.Add(new{role=role,handle=value});}handle=IntPtr.Zero;}
  static Observation Observe(string id,Task<PumpResult> pump){
   string run=Run(id);var r=new Observation{RunId=id,NoVisibleOwnedWindow=true};var clock=Stopwatch.StartNew();var session=new FullDesktopMonitorSession();IntPtr bootstrap=IntPtr.Zero,job=IntPtr.Zero,child=IntPtr.Zero,desktop=IntPtr.Zero;
   try{
    while(!File.Exists(run+@"\output\pre-resume.json")&&clock.ElapsedMilliseconds<5000&&!pump.IsCompleted)Thread.Sleep(2);
    var proof=Read(run+@"\output\pre-resume.json");Require((string)proof["runId"]==id&&(bool)proof["desktopLeaseAcknowledged"],"Pre-resume handoff proof missing");
    r.BootstrapPid=Convert.ToInt32(proof["bootstrapPid"]);r.ChildPid=Convert.ToInt32(proof["childPid"]);
    bootstrap=OpenProcess(0x00101040,false,r.BootstrapPid);Win(bootstrap!=IntPtr.Zero,"Open observation-only bootstrap");
    using(var p=Process.GetProcessById(r.BootstrapPid)){Require(p.StartTime.ToUniversalTime().ToString("o")== (string)proof["bootstrapStartUtc"],"Bootstrap PID reuse/time mismatch");}
    job=Duplicate(bootstrap,Convert.ToInt64(proof["jobHandle"]),4);
    child=Duplicate(bootstrap,Convert.ToInt64(proof["processHandle"]),0x00101000);
    bool bootstrapInside=false,childInside=false,controllerInside=false;Win(IsProcessInJob(bootstrap,job,out bootstrapInside)&&IsProcessInJob(child,job,out childInside)&&IsProcessInJob(GetCurrentProcess(),job,out controllerInside),"Observe exact Job ownership");
    Require(bootstrapInside&&childInside&&!controllerInside&&GetProcessId(child)==r.ChildPid&&GetProcessId(bootstrap)==r.BootstrapPid&&Active(job)==2,"Observation exact Job/member contract");
    var permission=new Dictionary<string,object>{{"requestedAccess",ObserverDesktopAccess},{"inherit",false},{"options",0},{"sourceHandle",Convert.ToInt64(proof["desktopHandle"])}};r.DesktopPermission=permission;
    bool duplicated=DuplicateHandle(bootstrap,new IntPtr(Convert.ToInt64(proof["desktopHandle"])),GetCurrentProcess(),out desktop,ObserverDesktopAccess,false,0);int duplicateError=duplicated?0:Marshal.GetLastWin32Error();
    permission["duplicateSucceeded"]=duplicated;permission["duplicateError"]=duplicateError;permission["returnedHandle"]=desktop.ToInt64();
    if(!duplicated)throw new Win32Exception(duplicateError,"Duplicate minimal observer desktop query reference");
    FullDesktopIdentity identity=new NativeFullDesktopMonitor().ReadIdentity(desktop);permission["identity"]=ObserverIdentity(identity);ValidateObserverDesktop(identity,desktop,id);
    Require(!WindowProbe.HasVisibleOnDesktop(desktop,new[]{r.BootstrapPid,r.ChildPid},"AzuriteFullCli_"+id,session),"Visible owned window before self-exit");
    Write(run+@"\output\observer-armed.json",new{fixtureOnly=true,runId=id,exactJobVerified=true,bootstrapPid=r.BootstrapPid,childPid=r.ChildPid,observationOnly=true,desktopPermission=r.DesktopPermission,fullDesktopMonitor=session.Snapshot()});
    while(clock.ElapsedMilliseconds<15000&&!pump.IsCompleted){
     var sample=new ObserverSample{runId=id,bootstrapPid=r.BootstrapPid,childPid=r.ChildPid,sampleBeforeQpc=Stopwatch.GetTimestamp(),qpcFrequency=Stopwatch.Frequency,desktopHandle=desktop.ToInt64(),observerDesktopHeld=desktop!=IntPtr.Zero};
     sample.bootstrapWaitBefore=WaitObserved(bootstrap);sample.childWaitBefore=WaitObserved(child);sample.activeBefore=Active(job);
     sample.monitorBeforeQpc=Stopwatch.GetTimestamp();
     if(desktop!=IntPtr.Zero){sample.visibleOwnedWindow=WindowProbe.HasVisibleOnDesktop(desktop,new[]{r.BootstrapPid,r.ChildPid},"AzuriteFullCli_"+id,session);sample.monitorCompleted=true;r.NoVisibleOwnedWindow&=!sample.visibleOwnedWindow;}
     sample.monitorAfterQpc=Stopwatch.GetTimestamp();
     sample.bootstrapWaitAfter=WaitObserved(bootstrap);sample.childWaitAfter=WaitObserved(child);sample.activeAfter=Active(job);sample.sampleAfterQpc=Stopwatch.GetTimestamp();
     if(r.Samples.Count<1024&&(sample.bootstrapWaitBefore==0||r.Samples.Count==0))r.Samples.Add(sample);
     if(r.QualifyingSample==null&&Qualifies(sample,id,r.BootstrapPid,r.ChildPid)){r.QualifyingSample=sample;r.QualifyingMonitorEvidence=session.Snapshot();r.ObservedDescendantAfterBootstrapExit=true;CloseObserved(ref desktop,"private-desktop-query",true,r);}
     Thread.Sleep(1);
    }
    if(desktop!=IntPtr.Zero)CloseObserved(ref desktop,"private-desktop-query",true,r);
    Require(r.ObservedDescendantAfterBootstrapExit&&r.QualifyingSample!=null,"No actual monitor-bracketed descendant interval observed; not qualified");
    Require(r.NoVisibleOwnedWindow,"Observed private/foreground window violation");r.Verified=true;
   }catch(Exception e){r.Error=(r.Error??"")+e.ToString();}
   finally{r.FullDesktopMonitorEvidence=session.Snapshot();CloseObserved(ref desktop,"private-desktop-query",true,r);CloseObserved(ref child,"child-query",false,r);CloseObserved(ref job,"job-query",false,r);CloseObserved(ref bootstrap,"bootstrap-query",false,r);if(r.Error!=null)r.Verified=false;}
   return r;
  }
  public static ObservedOuter RunObservedOuter(ProcessStartInfo info,string id,string hash){
   string run=Run(id);var r=new ObservedOuter();var pump=Task.Factory.StartNew(()=>ProcessPump.RunBootstrapFullRestricted(info,RuntimeMs,id,hash,262144,new[]{run+@"\request",run+@"\output"},4194304),CancellationToken.None,TaskCreationOptions.LongRunning,TaskScheduler.Default);
   r.Observation=Observe(id,pump);
   if(pump.Wait(16000)){r.Outer=pump.Result;r.ReturnedWithinBound=true;if(r.Observation.BootstrapPid!=r.Outer.Pid){r.Observation.Verified=false;r.Observation.Error+=" Outer-owned PID correlation mismatch";}}else{r.Error="Accepted outer pump failed to return within fixture bound";lock(retained)retained.Add(pump);}
   Write(run+@"\output\observer-result.json",r.Observation);return r;
  }
 }
}
