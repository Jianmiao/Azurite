#requires -Version 5.1
param([Parameter(Mandatory)][string]$OutputPath,[switch]$ExpectRed)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\FixtureRules.psm1') -Force -DisableNameChecking
Import-Module ($PSScriptRoot+'\FixtureHostRetention.psm1') -Force -DisableNameChecking
Assert-FixtureHost
$results=@();foreach($mode in @('snapshot','json','sink','stderr','decision','secondary','normal')){
 $state=[pscustomobject]@{held=0;diagnostics=0;secondary=0};$capturedState=$state;$capturedMode=$mode
 $run={throw [InvalidOperationException]::new('original-run-error')}.GetNewClosure()
 $decision={if($capturedMode -ceq 'decision'){throw 'decision failed'};return $true}.GetNewClosure()
 $snapshot={if($capturedMode -ceq 'snapshot'){throw 'projection failed'};return [ordered]@{holdHost=$true;items=[object[]]@()}}.GetNewClosure()
 $sink={param($record)if($capturedMode -ceq 'json'){throw 'JSON failed'};$null=$record|ConvertTo-Json -Depth 8;if($capturedMode -in @('sink','secondary')){throw 'sink failed'};$capturedState.diagnostics++}.GetNewClosure()
 $warning={if($capturedMode -ceq 'stderr'){throw 'stderr failed'}}.GetNewClosure()
 $hold={$capturedState.held++}.GetNewClosure()
 $secondary={param($errorRecord)$capturedState.secondary++;if($capturedMode -ceq 'secondary'){throw 'secondary reporting failed'}}.GetNewClosure()
 $errorText=$null;try{Invoke-FixtureHeldBoundary $run $decision $snapshot $sink $warning $hold $secondary}catch{$errorText=$_.Exception.Message}
 $passed=$state.held -eq 1 -and $errorText -ceq 'original-run-error';$results+=@{case=$mode;passed=$passed;holdCalls=$state.held;error=$errorText;secondary=$state.secondary}
}
$failed=@($results|Where-Object{-not $_.passed}).Count
Write-FixtureJson $OutputPath ([ordered]@{checks=$results.Count;failed=$failed;results=$results;nativeExecuted=$false;infiniteHoldExecuted=$false;fakeBoundary='diagnostic delegates and finite Hold callback; actual Invoke-FixtureHeldBoundary flow';host=$PSVersionTable.PSVersion.ToString()})
$results|Format-Table;Write-Output ('RESULT hold checks='+$results.Count+' failed='+$failed)
if(($ExpectRed -and $failed -eq 0)-or(-not $ExpectRed -and $failed -ne 0)){throw 'Unexpected retention fault result'}
