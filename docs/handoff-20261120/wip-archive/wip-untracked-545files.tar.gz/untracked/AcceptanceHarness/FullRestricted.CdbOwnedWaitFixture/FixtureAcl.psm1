Set-StrictMode -Version Latest
function Get-LeaseGateAclPlan([string]$OwnerSid,[string]$LogonSid){
 foreach($sid in @($OwnerSid,$LogonSid)){if($sid -cnotmatch '^S-1-5-(?:[0-9]+-)*[0-9]+$'){throw 'Exact owner/logon SID required'}}
 # OW READ_CONTROL makes implicit owner WRITE_DAC unavailable. The unrestricted
 # controller still has the explicit user full grant; the Full token must pass
 # its separate restricting-SID check, whose logon/world entries are read only.
 $prefix='O:'+$OwnerSid+'D:P(A;;RC;;;OW)(A;;FA;;;'+$OwnerSid+')'
 [pscustomobject][ordered]@{schema=1;controlDirectory=($prefix+'(A;;FRFX;;;'+$LogonSid+')(A;;FRFX;;;WD)');controlFile=($prefix+'(A;;FR;;;'+$LogonSid+')(A;;FR;;;WD)');creation='atomic protected descriptor at CREATE_NEW';executionAclChanges=$false;childReadyLocation='request/child-ready.json';controllerFiles=@('lease-offer.json','lease-ack.json','go.json');nativeAccessCheckQualified=$false}
}
function Assert-LeaseGateAclPlan($Plan){
 foreach($text in @($Plan.controlDirectory,$Plan.controlFile)){$d=[Security.AccessControl.RawSecurityDescriptor]::new($text);if(([int]$d.ControlFlags -band 0x1000)-eq 0 -or $d.DiscretionaryAcl.Count -ne 4){throw 'Exact protected gate DACL required'};if($d.DiscretionaryAcl[0].SecurityIdentifier.Value -cne 'S-1-3-4' -or $d.DiscretionaryAcl[0].AccessMask -ne 0x20000){throw 'Explicit owner rights restriction missing'};foreach($i in @(2,3)){if(($d.DiscretionaryAcl[$i].AccessMask -band 0xD0116)-ne 0){throw 'Child gate rights contain mutation'}}}
 if($Plan.executionAclChanges -ne $false -or $Plan.nativeAccessCheckQualified -ne $false){throw 'SOURCE plan cannot claim native ACL qualification'}
}
Export-ModuleMember -Function Get-LeaseGateAclPlan,Assert-LeaseGateAclPlan
