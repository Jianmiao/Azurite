using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32.SafeHandles;
namespace Azurite.Restricted {
 // Only this adapter calls Windows. Pure builds rewrite every import to a
 // deliberately nonexistent library, including imports in linked Full/Shared.
 internal sealed class CdbLeaseNative:ILeaseNative {
  readonly Dictionary<string,string> pinned;
  internal CdbLeaseNative(Dictionary<string,string> imagePins){pinned=imagePins;}
  internal static void Win(bool b,string why){if(!b)throw new Win32Exception(Marshal.GetLastWin32Error(),why);}
  [StructLayout(LayoutKind.Sequential)]struct Basic {internal uint Attributes,Access,Handles,Pointers,Paged,NonPaged,R1,R2,R3,Name,Type,Security;internal long Created;}
  [StructLayout(LayoutKind.Sequential)]struct Accounting {internal long User,Kernel,PeriodUser,PeriodKernel;internal uint Faults,Total,Active,Terminated;}
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool DuplicateHandle(IntPtr source,IntPtr remote,IntPtr target,out IntPtr value,uint access,bool inherit,uint options);
  [DllImport("kernel32.dll")]static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll",SetLastError=true)]static extern uint GetProcessId(IntPtr process);
  [DllImport("kernel32.dll",SetLastError=true)]static extern uint GetThreadId(IntPtr thread);
  [DllImport("kernel32.dll",SetLastError=true)]static extern uint GetProcessIdOfThread(IntPtr thread);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetProcessTimes(IntPtr h,out long created,out long exited,out long kernel,out long user);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetThreadTimes(IntPtr h,out long created,out long exited,out long kernel,out long user);
  [DllImport("kernel32.dll",SetLastError=true,CharSet=CharSet.Unicode)]static extern bool QueryFullProcessImageNameW(IntPtr h,uint flags,StringBuilder text,ref uint size);
  [DllImport("kernel32.dll",SetLastError=true)]static extern uint WaitForSingleObject(IntPtr h,uint ms);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetHandleInformation(IntPtr h,out uint flags);
  [DllImport("ntdll.dll")]static extern int NtQueryObject(IntPtr h,int kind,out Basic b,uint size,out uint returned);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool IsProcessInJob(IntPtr process,IntPtr job,out bool inside);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool QueryInformationJobObject(IntPtr h,int kind,IntPtr info,uint bytes,out uint returned);
  [DllImport("kernel32.dll",SetLastError=true,EntryPoint="QueryInformationJobObject")]static extern bool AccountingQuery(IntPtr h,int kind,out Accounting info,uint bytes,out uint returned);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr h);
  [DllImport("user32.dll",SetLastError=true)]static extern bool CloseDesktop(IntPtr h);
  public bool Duplicate(IntPtr source,long remote,uint access,out IntPtr value,out int error){bool okay=DuplicateHandle(source,new IntPtr(remote),GetCurrentProcess(),out value,access,false,0);error=okay?0:Marshal.GetLastWin32Error();return okay;}
  static uint Rights(IntPtr h,out bool inherited){uint flags;Win(GetHandleInformation(h,out flags),"lease inheritance query");inherited=(flags&1)!=0;Basic b;uint returned;int status=NtQueryObject(h,0,out b,(uint)Marshal.SizeOf(typeof(Basic)),out returned);if(status!=0||returned!=56)throw new InvalidOperationException("lease granted access query failed");return b.Access;}
  static bool Live(IntPtr h){uint state=WaitForSingleObject(h,0);if(state!=0&&state!=258)throw new Win32Exception(Marshal.GetLastWin32Error(),"lease liveness query");return state==258;}
  public LeaseProcessFacts Process(IntPtr h){var p=new LeaseProcessFacts();p.Pid=checked((int)GetProcessId(h));Win(p.Pid>0,"lease PID");long exit,kernel,user;Win(GetProcessTimes(h,out p.Created,out exit,out kernel,out user),"lease creation FILETIME");var path=new StringBuilder(32768);uint size=(uint)path.Capacity;Win(QueryFullProcessImageNameW(h,0,path,ref size),"lease image");p.Image=path.ToString();string hash;if(!pinned.TryGetValue(p.Image,out hash))throw new InvalidOperationException("process image was not pinned before spawn");p.Hash=hash;p.Live=Live(h);p.Rights=Rights(h,out p.Inherited);return p;}
  // Release-only facts from the retained HANDLE. Image/Hash intentionally stay
  // absent; callers must first prove that full live admission already succeeded.
  internal static Win32Exception ReleaseFailure(int error,string why){return new Win32Exception(error,why+"; NativeErrorCode="+error.ToString(System.Globalization.CultureInfo.InvariantCulture));}
  public LeaseProcessFacts ReleaseProcess(IntPtr h){
   var p=new LeaseProcessFacts();uint pid=GetProcessId(h);int error=pid==0?Marshal.GetLastWin32Error():0;
   if(pid==0)throw ReleaseFailure(error,"release held PID");p.Pid=checked((int)pid);
   long exit,kernel,user;bool okay=GetProcessTimes(h,out p.Created,out exit,out kernel,out user);error=okay?0:Marshal.GetLastWin32Error();
   if(!okay)throw ReleaseFailure(error,"release held creation FILETIME");
   uint wait=WaitForSingleObject(h,0);error=wait==0xffffffff?Marshal.GetLastWin32Error():0;
   if(wait==0xffffffff)throw ReleaseFailure(error,"release held Wait0");
   if(wait!=0&&wait!=258)throw new InvalidOperationException("release held Wait0 unexpected result="+wait);p.Live=wait==258;
   uint flags;okay=GetHandleInformation(h,out flags);error=okay?0:Marshal.GetLastWin32Error();
   if(!okay)throw ReleaseFailure(error,"release held inheritance flags");p.Inherited=(flags&1)!=0;
   Basic basic;uint returned;int status=NtQueryObject(h,0,out basic,(uint)Marshal.SizeOf(typeof(Basic)),out returned);
   if(status!=0||returned!=56)throw new InvalidOperationException("release held granted access NTSTATUS=0x"+unchecked((uint)status).ToString("x8")+" returned="+returned);
   p.Rights=basic.Access;return p;
  }
  public LeaseThreadFacts Thread(IntPtr h){var t=new LeaseThreadFacts{Tid=checked((int)GetThreadId(h)),Pid=checked((int)GetProcessIdOfThread(h))};Win(t.Tid>0&&t.Pid>0,"lease TID/owning PID");long exit,kernel,user;Win(GetThreadTimes(h,out t.Created,out exit,out kernel,out user),"lease thread creation FILETIME");t.Live=Live(h);t.Rights=Rights(h,out t.Inherited);return t;}
  public LeaseJobFacts Job(IntPtr h,IntPtr bootstrap,IntPtr child){var j=new LeaseJobFacts();j.Rights=Rights(h,out j.Inherited);Win(IsProcessInJob(bootstrap,h,out j.BootstrapInside)&&IsProcessInJob(child,h,out j.ChildInside)&&IsProcessInJob(GetCurrentProcess(),h,out j.ControllerInside),"exact held Job membership");Accounting a;uint n;Win(AccountingQuery(h,1,out a,(uint)Marshal.SizeOf(typeof(Accounting)),out n)&&n==(uint)Marshal.SizeOf(typeof(Accounting)),"exact held Job accounting");j.Active=a.Active;j.Total=a.Total;const int size=8+16*8;IntPtr b=Marshal.AllocHGlobal(size);try{Win(QueryInformationJobObject(h,3,b,size,out n),"bounded Job PID list");int assigned=Marshal.ReadInt32(b),listed=Marshal.ReadInt32(b,4);if(assigned!=listed||listed<0||listed>16)throw new InvalidOperationException("incomplete/big Job list");j.Members=new int[listed];for(int i=0;i<listed;i++)j.Members[i]=checked((int)Marshal.ReadInt64(b,8+i*8));}finally{Marshal.FreeHGlobal(b);}return j;}
  public FullDesktopIdentity Desktop(IntPtr h){return new NativeFullDesktopMonitor().ReadIdentity(h);}
  public int Close(IntPtr h,bool desktop){bool okay=desktop?CloseDesktop(h):CloseHandle(h);return okay?0:Marshal.GetLastWin32Error();}
 }
 internal sealed class LeasePinnedFiles:IDisposable {
  readonly List<FileStream> files=new List<FileStream>();internal readonly Dictionary<string,string> Hashes=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  internal void Add(string path,string expected){FileStream stream=LeaseFiles.OpenRead(path,104857600,expected);try{string hash;using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();if(hash!=expected)throw new InvalidOperationException("fixed image pin mismatch");Hashes.Add(path,hash);files.Add(stream);}catch{stream.Dispose();throw;}}
  public void Dispose(){foreach(var file in files)file.Dispose();}
 }
 internal static class LeaseFiles {
  [StructLayout(LayoutKind.Sequential,Pack=4)]struct FileInfo {internal uint Attributes;internal long Created,Accessed,Written;internal uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern SafeFileHandle CreateFileW(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(SafeFileHandle h,out FileInfo info);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern uint GetFinalPathNameByHandleW(SafeFileHandle h,StringBuilder path,uint size,uint flags);
  // Pure validation seam used by this actual same-handle read path.
  internal static void ValidateReadFacts(string path,string finalPath,uint attributes,uint links,uint sizeHigh,uint sizeLow,int max,string pinnedImageHash){
   // The reviewed Windows component-store image legitimately has two links.
   // This exception is not available to gate/run files or another shell/hash.
   bool reviewedSystem=String.Equals(path,@"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",StringComparison.OrdinalIgnoreCase)&&pinnedImageHash=="d8f182560210d43baaf767d482ad1dc1207372522e91413b9d5e515a875e552d"&&links==2&&sizeLow==495616;
   if(!String.Equals(finalPath,@"\\?\"+path,StringComparison.OrdinalIgnoreCase)||(links!=1&&!reviewedSystem)||(attributes&0x410)!=0||sizeHigh!=0||sizeLow>max)throw new InvalidOperationException("gate/image reparse, links, ancestry or size");
  }
  internal static FileStream OpenRead(string path,int max,string pinnedImageHash=null){if(Path.GetFullPath(path)!=path)throw new InvalidOperationException("canonical path required");SafeFileHandle handle=CreateFileW(path,0x80000000,1,IntPtr.Zero,3,0x00200000,IntPtr.Zero);if(handle.IsInvalid){handle.Dispose();throw new Win32Exception(Marshal.GetLastWin32Error(),"open fixed no-reparse gate/image");}try{FileInfo info;CdbLeaseNative.Win(GetFileInformationByHandle(handle,out info),"gate/image object identity");var actual=new StringBuilder(32768);uint n=GetFinalPathNameByHandleW(handle,actual,(uint)actual.Capacity,0);if(n==0||n>=actual.Capacity)throw new InvalidOperationException("final image path unavailable");ValidateReadFacts(path,actual.ToString(),info.Attributes,info.Links,info.SizeHigh,info.SizeLow,max,pinnedImageHash);return new FileStream(handle,FileAccess.Read);}catch{handle.Dispose();throw;}}
  internal static byte[] Read(string path){using(var f=OpenRead(path,4096)){byte[] data=new byte[(int)f.Length];int offset=0;while(offset<data.Length){int n=f.Read(data,offset,data.Length-offset);if(n<=0)throw new IOException("short gate read");offset+=n;}if(f.ReadByte()!=-1)throw new IOException("growing gate record");return data;}}
  internal static byte[] AwaitRead(string path,Func<int> remaining){for(;;){int left=remaining();if(left<=0)throw new TimeoutException("original record publication deadline");try{return Read(path);}catch(Win32Exception e){if(e.NativeErrorCode!=2&&e.NativeErrorCode!=32)throw;}System.Threading.Thread.Sleep(Math.Min(5,left));}}
  internal static void Create(string path,byte[] data,string sddl){if(data==null||data.Length<2||data.Length>4096)throw new InvalidOperationException("gate record bound");var security=new FileSecurity();security.SetSecurityDescriptorSddlForm(sddl);using(var file=new FileStream(path,FileMode.CreateNew,FileSystemRights.WriteData,FileShare.Read,4096,FileOptions.WriteThrough,security)){file.Write(data,0,data.Length);file.Flush(true);}}
  internal sealed class DirectoryPins:IDisposable{internal readonly List<SafeFileHandle> Handles=new List<SafeFileHandle>();public void Dispose(){for(int i=Handles.Count-1;i>=0;i--)Handles[i].Dispose();}}
  [DllImport("advapi32.dll")]static extern uint GetSecurityInfo(SafeFileHandle handle,uint type,uint information,out IntPtr owner,out IntPtr group,out IntPtr dacl,out IntPtr sacl,out IntPtr descriptor);
  [DllImport("advapi32.dll")]static extern uint GetSecurityDescriptorLength(IntPtr descriptor);
  [DllImport("kernel32.dll")]static extern IntPtr LocalFree(IntPtr value);
  static byte[] ReadControlDescriptor(SafeFileHandle handle){
   // The already pinned control handle has READ_CONTROL. Read Owner/DACL only;
   // retain the raw ACEs until the fixed-policy guard has accepted them.
   IntPtr owner,group,dacl,sacl,descriptor=IntPtr.Zero;
   try{uint error=GetSecurityInfo(handle,1,5,out owner,out group,out dacl,out sacl,out descriptor);if(error!=0)throw new Win32Exception((int)error,"read pinned control Owner/DACL");if(descriptor==IntPtr.Zero)throw new InvalidOperationException("missing pinned control descriptor");uint length=GetSecurityDescriptorLength(descriptor);if(length<20||length>65536)throw new InvalidOperationException("bounded control descriptor required");var bytes=new byte[checked((int)length)];Marshal.Copy(descriptor,bytes,0,bytes.Length);return bytes;}finally{if(descriptor!=IntPtr.Zero)LocalFree(descriptor);}
  }
  static void RequireControlPolicy(RawSecurityDescriptor descriptor,string owner,string logon){
   const ControlFlags flags=ControlFlags.SelfRelative|ControlFlags.DiscretionaryAclPresent|ControlFlags.DiscretionaryAclProtected;
   if(descriptor.Owner==null||descriptor.Owner.Value!=owner||descriptor.ControlFlags!=flags||descriptor.DiscretionaryAcl==null||descriptor.DiscretionaryAcl.Count!=4)throw new InvalidOperationException("exact protected raw control ACL required");
   int seen=0;
   for(int i=0;i<descriptor.DiscretionaryAcl.Count;i++){
    var ace=descriptor.DiscretionaryAcl[i] as CommonAce;
    if(ace==null||ace.AceType!=AceType.AccessAllowed||ace.AceQualifier!=AceQualifier.AccessAllowed||ace.IsCallback||ace.OpaqueLength!=0||ace.AceFlags!=AceFlags.None)throw new InvalidOperationException("only four explicit ordinary Allow ACEs permitted");
    string sid=ace.SecurityIdentifier.Value;int bit,mask;
    if(sid=="S-1-3-4"){bit=1;mask=0x20000;}else if(sid==owner){bit=2;mask=0x1f01ff;}else if(sid==logon){bit=4;mask=0x1200a9;}else if(sid=="S-1-1-0"){bit=8;mask=0x1200a9;}else throw new InvalidOperationException("unexpected raw control ACL SID");
    if((seen&bit)!=0||ace.AccessMask!=mask)throw new InvalidOperationException("duplicate role or different raw control ACL mask");seen|=bit;
   }
   if(seen!=15)throw new InvalidOperationException("missing fixed raw control ACL role");
  }
  static string ManagedControlProjection(RawSecurityDescriptor raw){var descriptor=new DirectorySecurity();descriptor.SetSecurityDescriptorSddlForm(raw.GetSddlForm(AccessControlSections.Owner|AccessControlSections.Access));return descriptor.GetSecurityDescriptorSddlForm(AccessControlSections.Owner|AccessControlSections.Access);}
  internal static void AssertControlDescriptor(byte[] actual,string expected){
   if(actual==null||actual.Length<20||actual.Length>65536)throw new InvalidOperationException("bounded raw control ACL input required");
   RawSecurityDescriptor actualRaw,expectedRaw;
   try{actualRaw=new RawSecurityDescriptor(actual,0);expectedRaw=new RawSecurityDescriptor(expected);}catch(ArgumentException e){throw new InvalidOperationException("invalid raw control ACL input",e);}
   string owner=expectedRaw.Owner==null?null:expectedRaw.Owner.Value,logon=null;
   if(!System.Text.RegularExpressions.Regex.IsMatch(owner??"","\\AS-1-5-21-(?:[0-9]+-){3}[0-9]+\\z")||expectedRaw.DiscretionaryAcl==null||expectedRaw.DiscretionaryAcl.Count!=4)throw new InvalidOperationException("fixed user and four-ACE expected policy required");
   foreach(GenericAce item in expectedRaw.DiscretionaryAcl){var ace=item as CommonAce;if(ace!=null&&System.Text.RegularExpressions.Regex.IsMatch(ace.SecurityIdentifier.Value,"\\AS-1-5-5-[0-9]+-[0-9]+\\z")){if(logon!=null)throw new InvalidOperationException("one expected logon role required");logon=ace.SecurityIdentifier.Value;}}
   if(logon==null)throw new InvalidOperationException("expected logon role missing");
   // CommonAcl can sort, merge and drop ACEs. Never use its projection as
   // evidence of the raw count/type/flags/masks that arrived on the handle.
   RequireControlPolicy(expectedRaw,owner,logon);RequireControlPolicy(actualRaw,owner,logon);
   if(ManagedControlProjection(actualRaw)!=ManagedControlProjection(expectedRaw))throw new InvalidOperationException("prepared controller-only write ACL differs");
  }
  internal static DirectoryPins HoldControl(string path,string expected){var held=new DirectoryPins();try{for(string cursor=path;!String.IsNullOrEmpty(cursor);cursor=Path.GetDirectoryName(cursor)){var h=CreateFileW(cursor,0x20080,3,IntPtr.Zero,3,0x02200000,IntPtr.Zero);if(h.IsInvalid){h.Dispose();throw new Win32Exception(Marshal.GetLastWin32Error(),"pin control ancestry");}held.Handles.Add(h);FileInfo info;CdbLeaseNative.Win(GetFileInformationByHandle(h,out info),"control ancestry identity");if((info.Attributes&0x410)!=0x10)throw new InvalidOperationException("control ancestry is not ordinary directory");}AssertControlDescriptor(ReadControlDescriptor(held.Handles[0]),expected);return held;}catch{held.Dispose();throw;}}
 }
 internal static class LeaseAcl {
  static void Sid(string s){if(!System.Text.RegularExpressions.Regex.IsMatch(s??"","\\AS-1-5-(?:[0-9]+-)*[0-9]+\\z"))throw new InvalidOperationException("fixed owner/logon SID");}
  internal static string File(string owner,string logon){Sid(owner);Sid(logon);return "O:"+owner+"D:P(A;;RC;;;OW)(A;;FA;;;"+owner+")(A;;FR;;;"+logon+")(A;;FR;;;WD)";}
  internal static string Directory(string owner,string logon){Sid(owner);Sid(logon);return "O:"+owner+"D:P(A;;RC;;;OW)(A;;FA;;;"+owner+")(A;;FRFX;;;"+logon+")(A;;FRFX;;;WD)";}
 }
}
