using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
namespace Azurite.Restricted {
 internal sealed class LeaseProcessFacts { internal int Pid;internal long Created;internal string Image,Hash;internal bool Live,Inherited;internal uint Rights; }
 internal sealed class LeaseThreadFacts { internal int Tid,Pid;internal long Created;internal bool Live,Inherited;internal uint Rights; }
 internal sealed class LeaseJobFacts { internal int[] Members;internal uint Active,Total,Rights;internal bool BootstrapInside,ChildInside,ControllerInside,Inherited; }
 internal interface ILeaseNative {
  bool Duplicate(IntPtr sourceProcess,long source,uint rights,out IntPtr value,out int error);
  LeaseProcessFacts Process(IntPtr handle);LeaseProcessFacts ReleaseProcess(IntPtr handle);LeaseThreadFacts Thread(IntPtr handle);LeaseJobFacts Job(IntPtr job,IntPtr bootstrap,IntPtr child);FullDesktopIdentity Desktop(IntPtr value);int Close(IntPtr value,bool desktop);
 }
 internal sealed class LeaseOffer {
  internal string Run,ImageHash;internal int BootstrapPid,ChildPid,MainTid;internal long BootstrapCreated,ChildCreated,ThreadCreated,ProcessSource,ThreadSource,JobSource,DesktopSource,NativeStart,NativeDeadline,Frequency;
 }
 internal sealed class CdbTargetLease {
  internal const uint BootstrapRights=0x101040,ProcessRights=0x101000,ThreadRights=0x100800,JobRights=4,DesktopRights=0x20001;
  internal volatile bool BootstrapStarted,Ready;internal readonly List<FullOwnedHandle> Owners=new List<FullOwnedHandle>();
  readonly object ownerLock=new object();bool releaseStarted,releaseResult;long targetSignalObserved;
  internal long TargetSignalObservedQpc {get{return Interlocked.Read(ref targetSignalObserved);}}
  LeaseProcessFacts QueryTarget(){var facts=api.Process(process.Value);if(!facts.Live)Interlocked.CompareExchange(ref targetSignalObserved,Stopwatch.GetTimestamp(),0);return facts;}
  readonly string run,image,hash,bootstrapImage,bootstrapHash;readonly ILeaseNative api;
  FullOwnedHandle bootstrap,process,thread,job,desktop;LeaseOffer accepted;LeaseProcessFacts boot;bool offered,bootstrapValidated;
  internal CdbTargetLease(string id,string target,string pin,string shell,string shellPin,ILeaseNative native) {
   Require(System.Text.RegularExpressions.Regex.IsMatch(id??"","\\A[a-f0-9]{32}\\z")&&native!=null,"fixed run/native required");run=id;image=target;hash=pin;bootstrapImage=shell;bootstrapHash=shellPin;api=native;
  }
  static void Require(bool b,string s){if(!b)throw new InvalidOperationException(s);}
  FullOwnedHandle Duplicate(string role,IntPtr source,long raw,uint rights,bool isDesktop){
   IntPtr candidate;int error;bool okay=api.Duplicate(source,raw,rights,out candidate,out error);
   // A FALSE out value is diagnostic only; it is never an owned reference.
   if(!okay)throw new Win32Exception(error,"Lease DuplicateHandle failed: "+role+"; untrusted output="+candidate.ToInt64());
   Require(candidate!=IntPtr.Zero&&candidate.ToInt64()!=-1,"TRUE duplicate returned no usable reference");
   var owner=new FullOwnedHandle(role,candidate,h=>api.Close(h,isDesktop));Owners.Add(owner);return owner;
  }
  internal void CaptureStarted(int pid,IntPtr actualHandle) {
   lock(ownerLock){
   Require(!BootstrapStarted&&pid>0&&actualHandle!=IntPtr.Zero,"start hook before start or repeated");
   BootstrapStarted=true;bootstrap=Duplicate("bootstrap",new IntPtr(-1),actualHandle.ToInt64(),BootstrapRights,false);
   boot=api.Process(bootstrap.Value);ValidateProcess(boot,pid,boot.Created,bootstrapImage,bootstrapHash,BootstrapRights);bootstrapValidated=true;
   }
  }
  static void ValidateProcess(LeaseProcessFacts v,int pid,long created,string image,string hash,uint rights){Require(v!=null&&pid>0&&created>0&&v.Pid==pid&&v.Created==created&&String.Equals(v.Image,image,StringComparison.OrdinalIgnoreCase)&&v.Hash==hash&&v.Live&&!v.Inherited&&v.Rights==rights,"held process identity/creation/image/liveness/access drift");}
  internal void Accept(LeaseOffer offer) {
   lock(ownerLock){
   Require(BootstrapStarted&&bootstrap!=null&&!offered,"target offer requires unique actual bootstrap lease");offered=true;
   Require(offer!=null&&offer.Run==run&&offer.BootstrapPid==boot.Pid&&offer.BootstrapCreated==boot.Created&&offer.ChildPid>0&&offer.ChildPid!=boot.Pid&&offer.MainTid>0&&offer.ChildCreated>0&&offer.ThreadCreated>0&&offer.ImageHash==hash,"untrusted offer identity");
   Require(offer.NativeStart>0&&offer.Frequency>0&&offer.NativeDeadline>offer.NativeStart&&offer.NativeDeadline-offer.NativeStart==checked(offer.Frequency*10),"native deadline is not original ten-second bound");
   var sources=new[]{offer.ProcessSource,offer.ThreadSource,offer.JobSource,offer.DesktopSource};Require(sources.All(x=>x>0)&&sources.Distinct().Count()==4,"remote handle scalars require positive distinct sources");
   try{
    process=Duplicate("target-process",bootstrap.Value,offer.ProcessSource,ProcessRights,false);
    thread=Duplicate("target-main-thread",bootstrap.Value,offer.ThreadSource,ThreadRights,false);
    job=Duplicate("target-job",bootstrap.Value,offer.JobSource,JobRights,false);
    desktop=Duplicate("target-desktop",bootstrap.Value,offer.DesktopSource,DesktopRights,true);
    accepted=offer;Revalidate();Ready=true;
   }catch{foreach(var owner in new[]{desktop,job,thread,process})if(owner!=null)owner.Close();throw;}
   }
  }
  internal void Revalidate() {
   lock(ownerLock){
   Require(accepted!=null&&bootstrap!=null&&process!=null&&thread!=null&&job!=null&&desktop!=null,"incomplete retained lease");
   ValidateProcess(api.Process(bootstrap.Value),boot.Pid,boot.Created,bootstrapImage,bootstrapHash,BootstrapRights);
   ValidateProcess(QueryTarget(),accepted.ChildPid,accepted.ChildCreated,image,hash,ProcessRights);
   var t=api.Thread(thread.Value);Require(t.Tid==accepted.MainTid&&t.Pid==accepted.ChildPid&&t.Created==accepted.ThreadCreated&&t.Live&&!t.Inherited&&t.Rights==ThreadRights,"held main thread identity drift");
   var j=api.Job(job.Value,bootstrap.Value,process.Value);Require(j.BootstrapInside&&j.ChildInside&&!j.ControllerInside&&!j.Inherited&&j.Rights==JobRights&&j.Active==2&&j.Total==2&&j.Members!=null&&j.Members.Length==2&&new HashSet<int>(j.Members).SetEquals(new[]{boot.Pid,accepted.ChildPid}),"exact target Job lineage drift");
   var d=api.Desktop(desktop.Value);FullDesktopMonitor.ValidateIdentity(d,desktop.Value,"AzuriteFullCli_"+run);Require(d.GrantedAccess==DesktopRights,"desktop query lease access drift");
   }
  }
  bool ProcessDrained(FullOwnedHandle owner,int pid,long created,uint rights,bool observeTarget) {
   if(owner==null||owner.Value==IntPtr.Zero||owner.Value!=owner.Acquired||owner.Closed||owner.Retained||owner.CloseAttempted||owner.CloseError!=0||!String.IsNullOrEmpty(owner.CloseException))return false;
   var facts=api.ReleaseProcess(owner.Value);
   Require(facts!=null&&pid>0&&created>0&&facts.Pid==pid&&facts.Created==created&&!facts.Inherited&&facts.Rights==rights,"release held process identity/creation/access drift");
   if(facts.Live)return false;
   if(observeTarget)Interlocked.CompareExchange(ref targetSignalObserved,Stopwatch.GetTimestamp(),0);
   return true;
  }
  internal bool CloseAfterDrain(bool drained) {
   lock(ownerLock){
   if(releaseStarted)return releaseResult;
   if(!drained)return false;
   // A cached object can exist before live admission validation has succeeded.
   // Release only the same admitted references; exited image lookup is not proof.
   if(!bootstrapValidated||boot==null||!ProcessDrained(bootstrap,boot.Pid,boot.Created,BootstrapRights,false))return false;
   if(process!=null&&!process.Closed&&(!Ready||accepted==null||!ProcessDrained(process,accepted.ChildPid,accepted.ChildCreated,ProcessRights,true)))return false;
   if(thread!=null&&!thread.Closed&&api.Thread(thread.Value).Live)return false;
   if(job!=null&&!job.Closed){var snapshot=api.Job(job.Value,bootstrap.Value,process.Value);if(snapshot.Active!=0||snapshot.Members==null||snapshot.Members.Length!=0||snapshot.Total!=2)return false;}
   // Drain is now proven through live retained references. Commit that fact
   // before release; a later finally must not re-query closed references or
   // retry a failed native close. FullOwnedHandle retains every failed owner.
   releaseStarted=true;bool okay=true;foreach(var owner in new[]{desktop,thread,process,job,bootstrap})if(owner!=null)okay=owner.Close()&&okay;releaseResult=okay;return releaseResult;
   }
  }
  internal object[] OwnerSnapshot(){
   if(!Monitor.TryEnter(ownerLock))throw new InvalidOperationException("owner snapshot busy; actual owner retention remains independent");
   try{Require(Owners.Count<=5,"fixed lease owner bound");return Owners.Select(o=>(object)new{role=o.Role,acquired=o.Acquired.ToInt64(),value=o.Value.ToInt64(),closed=o.Closed,retained=o.Retained,error=o.CloseError}).ToArray();}finally{Monitor.Exit(ownerLock);}
  }
 }
}
