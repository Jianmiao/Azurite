#ifndef AZURITE_CHILD_GO_CODEC_H
#define AZURITE_CHILD_GO_CODEC_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/* Pure bytes/state only; this is the helper called by the real child gate. */
typedef struct {char run[33];uint32_t pid,tid;uint64_t creation,start,deadline;int begun,consumed,rejected;} ChildGoState;
static int child_go_prepare(ChildGoState *state,int exists,const char *run,uint32_t pid,uint32_t tid,uint64_t creation,uint64_t start,uint64_t deadline,uint64_t now){
 size_t i;
 if(!state)return 0;
 if(state->begun||state->consumed||state->rejected||exists||!run||!pid||!tid||!creation||!start||deadline<=start||deadline-start!=12000||now<start||now>=deadline){state->rejected=1;return 0;}
 for(i=0;i<32;i++){char c=run[i];if(!((c>='0'&&c<='9')||(c>='a'&&c<='f'))){state->rejected=1;return 0;}}
 if(run[32]){state->rejected=1;return 0;}
 memcpy(state->run,run,33);state->pid=pid;state->tid=tid;state->creation=creation;state->start=start;state->deadline=deadline;state->begun=1;return 1;
}
static int child_go_accept(ChildGoState *state,const char *bytes,size_t count,uint64_t now){
 char text[1024],prefix[128],expected[1024],*end;unsigned long long bootstrap;int prefixCount,expectedCount;size_t i;
 if(!state)return 0;
 if(!state->begun||state->consumed||state->rejected||!bytes||count<2||count>=sizeof(text)||now<state->start||now>=state->deadline){state->rejected=1;return 0;}
 state->rejected=1; /* Any invalid record is terminal, matching child exit. */
 for(i=0;i<count;i++)if((unsigned char)bytes[i]<32||(unsigned char)bytes[i]>126)return 0;
 memcpy(text,bytes,count);text[count]=0;
 prefixCount=snprintf(prefix,sizeof(prefix),"{\"protocol\":\"go.v1\",\"runId\":\"%s\",\"bootstrapPid\":",state->run);
 if(prefixCount<=0||(size_t)prefixCount>=sizeof(prefix)||(size_t)prefixCount>=count||memcmp(text,prefix,(size_t)prefixCount))return 0;
 bootstrap=strtoull(text+prefixCount,&end,10);
 if(end==text+prefixCount||*end!=','||bootstrap==0||bootstrap>UINT32_MAX)return 0;
 expectedCount=snprintf(expected,sizeof(expected),"{\"protocol\":\"go.v1\",\"runId\":\"%s\",\"bootstrapPid\":%lu,\"childPid\":%lu,\"mainTid\":%lu,\"creation\":%llu}",state->run,(unsigned long)bootstrap,(unsigned long)state->pid,(unsigned long)state->tid,(unsigned long long)state->creation);
 if(expectedCount<=0||(size_t)expectedCount>=sizeof(expected)||(size_t)expectedCount!=count||memcmp(text,expected,count))return 0;
 state->rejected=0;state->consumed=1;return 1;
}
#endif
