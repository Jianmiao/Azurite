using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
namespace Azurite.Restricted {
 internal sealed class LeaseOperations:IFullRestrictedOperations {
  readonly IFullRestrictedOperations api;readonly Action handshake;readonly Func<bool> inTime;bool ack,resume;
  readonly Action<string,long> record;readonly Func<long> observationClock;
  internal Exception RecordingError;
  internal LeaseOperations(IFullRestrictedOperations inner,Action transfer,Func<bool> deadline,Action<string,long> stage=null,Func<long> clock=null){api=inner;handshake=transfer;inTime=deadline;record=stage;observationClock=clock??Stopwatch.GetTimestamp;}
  public void ReadOriginalAndDerive(){api.ReadOriginalAndDerive();}public void AcquireDesktopLease(){api.AcquireDesktopLease();}public void CreateSuspended(){api.CreateSuspended();}public void ValidateActualToken(){api.ValidateActualToken();}public void ValidateExactJob(){api.ValidateExactJob();}
  public void PrepareStreams(){if(ack||resume)throw new InvalidOperationException("repeated stream/lease transfer");api.PrepareStreams();if(!inTime())throw new InvalidOperationException("original deadline before offer");handshake();if(!inTime())throw new InvalidOperationException("original deadline before ACK acceptance");ack=true;}
  public uint Resume(){if(!ack||resume||!inTime())throw new InvalidOperationException("actual ACK and original deadline required for unique Resume");resume=true;return api.Resume();}
  void Mark(string name){try{if(record!=null)record(name,observationClock());}catch(Exception e){if(RecordingError==null)RecordingError=e;}}
  public void Monitor(){api.Monitor();}public bool Cleanup(){Mark("inner-cleanup-start");try{return api.Cleanup();}finally{Mark("inner-cleanup-end");}}public void Close(){api.Close();}
 }
 public static class LifecycleFixture {
  public static string Lab{get{return FullRestrictedContract.Lab;}}
  public static string Target{get{return FullRestrictedContract.Executable;}}
  static T Private<T>(FullRestrictedSpawn api,string name){if(name!="pi"&&name!="desktop"&&name!="childCreated")throw new InvalidOperationException("fixed source field only");return (T)typeof(FullRestrictedSpawn).GetField(name,BindingFlags.NonPublic|BindingFlags.Instance).GetValue(api);}
  public static FullRestrictedPumpResult RunNormal(ProcessStartInfo info,OwnedJob job,string id,string argumentsHash,string targetHash,string shellHash,string ownerSid,string logonSid){
   string run=Lab+@"\runs\restricted-"+id;FullRestrictedContract.ValidateRequest(id,run,"capabilities",info.FileName,info.Arguments,info.EnvironmentVariables["AZUREARCHIVE_CLI_DIRECTORY"],info.EnvironmentVariables["BEPINEX_GAME_ASSEMBLY_PATH"]);
   FullRestrictedContract.Require(job!=null&&info.WorkingDirectory==Lab+@"\install"&&String.IsNullOrEmpty(info.UserName)&&!info.UseShellExecute&&info.CreateNoWindow&&info.RedirectStandardOutput&&info.RedirectStandardError,"normal-only fixture startup contract");
   using(var pins=new LeasePinnedFiles())using(var directories=LeaseFiles.HoldControl(run+@"\control",LeaseAcl.Directory(ownerSid,logonSid))){
    string shell=Environment.GetFolderPath(Environment.SpecialFolder.System)+@"\WindowsPowerShell\v1.0\powershell.exe";pins.Add(Target,targetHash);pins.Add(shell,shellHash);var native=new CdbLeaseNative(pins.Hashes);
    // Exported start precedes construction; it can be earlier, never later,
    // than FullRestrictedSpawn's unmodified ten-second Stopwatch origin.
    long start=Stopwatch.GetTimestamp();var deadline=new LeaseDeadline(start,Stopwatch.Frequency,10000,Stopwatch.GetTimestamp);
    var api=new FullRestrictedSpawn(info,10000,job,id,run,argumentsHash,262144,new[]{run+@"\request",run+@"\output"},4194304);
    var wrapper=new LeaseOperations(api,()=>{
     FullRestrictedContract.Require(Private<bool>(api,"childCreated")&&!api.Result.Process.NoProcessCreated&&(bool)api.Result.Evidence["actualTokenVerified"]&&(bool)api.Result.Evidence["exactOwnedJobVerified"]&&api.Result.DesktopLeaseAcknowledged,"offer requires confirmed create/token/Job/desktop validation");
     var pi=Private<FullRestrictedSpawn.Pi>(api,"pi");LeaseProcessFacts bootstrap;using(var current=Process.GetCurrentProcess())bootstrap=native.Process(current.Handle);
     var child=native.Process(pi.Process);var primary=native.Thread(pi.Thread);
     var offer=new LeaseOffer{Run=id,ImageHash=targetHash,BootstrapPid=bootstrap.Pid,ChildPid=child.Pid,MainTid=primary.Tid,BootstrapCreated=bootstrap.Created,ChildCreated=child.Created,ThreadCreated=primary.Created,ProcessSource=pi.Process.ToInt64(),ThreadSource=pi.Thread.ToInt64(),JobSource=job.FullHandle.ToInt64(),DesktopSource=Private<IntPtr>(api,"desktop").ToInt64(),NativeStart=start,NativeDeadline=deadline.Expiry,Frequency=Stopwatch.Frequency};
     FullRestrictedContract.Require(child.Live&&primary.Live&&primary.Pid==child.Pid&&child.Pid==api.Result.Process.Pid&&primary.Tid==pi.Tid&&child.Image.Equals(Target,StringComparison.OrdinalIgnoreCase),"actual source handle identity mismatch");
     string ackPath=run+@"\control\lease-ack.json",goPath=run+@"\control\go.json";FullRestrictedContract.Require(!File.Exists(ackPath)&&!File.Exists(goPath),"stale ACK/go before offer");
     LeaseFiles.Create(run+@"\control\lease-offer.json",LeaseRecords.OfferBytes(offer),LeaseAcl.File(ownerSid,logonSid));
     FullRestrictedContract.Require(LeaseFiles.AwaitRead(ackPath,()=>deadline.Remaining).SequenceEqual(LeaseRecords.Signal("lease-ack.v1",id,bootstrap.Pid,child.Pid,primary.Tid,child.Created)),"wrong/stale/malformed actual lease ACK");
     api.Result.Evidence["actualLeaseAcknowledged"]=true;api.Result.Evidence["nativeStartQpc"]=start;api.Result.Evidence["nativeDeadlineQpc"]=deadline.Expiry;api.Result.Evidence["leaseAckQpc"]=Stopwatch.GetTimestamp();
    },()=>deadline.Remaining>0,(stage,qpc)=>{api.Result.Evidence[stage=="inner-cleanup-start"?"innerCleanupStartQpc":"innerCleanupEndQpc"]=qpc;});
    var outcome=FullRestrictedCoordinator.Run(wrapper);api.Result.Process.Error=outcome.Error;api.Result.Process.CleanupError=outcome.CleanupError;api.Result.Process.CleanupVerified=outcome.CleanupVerified&&api.Result.NativeHandlesClosed&&wrapper.RecordingError==null;api.Result.Evidence["coordinatorStages"]=outcome.Stages;api.Result.Evidence["resumeCalls"]=outcome.ResumeCalls;api.Result.Evidence["resumeVerified"]=outcome.ResumeVerified;api.Result.Evidence["cleanupBoundarySemantics"]="QPC sampled at fixture wrapper entry/exit; original cleanup clock unchanged";api.Result.Evidence["cleanupBoundaryError"]=wrapper.RecordingError==null?null:wrapper.RecordingError.ToString();api.Result.CleanupError=outcome.CleanupError;return api.Result;
   }
  }
 }
}
