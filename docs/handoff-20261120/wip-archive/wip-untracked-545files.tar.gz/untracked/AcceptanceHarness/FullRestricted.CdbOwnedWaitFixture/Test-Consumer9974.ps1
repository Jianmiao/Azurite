#requires -Version 5.1
param([Parameter(Mandatory)][ValidatePattern('^(red|green)(-[a-z0-9]+)?$')][string]$Stage,[switch]$ExpectRed)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1){throw 'Fresh x64 Windows PowerShell 5.1 required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$root=$repo+'\artifacts\aa-cdb-native-control-preparation-20261113\consumer9974-20261114';$output=$root+'\'+$Stage
if(-not(Test-Path -LiteralPath $root) -or (Test-Path -LiteralPath $output)){throw 'Fresh fixed consumer test stage required'}
[void][IO.Directory]::CreateDirectory($output)
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
$inputManifestPath=$root+'\input-manifest.json';if((Hash $inputManifestPath) -cne 'ad12e7f2af3dd1bba37d210ad2a3e5914cc6cde948ac3321b00f5061bc407bf6'){throw 'Exact actual-run input manifest required'}
$inputManifest=Get-Content -LiteralPath $inputManifestPath -Raw|ConvertFrom-Json
foreach($file in $inputManifest.records){if((Hash $file.copy) -cne $file.sha256 -or (Get-Item -LiteralPath $file.copy).Length -ne $file.bytes){throw 'Actual archived input copy drift'}}
$nativeModule=$repo+'\artifacts\aa-fr-native-lifecycle-fixture\build-cdb-owned-wait2-9974-rq2-native1\source\NativeControl.psm1';if((Hash $nativeModule) -cne $inputManifest.nativeControlModuleSha256){throw 'Unchanged native metadata consumer required'}
$rules=$PSScriptRoot+'\FixtureRules.psm1';$rulesHash=Hash $rules;[IO.File]::Copy($rules,($output+'\FixtureRules.psm1'),$false)
Import-Module $nativeModule -Force -DisableNameChecking
Import-Module ($output+'\FixtureRules.psm1') -Force -DisableNameChecking
Assert-FixtureHost
function Read-Input([string]$Name){Read-FixtureJson ($root+'\inputs\'+$Name) 1048576}
$retained=Read-Input 'retained.json';$manifest=Read-Input 'runtime-manifest.json'
$data=[pscustomobject]@{outer=(Read-Input 'outer.json');bootstrap=(Read-Input 'bootstrap.json');gate=$retained.gate;control=(Read-Input 'control.json');prepared=(Read-Input 'prepared.json');entry=(Read-Input 'entry.json');waitEntry=(Read-Input 'wait-host-entry.json');waitResult=(Read-Input 'wait-host-result.json');waitProbe=(Read-Input 'wait-probe.json');protection=(Read-Input 'protection-result.json')}
$runId=$inputManifest.runId;$packageHash=$inputManifest.runtimePackageSha256;$controlHash=Hash ($root+'\inputs\control.json');$probeBytes=(Get-Item -LiteralPath ($root+'\inputs\wait-probe.json')).Length
if($runId -cne 'e6adc2d85a084ffba2966e404ddd907e' -or $packageHash -cne (Hash ($root+'\inputs\runtime-manifest.json')) -or $inputManifest.historicalRunDisposition -cne 'FAILED-forced-stop' -or $inputManifest.protectionBeforeSnapshotsAvailable){throw 'Historical failed-run scope changed'}
function Copy-Case{($data|ConvertTo-Json -Depth 90 -Compress)|ConvertFrom-Json}
function Monitor($d,[string]$Key){switch($Key){'outer'{$d.outer.FullDesktopMonitorEvidence;break};'bootstrap'{$d.bootstrap.native.Evidence.fullDesktopMonitor;break};'inner'{$d.bootstrap.native.Process.FullDesktopMonitorEvidence;break};default{throw 'Unknown fixed monitor source'}}}
function Invoke-Part($d,[string]$Part){
 switch($Part){
  'binding'{Assert-NativeBinding $d.prepared $d.control $packageHash $controlHash $runId $d.prepared.originQpc $d.prepared.frequency $d.prepared.hostPid $d.prepared.hostCreationFileTime;break}
  'gate'{Assert-LeaseGateResult $d.outer $d.bootstrap $d.gate;break}
  'child'{Assert-FixtureChild $d.entry $d.control;break}
  'native-evidence'{Assert-FixtureNativeEvidence $d.bootstrap.native.Evidence $d.entry;break}
  'streams'{Assert-FixtureCaptured $d.bootstrap.native.Process.Stdout $d.bootstrap.native.Process.Stderr $runId;break}
  'runtime-files'{Assert-FixtureWaitRuntimePins $manifest.runtimePins;break}
  'cleanup'{Assert-FixtureCleanupOrdering $d.outer.FullDesktopMonitorEvidence.outerDrain $d.outer $runId;break}
  'wait'{$w=Assert-FixtureWaitProbe $d.waitEntry $d.waitResult $d.waitProbe $runId $d.entry.pid $d.bootstrap.native.Evidence.threadId $probeBytes;[pscustomobject]@{diagnosticOnly=$w.diagnosticOnly;applicationAccepted=$w.applicationAccepted;caseCount=$w.caseCount;successfulWaitCount=$w.successfulWaitCount;allWaitCallsSucceeded=$w.allWaitCallsSucceeded};break}
  'available-chain'{
   Invoke-Part $d 'binding';Invoke-Part $d 'runtime-files';Invoke-Part $d 'gate';Invoke-Part $d 'child';Invoke-Part $d 'native-evidence';Invoke-Part $d 'streams'
   Assert-FixtureMonitorEvidence (Monitor $d 'outer') $runId;Assert-FixtureMonitorEvidence (Monitor $d 'bootstrap') $runId;Assert-FixtureMonitorEvidence (Monitor $d 'inner') $runId
   Invoke-Part $d 'cleanup';Invoke-Part $d 'wait';Invoke-Part $d 'runtime-files';break
  }
  default{throw 'Unknown fixed consumer segment'}
 }
}
$cases=[Collections.Generic.List[object]]::new()
function Case([string]$CaseName,[scriptblock]$Work,[bool]$ShouldReject=$false,[scriptblock]$Mutate=$null){
 $sample=Copy-Case;$rejected=$false;$errorType=$null;$errorId=$null;$message=$null;$trace=$null;$returned=@()
 try{if($Mutate){& $Mutate $sample};$returned=@(& $Work $sample)}catch{$rejected=$true;$errorType=$_.Exception.GetType().FullName;$errorId=$_.FullyQualifiedErrorId;$message=$_.Exception.Message;$trace=$_.ScriptStackTrace}
 $cases.Add([pscustomobject]@{name=$CaseName;passed=($rejected -eq $ShouldReject);expectedReject=$ShouldReject;rejected=$rejected;errorType=$errorType;errorId=$errorId;message=$message;stack=$trace;returned=$returned})
}
Case 'historical FAILED wrapper is never relabeled by replay' {param($d) if($retained.runId -cne $runId -or $retained.nativeOwnersResolved -ne $false -or $retained.releaseComplete -ne $false -or $retained.mutexHeld -ne $true -or [string]::IsNullOrEmpty($retained.primaryError)){throw 'Original failure disposition changed'}}
foreach($partKey in @('binding','gate','child','native-evidence','streams','runtime-files')){Case ('actual archived consumer: '+$partKey) {param($d) Invoke-Part $d $partKey}}
foreach($monitorKey in @('outer','bootstrap','inner')){
 Case ('actual archived monitor: '+$monitorKey) {param($d) Assert-FixtureMonitorEvidence (Monitor $d $monitorKey) $runId}
 foreach($sampleKey in @('first','last')){Case ('actual archived two-image records: '+$monitorKey+' '+$sampleKey) {param($d) $m=Monitor $d $monitorKey;Assert-FixtureImagePins $m.$sampleKey.imagePins}}
}
Case 'actual cleanup function reaches its own local dependency' {param($d) Invoke-Part $d 'cleanup'}
Case 'actual wait correlation and diagnostic matrix after monitor' {param($d) Invoke-Part $d 'wait'}
Case 'complete available archived chain through CleanupOrdering and Wait' {param($d) Invoke-Part $d 'available-chain'}
Case 'localized raw version remains evidence while fixed versions stay exact' {param($d) Assert-FixtureMonitorEvidence (Monitor $d 'outer') $runId} $false {param($d) $d.outer.FullDesktopMonitorEvidence.first.imagePins[0].rawFileVersion='different nonempty localized display'}
Case 'missing original protection before snapshots cannot be accepted' {param($d) Assert-FixtureProtection -Probe $d.protection -Before $null -After $null -DirectoryBefore $null -DirectoryAfter $null -AnchorsBefore @() -AnchorsAfter @() -Positive $null -RunId $runId -ProcessId $d.entry.pid -NativeThreadId $d.bootstrap.native.Evidence.threadId -OwnerSid $d.control.userSid -LogonSid $d.control.logonSid -ExpectedHash $manifest.canarySha256 -ExpectedBytes 36} $true
foreach($monitorKey in @('outer','bootstrap','inner')){foreach($sampleKey in @('first','last')){foreach($targetImage in @(0,1)){foreach($pinField in @('sha256','expectedSha256','fixedFileVersion','expectedFixedFileVersion')){
 $drift=if($pinField -like '*Version'){if($targetImage -eq 0){'10.0.26100.9974'}else{'10.0.26100.9818'}}elseif($targetImage -eq 0){'5db5c7ceec0b8c19344d3720bb3548ad01831966d27d766204429d3147e46ecc'}else{'ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4'}
 Case ('image drift rejected: '+$monitorKey+' '+$sampleKey+' '+$targetImage+' '+$pinField) {param($d) $m=Monitor $d $monitorKey;Assert-FixtureImagePins $m.$sampleKey.imagePins} $true {param($d) $m=Monitor $d $monitorKey;$m.$sampleKey.imagePins[$targetImage].$pinField=$drift}
}}}}
foreach($targetImage in @(0,1)){foreach($typedField in @('name','sha256','expectedSha256','fixedFileVersion','expectedFixedFileVersion')){Case ('Boolean cannot substitute exact image string: '+$targetImage+' '+$typedField) {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.first.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.first.imagePins[$targetImage].$typedField=$true}}}
foreach($monitorKey in @('outer','bootstrap','inner')){Case ('old combined identity rejected: '+$monitorKey) {param($d) Assert-FixtureMonitorEvidence (Monitor $d $monitorKey) $runId} $true {param($d) $m=Monitor $d $monitorKey;$m.pinnedImageIdentity='user32.dll|10.0.26100.9818|4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91|EnumDesktopWindows:0x2a9a0;win32u.dll|10.0.26100.9818|ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4|NtUserBuildHwndList:0x1610'}}
foreach($monitorKey in @('outer','bootstrap','inner')){Case ('Boolean cannot replace complete pin identity: '+$monitorKey) {param($d) Assert-FixtureMonitorEvidence (Monitor $d $monitorKey) $runId} $true {param($d) $m=Monitor $d $monitorKey;$m.pinnedImageIdentity=$true}}
Case 'actual image row order remains fixed' {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.last.imagePins} $true {param($d) $p=$d.outer.FullDesktopMonitorEvidence.last.imagePins;$d.outer.FullDesktopMonitorEvidence.last.imagePins=@($p[1],$p[0])}
Case 'duplicate user32 cannot replace win32u' {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.last.imagePins} $true {param($d) $p=$d.outer.FullDesktopMonitorEvidence.last.imagePins;$d.outer.FullDesktopMonitorEvidence.last.imagePins=@($p[0],$p[0])}
Case 'missing image cannot pass exact two-row contract' {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.last.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.last.imagePins=@($d.outer.FullDesktopMonitorEvidence.last.imagePins[0])}
Case 'missing actual field cannot hide a pin' {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.first.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.first.imagePins[1].PSObject.Properties.Remove('expectedSha256')}
foreach($pathField in @('path','expectedPath')){Case ('loaded image path remains strict: '+$pathField) {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.first.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.first.imagePins[1].$pathField='C:\elsewhere\win32u.dll'}}
foreach($offsetField in @('exportOffset','expectedExportOffset')){Case ('loaded export remains strict: '+$offsetField) {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.first.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.first.imagePins[1].$offsetField=0}}
foreach($matchField in @('pathMatch','hashMatch','fixedVersionMatch','exportMatch','nonReparseMatch')){Case ('actual image match flag required: '+$matchField) {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.last.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.last.imagePins[1].$matchField=$false}}
Case 'reparse image remains refused' {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.first.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.first.imagePins[0].reparse=$true}
Case 'empty raw metadata remains refused' {param($d) Assert-FixtureImagePins $d.outer.FullDesktopMonitorEvidence.first.imagePins} $true {param($d) $d.outer.FullDesktopMonitorEvidence.first.imagePins[0].rawFileVersion=''}
foreach($countField in @('emptyCount','normalCount','failedCount')){Case ('actual monitor counter drift rejected: '+$countField) {param($d) Assert-FixtureMonitorEvidence $d.outer.FullDesktopMonitorEvidence $runId} $true {param($d) $d.outer.FullDesktopMonitorEvidence.$countField=if($countField -ceq 'emptyCount'){0}else{1}}}
Case 'foreign desktop name rejected' {param($d) Assert-FixtureMonitorEvidence $d.outer.FullDesktopMonitorEvidence $runId} $true {param($d) $d.outer.FullDesktopMonitorEvidence.last.expectedName='AzuriteFullCli_00000000000000000000000000000000'}
Case 'list sentinel drift rejected' {param($d) Assert-FixtureMonitorEvidence $d.outer.FullDesktopMonitorEvidence $runId} $true {param($d) $d.outer.FullDesktopMonitorEvidence.last.list.first=0}
Case 'actual desktop rights still required' {param($d) Assert-FixtureMonitorEvidence $d.outer.FullDesktopMonitorEvidence $runId} $true {param($d) $d.outer.FullDesktopMonitorEvidence.last.identityAfter.grantedAccess=0}
Case 'enumeration callback failure still rejected' {param($d) Assert-FixtureMonitorEvidence $d.outer.FullDesktopMonitorEvidence $runId} $true {param($d) $d.outer.FullDesktopMonitorEvidence.last.enumeration.callbackError='injected drift'}
Case 'archived P and Q cannot be substituted' {param($d) Invoke-Part $d 'binding'} $true {param($d) $d.prepared.packageSha256='b'*64}
Case 'archived control must match Q' {param($d) Invoke-Part $d 'binding'} $true {param($d) $d.control.packageSha256='b'*64}
Case 'actual held-gate refusal stays rejected' {param($d) Invoke-Part $d 'gate'} $true {param($d) $d.gate.holdHost=$true}
Case 'actual inner cleanup failure stays rejected' {param($d) Invoke-Part $d 'gate'} $true {param($d) $d.bootstrap.native.Process.CleanupVerified=$false}
Case 'foreign child run stays rejected' {param($d) Invoke-Part $d 'child'} $true {param($d) $d.entry.runId='0'*32}
Case 'native creation flags remain strict' {param($d) Invoke-Part $d 'native-evidence'} $true {param($d) $d.bootstrap.native.Evidence.creationFlags=0}
Case 'captured UTF8 output drift stays rejected' {param($d) Invoke-Part $d 'streams'} $true {param($d) $d.bootstrap.native.Process.Stdout+='extra'}
Case 'cleanup cannot omit final Job release' {param($d) Invoke-Part $d 'cleanup'} $true {param($d) $d.outer.FullDesktopMonitorEvidence.outerDrain.records[-1].jobAfter=3404}
Case 'cleanup cannot claim incomplete streams' {param($d) Invoke-Part $d 'cleanup'} $true {param($d) $d.outer.FullDesktopMonitorEvidence.outerDrain.records[-3].boolean=$false}
Case 'cleanup trace stays bound to actual bootstrap PID' {param($d) Invoke-Part $d 'cleanup'} $true {param($d) $d.outer.FullDesktopMonitorEvidence.outerDrain.bootstrapPid++}
Case 'later Wait rejects changed child PID after preceding consumers' {param($d) Invoke-Part $d 'available-chain'} $true {param($d) $d.entry.pid++}
Case 'Wait retains initial thread correlation' {param($d) Invoke-Part $d 'wait'} $true {param($d) $d.waitProbe.sameInitialThread=$false}
Case 'Wait actual byte count cannot drift' {param($d) Invoke-Part $d 'wait'} $true {param($d) $d.waitResult.managedBytes++}
Case 'Wait fixed runtime cannot drift' {param($d) Invoke-Part $d 'wait'} $true {param($d) $d.waitProbe.runtime='.NET wrong'}
Case 'Wait matrix may not omit actual cases' {param($d) Invoke-Part $d 'wait'} $true {param($d) $d.waitProbe.records=@($d.waitProbe.records|Select-Object -Skip 1)}
Case 'Wait mutex identity cannot be fabricated' {param($d) Invoke-Part $d 'wait'} $true {param($d) $d.waitProbe.records[0].mutexName='wrong'}
if((Hash $rules) -cne $rulesHash -or (Hash ($output+'\FixtureRules.psm1')) -cne $rulesHash){throw 'Actual consumer source changed during replay'}
foreach($file in $inputManifest.records){if((Hash $file.copy) -cne $file.sha256){throw 'Replay changed immutable input bytes'}}
$normal=@([AppDomain]::CurrentDomain.GetAssemblies()|Where-Object{$_.GetName().Name -in @('NativeControl.Preparation','AzuriteLifecycle.FixtureOnly')});if($normal.Count){throw 'Normal helper assembly was loaded'}
$failed=@($cases|Where-Object{-not $_.passed}).Count
$record=[ordered]@{schema='consumer9974-real-replay.v1';stage=$Stage;expectedRed=[bool]$ExpectRed;sourceBuildOnly=$true;nativeExecuted=$false;normalDllLoaded=$false;originalRunId=$runId;historicalRuntimeVerdict='FAILED-forced-stop';historicalRuntimeReclassified=$false;authorizationInvoked=$false;rulesSource=$rules;rulesSha256=$rulesHash;rulesSnapshotSha256=(Hash ($output+'\FixtureRules.psm1'));testSourceSha256=(Hash $PSCommandPath);nativeControlModuleSha256=(Hash $nativeModule);inputManifestSha256=(Hash $inputManifestPath);actualInputRecords=12;inputCopiesUnchanged=$true;checks=$cases.Count;failed=$failed;coverage=@{staticPQControl=$true;leaseGate=$true;childAndNativeEvidence=$true;streams=$true;outerAndInnerMonitor=$true;cleanupOrdering=$true;waitCorrelationAndMatrix=$true;runtimeFilesReadOnly=$true;protectionPositive=$false;protectionMissingEvidenceRejected=$true;protectionReason='Original controller before/after snapshots are absent; no after snapshot or reconstructed fixture substituted';fullRuntimeWrapperExecuted=$false};cases=$cases.ToArray()}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($record|ConvertTo-Json -Depth 30));$f=[IO.File]::Open(($output+'\source-test.json'),'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}
[pscustomobject]@{checks=$cases.Count;failed=$failed;rulesSha256=$rulesHash;historicalRuntimeVerdict='FAILED-forced-stop';sourceOnly=$true;nativeExecuted=$false;record=($output+'\source-test.json');failedCases=@($cases|Where-Object{-not $_.passed}|Select-Object name,errorType,errorId,message)}|ConvertTo-Json -Depth 6
if($failed -gt 0){exit 1}
