#requires -Version 5.1
param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Stage,[switch]$ExpectRed)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Fresh x64 Windows PowerShell 5.1 required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$build=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\build-cdb-owned-wait2-9974-cons1'
if([IO.File]::ReadAllText(($build+'\source-build-owner.txt')) -cne 'lease-gate-task-a-9974-cons1-20261114'){throw 'Wrong build reservation'}
$output=Join-Path $build $Stage;if(Test-Path -LiteralPath $output){throw 'Preserve existing pure evidence'};[void][IO.Directory]::CreateDirectory($output)
$nativeSources=if(Test-Path ($build+'\generated\RestrictedCliFullRestricted.cs')){@(($build+'\generated\RestrictedCliNative.cs'),($build+'\generated\RestrictedCliFullRestricted.cs'))}else{@((Join-Path $repo 'tools\headless\RestrictedCliNative.cs'),(Join-Path $repo 'tools\headless\RestrictedCliFullRestricted.cs'))}
$sources=$nativeSources+@(Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cs' -File|Where-Object Name -NE 'WaitProbe.Managed.cs'|Select-Object -ExpandProperty FullName)
$guarded=@();$proof=@();foreach($source in $sources){$before=[IO.File]::ReadAllText($source);$pattern='(\[DllImport\s*\(\s*)"[^"]+"';$after=[regex]::Replace($before,$pattern,'$1"Azurite.SourceBuildOnly.Forbidden.Native.dll"');$path=Join-Path $output ([IO.Path]::GetFileName($source));[IO.File]::WriteAllText($path,$after,[Text.UTF8Encoding]::new($false));$guarded+=$path;$proof+=@{source=$source;sha256=(Get-FileHash $source).Hash.ToLowerInvariant();guardedSha256=(Get-FileHash $path).Hash.ToLowerInvariant();importReplacements=([regex]::Matches($before,$pattern)).Count}}
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$extra=@();if($ExpectRed){$extra+='/nowarn:0649,0414,0169'}
& $csc /nologo /target:exe /platform:x64 /warn:4 /warnaserror+ /r:System.Web.Extensions.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll @extra ('/out:'+$output+'\Lease.PureTests.exe') @guarded 2>&1|Tee-Object -FilePath ($output+'\build.log')
if($LASTEXITCODE){throw 'Source-linked guarded tests did not compile'}
& ($output+'\Lease.PureTests.exe') 2>&1|Tee-Object -FilePath ($output+'\result.log');$code=$LASTEXITCODE
[IO.File]::WriteAllText(($output+'\guard-manifest.json'),(@{sourceBuildOnly=$true;nativeExecuted=$false;exitCode=$code;host=$PSVersionTable.PSVersion.ToString();x64=[Environment]::Is64BitProcess;files=$proof}|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
if(($ExpectRed -and $code -ne 1)-or(-not $ExpectRed -and $code -ne 0)){throw 'Unexpected pure test outcome'}
