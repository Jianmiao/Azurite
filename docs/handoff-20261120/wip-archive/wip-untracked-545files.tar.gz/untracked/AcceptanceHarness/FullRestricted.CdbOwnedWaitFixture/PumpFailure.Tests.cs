using System;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
namespace Azurite.Restricted {
 internal static class PumpFailureTests {
  const string Id="11111111111111111111111111111111";
  static int count,failed;
  static void Check(bool ok,string why){if(!ok)throw new Exception(why);}
  static void Case(string name,Action body){count++;try{body();Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+": "+e.Message);}}
  static PumpResult Pump(){return new PumpResult{RunId=Id,Pid=20,ExitCode=1,Stdout="original-pump-out",Stderr="original-pump-err",Error="pinned desktop implementation refused",CleanupError="original desktop monitor failed",CleanupVerified=false,FullRestrictedMode=true,JobObserved=true,DirectProcessExited=true,JobDrained=true,RemainingOwnedProcesses=0,DesktopLeaseObserved=true,DesktopLeaseClosed=true,DesktopLeaseRetained=false,StreamCaptureComplete=true,FullJobObserverClosed=true,FullJobObserverRetained=false,FullJobObserverCloseError=0};}
  sealed class Fixture {
   internal readonly LeaseFake Api=new LeaseFake();internal readonly CdbTargetLease Lease;internal readonly CdbGateProtocol Gate;
   internal Fixture(){Lease=new CdbTargetLease(Id,"target",new string('a',64),"bootstrap",new string('a',64),Api);Lease.CaptureStarted(20,new IntPtr(55));Gate=new CdbGateProtocol(Lease,Id,new LeaseDeadline(100,1000,30000,()=>100),()=>100,()=>100);Api.Drained=true;Api.Queried.Clear();}
  }
  static object Field(object obj,string name){return obj.GetType().GetField(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).GetValue(obj);}
  static void Set(object obj,string name,object value){obj.GetType().GetField(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).SetValue(obj,value);}
  static object Property(object obj,string name){var p=obj.GetType().GetProperty(name);return p==null?null:p.GetValue(obj,null);}
  static void WithSession(Action<object> body){
   var slot=typeof(CdbOwnedWait).GetField("current",BindingFlags.Static|BindingFlags.NonPublic);object prior=slot.GetValue(null);
   object session=Activator.CreateInstance(typeof(CdbOwnedWait).GetNestedType("Session",BindingFlags.NonPublic),true);
   Set(session,"Run",Id);Set(session,"Deadline",new LeaseDeadline(100,1000,30000,()=>100));Set(session,"Error",new InvalidOperationException("original gate refusal"));slot.SetValue(null,session);
   try{body(session);}finally{slot.SetValue(null,prior);((ManualResetEventSlim)Field(session,"Started")).Dispose();}
  }
  // Before the fix there is no producer capture hook; Snapshot is the actual
  // old public consumer. GREEN invokes the real hook used by RunPrepared.
  static void Remember(PumpResult pump){var method=typeof(CdbOwnedWait).GetMethod("RememberReturnedPump",BindingFlags.Static|BindingFlags.NonPublic);if(method==null)return;try{method.Invoke(null,new object[]{pump});}catch(TargetInvocationException e){throw e.InnerException;}}
  static void RejectRemember(PumpResult pump){try{Remember(pump);}catch(InvalidOperationException){return;}throw new Exception("unexpected pump capture accepted");}
  static bool Close(Fixture f,PumpResult p,Task worker=null,string run=Id,int pid=20,CdbGateProtocol gate=null,bool useNullGate=false){return CdbOwnedWait.CloseAfterPump(p,f.Lease,worker??Task.FromResult(0),run,pid,useNullGate?null:(gate??f.Gate));}
  public static int Run(){
   Case("actual returned PumpResult survives later gate failure snapshot",()=>WithSession(s=>{var p=Pump();Remember(p);var snapshot=CdbOwnedWait.Snapshot();Check(Object.ReferenceEquals(Property(snapshot,"pumpResult"),p),"actual PumpResult missing or replaced");Check(((string)Property(snapshot,"error")).Contains("original gate refusal"),"primary failure lost");string json=new JavaScriptSerializer().Serialize(snapshot);Check(json.Contains("original-pump-out")&&json.Contains("original-pump-err")&&json.Contains("pinned desktop implementation refused"),"raw output/error not persisted");Check(!p.CleanupVerified&&p.ExitCode==1,"failure relabeled");}));
   Case("foreign run PumpResult cannot replace same-run evidence",()=>WithSession(s=>{var p=Pump();p.RunId=new string('2',32);RejectRemember(p);Check(Property(CdbOwnedWait.Snapshot(),"pumpResult")==null,"foreign result stored");}));
   Case("second result cannot overwrite first actual return",()=>WithSession(s=>{var p=Pump();Remember(p);var later=Pump();later.Stdout="replacement";RejectRemember(later);Check(Object.ReferenceEquals(Property(CdbOwnedWait.Snapshot(),"pumpResult"),p),"first return replaced");}));
   Case("bootstrap-only failed drained pump closes original reference once",()=>{var f=new Fixture();var p=Pump();Check(Close(f,p),"proven bootstrap drain remained blocked by qualification failure");Check(f.Api.Closed.SequenceEqual(new long[]{101}),"wrong close set");Check(f.Lease.Owners[0].Closed&&f.Lease.Owners[0].Value==IntPtr.Zero,"original owner did not close");Check(!p.CleanupVerified&&p.Error!=null&&p.CleanupError!=null&&p.ExitCode==1,"failure verdict changed");});
   Case("live original bootstrap is rechecked and retained",()=>{var f=new Fixture();f.Api.Drained=false;Check(!Close(f,Pump())&&f.Api.Closed.Count==0&&f.Api.Queried.SequenceEqual(new long[]{101}),"live original reference closed or not checked");});
   Case("failed original close retains owner with no second query or close",()=>{var f=new Fixture();f.Api.FailClose=true;var p=Pump();Check(!Close(f,p),"failed close reported success");Check(f.Api.Closed.Count==1&&f.Lease.Owners[0].Retained,"failed owner lost");int queried=f.Api.Queried.Count;Check(!Close(f,p)&&f.Api.Closed.Count==1&&f.Api.Queried.Count==queried,"failed-close retry");});
   Case("original verified-cleanup branch remains accepted",()=>{var f=new Fixture();var p=Pump();p.CleanupVerified=true;p.Error=null;p.CleanupError=null;Check(Close(f,p)&&f.Api.Closed.SequenceEqual(new long[]{101}),"legacy accepted cleanup changed");});
   foreach(string fault in new[]{"mode","no-process","job-observed","direct-exit","job-drained","remaining","desktop-observed","desktop-closed","desktop-retained","streams","job-observer-closed","job-observer-retained","job-close-error","run","pid","zero-pid","no-error","worker","null-worker","gate","offer","ack","go","extra-owner","ready","retained-owner","closed-owner","close-attempted","owner-value"}){
    string kind=fault;Case("uncertain failed-pump release refused: "+kind,()=>{
     var f=new Fixture();var p=Pump();Task worker=Task.FromResult(0);string run=Id;int pid=20;CdbGateProtocol gate=f.Gate;
     switch(kind){case "mode":p.FullRestrictedMode=false;break;case "no-process":p.NoProcessCreated=true;break;case "job-observed":p.JobObserved=false;break;case "direct-exit":p.DirectProcessExited=false;break;case "job-drained":p.JobDrained=false;break;case "remaining":p.RemainingOwnedProcesses=1;break;case "desktop-observed":p.DesktopLeaseObserved=false;break;case "desktop-closed":p.DesktopLeaseClosed=false;break;case "desktop-retained":p.DesktopLeaseRetained=true;break;case "streams":p.StreamCaptureComplete=false;break;case "job-observer-closed":p.FullJobObserverClosed=false;break;case "job-observer-retained":p.FullJobObserverRetained=true;break;case "job-close-error":p.FullJobObserverCloseError=6;break;case "run":run=new string('2',32);break;case "pid":pid=21;break;case "zero-pid":pid=0;break;case "no-error":p.Error=null;p.CleanupError=null;break;case "worker":worker=new Task(()=>{});break;case "null-worker":worker=null;break;case "gate":gate=null;break;case "offer":gate.Offer=new LeaseOffer{Run=Id};break;case "ack":gate.Acknowledged=true;break;case "go":gate.GoPublished=true;break;case "extra-owner":f.Lease.Owners.Add(new FullOwnedHandle("unexpected",new IntPtr(999),h=>0));break;case "ready":f.Lease.Ready=true;break;case "retained-owner":f.Lease.Owners[0].Retained=true;break;case "closed-owner":f.Lease.Owners[0].Closed=true;break;case "close-attempted":f.Lease.Owners[0].CloseAttempted=true;break;case "owner-value":f.Lease.Owners[0].Value=new IntPtr(102);break;}
     Check(!CdbOwnedWait.CloseAfterPump(p,f.Lease,worker,run,pid,gate),"uncertain resource facts accepted");Check(f.Api.Closed.Count==0&&f.Api.Queried.Count==0,"guard queried or closed original owner before proof");
    });
   }
   Console.WriteLine("PUMP FAILURE SOURCE CHECKS "+count+" FAILED "+failed+"; no normal DLL/native process invoked");return failed==0?0:1;
  }
 }
}
