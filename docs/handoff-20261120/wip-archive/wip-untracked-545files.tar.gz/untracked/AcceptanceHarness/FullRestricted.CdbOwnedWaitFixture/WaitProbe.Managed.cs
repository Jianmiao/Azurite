using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
namespace WaitProbe {
public static class EntryPoint {
 [StructLayout(LayoutKind.Sequential)] private struct WaitResult {public uint returned,lastError,index;}
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern void Seed(uint value);
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern uint ReadLastError();
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern uint NativeThreadId();
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern int Apartment(out int kind,out int qualifier);
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern int InitializeSta();
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern void Uninitialize();
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern uint ThreadToken();
 [DllImport("WaitNative.dll",CallingConvention=CallingConvention.Cdecl,ExactSpelling=true)] private static extern void Measure(IntPtr handle,uint seed,int kind,out WaitResult result);
 [MethodImpl(MethodImplOptions.NoInlining)] private static bool ManagedWait(Mutex mutex,uint seed){Seed(seed);return mutex.WaitOne(100);}
 private static object Observe(){int kind,qualifier;int hr=Apartment(out kind,out qualifier);return new{nativeThreadId=NativeThreadId(),apartmentHr=hr,apartmentNative=kind,apartmentQualifier=qualifier,managedApartment=Thread.CurrentThread.GetApartmentState().ToString(),threadTokenError=ThreadToken()};}
 private static object Test(string phase,uint seed,string path){
  object before=Observe();string name="Global\\AzuriteWaitFixture_"+Guid.NewGuid().ToString("N");bool created;
  using(var mutex=new Mutex(false,name,out created)){
   if(!created)throw new InvalidOperationException("Fresh mutex required");
   uint? raw=null,index=null,lastError=null;bool acquired=false,released=false;string errorType=null,errorMessage=null,releaseError=null;int? exceptionHr=null;
   try{if(path=="managed"){acquired=ManagedWait(mutex,seed);lastError=ReadLastError();}else{WaitResult r;Measure(mutex.SafeWaitHandle.DangerousGetHandle(),seed,path=="raw"?0:1,out r);raw=r.returned;index=r.index;lastError=r.lastError;acquired=path=="raw"?(r.returned==0||r.returned==128):(r.returned==0&&(r.index==0||r.index==128));}}
   catch(Exception e){lastError=ReadLastError();errorType=e.GetType().FullName;errorMessage=e.Message;exceptionHr=e.HResult;}
   if(acquired){try{mutex.ReleaseMutex();released=true;}catch(Exception e){releaseError=e.ToString();}}
   return new{phase,seed,path,before,mutexName=name,created,raw,index,lastError,acquired,released,errorType,errorMessage,exceptionHr,releaseError};
  }
 }
 [UnmanagedCallersOnly(CallConvs=new[]{typeof(CallConvCdecl)})]
 public static int Run(IntPtr output,int capacity){
  try{
   if(output==IntPtr.Zero||capacity!=32768)return -1;
   uint original=NativeThreadId();object before=Observe();var records=new List<object>();
   foreach(uint seed in new uint[]{0,1008})foreach(string path in new[]{"raw","com","managed"})records.Add(Test("natural-host-thread",seed,path));
   int staHr=InitializeSta();
   try{if(staHr>=0)foreach(uint seed in new uint[]{0,1008})foreach(string path in new[]{"raw","com","managed"})records.Add(Test("explicit-sta-probe",seed,path));}
   finally{if(staHr>=0)Uninitialize();}
   var record=new{schema=1,scope="fixed wait diagnostic only, no AA acceptance",pid=Environment.ProcessId,nativeThreadId=original,finalNativeThreadId=NativeThreadId(),sameInitialThread=original==NativeThreadId(),runtime=RuntimeInformation.FrameworkDescription,corelib=typeof(object).Assembly.Location,before,initializeStaHr=staHr,records,aaExecuted=false,waitTimeoutMs=100};
   byte[] bytes=Encoding.UTF8.GetBytes(JsonSerializer.Serialize(record));if(bytes.Length+1>capacity)return -2;Marshal.Copy(bytes,0,output,bytes.Length);Marshal.WriteByte(output,bytes.Length,0);return bytes.Length;
  }catch(Exception e){try{byte[] bytes=Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new{schema=1,probeFailed=true,error=e.ToString(),aaExecuted=false}));if(bytes.Length+1>capacity)return -3;Marshal.Copy(bytes,0,output,bytes.Length);Marshal.WriteByte(output,bytes.Length,0);return bytes.Length;}catch{return -4;}}
 }
}
}
