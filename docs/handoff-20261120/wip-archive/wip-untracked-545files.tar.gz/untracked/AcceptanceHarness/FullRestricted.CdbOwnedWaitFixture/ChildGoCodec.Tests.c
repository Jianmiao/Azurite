#include <stdio.h>
#include <string.h>
#include "ChildGoCodec.h"
static const char *run="11111111111111111111111111111111";
static const char *valid="{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":20,\"childPid\":30,\"mainTid\":40,\"creation\":300}";
static int checks,failed;
static void check(int okay,const char *name){checks++;printf("%s %s\n",okay?"PASS":"FAIL",name);if(!okay)failed++;}
static int prepare(ChildGoState *s){return child_go_prepare(s,0,run,30,40,300,1000,13000,1100);}
int main(void){
 ChildGoState s={0};char large[1025],nul[512];size_t len=strlen(valid);unsigned i;
 const char *names[]={"wrong-run","wrong-pid","wrong-tid","wrong-creation","zero-bootstrap","trailing","duplicate-field","noncanonical-number"};
 const char *bad[]={
 "{\"protocol\":\"go.v1\",\"runId\":\"22222222222222222222222222222222\",\"bootstrapPid\":20,\"childPid\":30,\"mainTid\":40,\"creation\":300}",
 "{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":20,\"childPid\":31,\"mainTid\":40,\"creation\":300}",
 "{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":20,\"childPid\":30,\"mainTid\":41,\"creation\":300}",
 "{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":20,\"childPid\":30,\"mainTid\":40,\"creation\":301}",
 "{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":0,\"childPid\":30,\"mainTid\":40,\"creation\":300}",
 "{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":20,\"childPid\":30,\"mainTid\":40,\"creation\":300} ",
 "{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":20,\"childPid\":30,\"childPid\":30,\"mainTid\":40,\"creation\":300}",
 "{\"protocol\":\"go.v1\",\"runId\":\"11111111111111111111111111111111\",\"bootstrapPid\":020,\"childPid\":30,\"mainTid\":40,\"creation\":300}"};
 /* Pure CRT stdin rendezvous lets the owning runner set/read back low
    priority before any codec case executes. It is not the lifecycle probe. */
 if(getchar()!='G'||getchar()!=EOF)return 2;
 check(prepare(&s)&&child_go_accept(&s,valid,len,1200)&&s.consumed,"valid actual consumer");
 for(i=0;i<sizeof(bad)/sizeof(bad[0]);i++){memset(&s,0,sizeof(s));check(prepare(&s)&&!child_go_accept(&s,bad[i],strlen(bad[i]),1200),names[i]);}
 memset(&s,0,sizeof(s));check(!child_go_prepare(&s,1,run,30,40,300,1000,13000,1100),"stale existing go before ready");
 memset(&s,0,sizeof(s));check(!child_go_prepare(&s,0,run,30,40,300,1000,13000,13000),"expired before ready");
 memset(&s,0,sizeof(s));check(prepare(&s)&&!child_go_accept(&s,valid,len,13000),"expired before consumption");
 memset(&s,0,sizeof(s));check(prepare(&s)&&child_go_accept(&s,valid,len,1200)&&!child_go_accept(&s,valid,len,1201),"duplicate go consumption");
 memset(&s,0,sizeof(s));check(!child_go_accept(&s,valid,len,1200),"go before prepare");
 memset(&s,0,sizeof(s));memcpy(nul,valid,len);nul[5]=0;check(prepare(&s)&&!child_go_accept(&s,nul,len,1200),"embedded NUL");
 memset(&s,0,sizeof(s));memcpy(nul,valid,len);nul[5]=-1;check(prepare(&s)&&!child_go_accept(&s,nul,len,1200),"non ASCII");
 memset(&s,0,sizeof(s));memset(large,'x',sizeof(large));check(prepare(&s)&&!child_go_accept(&s,large,sizeof(large),1200),"overlong record");
 memset(&s,0,sizeof(s));check(prepare(&s)&&!child_go_accept(&s,bad[0],strlen(bad[0]),1200)&&!child_go_accept(&s,valid,len,1201),"invalid go is terminal");
 memset(&s,0,sizeof(s));check(prepare(&s)&&!prepare(&s),"repeated prepare");
 memset(&s,0,sizeof(s));check(!child_go_prepare(&s,0,run,30,40,300,1000,13001,1100),"absolute child deadline cannot reset");
 printf("RESULT codec checks=%d failed=%d lifecycleExecuted=false win32Calls=false\n",checks,failed);return failed?1:0;
}
