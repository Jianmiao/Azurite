/* Eight individual modification-right requests on fixed new C-owned canaries. */
_Static_assert(FILE_WRITE_DATA==2 && FILE_APPEND_DATA==4 && DELETE==0x10000 && WRITE_DAC==0x40000 && WRITE_OWNER==0x80000,"Fixed file access rights must match the Windows SDK");
_Static_assert(FILE_ADD_FILE==2 && FILE_ADD_SUBDIRECTORY==4 && FILE_DELETE_CHILD==0x40,"Fixed directory access rights must match the Windows SDK");
typedef struct {const char *name;DWORD rights;BOOL directory,attempted,opened;DWORD openError,closeError,flags;} ProtectionAttempt;
static void probe_canary(void){
 const wchar_t *file=FIXTURE_LAB L"\\install\\protected\\proof.bin";
 const wchar_t *directory=FIXTURE_LAB L"\\install\\protected";
 const char expected[]="AZURITE_WRITE_RESTRICTION_CANARY_V1\n";
 _Static_assert(sizeof(expected)-1==36,"Canary payload is exactly 36 ASCII bytes");
 ProtectionAttempt attempts[8]={{"file-write-data",FILE_WRITE_DATA,FALSE},{"file-append-data",FILE_APPEND_DATA,FALSE},{"file-delete",DELETE,FALSE},{"file-write-dac",WRITE_DAC,FALSE},{"file-write-owner",WRITE_OWNER,FALSE},{"directory-add-file",FILE_ADD_FILE,TRUE},{"directory-add-subdirectory",FILE_ADD_SUBDIRECTORY,TRUE},{"directory-delete-child",FILE_DELETE_CHILD,TRUE}};
 char content[sizeof(expected)]={0},json[8192];HANDLE readHandle;DWORD readOpenError=0,readError=0,readCloseError=0,infoError=0,bytes=0;BOOL readOpened=FALSE,readOkay=FALSE,contentMatches=FALSE,infoOkay=FALSE;BY_HANDLE_FILE_INFORMATION info;int length,n;unsigned i;ZeroMemory(&info,sizeof(info));
 SetLastError(ERROR_SUCCESS);readHandle=CreateFileW(file,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OPEN_REPARSE_POINT,NULL);
 readOpened=readHandle!=INVALID_HANDLE_VALUE;readOpenError=readOpened?ERROR_SUCCESS:GetLastError();
 if(readOpened){infoOkay=GetFileInformationByHandle(readHandle,&info);infoError=infoOkay?ERROR_SUCCESS:GetLastError();readOkay=ReadFile(readHandle,content,sizeof(content),&bytes,NULL);readError=readOkay?ERROR_SUCCESS:GetLastError();contentMatches=readOkay&&bytes==sizeof(expected)-1&&memcmp(content,expected,sizeof(expected)-1)==0;if(!CloseHandle(readHandle))readCloseError=GetLastError();}
 /* No retained read handle and no metadata query can overwrite a rights-open result. */
 if(readCloseError==0){for(i=0;i<8;i++){
  HANDLE handle;ProtectionAttempt *a=&attempts[i];DWORD flags=FILE_FLAG_OPEN_REPARSE_POINT|(a->directory?FILE_FLAG_BACKUP_SEMANTICS:FILE_ATTRIBUTE_NORMAL);
  a->flags=flags;a->attempted=TRUE;SetLastError(ERROR_SUCCESS);handle=CreateFileW(a->directory?directory:file,a->rights,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,NULL,OPEN_EXISTING,flags,NULL);
  a->opened=handle!=INVALID_HANDLE_VALUE;a->openError=a->opened?ERROR_SUCCESS:GetLastError();
  if(a->opened&&!CloseHandle(handle)){a->closeError=GetLastError();break;}
 }}
 length=_snprintf_s(json,sizeof(json),_TRUNCATE,"{\"protocol\":\"owned-modification-rights.v1\",\"runId\":\"%s\",\"pid\":%lu,\"nativeThreadId\":%lu,\"fileLeaf\":\"proof.bin\",\"directoryLeaf\":\"protected\",\"readDesiredAccess\":%lu,\"creationDisposition\":%lu,\"shareMode\":%lu,\"readOpened\":%s,\"readOpenError\":%lu,\"readCallSucceeded\":%s,\"readError\":%lu,\"readBytes\":%lu,\"contentMatches\":%s,\"readCloseError\":%lu,\"infoSucceeded\":%s,\"infoError\":%lu,\"attributes\":%lu,\"links\":%lu,\"fileIndexHigh\":%lu,\"fileIndexLow\":%lu,\"volumeSerial\":%lu,\"fileSizeHigh\":%lu,\"fileSizeLow\":%lu,\"dataWriteCalled\":false,\"createCalled\":false,\"deleteCalled\":false,\"renameCalled\":false,\"securitySetCalled\":false,\"attempts\":[",runid,GetCurrentProcessId(),GetCurrentThreadId(),(DWORD)GENERIC_READ,(DWORD)OPEN_EXISTING,(DWORD)(FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE),readOpened?"true":"false",readOpenError,readOkay?"true":"false",readError,bytes,contentMatches?"true":"false",readCloseError,infoOkay?"true":"false",infoError,info.dwFileAttributes,info.nNumberOfLinks,info.nFileIndexHigh,info.nFileIndexLow,info.dwVolumeSerialNumber,info.nFileSizeHigh,info.nFileSizeLow);require(length>0,96);
 for(i=0;i<8;i++){ProtectionAttempt *a=&attempts[i];n=_snprintf_s(json+length,sizeof(json)-(size_t)length,_TRUNCATE,"%s{\"name\":\"%s\",\"directory\":%s,\"desiredAccess\":%lu,\"openFlags\":%lu,\"attempted\":%s,\"opened\":%s,\"openError\":%lu,\"closeError\":%lu}",i?",":"",a->name,a->directory?"true":"false",a->rights,a->flags,a->attempted?"true":"false",a->opened?"true":"false",a->openError,a->closeError);require(n>0,96);length+=n;}
 require(strcat_s(json,sizeof(json),"]}")==0,96);write_new(L"protection-result.json",json);
}
