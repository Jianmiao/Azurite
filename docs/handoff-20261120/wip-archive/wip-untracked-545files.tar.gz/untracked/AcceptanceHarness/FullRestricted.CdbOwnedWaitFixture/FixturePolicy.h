#ifndef AZURITE_LIFECYCLE_POLICY_H
#define AZURITE_LIFECYCLE_POLICY_H
#include <stddef.h>
#include <string.h>
#include <stdint.h>
static int fixture_run_id(const char *p){size_t i;if(!p||strlen(p)!=32)return 0;for(i=0;i<32;i++)if(!((p[i]>='a'&&p[i]<='f')||(p[i]>='0'&&p[i]<='9')))return 0;return 1;}
static int fixture_u32(const char *p,uint32_t *out){uint64_t n=0;size_t i;if(!p||!p[0])return 0;for(i=0;p[i];i++){if(p[i]<'0'||p[i]>'9')return 0;n=n*10+(unsigned)(p[i]-'0');if(n>UINT32_MAX)return 0;}*out=(uint32_t)n;return 1;}
static int fixture_case(const char *p){return p&&(!strcmp(p,"normal")||!strcmp(p,"bootstrap-exit"));}
static int fixture_sid(const char *p){size_t i,n;if(!p||strncmp(p,"S-1-",4))return 0;n=strlen(p);if(n<7||n>180)return 0;for(i=4;i<n;i++)if((p[i]<'0'||p[i]>'9')&&p[i]!='-')return 0;return 1;}
static int fixture_full_set(unsigned total,unsigned logon,unsigned world,unsigned users){return total==3&&logon==1&&world==1&&users==1;}
static int fixture_inherited(uint32_t rid,uint32_t policy,uint32_t expected_rid,uint32_t expected_policy){return rid==expected_rid&&policy==expected_policy&&(policy&~3u)==0;}
#endif
