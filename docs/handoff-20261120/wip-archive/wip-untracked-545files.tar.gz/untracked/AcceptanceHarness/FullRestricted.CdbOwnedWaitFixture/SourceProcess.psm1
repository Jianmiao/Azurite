Set-StrictMode -Version Latest
# SOURCE compiler / pure-test processes only; never used by the native runner.
function Invoke-FixtureSourceProcess {
 param([Parameter(Mandatory)][string]$File,[Parameter(Mandatory)][string[]]$Arguments,[Parameter(Mandatory)][string]$Record,[Parameter(Mandatory)][string]$Directory,[ValidateRange(1000,120000)][int]$BoundMs=30000)
 if(Test-Path -LiteralPath $Record){throw 'New owned SOURCE process record required'}
 $quoted=@();foreach($argument in $Arguments){if($argument.Contains('"') -or $argument.Contains("`r") -or $argument.Contains("`n") -or $argument.EndsWith('\')){throw 'Unsupported SOURCE process argument quoting'};$quoted+='"'+$argument+'"'}
 $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$File;$psi.Arguments=$quoted -join ' ';$psi.WorkingDirectory=$Directory;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.WindowStyle='Hidden';$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
 $p=[Diagnostics.Process]::new();$p.StartInfo=$psi
 $state=[ordered]@{file=$File;arguments=$Arguments;pid=$null;creationFileTime=$null;started=$false;exited=$false;exitCode=$null;timedOut=$false;terminatedOwnedPureChild=$false;hidden=$true;priority='BelowNormal';boundMs=$BoundMs;stdout='';stderr='';errors=@();sourceOnly=$true;nativeExecuted=$false}
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($state|ConvertTo-Json -Depth 8));$f=[IO.File]::Open($Record,'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}
 $save={ [IO.File]::WriteAllText($Record,($state|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false)) }
 try{
  [void]$p.Start();$state.started=$true;$state.pid=$p.Id;$state.creationFileTime=$p.StartTime.ToUniversalTime().ToFileTimeUtc();& $save
  $p.PriorityClass='BelowNormal';$out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync()
  if(-not $p.WaitForExit($BoundMs)){$state.timedOut=$true;& $save;$p.Kill();$state.terminatedOwnedPureChild=$true;if(-not $p.WaitForExit(5000)){throw 'Owned SOURCE child did not exit after bounded termination'}}
  $state.exited=$true;$state.exitCode=$p.ExitCode;$state.stdout=$out.Result;$state.stderr=$err.Result;& $save
  if($state.timedOut){throw 'Owned SOURCE process deadline exceeded; preserve evidence'}
 }catch{
  $state.errors+=@($_.Exception.ToString());try{& $save}catch{}
  if($state.started -and -not $state.exited){try{if(-not $p.HasExited){$p.Kill();$state.terminatedOwnedPureChild=$true};if($p.WaitForExit(5000)){$state.exited=$true;$state.exitCode=$p.ExitCode;& $save}}catch{$state.errors+=@($_.Exception.ToString());try{& $save}catch{}};if(-not $state.exited){[Console]::Error.WriteLine('Owned SOURCE process remains uncertain; original Process retained.');while($true){[Threading.Thread]::Sleep(1000)}}}
  throw
 }finally{if($state.exited -or -not $state.started){$p.Dispose()}}
 [pscustomobject]$state
}
Export-ModuleMember -Function Invoke-FixtureSourceProcess
