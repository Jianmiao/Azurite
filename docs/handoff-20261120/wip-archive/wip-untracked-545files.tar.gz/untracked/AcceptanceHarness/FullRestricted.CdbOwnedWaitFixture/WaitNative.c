#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0602
#include <windows.h>
#include <objbase.h>
typedef struct { DWORD returned; DWORD lastError; DWORD index; } WaitResult;
__declspec(dllexport) void __cdecl Seed(DWORD value) { SetLastError(value); }
__declspec(dllexport) DWORD __cdecl ReadLastError(void) { return GetLastError(); }
__declspec(dllexport) DWORD __cdecl NativeThreadId(void) { return GetCurrentThreadId(); }
__declspec(dllexport) HRESULT __cdecl Apartment(int *kind,int *qualifier) { return CoGetApartmentType((APTTYPE*)kind,(APTTYPEQUALIFIER*)qualifier); }
__declspec(dllexport) HRESULT __cdecl InitializeSta(void) { return CoInitializeEx(NULL,COINIT_APARTMENTTHREADED); }
__declspec(dllexport) void __cdecl Uninitialize(void) { CoUninitialize(); }
__declspec(dllexport) DWORD __cdecl ThreadToken(void) {
 HANDLE token=NULL;
 if(OpenThreadToken(GetCurrentThread(),TOKEN_QUERY,TRUE,&token)){CloseHandle(token);return ERROR_SUCCESS;}
 return GetLastError();
}
__declspec(dllexport) void __cdecl Measure(HANDLE object,DWORD seed,int kind,WaitResult *result) {
 DWORD index=0xffffffff;
 SetLastError(seed);
 if(kind==0)result->returned=WaitForSingleObject(object,100);
 else result->returned=(DWORD)CoWaitForMultipleHandles(COWAIT_ALERTABLE,100,1,&object,&index);
 result->lastError=GetLastError();result->index=index;
}
