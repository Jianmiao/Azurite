using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
namespace Azurite.Restricted {
 internal sealed class ReleaseQueryFake:ILeaseNative {
  internal readonly LeaseFake Inner=new LeaseFake();
  internal readonly List<long> FullQueries=new List<long>(),ReleaseQueries=new List<long>();
  internal bool RejectImageAfterExit;internal string AdmissionFault,ReleaseFault;internal long FaultHandle=101;internal Exception QueryError;
  public bool Duplicate(IntPtr source,long remote,uint rights,out IntPtr value,out int error){return Inner.Duplicate(source,remote,rights,out value,out error);}
  public LeaseProcessFacts Process(IntPtr h){
   FullQueries.Add(h.ToInt64());
   if(RejectImageAfterExit&&Inner.Drained)throw new Win32Exception(31,"simulated post-exit image-only failure");
   if(AdmissionFault=="query"&&h.ToInt64()==101)throw new Win32Exception(6,"simulated incomplete admission query");
   var p=Inner.Process(h);
   if(AdmissionFault=="bootstrap-image"&&h.ToInt64()==101)p.Image="foreign";
   if(AdmissionFault=="bootstrap-hash"&&h.ToInt64()==101)p.Hash=new string('b',64);
   if(AdmissionFault=="target-image"&&h.ToInt64()==102)p.Image="foreign";
   if(AdmissionFault=="target-hash"&&h.ToInt64()==102)p.Hash=new string('b',64);
   return p;
  }
  // Extra method compiles against the old interface for the RED run. Only the
  // production lease's new release path will select it in GREEN.
  public LeaseProcessFacts ReleaseProcess(IntPtr h){
   ReleaseQueries.Add(h.ToInt64());
   if(h.ToInt64()==FaultHandle&&QueryError!=null)throw QueryError;
   if(h.ToInt64()==FaultHandle&&ReleaseFault=="null")return null;
   var p=Inner.Process(h);p.Image=null;p.Hash=null;
   if(h.ToInt64()==FaultHandle)switch(ReleaseFault){case "pid":p.Pid++;break;case "creation":p.Created++;break;case "rights":p.Rights^=1;break;case "inherited":p.Inherited=true;break;case "live":p.Live=true;break;}
   return p;
  }
  public LeaseThreadFacts Thread(IntPtr h){return Inner.Thread(h);}
  public LeaseJobFacts Job(IntPtr h,IntPtr b,IntPtr c){return Inner.Job(h,b,c);}
  public FullDesktopIdentity Desktop(IntPtr h){return Inner.Desktop(h);}
  public int Close(IntPtr h,bool desktop){return Inner.Close(h,desktop);}
  internal void ClearQueries(){FullQueries.Clear();ReleaseQueries.Clear();Inner.Queried.Clear();}
 }
 internal static class ReleaseQueryTests {
  const string Id="11111111111111111111111111111111";static int count,failed;
  static void Check(bool okay,string why){if(!okay)throw new Exception(why);}
  static void Case(string name,Action action){count++;try{action();Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+": "+e.Message);}}
  static void Reject(Action action){try{action();}catch(InvalidOperationException){return;}catch(Win32Exception){return;}throw new Exception("unproven facts were accepted");}
  static CdbTargetLease Lease(ReleaseQueryFake api){return new CdbTargetLease(Id,"target",new string('a',64),"bootstrap",new string('a',64),api);}
  static LeaseOffer Offer(){return new LeaseOffer{Run=Id,ImageHash=new string('a',64),BootstrapPid=20,ChildPid=30,MainTid=40,BootstrapCreated=200,ChildCreated=300,ThreadCreated=400,ProcessSource=201,ThreadSource=202,JobSource=203,DesktopSource=204,NativeStart=100,NativeDeadline=10100,Frequency=1000};}
  static CdbTargetLease Admitted(ReleaseQueryFake api,bool target){var lease=Lease(api);lease.CaptureStarted(20,new IntPtr(55));if(target)lease.Accept(Offer());api.Inner.Drained=true;api.ClearQueries();return lease;}
  static void Refused(CdbTargetLease lease,ReleaseQueryFake api){bool result=false;try{result=lease.CloseAfterDrain(true);}catch(InvalidOperationException){}catch(Win32Exception){}Check(!result&&api.Inner.Closed.Count==0,"uncertain original owner was released");Check(lease.Owners.All(o=>o.Value==o.Acquired&&!o.Closed),"owner changed on refusal");}
  public static int Run(){
   Case("admitted exited bootstrap closes without post-exit image lookup",()=>{var api=new ReleaseQueryFake{RejectImageAfterExit=true};var lease=Admitted(api,false);Check(lease.CloseAfterDrain(true),"exited bootstrap remained blocked by image lookup");Check(api.FullQueries.Count==0&&api.ReleaseQueries.SequenceEqual(new long[]{101}),"release used a full query or a different handle");Check(api.Inner.Closed.SequenceEqual(new long[]{101}),"wrong bootstrap close");});
   Case("admitted exited target uses both original process references and unchanged close order",()=>{var api=new ReleaseQueryFake{RejectImageAfterExit=true};var lease=Admitted(api,true);Check(lease.CloseAfterDrain(true),"target release still requires exited image");Check(api.FullQueries.Count==0&&api.ReleaseQueries.SequenceEqual(new long[]{101,102}),"wrong release references");Check(api.Inner.Closed.SequenceEqual(new long[]{105,103,102,104,101}),"original close order changed");});
   Case("no admission and no original reference cannot become released",()=>{var api=new ReleaseQueryFake();var lease=Lease(api);Check(!lease.CloseAfterDrain(true)&&api.ReleaseQueries.Count==0&&api.Inner.Closed.Count==0,"missing admission became proven drain");});
   foreach(string fault in new[]{"bootstrap-image","bootstrap-hash","query"}){string one=fault;Case("failed bootstrap admission remains held after later basic facts succeed: "+one,()=>{var api=new ReleaseQueryFake{AdmissionFault=one};var lease=Lease(api);Reject(()=>lease.CaptureStarted(20,new IntPtr(55)));Check(lease.BootstrapStarted&&lease.Owners.Count==1,"original partial-capture owner missing");api.AdmissionFault=null;api.Inner.Drained=true;api.ClearQueries();Refused(lease,api);Check(api.ReleaseQueries.Count==0&&api.FullQueries.Count==0,"failed admission queried for release");});}
   foreach(string fault in new[]{"target-image","target-hash"}){string one=fault;Case("live target admission still requires full identity: "+one,()=>{var api=new ReleaseQueryFake();var lease=Lease(api);lease.CaptureStarted(20,new IntPtr(55));api.AdmissionFault=one;Reject(()=>lease.Accept(Offer()));Check(!lease.Ready&&api.FullQueries.Contains(102)&&api.ReleaseQueries.Count==0,"live target image/hash check bypassed");});}
   Case("accepted target without Ready cannot release original owners",()=>{var api=new ReleaseQueryFake();var lease=Admitted(api,true);lease.Ready=false;Refused(lease,api);Check(!api.ReleaseQueries.Contains(102),"unadmitted target queried by release path");});
   Case("failed partial target close is retained without releasing bootstrap or retrying",()=>{var api=new ReleaseQueryFake();var lease=Lease(api);lease.CaptureStarted(20,new IntPtr(55));api.AdmissionFault="target-image";api.Inner.FailCloseHandle=102;Reject(()=>lease.Accept(Offer()));var attempts=api.Inner.Closed.ToArray();api.AdmissionFault=null;api.Inner.Drained=true;api.ClearQueries();Check(!lease.CloseAfterDrain(true),"partial target became released");Check(api.Inner.Closed.SequenceEqual(attempts)&&!lease.Owners[0].Closed&&lease.Owners.Single(o=>o.Role=="target-process").Retained,"partial failed owner retried or bootstrap released");});
   Case("unproven outer drain does not query original references",()=>{var api=new ReleaseQueryFake();var lease=Admitted(api,true);Check(!lease.CloseAfterDrain(false)&&api.ReleaseQueries.Count==0&&api.FullQueries.Count==0&&api.Inner.Closed.Count==0,"false drain was queried or closed");});
   foreach(long handle in new long[]{101,102})foreach(string fault in new[]{"pid","creation","rights","inherited","live","null"}){long h=handle;string one=fault;Case("release retains original owner on "+h+" "+one,()=>{var api=new ReleaseQueryFake{FaultHandle=h,ReleaseFault=one};var lease=Admitted(api,h==102);Refused(lease,api);Check(api.FullQueries.Count==0&&api.ReleaseQueries.Contains(h),"release did not inspect same held reference");});}
   foreach(long handle in new long[]{101,102})foreach(string query in new[]{"PID","creation","Wait0","flags","rights"}){long h=handle;string one=query;Case("release preserves exact "+h+" "+one+" query failure",()=>{Exception error=one=="rights"?(Exception)new InvalidOperationException("release granted access NTSTATUS=0xc0000008 returned=0"):new Win32Exception(one=="PID"?87:one=="creation"?6:one=="Wait0"?31:5,"release "+one);var api=new ReleaseQueryFake{FaultHandle=h,QueryError=error};var lease=Admitted(api,h==102);Exception observed=null;try{lease.CloseAfterDrain(true);}catch(Exception e){observed=e;}Check(Object.ReferenceEquals(error,observed),"query failure was lost, wrapped or treated as exited");Check(api.Inner.Closed.Count==0&&lease.Owners.All(o=>o.Value==o.Acquired&&!o.Closed),"failed query released owner");});}
   foreach(long handle in new long[]{101,102}){long h=handle;Case("changed owned handle value is never queried or closed: "+h,()=>{var api=new ReleaseQueryFake();var lease=Admitted(api,h==102);var owner=lease.Owners.Single(o=>o.Acquired.ToInt64()==h);owner.Value=new IntPtr(999);bool result=false;try{result=lease.CloseAfterDrain(true);}catch(InvalidOperationException){}Check(!result&&api.Inner.Closed.Count==0&&!api.ReleaseQueries.Contains(999)&&api.FullQueries.Count==0,"changed original owner used");});}
   Case("already closed bootstrap is not queried",()=>{var api=new ReleaseQueryFake();var lease=Admitted(api,false);lease.Owners[0].Closed=true;Check(!lease.CloseAfterDrain(true)&&api.ReleaseQueries.Count==0&&api.FullQueries.Count==0&&api.Inner.Closed.Count==0,"closed bootstrap was queried");});
   Case("bootstrap with prior close attempt stays retained without query",()=>{var api=new ReleaseQueryFake();var lease=Admitted(api,false);lease.Owners[0].CloseAttempted=true;lease.Owners[0].Retained=true;Check(!lease.CloseAfterDrain(true)&&api.ReleaseQueries.Count==0&&api.FullQueries.Count==0&&api.Inner.Closed.Count==0,"previous close attempt reused");});
   Case("failed native close commits once and cannot query or close again",()=>{var api=new ReleaseQueryFake{RejectImageAfterExit=true};var lease=Admitted(api,true);api.Inner.FailCloseHandle=102;Check(!lease.CloseAfterDrain(true),"failed native close reported success");int queries=api.ReleaseQueries.Count,closes=api.Inner.Closed.Count;Check(!lease.CloseAfterDrain(true)&&api.ReleaseQueries.Count==queries&&api.Inner.Closed.Count==closes,"failed close retried");Check(lease.Owners.Single(o=>o.Role=="target-process").Retained,"failed target owner lost");});
   Case("first target signal is observed through release reference and stays fixed",()=>{var api=new ReleaseQueryFake{RejectImageAfterExit=true};var lease=Admitted(api,true);Check(lease.TargetSignalObservedQpc==0,"early target signal");Check(lease.CloseAfterDrain(true)&&lease.TargetSignalObservedQpc>0,"release signal missing");long first=lease.TargetSignalObservedQpc;int queries=api.ReleaseQueries.Count;Check(lease.CloseAfterDrain(true)&&lease.TargetSignalObservedQpc==first&&api.ReleaseQueries.Count==queries,"repeat release rewrote signal or queried closed reference");});
   Case("release preserves a target signal previously observed by full revalidation",()=>{var api=new ReleaseQueryFake();var lease=Lease(api);lease.CaptureStarted(20,new IntPtr(55));lease.Accept(Offer());api.Inner.Drift="target-exit";Reject(()=>lease.Revalidate());long first=lease.TargetSignalObservedQpc;Check(first>0,"full revalidation signal missing");api.Inner.Drift=null;api.Inner.Drained=true;api.RejectImageAfterExit=true;Check(lease.CloseAfterDrain(true)&&lease.TargetSignalObservedQpc==first,"first signal replaced during release");});
   Case("unchanged Job drain still rejects nonempty or wrong lineage",()=>{var api=new ReleaseQueryFake();var lease=Admitted(api,true);api.Inner.Drift="job-total";Refused(lease,api);Check(api.Inner.Queried.Contains(104),"Job drain proof skipped");});
   Case("failed PumpResult verdict survives successful bootstrap release",()=>{var api=new ReleaseQueryFake{RejectImageAfterExit=true};var lease=Admitted(api,false);var gate=new CdbGateProtocol(lease,Id,new LeaseDeadline(100,1000,30000,()=>100),()=>100,()=>1000);var p=new PumpResult{RunId=Id,Pid=20,ExitCode=1,Error="original qualification failed",CleanupVerified=false,FullRestrictedMode=true,JobObserved=true,DirectProcessExited=true,JobDrained=true,RemainingOwnedProcesses=0,DesktopLeaseObserved=true,DesktopLeaseClosed=true,StreamCaptureComplete=true,FullJobObserverClosed=true};Check(CdbOwnedWait.CloseAfterPump(p,lease,Task.FromResult(0),Id,20,gate),"strict failed-pump release still blocked");Check(!p.CleanupVerified&&p.ExitCode==1&&p.Error=="original qualification failed"&&api.Inner.Closed.SequenceEqual(new long[]{101}),"failure verdict changed");});
   Console.WriteLine("RELEASE QUERY SOURCE CHECKS "+count+" FAILED "+failed+"; no normal DLL/native process invoked");return failed==0?0:1;
  }
 }
}
