#requires -Version 5.1
param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\FixtureRules.psm1') -Force -DisableNameChecking
Import-Module ($PSScriptRoot+'\FixtureAcl.psm1') -Force -DisableNameChecking
Assert-FixtureHost
$parserRows=@();foreach($p in @(Get-ChildItem -LiteralPath $PSScriptRoot -File|Where-Object{$_.Extension -in @('.ps1','.psm1')})){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseFile($p.FullName,[ref]$tokens,[ref]$errors);Assert-Fixture ($errors.Count -eq 0) ('PS5.1 parser: '+$p.Name);$parserRows+=@{name=$p.Name;errors=$errors.Count}}
$rows=[Collections.Generic.List[object]]::new();$capturedRows=$rows;$sink={param($row)$capturedRows.Add($row)}.GetNewClosure();$record=New-FixtureRecorder ('a'*32) $sink
function Invoke-OutsideOriginalScope([scriptblock]$Callback){& $Callback 'prepared' ([ordered]@{empty=[object[]]@();normal=$true})}
$n=Invoke-OutsideOriginalScope $record;Assert-Fixture ($n -eq 1 -and $rows.Count -eq 1 -and $rows[0].runId -ceq ('a'*32)) 'captured closure outside original dynamic scope'
$json=$rows[0]|ConvertTo-Json -Depth 10 -Compress;$r=$json|ConvertFrom-Json;Assert-Fixture ($r.items -is [array] -and $r.items.Count -eq 0 -and $r.details.empty -is [array] -and $r.details.empty.Count -eq 0 -and $r.details.normal -is [bool]) 'explicit empty-array and Boolean record shape'
$plan=Get-LeaseGateAclPlan 'S-1-5-21-1-2-3-1001' 'S-1-5-5-10-20';Assert-LeaseGateAclPlan $plan
$bad=($plan|ConvertTo-Json -Depth 5)|ConvertFrom-Json;$bad.controlFile=$bad.controlFile.Replace('(A;;FR;;;WD)','(A;;FA;;;WD)');$rejected=$false;try{Assert-LeaseGateAclPlan $bad}catch{$rejected=$true};Assert-Fixture $rejected 'child writable control file plan rejected'
Write-FixtureJson $OutputPath ([ordered]@{passed=$true;host=$PSVersionTable.PSVersion.ToString();x64=[Environment]::Is64BitProcess;checks=4;parser=$parserRows;closure=$rows.ToArray();aclPlan=$plan;nativeExecuted=$false;aclMutated=$false;runtimeQualified=$false})
[pscustomobject]@{passed=$true;checks=4;nativeExecuted=$false;aclMutated=$false}
