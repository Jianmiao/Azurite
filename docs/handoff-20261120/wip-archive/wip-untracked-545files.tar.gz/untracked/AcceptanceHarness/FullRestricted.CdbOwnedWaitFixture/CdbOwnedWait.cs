using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
namespace Azurite.Restricted {
 // Fixed Task A controller. It never creates/attaches a debugger. A future
 // Task B must add the separately reviewed shared stop-before-target-cleanup
 // handoff to BOTH inner Cleanup and outer finally before target termination.
 // This startup-only hook must never be represented as sufficient for Task B.
 public static class CdbOwnedWait {
  static Session current;static readonly object sync=new object();
  sealed class Session {
   internal string Run,Directory,Owner,Logon;internal int BootstrapPid;internal PumpResult Pump;internal LeaseDeadline Deadline;internal LeasePinnedFiles Pins;internal LeaseFiles.DirectoryPins Directories;internal CdbTargetLease Lease;internal CdbGateProtocol Gate;internal readonly ManualResetEventSlim Started=new ManualResetEventSlim(false);internal volatile Task Worker;internal Exception Error;internal readonly Dictionary<string,long> Stages=new Dictionary<string,long>();internal volatile bool Closed;internal readonly List<Exception> Secondary=new List<Exception>();
   internal void First(Exception e){Interlocked.CompareExchange(ref Error,e,null);}
   internal void Later(Exception e){try{lock(Secondary){if(Secondary.Count<16)Secondary.Add(e);}}catch{/* Diagnostic allocation cannot replace the primary error or release owners. */}}
   internal void Mark(string stage){lock(Stages){if(Stages.ContainsKey(stage))throw new InvalidOperationException("repeated controller transition");Stages.Add(stage,Stopwatch.GetTimestamp());}}
  }
  [DllImport("kernel32.dll")]static extern ulong GetTickCount64();
  internal static void CaptureStartedBootstrap(Process actual,string run){Session s;lock(sync)s=current;FullRestrictedContract.Require(s!=null&&s.Run==run&&actual!=null,"start hook is outside fixed Task A session");try{int capturedPid=actual.Id;s.Lease.CaptureStarted(capturedPid,actual.Handle);s.BootstrapPid=capturedPid;s.Mark("bootstrap-start");}catch(Exception e){s.First(e);throw;}finally{s.Started.Set();}}
  public static PumpResult RunPrepared(ProcessStartInfo info,string run,string controlHash,string targetHash,string shellHash,string ownerSid,string logonSid,long admissionQpc){
   FullRestrictedContract.ValidateBootstrap(info,run,controlHash);FullRestrictedContract.Require(IntPtr.Size==8&&admissionQpc>0&&admissionQpc<=Stopwatch.GetTimestamp(),"fixed fresh x64 PS5.1 admission origin");
   var s=new Session{Run=run,Directory=FullRestrictedContract.Lab+@"\runs\restricted-"+run,Owner=ownerSid,Logon=logonSid,Deadline=new LeaseDeadline(admissionQpc,Stopwatch.Frequency,30000,Stopwatch.GetTimestamp),Pins=new LeasePinnedFiles()};
   lock(sync){FullRestrictedContract.Require(current==null,"one fixed session per fresh host; retained owners forbid retry");current=s;}
   PumpResult result=null;
   try{
    s.Directories=LeaseFiles.HoldControl(s.Directory+@"\control",LeaseAcl.Directory(ownerSid,logonSid));
    foreach(string name in new[]{@"\control\lease-offer.json",@"\control\lease-ack.json",@"\control\go.json",@"\request\child-ready.json"})FullRestrictedContract.Require(!File.Exists(s.Directory+name),"stale gate file before process start");
    s.Pins.Add(FullRestrictedContract.Executable,targetHash);s.Pins.Add(info.FileName,shellHash);s.Mark("pins-complete");
    s.Lease=new CdbTargetLease(run,FullRestrictedContract.Executable,targetHash,info.FileName,shellHash,new CdbLeaseNative(s.Pins.Hashes));s.Gate=new CdbGateProtocol(s.Lease,run,s.Deadline,Stopwatch.GetTimestamp,GetTickCount64);
    s.Worker=Task.Factory.StartNew(()=>Control(s),CancellationToken.None,TaskCreationOptions.LongRunning,TaskScheduler.Default);
    int remaining=s.Deadline.Remaining-5000;FullRestrictedContract.Require(remaining>0,"outer preparation consumed active allowance");
    result=ProcessPump.RunBootstrapFullRestricted(info,remaining,run,controlHash,262144,new[]{s.Directory+@"\request",s.Directory+@"\output",s.Directory+@"\control"},4194304);
    RememberReturnedPump(result);
    s.Mark("outer-pump-return");
    if(!s.Worker.Wait(Math.Max(0,s.Deadline.Remaining)))throw new TimeoutException("controller gate worker remains owned");
    if(s.Error!=null)throw new InvalidOperationException("lease-control worker failed",s.Error);
    FullRestrictedContract.Require(s.Gate.Acknowledged&&s.Gate.GoPublished,"no complete lease-control gate");
    FullRestrictedContract.Require(result.CleanupVerified&&result.DirectProcessExited&&result.JobDrained&&result.StreamCaptureComplete,"outer exact cleanup not proven");
    FullRestrictedContract.Require(s.Lease.CloseAfterDrain(true),"held lease close/drain remains unresolved");s.Closed=true;s.Mark("leases-closed");
    FullRestrictedContract.Require(s.Deadline.Remaining>0,"outer admission deadline overrun");return result;
   }catch(Exception e){s.First(e);throw;}finally{
    // Only confirmed exact outer drain permits final duplicate close. Failure
    // keeps this Session in this host; no PID reopen, next run or owner drop.
    try{if(!s.Closed)s.Closed=CloseAfterPump(result,s.Lease,s.Worker,s.Run,s.BootstrapPid,s.Gate);}catch(Exception e){s.Later(e);}
    try{if(s.Closed||s.Lease==null||!s.Lease.BootstrapStarted){if(s.Worker==null||s.Worker.IsCompleted){s.Pins.Dispose();if(s.Directories!=null)s.Directories.Dispose();}}}catch(Exception e){s.Later(e);if(s.Error==null){s.First(e);throw;}}
   }
  }
  internal static void RememberReturnedPump(PumpResult result){
   lock(sync){FullRestrictedContract.Require(current!=null&&result!=null&&result.RunId==current.Run&&current.Pump==null,"one actual same-run PumpResult required");current.Pump=result;}
  }
  internal static bool CloseAfterPump(PumpResult result,CdbTargetLease lease,Task worker,string run,int bootstrapPid,CdbGateProtocol gate){
   if(result==null||lease==null||(worker!=null&&!worker.IsCompleted))return false;
   // Keep the original accepted cleanup path unchanged. A separate failure
   // path may close only the original bootstrap-only, no-offer lease.
   bool normal=result.CleanupVerified&&result.DirectProcessExited&&result.JobDrained;
   bool failedBootstrap=!result.CleanupVerified&&worker!=null&&worker.IsCompleted&&gate!=null&&gate.Offer==null&&!gate.Acknowledged&&!gate.GoPublished&&lease.BootstrapStarted&&!lease.Ready&&lease.Owners.Count==1&&bootstrapPid>0&&result.Pid==bootstrapPid&&result.RunId==run&&result.FullRestrictedMode&&!result.NoProcessCreated&&result.JobObserved&&result.DirectProcessExited&&result.JobDrained&&result.RemainingOwnedProcesses==0&&result.DesktopLeaseObserved&&result.DesktopLeaseClosed&&!result.DesktopLeaseRetained&&result.StreamCaptureComplete&&result.FullJobObserverClosed&&!result.FullJobObserverRetained&&result.FullJobObserverCloseError==0&&(!String.IsNullOrEmpty(result.Error)||!String.IsNullOrEmpty(result.CleanupError));
   if(failedBootstrap){var owner=lease.Owners[0];failedBootstrap=owner.Role=="bootstrap"&&owner.Value!=IntPtr.Zero&&owner.Value==owner.Acquired&&!owner.Closed&&!owner.Retained&&!owner.CloseAttempted&&owner.CloseError==0&&String.IsNullOrEmpty(owner.CloseException);}
   if(!normal&&!failedBootstrap)return false;
   // The existing owner rechecks its retained reference and closes at most
   // once. Do not change PumpResult/Error/CleanupVerified or invent an owner.
   return lease.CloseAfterDrain(true);
  }
  static void Control(Session s){try{
   while(!s.Started.IsSet){if(s.Deadline.Remaining<=5000)throw new TimeoutException("bootstrap ownership capture deadline");s.Started.Wait(Math.Min(5,s.Deadline.Remaining));}
   if(s.Error!=null)throw new InvalidOperationException("post-start capture failed",s.Error);
   string offer=s.Directory+@"\control\lease-offer.json";s.Gate.AcceptOffer(LeaseRecords.ParseOffer(LeaseFiles.AwaitRead(offer,()=>Remaining(s))));s.Mark("leases-validated");
   s.Gate.PublishAck(bytes=>LeaseFiles.Create(s.Directory+@"\control\lease-ack.json",bytes,LeaseAcl.File(s.Owner,s.Logon)));s.Mark("lease-ack");
   string ready=s.Directory+@"\request\child-ready.json";s.Gate.Ready(LeaseFiles.AwaitRead(ready,()=>Remaining(s)));s.Mark("child-ready");
   s.Gate.PublishGo(bytes=>LeaseFiles.Create(s.Directory+@"\control\go.json",bytes,LeaseAcl.File(s.Owner,s.Logon)));s.Mark("go");
  }catch(Exception e){s.First(e);}}
  static int Remaining(Session s){int left=Math.Max(0,s.Deadline.Remaining-5000);if(s.Gate.Offer!=null){long ticks=s.Gate.Offer.NativeDeadline-Stopwatch.GetTimestamp();left=(int)Math.Min(left,ticks<=0?0:checked(ticks*1000)/Stopwatch.Frequency);}return left;}
  // No projection, enumeration, native query, JSON or output is involved in
  // this conservative retention decision. Unknown/throwing callers must hold.
  public static bool MustHoldHost(){Session s;lock(sync)s=current;return s!=null&&((s.Worker!=null&&!s.Worker.IsCompleted)||(s.Lease!=null&&s.Lease.BootstrapStarted&&!s.Closed));}
  public static object Snapshot(){Session s;lock(sync)s=current;if(s==null)return new{session=false,holdHost=false};object[] owners=s.Lease==null?new object[0]:s.Lease.OwnerSnapshot();Dictionary<string,long> stages;lock(s.Stages)stages=new Dictionary<string,long>(s.Stages);string[] secondary;lock(s.Secondary)secondary=s.Secondary.ConvertAll(e=>e.ToString()).ToArray();return new{session=true,runId=s.Run,holdHost=MustHoldHost(),sourceBuildOnly=false,cdbExecuted=false,debuggerAttached=false,admissionQpc=s.Deadline.Start,outerDeadlineQpc=s.Deadline.Expiry,targetSignalObservedQpc=s.Lease==null?0:s.Lease.TargetSignalObservedQpc,targetSignalSemantics="first signal observed by the actual retained target HANDLE query; not OS exit time",stages=stages,owners=owners,bootstrapPid=s.BootstrapPid,pumpResult=s.Pump,error=s.Error==null?null:s.Error.ToString(),secondaryCleanupErrors=secondary,taskBStopHandoffImplemented=false};}
 }
}
