#requires -Version 5.1
[CmdletBinding()]
param([ValidateSet('normal')][string]$Scenario='normal',[switch]$Execute,[ValidatePattern('^[a-f0-9]{32}$')][string]$RunId,[ValidatePattern('^[a-f0-9]{64}$')][string]$ReviewedPackageSha256)
$admissionQpc=[Diagnostics.Stopwatch]::GetTimestamp()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$build=$repo+'\artifacts\aa-fr-native-lifecycle-fixture\build-cdb-owned-wait2-9974-cons1';$lab=$repo+'\artifacts\aa-fr-native-lifecycle-fixture\lab-cdb-owned-wait2'
Import-Module ($PSScriptRoot+'\FixtureRules.psm1') -Force -DisableNameChecking
Assert-FixtureHost
$plan=[ordered]@{schema=1;scenario=$Scenario;protocol='lease-control.v1';sourceBuildOnly=$true;runtimeAllowed=$false;lab=$lab;controller='fresh-x64-PS5.1';outerMs=30000;innerMs=10000;childMs=12000;cleanupMs=5000;cdbExecuted=$false;debuggerAttached=$false;executionAclChanges=$false;requiresPreparedAclAtCreation=$true}
if(-not $Execute){[pscustomobject]$plan;return}
Assert-Fixture ($ReviewedPackageSha256 -and (Get-FixtureHash ($build+'\manifest.json')) -ceq $ReviewedPackageSha256) 'exact separately reviewed package required'
$manifest=Read-FixtureJson ($build+'\manifest.json') 1048576
# This Task A package is SOURCE/BUILD only. A future separately reviewed native
# admission package must supply prepared objects and a matching native record.
Assert-Fixture ($manifest.runtimeAllowed -eq $true -and -not $manifest.sourceBuildOnly) 'Task A SOURCE/BUILD package has no native execution admission'
foreach($file in $manifest.files){Assert-Fixture ((Get-FixtureHash ($build+'\'+$file.path)) -ceq $file.sha256) 'frozen package drift'}
Assert-Fixture (-not('Azurite.Restricted.ProcessPump' -as [type])) 'fresh host: no earlier native owners'
Assert-Fixture ($RunId -cmatch '^[a-f0-9]{32}$') 'prepared run identity required'
$run=$lab+'\runs\restricted-'+$RunId;$controlPath=$run+'\tooling\control.json';$control=Read-FixtureJson $controlPath
Assert-Fixture ($control.protocol -ceq 'lease-control.v1' -and $control.scenario -ceq 'normal' -and $control.runId -ceq $RunId -and $control.packageSha256 -ceq $ReviewedPackageSha256) 'prepared fixed control binding'
Add-Type -Path ($build+'\AzuriteLifecycle.FixtureOnly.dll')
function Capture-ProtectedFile { [pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read(($lab+'\install\protected\proof.bin'),$false);attributes=[int](Get-Item -LiteralPath ($lab+'\install\protected\proof.bin')).Attributes;captureHandleRetained=$false} }
function Capture-ProtectedDirectory { [pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read(($lab+'\install\protected'),$false);attributes=[int](Get-Item -LiteralPath ($lab+'\install\protected')).Attributes;children=@(Get-ChildItem -LiteralPath ($lab+'\install\protected') -Force|Select-Object -ExpandProperty Name|Sort-Object);captureHandleRetained=$false} }
$canaryBefore=Capture-ProtectedFile;$directoryBefore=Capture-ProtectedDirectory;$anchorsBefore=@($lab,($lab+'\install'))|ForEach-Object{[Azurite.Stage.FileSecurity]::Read($_,$false)}
Assert-Fixture (-not(Test-Path -LiteralPath ($run+'\request\protection-result.json'))) 'child positive control must not preexist'
Assert-FixtureWaitRuntimePins $manifest.runtimePins
$shell=Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe'
$psi=New-FixtureStart $shell ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+$run+'\tooling\RestrictedCliBootstrap.ps1 -ControlPath '+$controlPath+' -ReviewedControlSha256 '+(Get-FixtureHash $controlPath)) $run
$psi.EnvironmentVariables.Remove('PSModulePath')
$outer=[Azurite.Restricted.CdbOwnedWait]::RunPrepared($psi,$RunId,(Get-FixtureHash $controlPath),$manifest.probeSha256,$manifest.bootstrapSha256,$control.userSid,$control.logonSid,$admissionQpc)
$gate=[Azurite.Restricted.CdbOwnedWait]::Snapshot();$bootstrap=Read-FixtureJson ($run+'\output\fixture-bootstrap-result.json') 1048576
Assert-LeaseGateResult $outer $bootstrap $gate
$entry=Read-FixtureJson ($run+'\request\entry.json');Assert-FixtureChild $entry $control;Assert-FixtureNativeEvidence $bootstrap.native.Evidence $entry;Assert-FixtureCaptured $bootstrap.native.Process.Stdout $bootstrap.native.Process.Stderr $RunId
Assert-FixtureMonitorEvidence $outer.FullDesktopMonitorEvidence $RunId;Assert-FixtureMonitorEvidence $bootstrap.native.Evidence.fullDesktopMonitor $RunId;Assert-FixtureCleanupOrdering $outer.FullDesktopMonitorEvidence.outerDrain $outer $RunId
$wait=Assert-FixtureWaitProbe (Read-FixtureJson ($run+'\request\wait-host-entry.json')) (Read-FixtureJson ($run+'\request\wait-host-result.json')) (Read-FixtureJson ($run+'\request\wait-probe.json')) $RunId $entry.pid $bootstrap.native.Evidence.threadId (Get-Item ($run+'\request\wait-probe.json')).Length
$canaryAfter=Capture-ProtectedFile;$directoryAfter=Capture-ProtectedDirectory;$anchorsAfter=@($lab,($lab+'\install'))|ForEach-Object{[Azurite.Stage.FileSecurity]::Read($_,$false)}
$positive=[pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read(($run+'\request\protection-result.json'),$true);absentBeforeLaunch=$true;controllerCreatedResult=$false;captureHandleRetained=$false}
$protection=Assert-FixtureProtection (Read-FixtureJson ($run+'\request\protection-result.json')) $canaryBefore $canaryAfter $directoryBefore $directoryAfter $anchorsBefore $anchorsAfter $positive $RunId $entry.pid $bootstrap.native.Evidence.threadId $control.userSid $control.logonSid $manifest.canarySha256 36
Assert-FixtureWaitRuntimePins $manifest.runtimePins
[pscustomobject][ordered]@{passed=$true;outer=$outer;bootstrap=$bootstrap;gate=$gate;wait=$wait;protection=$protection;debuggerAttached=$false;aaExecuted=$false}
