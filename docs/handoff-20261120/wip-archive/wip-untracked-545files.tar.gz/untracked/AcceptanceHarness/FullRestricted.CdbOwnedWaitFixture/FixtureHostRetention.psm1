Set-StrictMode -Version Latest
function Invoke-FixtureHeldBoundary {
 param([scriptblock]$Run,[scriptblock]$NeedHold,[scriptblock]$Snapshot,[scriptblock]$Sink,[scriptblock]$Warning,[scriptblock]$Hold,[scriptblock]$Secondary)
 $primary=$null;$result=$null;$mustHold=$true
 try{$result=& $Run}catch{$primary=$_}
 finally{
  # The minimal decision runs first and fails closed. No evidence projection
  # or output determines whether the original process must stay alive.
  try{try{$mustHold=[bool](& $NeedHold)}catch{try{& $Secondary $_}catch{}}}
  finally{
   try{try{$state=& $Snapshot;& $Sink $state}catch{try{& $Secondary $_}catch{}}}
   finally{
    try{if($mustHold){try{& $Warning}catch{try{& $Secondary $_}catch{}}}}
    finally{if($mustHold){& $Hold}}
   }
  }
 }
 if($null -ne $primary){throw $primary}
 if($mustHold){throw 'Unresolved ownership; hold callback returned unexpectedly'}
 return $result
}
Export-ModuleMember -Function Invoke-FixtureHeldBoundary
