/* Fixed diagnostic extension only. Invoked on wmain's original native thread. */
typedef int32_t (__cdecl *wait_init_runtime)(const wchar_t*,const void*,void**);
typedef int32_t (__cdecl *wait_runtime_delegate)(void*,int,void**);
typedef int32_t (__cdecl *wait_close_runtime)(void*);
typedef int32_t (__stdcall *wait_load_method)(const wchar_t*,const wchar_t*,const wchar_t*,const wchar_t*,void*,void**);
typedef int32_t (__cdecl *wait_managed_entry)(char*,int);
typedef HRESULT (WINAPI *wait_apartment_type)(int*,int*);
static int run_wait_probe(void) {
 const wchar_t *fxrPath=L"C:\\Program Files\\dotnet\\host\\fxr\\6.0.36\\hostfxr.dll";
 const wchar_t *config=FIXTURE_LAB L"\\install\\WaitProbe.Managed.runtimeconfig.json";
 const wchar_t *assembly=FIXTURE_LAB L"\\install\\WaitProbe.Managed.dll";
 char initial[1024],status[2048],payload[32768];
 HMODULE ole=LoadLibraryExW(L"ole32.dll",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32),fxr=NULL;
 wait_apartment_type apartment=NULL;wait_init_runtime initialize=NULL;
 wait_runtime_delegate delegate=NULL;wait_close_runtime close_runtime=NULL;
 wait_load_method load_method=NULL;wait_managed_entry entry=NULL;
 void *context=NULL,*loader=NULL,*method=NULL;
 HRESULT apartmentHr=(HRESULT)0x80004005;int apartmentKind=-1,apartmentQualifier=-1;
 int32_t initHr=(int32_t)0x80004005,delegateHr=initHr,loadHr=initHr,closeHr=initHr,written=-1;
 DWORD error=0;
 if(ole)apartment=(wait_apartment_type)(void*)GetProcAddress(ole,"CoGetApartmentType");
 if(apartment)apartmentHr=apartment(&apartmentKind,&apartmentQualifier);
 _snprintf_s(initial,sizeof(initial),_TRUNCATE,"{\"schema\":1,\"runId\":\"%s\",\"pid\":%lu,\"nativeThreadId\":%lu,\"beforeManagedRuntime\":true,\"apartmentHr\":%ld,\"apartmentKind\":%d,\"apartmentQualifier\":%d}",runid,GetCurrentProcessId(),GetCurrentThreadId(),(long)apartmentHr,apartmentKind,apartmentQualifier);
 write_new(L"wait-host-entry.json",initial);
 fxr=LoadLibraryExW(fxrPath,NULL,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
 if(!fxr){error=GetLastError();goto done;}
 initialize=(wait_init_runtime)(void*)GetProcAddress(fxr,"hostfxr_initialize_for_runtime_config");
 delegate=(wait_runtime_delegate)(void*)GetProcAddress(fxr,"hostfxr_get_runtime_delegate");
 close_runtime=(wait_close_runtime)(void*)GetProcAddress(fxr,"hostfxr_close");
 if(!initialize||!delegate||!close_runtime){error=GetLastError();goto done;}
 initHr=initialize(config,NULL,&context);
 if(initHr<0||context==NULL)goto done;
 delegateHr=delegate(context,5,&loader); /* hdt_load_assembly_and_get_function_pointer */
 closeHr=close_runtime(context);context=NULL;
 if(delegateHr<0||loader==NULL)goto done;
 load_method=(wait_load_method)loader;
 loadHr=load_method(assembly,L"WaitProbe.EntryPoint, WaitProbe.Managed",L"Run",(const wchar_t*)(intptr_t)-1,NULL,&method);
 if(loadHr<0||method==NULL)goto done;
 entry=(wait_managed_entry)method;
 written=entry(payload,(int)sizeof(payload));
 if(written>0&&written<(int)sizeof(payload)&&payload[written]==0)write_new(L"wait-probe.json",payload);
done:
 if(context&&close_runtime)closeHr=close_runtime(context);
 _snprintf_s(status,sizeof(status),_TRUNCATE,"{\"schema\":1,\"runId\":\"%s\",\"pid\":%lu,\"nativeThreadId\":%lu,\"initializeHr\":%ld,\"delegateHr\":%ld,\"loadHr\":%ld,\"closeHr\":%ld,\"nativeError\":%lu,\"managedBytes\":%ld,\"sameInitialThread\":true,\"aaExecuted\":false}",runid,GetCurrentProcessId(),GetCurrentThreadId(),(long)initHr,(long)delegateHr,(long)loadHr,(long)closeHr,error,(long)written);
 write_new(L"wait-host-result.json",status);
 return (written>0&&written<(int)sizeof(payload)&&closeHr>=0)?0:1;
}
