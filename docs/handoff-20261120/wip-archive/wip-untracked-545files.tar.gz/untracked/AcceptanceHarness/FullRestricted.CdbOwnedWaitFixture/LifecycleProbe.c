#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0A00
#include <windows.h>
#include <sddl.h>
#include <stdio.h>
#include <wchar.h>
#include <stdint.h>
#include "FixturePolicy.h"
#include "FixtureTarget.h"
/* Diagnostic variant: retains lifecycle checks; invokes fixed CLR wait hook. No shell/child creation,
   AA, registry, network, audio, input, GUI or desktop switching operations. */
typedef BOOL (WINAPI *OPEN_TOKEN)(HANDLE,DWORD,PHANDLE);
typedef BOOL (WINAPI *QUERY_TOKEN)(HANDLE,TOKEN_INFORMATION_CLASS,LPVOID,DWORD,PDWORD);
typedef BOOL (WINAPI *IS_RESTRICTED)(HANDLE);
typedef BOOL (WINAPI *SID_TEXT)(PSID,LPSTR*);
typedef BOOL (WINAPI *PRIV_TEXT)(LPCSTR,PLUID,LPSTR,LPDWORD);
typedef HDESK (WINAPI *THREAD_DESKTOP)(DWORD);
typedef BOOL (WINAPI *OBJECT_INFO)(HANDLE,int,PVOID,DWORD,LPDWORD);
static QUERY_TOKEN query_token;static SID_TEXT sid_text;static char runid[33],scenario[32],user[192],logon[192];
static wchar_t request[260];static uint32_t session_expected,integrity_expected,policy_expected;
static ULONGLONG child_deadline;
static DWORD WINAPI lifetime_limit(LPVOID ignored){(void)ignored;for(;;){ULONGLONG now=GetTickCount64();if(now>=child_deadline)ExitProcess(91);Sleep((DWORD)((child_deadline-now)>50?50:(child_deadline-now)));}}
static void require(int b,int code){if(!b)ExitProcess((UINT)code);}
static void path(wchar_t *out,const wchar_t *leaf){require(swprintf_s(out,260,L"%s\\%s",request,leaf)>0,11);}
static void write_new(const wchar_t *leaf,const char *data){
 wchar_t p[260];HANDLE f;DWORD n;size_t len=strlen(data);path(p,leaf);require(len<32768,12);
 f=CreateFileW(p,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OPEN_REPARSE_POINT,NULL);require(f!=INVALID_HANDLE_VALUE,13);
 require(WriteFile(f,data,(DWORD)len,&n,NULL)&&n==len&&FlushFileBuffers(f),14);require(CloseHandle(f),15);
}
static void get_input(void){
 wchar_t p[260];HANDLE f;DWORD n;char b[4096],*line,*next,*eq;unsigned count=0;BY_HANDLE_FILE_INFORMATION info;
 path(p,L"fixture-input.txt");f=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);require(f!=INVALID_HANDLE_VALUE,16);
 require(GetFileInformationByHandle(f,&info)&&info.nNumberOfLinks==1&&!(info.dwFileAttributes&FILE_ATTRIBUTE_REPARSE_POINT)&&info.nFileSizeHigh==0&&info.nFileSizeLow<sizeof(b),17);
 require(ReadFile(f,b,sizeof(b)-1,&n,NULL)&&n==info.nFileSizeLow,18);b[n]=0;require(CloseHandle(f),19);
 line=b;while(*line){next=strchr(line,'\n');require(next!=NULL,20);*next=0;eq=strchr(line,'=');require(eq!=NULL,20);*eq++=0;
  if(count==0){require(!strcmp(line,"runId")&&fixture_run_id(eq),21);strcpy_s(runid,sizeof(runid),eq);}
  else if(count==1){require(!strcmp(line,"scenario")&&fixture_case(eq),21);strcpy_s(scenario,sizeof(scenario),eq);}
  else if(count==2){require(!strcmp(line,"userSid")&&fixture_sid(eq),21);strcpy_s(user,sizeof(user),eq);}
  else if(count==3){require(!strcmp(line,"logonSid")&&fixture_sid(eq),21);strcpy_s(logon,sizeof(logon),eq);}
  else if(count==4)require(!strcmp(line,"session")&&fixture_u32(eq,&session_expected),21);
  else if(count==5)require(!strcmp(line,"integrityRid")&&fixture_u32(eq,&integrity_expected),21);
  else if(count==6)require(!strcmp(line,"mandatoryPolicy")&&fixture_u32(eq,&policy_expected),21);
  else require(0,21);count++;line=next+1;
 }require(count==7,22);
}
static DWORD scalar(HANDLE t,TOKEN_INFORMATION_CLASS c){DWORD v=0,n=0;require(query_token(t,c,&v,4,&n)&&n==4,31);return v;}
static void variable(HANDLE t,TOKEN_INFORMATION_CLASS c,BYTE *buffer,DWORD capacity){
 DWORD n=0;BOOL ok=query_token(t,c,NULL,0,&n);require(!ok&&GetLastError()==ERROR_INSUFFICIENT_BUFFER&&n>0&&n<=capacity,32);
 require(query_token(t,c,buffer,capacity,&n)&&n>0&&n<=capacity,33);
}
static void sid_copy(PSID sid,char *out,size_t cap){LPSTR s=NULL;require(sid_text(sid,&s)&&s!=NULL,34);require(strlen(s)<cap,34);strcpy_s(out,cap,s);require(LocalFree(s)==NULL,34);}
#include "WaitManagedHook.h"
#include "ProtectionProbe.h"
#include "ChildGate.h"
int wmain(int argc,wchar_t **argv){
 wchar_t expected[260],env[260],desktop[256],rwide[33];char entry[32768],observed_user[192],actual_logon[192],priv_name[128],prefix[256];DWORD got,pid=GetCurrentProcessId(),n,err,flags[3],types[3],session,integrity,policy,elevated,app,type;
 HANDLE t=NULL,h[3],watch;BOOL any_job=FALSE,eof;BYTE buffer[65536];HMODULE adv,usr;OPEN_TOKEN open_token;IS_RESTRICTED restricted;PRIV_TEXT priv_text;THREAD_DESKTOP thread_desktop;OBJECT_INFO object_info;TOKEN_GROUPS *groups;TOKEN_PRIVILEGES *privs;TOKEN_MANDATORY_LABEL *label;unsigned i,actual_logons=0,user_count=0,restricted_logon=0,restricted_world=0,restricted_users=0;DWORD user_attributes=0,priv_size=sizeof(priv_name);char rs[192];ULONGLONG ticks=GetTickCount64();
 child_deadline=ticks+12000;
 watch=CreateThread(NULL,0,lifetime_limit,NULL,0,NULL);require(watch!=NULL,10);require(CloseHandle(watch),10);
 require(argc==6&&!wcscmp(argv[1],L"-batchmode")&&!wcscmp(argv[2],L"-nographics")&&!wcscmp(argv[3],L"-disableaudio")&&!wcscmp(argv[4],L"-logFile"),10);
 got=GetEnvironmentVariableW(L"AZUREARCHIVE_CLI_DIRECTORY",request,260);require(got>0&&got<260,10);get_input();require(MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,runid,-1,rwide,33)==33,10);
 require(swprintf_s(expected,260,L"%s\\runs\\restricted-%s\\request",FIXTURE_LAB,rwide)>0&&!wcscmp(request,expected),10);
 require(swprintf_s(expected,260,L"%s\\runs\\restricted-%s\\output\\unity.log",FIXTURE_LAB,rwide)>0&&!wcscmp(argv[5],expected),10);
 require(GetEnvironmentVariableW(L"BEPINEX_GAME_ASSEMBLY_PATH",env,260)==0,10);
 _snprintf_s(entry,sizeof(entry),_TRUNCATE,"{\"fixtureOnly\":true,\"productionTargetExecuted\":false,\"runId\":\"%s\",\"pid\":%lu,\"stage\":\"native-entry\"}",runid,pid);write_new(L"entry-start.json",entry);
 adv=LoadLibraryExW(L"advapi32.dll",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32);usr=LoadLibraryExW(L"user32.dll",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32);require(adv&&usr,30);
#define LOAD(module,target,name,type_name) target=(type_name)(void*)GetProcAddress(module,name);require(target!=NULL,30)
 LOAD(adv,open_token,"OpenProcessToken",OPEN_TOKEN);LOAD(adv,query_token,"GetTokenInformation",QUERY_TOKEN);LOAD(adv,restricted,"IsTokenRestricted",IS_RESTRICTED);LOAD(adv,sid_text,"ConvertSidToStringSidA",SID_TEXT);LOAD(adv,priv_text,"LookupPrivilegeNameA",PRIV_TEXT);
 LOAD(usr,thread_desktop,"GetThreadDesktop",THREAD_DESKTOP);LOAD(usr,object_info,"GetUserObjectInformationW",OBJECT_INFO);
 require(open_token(GetCurrentProcess(),TOKEN_QUERY,&t),31);variable(t,TokenUser,buffer,sizeof(buffer));sid_copy(((TOKEN_USER*)buffer)->User.Sid,observed_user,sizeof(observed_user));require(!strcmp(observed_user,user),35);
 session=scalar(t,TokenSessionId);elevated=scalar(t,TokenElevation);app=scalar(t,TokenIsAppContainer);type=scalar(t,TokenType);policy=scalar(t,TokenMandatoryPolicy);
 require(restricted(t)&&session==session_expected&&elevated==0&&app==0&&type==TokenPrimary,36);
 variable(t,TokenGroups,buffer,sizeof(buffer));groups=(TOKEN_GROUPS*)buffer;require(groups->GroupCount<256,37);for(i=0;i<groups->GroupCount;i++){sid_copy(groups->Groups[i].Sid,rs,sizeof(rs));if((groups->Groups[i].Attributes&SE_GROUP_LOGON_ID)==SE_GROUP_LOGON_ID){actual_logons++;strcpy_s(actual_logon,sizeof(actual_logon),rs);}if(!strcmp(rs,"S-1-5-32-545")){user_count++;user_attributes=groups->Groups[i].Attributes;}}
 require(actual_logons==1&&!strcmp(actual_logon,logon)&&user_count==1&&(user_attributes&SE_GROUP_ENABLED)&&!(user_attributes&SE_GROUP_USE_FOR_DENY_ONLY),38);
 variable(t,TokenRestrictedSids,buffer,sizeof(buffer));groups=(TOKEN_GROUPS*)buffer;require(groups->GroupCount==3,39);for(i=0;i<groups->GroupCount;i++){sid_copy(groups->Groups[i].Sid,rs,sizeof(rs));if(!strcmp(rs,logon))restricted_logon++;if(!strcmp(rs,"S-1-1-0"))restricted_world++;if(!strcmp(rs,"S-1-5-32-545"))restricted_users++;}require(fixture_full_set(groups->GroupCount,restricted_logon,restricted_world,restricted_users),39);
 variable(t,TokenIntegrityLevel,buffer,sizeof(buffer));label=(TOKEN_MANDATORY_LABEL*)buffer;require(label->Label.Attributes==0x60,40);sid_copy(label->Label.Sid,rs,sizeof(rs));require(sscanf_s(rs,"S-1-16-%lu",&integrity)==1&&fixture_inherited(integrity,policy,integrity_expected,policy_expected),40);
 variable(t,TokenPrivileges,buffer,sizeof(buffer));privs=(TOKEN_PRIVILEGES*)buffer;require(privs->PrivilegeCount==1&&priv_text(NULL,&privs->Privileges[0].Luid,priv_name,&priv_size)&&!strcmp(priv_name,"SeChangeNotifyPrivilege")&&(privs->Privileges[0].Attributes&SE_PRIVILEGE_ENABLED),41);require(CloseHandle(t),42);
 require(object_info(thread_desktop(GetCurrentThreadId()),UOI_NAME,desktop,sizeof(desktop),&n),43);require(swprintf_s(expected,260,L"AzuriteFullCli_%s",rwide)>0&&!wcscmp(desktop,expected),43);
 require(IsProcessInJob(GetCurrentProcess(),NULL,&any_job)&&any_job,44);
 h[0]=GetStdHandle(STD_INPUT_HANDLE);h[1]=GetStdHandle(STD_OUTPUT_HANDLE);h[2]=GetStdHandle(STD_ERROR_HANDLE);require(h[0]&&h[1]&&h[2]&&h[0]!=h[1]&&h[0]!=h[2]&&h[1]!=h[2],45);
 for(i=0;i<3;i++){require(h[i]!=INVALID_HANDLE_VALUE&&GetHandleInformation(h[i],&flags[i]),45);types[i]=GetFileType(h[i]);require(types[i]==FILE_TYPE_PIPE,45);}
 n=0;eof=ReadFile(h[0],buffer,1,&n,NULL);err=eof?0:GetLastError();require((eof&&n==0)||(!eof&&err==ERROR_BROKEN_PIPE),46);
 _snprintf_s(prefix,sizeof(prefix),_TRUNCATE,"FIXTURE_STDOUT %s ",runid);require(WriteFile(h[1],prefix,(DWORD)strlen(prefix),&n,NULL)&&n==strlen(prefix),47);
 require(WriteFile(h[1],"\xE2",1,&n,NULL)&&n==1,47);Sleep(20);require(WriteFile(h[1],"\x82\xAC\n",3,&n,NULL)&&n==3,47);
 _snprintf_s(prefix,sizeof(prefix),_TRUNCATE,"FIXTURE_STDERR %s ",runid);require(WriteFile(h[2],prefix,(DWORD)strlen(prefix),&n,NULL)&&n==strlen(prefix),48);require(WriteFile(h[2],"\xF0\x9F",2,&n,NULL)&&n==2,48);Sleep(20);require(WriteFile(h[2],"\x8C\x9F\n",3,&n,NULL)&&n==3,48);
 _snprintf_s(entry,sizeof(entry),_TRUNCATE,"{\"schema\":1,\"fixtureOnly\":true,\"productionTargetExecuted\":false,\"runId\":\"%s\",\"scenario\":\"%s\",\"pid\":%lu,\"tick\":%llu,\"userSid\":\"%s\",\"logonSid\":\"%s\",\"session\":%lu,\"integrityRid\":%lu,\"integrityAttributes\":96,\"mandatoryPolicy\":%lu,\"elevated\":%lu,\"appContainer\":%lu,\"tokenType\":%lu,\"isRestricted\":true,\"usersAttributes\":%lu,\"restrictedSidCount\":3,\"restrictingSids\":[\"%s\",\"S-1-1-0\",\"S-1-5-32-545\"],\"privilege\":\"%s\",\"privilegeEnabled\":true,\"desktop\":\"AzuriteFullCli_%s\",\"anyJobMembership\":true,\"exactJobClaimedByChild\":false,\"stdHandles\":[%llu,%llu,%llu],\"stdTypes\":[%lu,%lu,%lu],\"stdFlags\":[%lu,%lu,%lu],\"stdinEof\":true,\"stdinReadError\":%lu,\"streamsWritten\":true,\"lifetimeLimitMs\":12000}",runid,scenario,pid,ticks,observed_user,actual_logon,session,integrity,policy,elevated,app,type,user_attributes,logon,priv_name,runid,(unsigned long long)(uintptr_t)h[0],(unsigned long long)(uintptr_t)h[1],(unsigned long long)(uintptr_t)h[2],types[0],types[1],types[2],flags[0],flags[1],flags[2],err);
 write_new(L"entry.json",entry);
 require(!strcmp(scenario,"normal"),92);
 await_controller_go(ticks,pid);
 probe_canary();
 require(run_wait_probe()==0,95);
 write_new(L"normal-complete.json","{\"fixtureOnly\":true,\"normalCompletion\":true}");return 0;
}
