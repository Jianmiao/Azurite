#requires -Version 5.1
param([ValidateSet('normal')][string]$Scenario='normal',[switch]$Execute,[string]$RunId,[string]$ReviewedPackageSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Fresh x64 PS5.1 host required'}
$parameters=@{Scenario=$Scenario;Execute=$Execute};if($RunId){$parameters.RunId=$RunId};if($ReviewedPackageSha256){$parameters.ReviewedPackageSha256=$ReviewedPackageSha256}
Import-Module ($PSScriptRoot+'\FixtureHostRetention.psm1') -Force -DisableNameChecking
$capturedRunner=$PSScriptRoot+'\Run-Fixture.ps1';$capturedParameters=$parameters
$dispatch={. $capturedRunner @capturedParameters}.GetNewClosure()
$decision={if('Azurite.Restricted.CdbOwnedWait' -as [type]){return [Azurite.Restricted.CdbOwnedWait]::MustHoldHost()};return $false}
$snapshot={if('Azurite.Restricted.CdbOwnedWait' -as [type]){return [Azurite.Restricted.CdbOwnedWait]::Snapshot()};return [ordered]@{session=$false;holdHost=$false}}
$sink={param($state)$state|ConvertTo-Json -Depth 12}
$warning={[Console]::Error.WriteLine('Actual owners unresolved. This original controller host remains retained for inspection; no next run, kill or retry.')}
$hold={while($true){[Threading.Thread]::Sleep(30000)}}
$secondary={param($errorRecord)try{[Console]::Error.WriteLine('Secondary diagnostic failure: '+$errorRecord.Exception.Message)}catch{}}
Invoke-FixtureHeldBoundary $dispatch $decision $snapshot $sink $warning $hold $secondary
