using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using System.Web.Script.Serialization;
namespace Azurite.Restricted {
 internal static class ReleaseErrorTests {
  static int count,failed;
  static void Check(bool okay,string why){if(!okay)throw new Exception(why);}
  static void Set(object target,string name,object value){target.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).SetValue(target,value);}
  static object Property(object target,string name){return target.GetType().GetProperty(name).GetValue(target,null);}
  static void Observe(int code,string call){
   var error=CdbLeaseNative.ReleaseFailure(code,call);
   Check(error.NativeErrorCode==code,"native code changed before diagnostic consumption");
   var slot=typeof(CdbOwnedWait).GetField("current",BindingFlags.Static|BindingFlags.NonPublic);object previous=slot.GetValue(null);
   var type=typeof(CdbOwnedWait).GetNestedType("Session",BindingFlags.NonPublic);var session=Activator.CreateInstance(type,true);
   Set(session,"Run","11111111111111111111111111111111");Set(session,"Deadline",new LeaseDeadline(100,1000,30000,()=>100));
   Set(session,"Error",new InvalidOperationException("original primary failure"));slot.SetValue(null,session);
   try{
    type.GetMethod("Later",BindingFlags.Instance|BindingFlags.NonPublic).Invoke(session,new object[]{error});
    var snapshot=CdbOwnedWait.Snapshot();var secondary=(string[])Property(snapshot,"secondaryCleanupErrors");string marker="NativeErrorCode="+code;
    Check(secondary.Length==1&&secondary[0].Contains(call)&&secondary[0].Contains(marker),"actual Snapshot secondary string lost "+marker);
    Check(((string)Property(snapshot,"error")).Contains("original primary failure"),"secondary error replaced primary");
    string json=new JavaScriptSerializer().Serialize(snapshot);Check(json.Contains(marker),"serialized Snapshot lost native code");
    var retained=(List<Exception>)type.GetField("Secondary",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(session);
    Check(Object.ReferenceEquals(retained[0],error),"original native exception was wrapped or replaced");
   }finally{slot.SetValue(null,previous);((ManualResetEventSlim)type.GetField("Started",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(session)).Dispose();}
  }
  public static int Run(){
   int[] codes={87,6,31,5};string[] calls={"release held PID","release held creation FILETIME","release held Wait0","release held inheritance flags"};
   for(int i=0;i<codes.Length;i++){count++;try{Observe(codes[i],calls[i]);Console.WriteLine("PASS actual release exception survives Snapshot: "+calls[i]+" code="+codes[i]);}catch(Exception error){failed++;Console.WriteLine("FAIL actual release exception survives Snapshot: "+calls[i]+": "+error.Message);}}
   Console.WriteLine("RELEASE ERROR SOURCE CHECKS "+count+" FAILED "+failed+"; no normal DLL/native process invoked");return failed==0?0:1;
  }
 }
}
