/* Task A: runs on the actual wmain thread, before protection proof and CLR.
   Child stdin remains EOF. The request directory contains only child-ready;
   controller go is read from the prepared child-read-only control directory. */
#include "ChildGoCodec.h"
static void await_controller_go(ULONGLONG started,DWORD pid){
 wchar_t go[512],resolved[512],wanted[512],wide[33];char ready[512],body[1024];
 DWORD tid=GetCurrentThreadId(),got,used=0,attributes,error;HANDLE f;BY_HANDLE_FILE_INFORMATION info;ChildGoState codec={0};
 FILETIME created,exited,kernel,userTime;ULARGE_INTEGER creation;
 require(GetProcessTimes(GetCurrentProcess(),&created,&exited,&kernel,&userTime),96);creation.LowPart=created.dwLowDateTime;creation.HighPart=created.dwHighDateTime;
 require(MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,runid,-1,wide,33)==33,96);
 require(swprintf_s(go,512,L"%s\\runs\\restricted-%s\\control\\go.json",FIXTURE_LAB,wide)>0,96);
 attributes=GetFileAttributesW(go);error=attributes==INVALID_FILE_ATTRIBUTES?GetLastError():0;require(attributes!=INVALID_FILE_ATTRIBUTES||error==ERROR_FILE_NOT_FOUND,96);
 require(child_go_prepare(&codec,attributes!=INVALID_FILE_ATTRIBUTES,runid,pid,tid,creation.QuadPart,started,child_deadline,GetTickCount64()),96);
 _snprintf_s(ready,sizeof(ready),_TRUNCATE,"{\"protocol\":\"child-ready.v1\",\"runId\":\"%s\",\"childPid\":%lu,\"mainTid\":%lu,\"startTick\":%llu,\"deadlineTick\":%llu}",runid,pid,tid,started,child_deadline);
 write_new(L"child-ready.json",ready);
 for(;;){
  require(GetTickCount64()<child_deadline,97);
  f=CreateFileW(go,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);
  if(f!=INVALID_HANDLE_VALUE)break;
  got=GetLastError();require(got==ERROR_FILE_NOT_FOUND||got==ERROR_SHARING_VIOLATION,97);Sleep(5);
 }
 require(GetFileInformationByHandle(f,&info)&&info.nNumberOfLinks==1&&!(info.dwFileAttributes&(FILE_ATTRIBUTE_REPARSE_POINT|FILE_ATTRIBUTE_DIRECTORY))&&info.nFileSizeHigh==0&&info.nFileSizeLow>1&&info.nFileSizeLow<sizeof(body),98);
 got=GetFinalPathNameByHandleW(f,resolved,512,0);require(got>0&&got<512&&swprintf_s(wanted,512,L"\\\\?\\%s",go)>0&&!_wcsicmp(resolved,wanted),98);
 require(ReadFile(f,body,info.nFileSizeLow,&used,NULL)&&used==info.nFileSizeLow,98);body[used]=0;require(CloseHandle(f),98);
 require(child_go_accept(&codec,body,used,GetTickCount64()),99);
}
