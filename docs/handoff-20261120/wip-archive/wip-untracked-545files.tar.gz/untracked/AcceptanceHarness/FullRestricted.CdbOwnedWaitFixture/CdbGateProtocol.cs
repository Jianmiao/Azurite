using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Web.Script.Serialization;
namespace Azurite.Restricted {
 internal sealed class LeaseDeadline {
  internal readonly long Start,Expiry,Frequency;readonly Func<long> now;
  internal LeaseDeadline(long start,long frequency,int milliseconds,Func<long> clock){Start=start;Frequency=frequency;now=clock;Expiry=checked(start+checked(frequency*milliseconds)/1000);}
  internal int Remaining {get{long current=now();if(Frequency<=0||current<Start)throw new InvalidOperationException("monotonic clock/frequency invalid");long left=Expiry-current;return left<=0?0:(int)Math.Min(Int32.MaxValue,checked(left*1000)/Frequency);}}
 }
 internal sealed class CdbGateProtocol {
  internal bool Acknowledged,GoPublished;internal LeaseOffer Offer;
  readonly CdbTargetLease lease;readonly string run;readonly LeaseDeadline outer;readonly Func<long> qpc;readonly Func<ulong> uptime;bool ready,ackAttempted,goAttempted;ulong childExpiry;
  internal CdbGateProtocol(CdbTargetLease owner,string id,LeaseDeadline deadline,Func<long> clock,Func<ulong> tick){lease=owner;run=id;outer=deadline;qpc=clock;uptime=tick;}
  static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
  void InTime(){Require(outer.Remaining>5000&&Offer!=null&&Offer.Frequency==outer.Frequency&&qpc()>=Offer.NativeStart&&qpc()<Offer.NativeDeadline,"original inner/outer gate deadline expired");}
  internal void AcceptOffer(LeaseOffer offer){Require(Offer==null&&offer!=null&&offer.Run==run,"repeated/wrong run offer");Offer=offer;InTime();lease.Accept(offer);}
  internal void PublishAck(Action<byte[]> write){Require(lease.Ready&&!ackAttempted&&!Acknowledged,"ACK requires all retained leases exactly once");ackAttempted=true;InTime();lease.Revalidate();write(LeaseRecords.Signal("lease-ack.v1",run,Offer.BootstrapPid,Offer.ChildPid,Offer.MainTid,Offer.ChildCreated));Acknowledged=true;}
  internal void Ready(byte[] data){Require(Acknowledged&&!ready&&!GoPublished,"ready before ACK or repeated");InTime();var r=LeaseRecords.ParseReady(data);Require(r.Run==run&&r.Pid==Offer.ChildPid&&r.Tid==Offer.MainTid&&r.Expiry-r.Start==12000&&uptime()>=r.Start&&uptime()<r.Expiry,"child ready identity/deadline mismatch");lease.Revalidate();childExpiry=r.Expiry;ready=true;}
  internal void PublishGo(Action<byte[]> write){Require(ready&&Acknowledged&&!goAttempted&&!GoPublished,"go requires unique ready after ACK");goAttempted=true;InTime();Require(uptime()<childExpiry,"absolute child deadline exhausted");lease.Revalidate();write(LeaseRecords.Signal("go.v1",run,Offer.BootstrapPid,Offer.ChildPid,Offer.MainTid,Offer.ChildCreated));GoPublished=true;}
 }
 internal static class LeaseRecords {
  internal sealed class ReadyFact{internal string Run;internal int Pid,Tid;internal ulong Start,Expiry;}
  static void Require(bool v,string message){if(!v)throw new InvalidOperationException("lease record: "+message);}
  static void Id(string id){Require(System.Text.RegularExpressions.Regex.IsMatch(id??"","\\A[a-f0-9]{32}\\z"),"run shape");}
  static byte[] Bytes(string text){return Encoding.ASCII.GetBytes(text);}
  static string F(string format,params object[] values){return String.Format(CultureInfo.InvariantCulture,format,values);}
  internal static byte[] Signal(string kind,string id,int bootstrap,int pid,int tid,long created){Id(id);Require((kind=="lease-ack.v1"||kind=="go.v1")&&bootstrap>0&&pid>0&&tid>0&&created>0,"signal identity");return Bytes(F("{{\"protocol\":\"{0}\",\"runId\":\"{1}\",\"bootstrapPid\":{2},\"childPid\":{3},\"mainTid\":{4},\"creation\":{5}}}",kind,id,bootstrap,pid,tid,created));}
  internal static byte[] Ready(string id,int pid,int tid,ulong start,ulong expiry){Id(id);Require(pid>0&&tid>0&&start>0&&expiry>start&&expiry-start==12000,"ready fields");return Bytes(F("{{\"protocol\":\"child-ready.v1\",\"runId\":\"{0}\",\"childPid\":{1},\"mainTid\":{2},\"startTick\":{3},\"deadlineTick\":{4}}}",id,pid,tid,start,expiry));}
  static Dictionary<string,object> Parse(byte[] data){Require(data!=null&&data.Length>1&&data.Length<=4096&&data.All(b=>b>=32&&b<=126),"ASCII bounded record");try{var value=new JavaScriptSerializer{MaxJsonLength=4096,RecursionLimit=4}.Deserialize<Dictionary<string,object>>(Encoding.ASCII.GetString(data));Require(value!=null,"object required");return value;}catch(Exception e){throw new InvalidOperationException("malformed lease record",e);}}
  static long Number(Dictionary<string,object> d,string key){object o;Require(d.TryGetValue(key,out o)&&(o is int||o is long),"integer "+key);long n=Convert.ToInt64(o,CultureInfo.InvariantCulture);Require(n>0,"positive "+key);return n;}
  static int Small(Dictionary<string,object>d,string key){long n=Number(d,key);Require(n<=Int32.MaxValue,"bounded "+key);return (int)n;}
  static string Text(Dictionary<string,object>d,string key){object o;Require(d.TryGetValue(key,out o)&&o is string,"string "+key);return (string)o;}
  internal static ReadyFact ParseReady(byte[] data){var d=Parse(data);Require(d.Count==6&&Text(d,"protocol")=="child-ready.v1","ready schema");var r=new ReadyFact{Run=Text(d,"runId"),Pid=Small(d,"childPid"),Tid=Small(d,"mainTid"),Start=(ulong)Number(d,"startTick"),Expiry=(ulong)Number(d,"deadlineTick")};Require(data.SequenceEqual(Ready(r.Run,r.Pid,r.Tid,r.Start,r.Expiry)),"noncanonical/duplicate/trailing ready");return r;}
  internal static byte[] OfferBytes(LeaseOffer o){Id(o.Run);Require(System.Text.RegularExpressions.Regex.IsMatch(o.ImageHash??"","\\A[a-f0-9]{64}\\z"),"image hash");return Bytes(F("{{\"protocol\":\"lease-offer.v1\",\"runId\":\"{0}\",\"bootstrapPid\":{1},\"childPid\":{2},\"mainTid\":{3},\"bootstrapCreated\":{4},\"childCreated\":{5},\"threadCreated\":{6},\"processSource\":{7},\"threadSource\":{8},\"jobSource\":{9},\"desktopSource\":{10},\"nativeStart\":{11},\"nativeDeadline\":{12},\"frequency\":{13},\"imageHash\":\"{14}\"}}",o.Run,o.BootstrapPid,o.ChildPid,o.MainTid,o.BootstrapCreated,o.ChildCreated,o.ThreadCreated,o.ProcessSource,o.ThreadSource,o.JobSource,o.DesktopSource,o.NativeStart,o.NativeDeadline,o.Frequency,o.ImageHash));}
  internal static LeaseOffer ParseOffer(byte[] data){var d=Parse(data);Require(d.Count==16&&Text(d,"protocol")=="lease-offer.v1","offer schema");var o=new LeaseOffer{Run=Text(d,"runId"),ImageHash=Text(d,"imageHash"),BootstrapPid=Small(d,"bootstrapPid"),ChildPid=Small(d,"childPid"),MainTid=Small(d,"mainTid"),BootstrapCreated=Number(d,"bootstrapCreated"),ChildCreated=Number(d,"childCreated"),ThreadCreated=Number(d,"threadCreated"),ProcessSource=Number(d,"processSource"),ThreadSource=Number(d,"threadSource"),JobSource=Number(d,"jobSource"),DesktopSource=Number(d,"desktopSource"),NativeStart=Number(d,"nativeStart"),NativeDeadline=Number(d,"nativeDeadline"),Frequency=Number(d,"frequency")};Require(data.SequenceEqual(OfferBytes(o)),"noncanonical/duplicate/trailing offer");return o;}
 }
}
