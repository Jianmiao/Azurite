using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using Microsoft.Win32.SafeHandles;
namespace Azurite.Stage {
 public sealed class ObjectEvidence {
  public string path,identity,volume,owner,finalPath,sddl,ownerAccessSddl,rawDescriptor,sha256,content;
  public bool directory,reparse; public uint links; public long bytes;
 }
 public static class FileSecurity {
  [StructLayout(LayoutKind.Sequential)] struct FT {public uint Low,High;}
  [StructLayout(LayoutKind.Sequential)] struct FI {public uint Attr; public FT Creation,Access,Write; public uint Volume,SizeHigh,SizeLow,Links,IdHigh,IdLow;}
  [StructLayout(LayoutKind.Sequential)] struct SA {public int Length;public IntPtr Descriptor;[MarshalAs(UnmanagedType.Bool)]public bool Inherit;}
  [StructLayout(LayoutKind.Sequential)] struct Disposition {[MarshalAs(UnmanagedType.U1)]public bool DeleteFile;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFileW(string p,uint access,uint share,IntPtr sa,uint create,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,EntryPoint="CreateFileW")] static extern SafeFileHandle CreateFileSecure(string p,uint access,uint share,ref SA sa,uint create,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateDirectoryW(string p,ref SA sa);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileInformationByHandle(SafeFileHandle h,out FI info);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetFileInformationByHandle(SafeFileHandle h,int type,ref Disposition info,uint length);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandleW(SafeFileHandle h,StringBuilder b,uint size,uint flags);
  [DllImport("advapi32.dll")] static extern uint GetSecurityInfo(SafeFileHandle h,uint type,uint info,out IntPtr o,out IntPtr g,out IntPtr d,out IntPtr s,out IntPtr sd);
  [DllImport("advapi32.dll")] static extern uint GetSecurityDescriptorLength(IntPtr sd);
  [DllImport("advapi32.dll",SetLastError=true)] static extern bool SetKernelObjectSecurity(SafeFileHandle h,uint info,byte[] sd);
  [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr p);
  static void Require(bool b,string m){if(!b)throw new InvalidOperationException(m);}
  static string Hash(byte[] b){using(var s=SHA256.Create())return BitConverter.ToString(s.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
  static string Id(FI i){return i.Volume.ToString("x8")+"00000000"+i.IdHigh.ToString("x8")+i.IdLow.ToString("x8");}
  static SafeFileHandle Open(string p,uint rights){var h=CreateFileW(p,rights,1,IntPtr.Zero,3,0x02200000,IntPtr.Zero);if(h.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error(),p);return h;}
  static byte[] Sd(SafeFileHandle h){IntPtr o,g,d,s,p;uint e=GetSecurityInfo(h,1,7,out o,out g,out d,out s,out p);if(e!=0)throw new Win32Exception((int)e);try{var b=new byte[GetSecurityDescriptorLength(p)];Marshal.Copy(p,b,0,b.Length);return b;}finally{LocalFree(p);}}
  static byte[] Binary(string s){var sd=new RawSecurityDescriptor(s);var b=new byte[sd.BinaryLength];sd.GetBinaryForm(b,0);return b;}
  static string Sddl(byte[] b){return new RawSecurityDescriptor(b,0).GetSddlForm(AccessControlSections.Owner|AccessControlSections.Group|AccessControlSections.Access);}
  static FI Info(SafeFileHandle h){FI i;if(!GetFileInformationByHandle(h,out i))throw new Win32Exception(Marshal.GetLastWin32Error());Require((i.Attr&0x400)==0,"Reparse object refused");Require((i.Attr&16)!=0||i.Links==1,"Hardlinked file refused");return i;}
  static string Final(SafeFileHandle h){var b=new StringBuilder(32768);uint n=GetFinalPathNameByHandleW(h,b,(uint)b.Capacity,1);if(n==0||n>=b.Capacity)throw new Win32Exception(Marshal.GetLastWin32Error());return b.ToString();}
  public static SafeFileHandle LockDirectory(string p){var h=Open(p,0x20081);try{Require((Info(h).Attr&16)!=0,"Directory lock type differs");return h;}catch{h.Dispose();throw;}}
  public static ObjectEvidence Read(string p,bool capture){
   using(var h=Open(p,0x80020000)){FI before=Info(h);byte[] descriptor=Sd(h);var sd=new RawSecurityDescriptor(descriptor,0);string final=Final(h);int end=final.IndexOf("}\\",StringComparison.Ordinal);Require(end>0,"No canonical GUID volume");string volume=final.Substring(0,end+2);string expected=volume+p.Substring(3);Require(final==expected,"Canonical ancestry/path spelling differs");
    var r=new ObjectEvidence{path=p,identity=Id(before),volume=volume,owner=sd.Owner.Value,finalPath=p,directory=(before.Attr&16)!=0,reparse=false,links=before.Links,bytes=((long)before.SizeHigh<<32)|before.SizeLow,sddl=Sddl(descriptor),ownerAccessSddl=sd.GetSddlForm(AccessControlSections.Owner|AccessControlSections.Access),rawDescriptor=Convert.ToBase64String(descriptor)};
    if(!r.directory){using(var fs=new FileStream(h,FileAccess.Read,65536,false)){if(capture){Require(r.bytes<=4194304,"Before-image payload over 4 MiB");var bytes=new byte[(int)r.bytes];int n=0,k;while(n<bytes.Length&&(k=fs.Read(bytes,n,bytes.Length-n))>0)n+=k;Require(n==bytes.Length,"Short payload read");r.sha256=Hash(bytes);r.content=Convert.ToBase64String(bytes);}else{using(var hash=SHA256.Create())r.sha256=BitConverter.ToString(hash.ComputeHash(fs)).Replace("-","").ToLowerInvariant();}FI after=Info(h);Require(Id(after)==r.identity&&after.SizeHigh==before.SizeHigh&&after.SizeLow==before.SizeLow&&after.Write.High==before.Write.High&&after.Write.Low==before.Write.Low&&Sddl(Sd(h))==r.sddl,"Object changed during read");}}
    return r;
   }
  }
  public static void NewDirectory(string p,string sddl){byte[] b=Binary(sddl);var pin=GCHandle.Alloc(b,GCHandleType.Pinned);try{var sa=new SA{Length=Marshal.SizeOf(typeof(SA)),Descriptor=pin.AddrOfPinnedObject(),Inherit=false};if(!CreateDirectoryW(p,ref sa))throw new Win32Exception(Marshal.GetLastWin32Error());}finally{pin.Free();}}
  public static void NewFile(string p,byte[] data,string sddl){byte[] b=Binary(sddl);var pin=GCHandle.Alloc(b,GCHandleType.Pinned);try{var sa=new SA{Length=Marshal.SizeOf(typeof(SA)),Descriptor=pin.AddrOfPinnedObject(),Inherit=false};using(var h=CreateFileSecure(p,0xC0020000,0,ref sa,1,0x00200000,IntPtr.Zero)){if(h.IsInvalid)throw new Win32Exception(Marshal.GetLastWin32Error());Require(Info(h).Links==1,"New file alias");using(var fs=new FileStream(h,FileAccess.ReadWrite,65536,false)){fs.Write(data,0,data.Length);fs.Flush(true);fs.Position=0;using(var hash=SHA256.Create())Require(BitConverter.ToString(hash.ComputeHash(fs)).Replace("-","").ToLowerInvariant()==Hash(data),"Same-handle new content mismatch");Require(Sddl(Sd(h))==sddl,"Same-handle creation descriptor mismatch");}}}finally{pin.Free();}}
  public static void SetDescriptor(string p,string identity,string before,string after){using(var h=Open(p,0x60000)){Require(Id(Info(h))==identity&&Sddl(Sd(h))==before,"Before descriptor/identity drift");var old=new RawSecurityDescriptor(before);var next=new RawSecurityDescriptor(after);Require(old.Owner==next.Owner&&((old.Group==null&&next.Group==null)||(old.Group!=null&&next.Group!=null&&old.Group.Value==next.Group.Value)),"Owner/group delta forbidden");uint flags=4|(((next.ControlFlags&ControlFlags.DiscretionaryAclProtected)!=0)?0x80000000u:0x20000000u);if(!SetKernelObjectSecurity(h,flags,Binary(after)))throw new Win32Exception(Marshal.GetLastWin32Error());Require(Id(Info(h))==identity&&Sddl(Sd(h))==after,"Same-handle descriptor delta mismatch");}}
  public static void WriteExisting(string p,string identity,string before,string hash,byte[] data){using(var h=Open(p,0xC0020000)){Require(Id(Info(h))==identity&&Sddl(Sd(h))==before,"Write identity/descriptor drift");using(var fs=new FileStream(h,FileAccess.ReadWrite,65536,false)){using(var s=SHA256.Create())Require(BitConverter.ToString(s.ComputeHash(fs)).Replace("-","").ToLowerInvariant()==hash,"Write original hash drift");fs.Position=0;fs.SetLength(0);fs.Write(data,0,data.Length);fs.Flush(true);fs.Position=0;using(var s=SHA256.Create())Require(BitConverter.ToString(s.ComputeHash(fs)).Replace("-","").ToLowerInvariant()==Hash(data),"Write same-handle readback mismatch");Require(Id(Info(h))==identity&&Sddl(Sd(h))==before,"Write descriptor/identity changed");}}}
  // Runtime-only pending-marker cleanup. The preparation coordinator never calls
  // this method; the runtime must already prove drain and zero shared delta.
  public static void DeleteExisting(string p,string identity,string before,string hash){using(var h=Open(p,0x80030000)){Require(Id(Info(h))==identity&&Sddl(Sd(h))==before,"Delete identity/descriptor drift");Require((Info(h).Attr&16)==0,"Directory deletion forbidden");using(var fs=new FileStream(h,FileAccess.Read,65536,false)){using(var s=SHA256.Create())Require(BitConverter.ToString(s.ComputeHash(fs)).Replace("-","").ToLowerInvariant()==hash,"Delete original hash drift");var remove=new Disposition{DeleteFile=true};if(!SetFileInformationByHandle(h,4,ref remove,(uint)Marshal.SizeOf(typeof(Disposition))))throw new Win32Exception(Marshal.GetLastWin32Error());}}}
 }
}