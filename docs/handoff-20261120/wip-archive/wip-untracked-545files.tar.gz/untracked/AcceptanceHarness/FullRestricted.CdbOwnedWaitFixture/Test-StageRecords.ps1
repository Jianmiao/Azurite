#requires -Version 5.1
param([Parameter(Mandatory)][string]$OutputPath,[switch]$ExpectRed)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\FixtureRules.psm1') -Force -DisableNameChecking
Assert-FixtureHost
$results=@();foreach($case in @('valid','missing-signal','signal-before-go','cleanup-reversed','cleanup-after-outer')){
 $outer=[pscustomobject]@{CleanupVerified=$true;DirectProcessExited=$true;JobDrained=$true;StreamCaptureComplete=$true;ExitCode=0;TimedOut=$false;Error=$null}
 $bootstrap=[pscustomobject]@{passed=$true;native=[pscustomobject]@{Process=[pscustomobject]@{CleanupVerified=$true;ExitCode=0};Evidence=[pscustomobject]@{resumeCalls=1;resumeVerified=$true;actualLeaseAcknowledged=$true;nativeStartQpc=100;innerCleanupStartQpc=500;innerCleanupEndQpc=600}}}
 $gate=[pscustomobject]@{holdHost=$false;cdbExecuted=$false;debuggerAttached=$false;outerDeadlineQpc=1000;targetSignalObservedQpc=800;stages=[pscustomobject]@{'lease-ack'=200;'child-ready'=300;go=400;'leases-closed'=900}}
 switch($case){'missing-signal'{$gate.targetSignalObservedQpc=0};'signal-before-go'{$gate.targetSignalObservedQpc=350};'cleanup-reversed'{$bootstrap.native.Evidence.innerCleanupEndQpc=450};'cleanup-after-outer'{$bootstrap.native.Evidence.innerCleanupEndQpc=1001}}
 $accepted=$false;try{Assert-LeaseGateResult $outer $bootstrap $gate;$accepted=$true}catch{}
 $results+=@{case=$case;passed=($accepted -eq ($case -ceq 'valid'));accepted=$accepted}
}
$failed=@($results|Where-Object{-not $_.passed}).Count
Write-FixtureJson $OutputPath ([ordered]@{checks=$results.Count;failed=$failed;results=$results;nativeExecuted=$false;scope='actual result consumer against finite source-only records'})
Write-Output ('RESULT stage checks='+$results.Count+' failed='+$failed)
if(($ExpectRed -and $failed -eq 0)-or(-not $ExpectRed -and $failed -ne 0)){throw 'Unexpected stage consumer result'}
