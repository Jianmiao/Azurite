#requires -Version 5.1
param([Parameter(Mandatory)][string]$ControlPath,[Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ReviewedControlSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
Import-Module ($PSScriptRoot+'\FixtureRules.psm1') -Force -DisableNameChecking
Assert-FixtureHost
Assert-Fixture ((Get-FixtureHash $ControlPath) -ceq $ReviewedControlSha256) 'protected bootstrap control digest'
$c=Read-FixtureJson $ControlPath
Assert-Fixture ($c.fixtureOnly -and -not $c.productionTargetExecuted -and $c.protocol -ceq 'lease-control.v1' -and $c.scenario -ceq 'normal' -and $c.runId -cmatch '^[a-f0-9]{32}$') 'normal-only lease-control bootstrap'
foreach($name in @('RestrictedCliBootstrap.ps1','FixtureRules.psm1','AzuriteLifecycle.FixtureOnly.dll')){Assert-Fixture ((Get-FixtureHash ($PSScriptRoot+'\'+$name)) -ceq $c.toolHashes.$name) 'protected bootstrap tooling pin'}
Add-Type -Path ($PSScriptRoot+'\AzuriteLifecycle.FixtureOnly.dll')
$run=[Azurite.Restricted.LifecycleFixture]::Lab+'\runs\restricted-'+$c.runId
Assert-Fixture ($ControlPath -ceq ($run+'\tooling\control.json') -and $PSScriptRoot -ceq ($run+'\tooling')) 'fixed bootstrap layout'
$identity=[Azurite.Restricted.FullBootstrapIdentity]::Read($c.runId)
Assert-Fixture ($identity.identitySid -ceq $c.userSid -and $identity.token.logon_sid -ceq $c.logonSid -and -not $identity.isAdministrator) 'actual unrestricted bootstrap identity'
Assert-Fixture ((Get-FixtureHash ($run+'\request\arguments.json')) -ceq $c.argumentsSha256 -and (Get-FixtureHash ($run+'\request\fixture-input.txt')) -ceq $c.inputSha256) 'protected child input pins'
$job=[Azurite.Restricted.OwnedJob]::CreateAndJoinCurrent();$exit=1;$r=[ordered]@{fixtureOnly=$true;productionTargetExecuted=$false;runId=$c.runId;bootstrapPid=$PID;scenario='normal';passed=$false}
try{
 $job.AnnounceAndAwaitControllerFull($c.runId,5000)
 $psi=New-FixtureStart ([Azurite.Restricted.LifecycleFixture]::Target) ('-batchmode -nographics -disableaudio -logFile '+$run+'\output\unity.log') ([Azurite.Restricted.LifecycleFixture]::Lab+'\install')
 $psi.EnvironmentVariables['AZUREARCHIVE_CLI_DIRECTORY']=$run+'\request'
 $native=[Azurite.Restricted.LifecycleFixture]::RunNormal($psi,$job,$c.runId,$c.argumentsSha256,$c.probeSha256,$c.bootstrapSha256,$c.userSid,$c.logonSid);$r.native=$native
 Assert-Fixture ($native.Process.CleanupVerified -and $native.Process.ExitCode -eq 0 -and -not $native.Process.TimedOut -and [string]::IsNullOrEmpty($native.Process.Error)) 'normal retained-lease native outcome'
 [Console]::Out.Write($native.Process.Stdout);[Console]::Error.Write($native.Process.Stderr);$r.passed=$true;$exit=0
}catch{$r.error=$_.Exception.ToString()}
finally{try{Write-FixtureJson ($run+'\output\fixture-bootstrap-result.json') $r;[Console]::Out.Flush();[Console]::Error.Flush()}finally{$job.TerminateFull([uint32]$exit)}}
