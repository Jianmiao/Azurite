#requires -Version 5.1
param([Parameter(Mandatory)][ValidatePattern('^(red|green)(-[a-z0-9]+)?$')][string]$Stage,[switch]$ExpectRed)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1){throw 'Fresh x64 PS5.1 required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$root=$repo+'\artifacts\aa-cdb-native-control-preparation-20261113\release-query1';$output=$root+'\'+$Stage
if(-not(Test-Path -LiteralPath $root) -or (Test-Path -LiteralPath $output)){throw 'Fixed fresh release-query test stage required'}
[void][IO.Directory]::CreateDirectory($output)
Import-Module ($PSScriptRoot+'\SourceProcess.psm1') -Force -DisableNameChecking
$sources=@(($repo+'\tools\headless\RestrictedCliNative.cs'),($repo+'\tools\headless\RestrictedCliFullRestricted.cs'))
foreach($name in @('CdbTargetLease.cs','CdbLeaseNative.cs','CdbGateProtocol.cs','CdbOwnedWait.cs','FixtureSupport.cs','FullRestrictedStageFileSecurity.cs','CdbOwnedWait.Tests.cs','ReleaseQuery.Tests.cs')){$sources+=@($PSScriptRoot+'\'+$name)}
$guarded=@();$proof=@();foreach($source in $sources){$before=[IO.File]::ReadAllText($source);$pattern='(\[DllImport\s*\(\s*)"[^"]+"';$after=[regex]::Replace($before,$pattern,'$1"Azurite.SourceBuildOnly.Forbidden.Native.dll"');$path=$output+'\'+[IO.Path]::GetFileName($source);[IO.File]::WriteAllText($path,$after,[Text.UTF8Encoding]::new($false));$guarded+=$path;$proof+=@{source=$source;sha256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant();guardedSha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();importReplacements=([regex]::Matches($before,$pattern)).Count}}
$entry=$output+'\ReleaseQuery.Entry.cs';[IO.File]::WriteAllText($entry,'namespace Azurite.Restricted { public static class ReleaseQueryPureEntry { public static int Main(){return ReleaseQueryTests.Run();} } }',[Text.UTF8Encoding]::new($false));$guarded+=$entry
$csc='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe';if((Get-FileHash -LiteralPath $csc -Algorithm SHA256).Hash.ToLowerInvariant() -cne 'eca02e6b15cde93009a59a3d129d5a77fb5008f2e1cf62cf573b6737c747ecc3'){throw 'Reviewed Framework compiler pin drift'}
$exe=$output+'\ReleaseQuery.PureTests.exe'
$compile=Invoke-FixtureSourceProcess -File $csc -Arguments (@('/nologo','/target:exe','/main:Azurite.Restricted.ReleaseQueryPureEntry','/platform:x64','/warn:4','/warnaserror+','/r:System.Web.Extensions.dll','/r:System.Runtime.Serialization.dll','/r:System.Xml.dll',('/out:'+$exe))+@($guarded)) -Directory $output -Record ($output+'\compile-process.json')
[IO.File]::WriteAllText($output+'\build.log',($compile.stdout+$compile.stderr),[Text.UTF8Encoding]::new($false));if($compile.exitCode -ne 0){throw 'Real-source guarded release-query tests did not compile'}
$run=Invoke-FixtureSourceProcess -File $exe -Arguments @('source-only') -Directory $output -Record ($output+'\test-process.json')
[IO.File]::WriteAllText($output+'\result.log',($run.stdout+$run.stderr),[Text.UTF8Encoding]::new($false))
$record=[ordered]@{schema='task-a-release-query-pure.v1';sourceBuildOnly=$true;nativeExecuted=$false;normalDllLoaded=$false;stage=$Stage;expectedRed=[bool]$ExpectRed;actualExitCode=$run.exitCode;compilerPid=$compile.pid;testPid=$run.pid;files=$proof;stdout=$run.stdout;stderr=$run.stderr}
[IO.File]::WriteAllText($output+'\source-test.json',($record|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
if(($ExpectRed -and $run.exitCode -ne 1) -or (-not $ExpectRed -and $run.exitCode -ne 0)){throw 'Unexpected actual-source release-query result; preserve stage'}
[pscustomobject]$record|ConvertTo-Json -Depth 10
