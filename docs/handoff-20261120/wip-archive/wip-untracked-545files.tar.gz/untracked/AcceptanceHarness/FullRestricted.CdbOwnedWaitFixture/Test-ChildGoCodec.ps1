#requires -Version 5.1
param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Stage,[switch]$ExpectRed)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop'){throw 'Fresh x64 PS5.1 required'}
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$root=$repo+'\artifacts\aa-fr-native-lifecycle-fixture\build-cdb-owned-wait2-9974-cons1';$output=$root+'\'+$Stage
if(Test-Path $output){throw 'Preserve existing codec evidence'};[void][IO.Directory]::CreateDirectory($output)
foreach($name in @('ChildGoCodec.h','ChildGoCodec.Tests.c')){[IO.File]::Copy(($PSScriptRoot+'\'+$name),($output+'\'+$name),$false)}
$msvc='C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207';$kits='C:\Program Files (x86)\Windows Kits\10';$compiler=$msvc+'\bin\Hostx64\x64\cl.exe'
if((Get-FileHash $compiler).Hash.ToLowerInvariant() -cne '88c8344236a27a6e727e0a8edc49aaa2690bdc7a9464b9d18cc7abe70a9f1c0d'){throw 'Reviewed compiler pin drift'}
$includes=@(('/I'+$msvc+'\include'),('/I'+$kits+'\Include\10.0.26100.0\ucrt'));$libs=@(('/LIBPATH:'+$msvc+'\lib\x64'),('/LIBPATH:'+$kits+'\Lib\10.0.26100.0\ucrt\x64'),('/LIBPATH:'+$kits+'\Lib\10.0.26100.0\um\x64'))
$exe=$output+'\ChildGoCodec.Pure.exe'
& $compiler /nologo /TC /std:c11 /W4 /WX /MT /O2 @includes ('/Fo:'+$output+'\ChildGoCodec.Tests.obj') ('/Fe:'+$exe) ($output+'\ChildGoCodec.Tests.c') /link /MACHINE:X64 /SUBSYSTEM:CONSOLE @libs 2>&1|Tee-Object -FilePath ($output+'\build.log');if($LASTEXITCODE){throw 'Pure CRT codec compile failed'}
$process=[Diagnostics.Process]::new();$info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.WorkingDirectory=$output;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardInput=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true;$process.StartInfo=$info
$started=$false;$exited=$false;$hold=$false;$primary=$null;$stdout=$null;$stderr=$null;$outTask=$null;$errTask=$null;$code=$null;$priority=$null;$pidValue=0;$clock=[Diagnostics.Stopwatch]::StartNew()
try{
 if(-not $process.Start()){throw 'Pure codec start failed'};$started=$true;$pidValue=$process.Id
 $outTask=$process.StandardOutput.ReadToEndAsync();$errTask=$process.StandardError.ReadToEndAsync()
 $process.PriorityClass=[Diagnostics.ProcessPriorityClass]::BelowNormal;$priority=$process.PriorityClass.ToString();if($priority -cne 'BelowNormal'){throw 'Pure codec priority not confirmed'}
 $process.StandardInput.Write('G');$process.StandardInput.Close()
 if(-not $process.WaitForExit([Math]::Max(0,5000-[int]$clock.ElapsedMilliseconds))){throw 'Pure codec execution deadline'};$exited=$true;$code=$process.ExitCode
 if(-not $outTask.Wait([Math]::Max(0,10000-[int]$clock.ElapsedMilliseconds)) -or -not $errTask.Wait([Math]::Max(0,10000-[int]$clock.ElapsedMilliseconds))){throw 'Pure codec stream deadline'};$stdout=$outTask.Result;$stderr=$errTask.Result
 if($stdout.Length -gt 65536 -or $stderr.Length -gt 65536){throw 'Pure codec output bound'}
 if(($ExpectRed -and $code -ne 1)-or(-not $ExpectRed -and $code -ne 0)){throw 'Unexpected pure codec result'}
}catch{$primary=$_}
finally{
 try{
  if($started){try{$exited=$process.HasExited}catch{$exited=$false};if(-not $exited){try{$process.Kill()}catch{};try{$exited=$process.WaitForExit([Math]::Max(0,10000-[int]$clock.ElapsedMilliseconds)) -and $process.HasExited}catch{$exited=$false}}}
  $hold=$started -and -not $exited
  if(-not $hold){$process.Dispose()}
  if($stdout){[IO.File]::WriteAllText(($output+'\result.log'),$stdout,[Text.UTF8Encoding]::new($false))}
  $record=[ordered]@{sourceBuildOnly=$true;pureCodecExecuted=$started;lifecycleExecuted=$false;nativeAdapterExecuted=$false;noWindow=$info.CreateNoWindow;priority=$priority;pid=$pidValue;exited=$exited;holdHost=$hold;exitCode=$code;elapsedMs=$clock.ElapsedMilliseconds;inputHeaderSha256=(Get-FileHash ($output+'\ChildGoCodec.h')).Hash.ToLowerInvariant();testSha256=(Get-FileHash ($output+'\ChildGoCodec.Tests.c')).Hash.ToLowerInvariant();exeSha256=(Get-FileHash $exe).Hash.ToLowerInvariant();stdout=$stdout;stderr=$stderr;error=$(if($primary){$primary.Exception.Message}else{$null})}
  [IO.File]::WriteAllText(($output+'\runner.json'),($record|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
 }finally{if($hold){try{[Console]::Error.WriteLine('Owned pure codec process remains unresolved; retaining this original host.')}catch{};while($true){[Threading.Thread]::Sleep(30000)}}}
}
if($primary){throw $primary};Write-Output $stdout
