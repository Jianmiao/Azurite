using System;
using System.Security.AccessControl;
using System.Security.Principal;
namespace Azurite.Restricted {
 internal static class ControlAclTests {
  const string Owner="S-1-5-21-1-2-3-1001",Logon="S-1-5-5-10-20";
  // Anonymized captured raw/managed pair. SID roles, masks, flags and order
  // preserve the observed failure; neither expectation is built by the seam.
  const string CapturedRaw="O:S-1-5-21-1-2-3-1001D:P(A;;RC;;;OW)(A;;FA;;;S-1-5-21-1-2-3-1001)(A;;0x1200a9;;;S-1-5-5-10-20)(A;;0x1200a9;;;WD)";
  const string CapturedManaged="O:S-1-5-21-1-2-3-1001D:P(A;;0x1200a9;;;WD)(A;;RC;;;OW)(A;;0x1200a9;;;S-1-5-5-10-20)(A;;FA;;;S-1-5-21-1-2-3-1001)";
  static int count,failed;
  static void Case(string name,Action body){count++;try{body();Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+": "+e.GetType().Name+": "+e.Message);}}
  static byte[] Bytes(RawSecurityDescriptor d){var b=new byte[d.BinaryLength];d.GetBinaryForm(b,0);return b;}
  static byte[] Bytes(string s){return Bytes(new RawSecurityDescriptor(s));}
  static RawSecurityDescriptor Raw(){return new RawSecurityDescriptor(CapturedRaw);}
  static CommonAce Allow(string sid,int mask,AceFlags flags=AceFlags.None){return new CommonAce(flags,AceQualifier.AccessAllowed,mask,new SecurityIdentifier(sid),false,null);}
  static byte[] Changed(Action<RawSecurityDescriptor> edit){var d=Raw();edit(d);return Bytes(d);}
  static void Reject(byte[] actual,string expected=CapturedManaged){try{LeaseFiles.AssertControlDescriptor(actual,expected);}catch(InvalidOperationException){return;}throw new Exception("unsafe descriptor was accepted");}
  public static int Run(){
   Case("captured raw order accepted against real caller policy",()=>LeaseFiles.AssertControlDescriptor(Bytes(CapturedRaw),LeaseAcl.Directory(Owner,Logon)));
   Case("captured managed order accepted against real caller policy",()=>LeaseFiles.AssertControlDescriptor(Bytes(CapturedManaged),LeaseAcl.Directory(Owner,Logon)));
   Case("valid managed expected representation remains accepted",()=>LeaseFiles.AssertControlDescriptor(Bytes(CapturedRaw),CapturedManaged));
   Case("logon write-data expansion rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[2]=Allow(Logon,0x1200ab))));
   Case("Everyone full-control expansion rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[3]=Allow("S-1-1-0",0x1f01ff))));
   Case("OWNER RIGHTS removal rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl.RemoveAce(0))));
   Case("DACL protection removal rejected",()=>Reject(Changed(d=>d.SetFlags(d.ControlFlags&~ControlFlags.DiscretionaryAclProtected))));
   Case("inheritable ACE rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[3]=Allow("S-1-1-0",0x1200a9,AceFlags.ObjectInherit))));
   Case("inherited ACE rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[3]=Allow("S-1-1-0",0x1200a9,AceFlags.Inherited))));
   Case("different descriptor owner rejected",()=>Reject(Changed(d=>d.Owner=new SecurityIdentifier("S-1-5-21-1-2-3-1002"))));
   Case("different full-control user ACE rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[1]=Allow("S-1-5-21-1-2-3-1002",0x1f01ff))));
   Case("unknown extra ACE rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl.InsertAce(4,Allow("S-1-5-32-545",0x120089)))));
   Case("duplicate full-control ACE rejected before merge",()=>Reject(Changed(d=>d.DiscretionaryAcl.InsertAce(4,Allow(Owner,0x1f01ff)))));
   Case("split mergeable logon ACEs rejected before merge",()=>Reject(Changed(d=>{d.DiscretionaryAcl[2]=Allow(Logon,0x120089);d.DiscretionaryAcl.InsertAce(4,Allow(Logon,0x20));})));
   Case("extra zero-mask ACE rejected before deletion",()=>Reject(Changed(d=>d.DiscretionaryAcl.InsertAce(4,Allow("S-1-5-32-545",0)))));
   Case("inherit-only extra ACE rejected before deletion",()=>Reject(Changed(d=>d.DiscretionaryAcl.InsertAce(4,Allow("S-1-5-32-545",0x120089,AceFlags.InheritOnly)))));
   Case("audit extra ACE rejected before deletion",()=>Reject(Changed(d=>d.DiscretionaryAcl.InsertAce(4,new CommonAce(AceFlags.SuccessfulAccess,AceQualifier.SystemAudit,0x120089,new SecurityIdentifier(Logon),false,null)))));
   Case("deny ACE rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[2]=new CommonAce(AceFlags.None,AceQualifier.AccessDenied,0x1200a9,new SecurityIdentifier(Logon),false,null))));
   Case("callback ACE rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[2]=new CommonAce(AceFlags.None,AceQualifier.AccessAllowed,0x1200a9,new SecurityIdentifier(Logon),true,new byte[0]))));
   Case("object ACE rejected",()=>Reject(Changed(d=>{var acl=new RawAcl(GenericAcl.AclRevisionDS,4);for(int i=0;i<4;i++)acl.InsertAce(i,i==2?(GenericAce)new ObjectAce(AceFlags.None,AceQualifier.AccessAllowed,0x1200a9,new SecurityIdentifier(Logon),ObjectAceFlags.ObjectAceTypePresent,new Guid("11111111-1111-1111-1111-111111111111"),Guid.Empty,false,null):d.DiscretionaryAcl[i]);d.DiscretionaryAcl=acl;})));
   Case("duplicate role replacing Everyone rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[3]=Allow(Logon,0x1200a9))));
   Case("wrong OWNER RIGHTS mask rejected",()=>Reject(Changed(d=>d.DiscretionaryAcl[0]=Allow("S-1-3-4",0x60000))));
   Case("null DACL rejected",()=>Reject(Bytes(new RawSecurityDescriptor(ControlFlags.DiscretionaryAclPresent|ControlFlags.DiscretionaryAclProtected,new SecurityIdentifier(Owner),null,null,null))));
   Case("missing DACL rejected",()=>Reject(Bytes(new RawSecurityDescriptor(ControlFlags.None,new SecurityIdentifier(Owner),null,null,null))));
   Case("null owner rejected",()=>Reject(Changed(d=>d.Owner=null)));
   Case("bad expected policy cannot authorize same write expansion",()=>Reject(Changed(d=>d.DiscretionaryAcl[2]=Allow(Logon,0x1200ab)),CapturedManaged.Replace("0x1200a9;;;S-1-5-5-10-20","0x1200ab;;;S-1-5-5-10-20")));
   Console.WriteLine("ACL SOURCE CHECKS "+count+" FAILED "+failed+"; no native methods or normal DLLs invoked");return failed==0?0:1;
  }
 }
}
