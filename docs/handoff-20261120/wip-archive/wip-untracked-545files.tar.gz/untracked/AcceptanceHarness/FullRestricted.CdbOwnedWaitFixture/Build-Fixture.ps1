#requires -Version 5.1
param()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5){throw 'Build must run in fresh x64 PS5.1'}
Import-Module ($PSScriptRoot+'\SourceProcess.psm1') -Force -DisableNameChecking
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$base=$repo+'\artifacts\aa-fr-native-lifecycle-fixture';$build=$base+'\build-cdb-owned-wait2-9974-cons1';$lab=$base+'\lab-cdb-owned-wait2'
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save([string]$Path,[string]$Text){if(Test-Path -LiteralPath $Path){throw ('Refuse overwrite: '+$Path)};[IO.File]::WriteAllText($Path,$Text,[Text.UTF8Encoding]::new($false))}
function Json([string]$Path,$Value){Save $Path ($Value|ConvertTo-Json -Depth 40)}
function Build-Tool([string]$Name,[string]$File,[string[]]$Arguments,[string]$Log){$result=Invoke-FixtureSourceProcess -File $File -Arguments $Arguments -Directory $work -Record ($work+'\'+$Name+'-process.json') -BoundMs 60000;Save $Log ($result.stdout+$result.stderr);if($result.exitCode -ne 0){throw ('SOURCE tool failed: '+$Name)}}
if(Test-Path -LiteralPath $lab){throw 'Fixed lab name already used; new reviewed package name required'}
if(-not(Test-Path -LiteralPath $build)){[void][IO.Directory]::CreateDirectory($build);Save ($build+'\source-build-owner.txt') 'lease-gate-task-a-9974-cons1-20261114'}
if([IO.File]::ReadAllText(($build+'\source-build-owner.txt')) -cne 'lease-gate-task-a-9974-cons1-20261114' -or (Test-Path ($build+'\manifest.json'))){throw 'Existing package not this unfinished Task A reservation'}
$attempt=1;while(Test-Path ($build+'\compile'+$attempt)){$attempt++};$work=$build+'\compile'+$attempt
[void][IO.Directory]::CreateDirectory($work);[void][IO.Directory]::CreateDirectory(($work+'\source'));[void][IO.Directory]::CreateDirectory(($work+'\generated'))
$pins=[ordered]@{'RestrictedCliFullRestricted.cs'='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533';'RestrictedCliNative.cs'='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'}
foreach($name in $pins.Keys){if((Hash ($repo+'\tools\headless\'+$name)) -cne $pins[$name]){throw 'Accepted integrated production pin drift'}}
$map=$repo+'\artifacts\aa-cdb-trace-design-20261113\IMPLEMENTATION-MAP.md';if((Hash $map)-cne 'b3723e4cf5ccafa446c688d08294ee72e46291108b182d163431e9c1f99b14bf'){throw 'Implementation map drift'}
$review=$repo+'\.superpowers\sdd\azurite-authoring-20261108\full-creation-ownership-runner-cleanup-fix-review-20261113.md';if(-not(Test-Path $review)){throw 'Accepted source/pure independent review missing'}
$fixPins=[ordered]@{'.superpowers/sdd/azurite-authoring-20261108/cdb-lease-gate-lifetime-review-20261113.md'='9045c8de03c7080be86a4538688383ed0026d410616c20ea4aac39c5a0024cbf';'.superpowers/sdd/azurite-authoring-20261108/cdb-lease-gate-spec-review-20261113.md'='376c199519a2c8bfa94798ab3bf14956c902a6a42fa828a6119e53a43f9b65e0';'artifacts/aa-cdb-trace-design-20261113/powershell-hardlinks-readonly-20261113.json'='3d6f7a01f2c7bef1335396de6d96c21fc8faa20d70b0fbd5b792499517287ad6';'artifacts/aa-fr-native-lifecycle-fixture/build-cdb-owned-wait1/manifest.json'='de88dfa2d02da260202113e058e14167c0aac4d9f449f863a1f94c10fb0e6471'}
foreach($entry in $fixPins.Keys){if((Hash ($repo+'\'+$entry.Replace('/','\')))-cne $fixPins[$entry]){throw 'Reviewed fix/baseline evidence drift'}}
$original=[IO.File]::ReadAllText(($repo+'\tools\headless\RestrictedCliFullRestricted.cs')).Replace("`r`n","`n")
$transforms=@(@('Lab=@"F:\AzuriteLabs\Editor-20261108-normal"',('Lab=@"'+$lab+'"')),@('Executable=Lab+@"\install\AzureArchive.exe"','Executable=Lab+@"\install\AzuriteLifecycleProbe.exe"'),@('FullRestrictedContract.Require(process.Start(),"Bootstrap did not start");started=true;result.Pid=process.Id;','FullRestrictedContract.Require(process.Start(),"Bootstrap did not start");started=true;result.Pid=process.Id;CdbOwnedWait.CaptureStartedBootstrap(process,runId);'))
$generated=$original;foreach($t in $transforms){if(([regex]::Matches($generated,[regex]::Escape($t[0]))).Count -ne 1){throw 'Approved transform must match once'};$generated=$generated.Replace($t[0],$t[1])}
$reverse=$generated;for($i=$transforms.Count-1;$i -ge 0;$i--){$reverse=$reverse.Replace($transforms[$i][1],$transforms[$i][0])};if($reverse -cne $original){throw 'Unapproved source transformation'}
Save ($work+'\generated\RestrictedCliFullRestricted.cs') $generated
[IO.File]::Copy(($repo+'\tools\headless\RestrictedCliNative.cs'),($work+'\generated\RestrictedCliNative.cs'),$false)
Save ($work+'\generated\FixtureTarget.h') ('#define FIXTURE_LAB L"'+$lab.Replace('\','\\')+'"'+"`n")
foreach($file in Get-ChildItem -LiteralPath $PSScriptRoot -File){[IO.File]::Copy($file.FullName,($work+'\source\'+$file.Name),$false)}
$baseline=$repo+'\artifacts\aa-waitone-token-diagnostic-20261113\fixture-write-protection\source';$unchanged=@('ProtectionProbe.h','WaitManagedHook.h','FixturePolicy.h','WaitProbe.Managed.cs','WaitProbe.Managed.runtimeconfig.json','WaitNative.c');$copyPins=@()
foreach($name in $unchanged){if((Hash ($baseline+'\'+$name)) -cne (Hash ($work+'\source\'+$name))){throw ('Unchanged baseline copy drift: '+$name)};$copyPins+=@{name=$name;source=($baseline+'\'+$name);sha256=(Hash ($baseline+'\'+$name))}}
$helperSource=$repo+'\artifacts\aa-fr-transition-preparation\integration-20261110-01\helper-build1\FullRestrictedStageFileSecurity.cs';if((Hash $helperSource)-cne (Hash ($work+'\source\FullRestrictedStageFileSecurity.cs'))){throw 'Unchanged file evidence helper drift'}
$provenance=[ordered]@{instrumentedFixture=$true;productionByteIdenticalClaimed=$false;mapSha256=(Hash $map);integrationReview=@{path=$review;sha256=(Hash $review);nativeQualificationInherited=$false};productionSources=$pins;transforms=$transforms;reverseNormalizedByteEqual=$true;normalization='CRLF to LF only';generatedFullSha256=(Hash ($work+'\generated\RestrictedCliFullRestricted.cs'));sharedByteIdentical=$true;generatedSharedSha256=(Hash ($work+'\generated\RestrictedCliNative.cs'));postStartHooks=1;preCleanupHooks=0;unchangedCopies=$copyPins;unchangedFileEvidenceHelper=@{path=$helperSource;sha256=(Hash $helperSource);onlyReadCalledByRunner=$true};compilerSourceSet=@('generated/RestrictedCliNative.cs','generated/RestrictedCliFullRestricted.cs','source/CdbTargetLease.cs','source/CdbLeaseNative.cs','source/CdbGateProtocol.cs','source/CdbOwnedWait.cs','source/FixtureSupport.cs','source/FullRestrictedStageFileSecurity.cs')}
Json ($work+'\source-transform-whitelist.json') $provenance
Json ($work+'\fix1-review-pins.json') $fixPins
$toolBaseline=Get-Content -Raw ($repo+'\artifacts\aa-waitone-token-diagnostic-20261113\fixture-wait1\build\build-result.json')|ConvertFrom-Json
foreach($pin in @($toolBaseline.tools)+@($toolBaseline.runtimePins)){if((Hash $pin.path)-cne $pin.sha256){throw ('Established compiler/runtime pin drift: '+$pin.path)}}
$csc=$env:WINDIR+'\Microsoft.NET\Framework64\v4.0.30319\csc.exe';$managed=@($provenance.compilerSourceSet|ForEach-Object{$work+'\'+$_.Replace('/','\')})
Build-Tool 'framework' $csc (@('/nologo','/target:library','/platform:x64','/warn:4','/warnaserror+','/r:System.Web.Extensions.dll','/r:System.Runtime.Serialization.dll','/r:System.Xml.dll',('/out:'+$work+'\AzuriteLifecycle.FixtureOnly.dll'))+@($managed)) ($work+'\framework-build.log')
$msvc='C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207';$kits='C:\Program Files (x86)\Windows Kits\10';$cl=$msvc+'\bin\Hostx64\x64\cl.exe'
$includes=@(('/I'+$msvc+'\include'),('/I'+$kits+'\Include\10.0.26100.0\ucrt'),('/I'+$kits+'\Include\10.0.26100.0\shared'),('/I'+$kits+'\Include\10.0.26100.0\um'),('/I'+$work+'\generated'),('/I'+$work+'\source'))
$libraries=@('/MACHINE:X64',('/LIBPATH:'+$msvc+'\lib\x64'),('/LIBPATH:'+$kits+'\Lib\10.0.26100.0\ucrt\x64'),('/LIBPATH:'+$kits+'\Lib\10.0.26100.0\um\x64'))
Build-Tool 'wait-native' $cl (@('/nologo','/TC','/LD','/MT','/W4','/WX','/O2')+@($includes)+@(('/Fo:'+$work+'\WaitNative.obj'),('/Fe:'+$work+'\WaitNative.dll'),($work+'\source\WaitNative.c'),'/link')+@($libraries)+@('kernel32.lib','ole32.lib','advapi32.lib')) ($work+'\wait-native-build.log')
Build-Tool 'probe' $cl (@('/nologo','/TC','/std:c11','/MT','/W4','/WX','/O2','/GS','/guard:cf','/DUNICODE','/D_UNICODE')+@($includes)+@(('/Fo:'+$work+'\LifecycleProbe.obj'),('/Fe:'+$work+'\AzuriteLifecycleProbe.exe'),($work+'\source\LifecycleProbe.c'),'/link')+@($libraries)+@('/SUBSYSTEM:WINDOWS','/ENTRY:wmainCRTStartup','/DYNAMICBASE','/NXCOMPAT','/HIGHENTROPYVA','/guard:cf','kernel32.lib')) ($work+'\probe-build.log')
$runtime='C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36';$roslyn='C:\Program Files\dotnet\sdk\10.0.203\Roslyn\bincore\csc.dll';$dotnet='C:\Program Files\dotnet\dotnet.exe'
$arguments=@('/nologo','/nostdlib+','/target:library','/langversion:10','/platform:x64','/warn:4','/warnaserror+',('/out:"'+$work+'\WaitProbe.Managed.dll"'))
$arguments+=@(Get-ChildItem -LiteralPath $runtime -Filter 'System*.dll' -File|Where-Object Name -NotLike '*.Native.dll'|ForEach-Object{'/r:"'+$_.FullName+'"'});$arguments+=@(('/r:"'+$runtime+'\netstandard.dll"'),('/r:"'+$runtime+'\mscorlib.dll"'),('"'+$work+'\source\WaitProbe.Managed.cs"'))
Save ($work+'\managed.rsp') ($arguments -join "`r`n")
Build-Tool 'wait-managed' $dotnet @($roslyn,('@'+$work+'\managed.rsp')) ($work+'\wait-managed-build.log')
[IO.File]::Copy(($work+'\source\WaitProbe.Managed.runtimeconfig.json'),($work+'\WaitProbe.Managed.runtimeconfig.json'),$false)
$dump=$msvc+'\bin\Hostx64\x64\dumpbin.exe';foreach($name in @('AzuriteLifecycleProbe.exe','WaitNative.dll')){Build-Tool ('pe-'+$name) $dump @('/headers','/imports',($work+'\'+$name)) ($work+'\'+$name+'.pe.txt')}
$imports=Get-Content -Raw ($work+'\AzuriteLifecycleProbe.exe.pe.txt');if($imports -match '(?m)\s(?:CreateProcess\w*|RegOpen\w*|RegSet\w*|SendInput|SetThreadDesktop|SwitchDesktop|CreateWindow\w*)\s*$'){throw 'Unexpected probe import'}
if($imports -notmatch '8664 machine \(x64\)' -or $imports -notmatch 'Windows GUI'){throw 'Probe PE shape differs'}
Json ($work+'\build-result.json') ([ordered]@{sourceBuildOnly=$true;nativeExecuted=$false;cdbExecuted=$false;nativeLifecycleExecuted=$false;aaExecuted=$false;aclMutated=$false;registryAccessed=$false;labCreated=$false;built=$true;frameworkCsc=@{path=$csc;sha256=(Hash $csc)};establishedToolPins=$toolBaseline.tools;runtimePins=$toolBaseline.runtimePins;provenance=$provenance})
# Freeze only after every compiler and PE check succeeded. No normal assembly,
# probe, old pure runner, native fixture runner, CDB or AA is ever invoked here.
foreach($dir in @('source','generated')){if(Test-Path ($build+'\'+$dir)){throw 'Frozen source already exists'};Copy-Item -LiteralPath ($work+'\'+$dir) -Destination ($build+'\'+$dir) -Recurse}
foreach($name in @('AzuriteLifecycle.FixtureOnly.dll','AzuriteLifecycleProbe.exe','WaitNative.dll','WaitProbe.Managed.dll','WaitProbe.Managed.runtimeconfig.json','source-transform-whitelist.json','build-result.json')){[IO.File]::Copy(($work+'\'+$name),($build+'\'+$name),$false)}
[pscustomobject]@{built=$true;compileAttempt=$attempt;path=$build;sourceBuildOnly=$true;nativeExecuted=$false;freezePendingFinalPureAndManifest=$true}
