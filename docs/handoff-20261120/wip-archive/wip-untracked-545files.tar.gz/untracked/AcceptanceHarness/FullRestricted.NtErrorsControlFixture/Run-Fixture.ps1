#requires -Version 7.0
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('normal')][string]$Scenario,[switch]$Execute,[string]$ReviewedPackageSha256,[string]$NormalReceiptPath,[string]$NormalReceiptSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$base=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture';$build=Join-Path $base 'build-nt-errors-control'
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
$lab=Get-FixtureLab
Assert-Fixture ($lab -ceq (Join-Path $base 'lab-nt-errors-control')) 'fixed C workspace boundary'
$plan=[ordered]@{fixtureOnly=$true;productionTargetExecuted=$false;scenario=$Scenario;scenarioReady=($Scenario -ceq 'normal');bootstrapExitReady=$false;bootstrapExitReason='Requires reviewed new package and exact same-package actual normal final receipt path/hash';normalReceiptRequired=($Scenario -ceq 'bootstrap-exit');normalReceiptProvided=([bool]$NormalReceiptPath -and [bool]$NormalReceiptSha256);lab=$lab;target=($lab+'\install\AzuriteLifecycleProbe.exe');outerController='direct-x64-PowerShell-7';bootstrap='system-x64-Windows-PowerShell-5.1';outerBootstrapBudgetMs=30000;innerNativeBudgetMs=10000;cleanupGraceMs=5000;childLifetimeMs=12000;globalMutex='Global\AzuriteRestrictedCli-AA';actions='new C fixture objects only; no ancestor ACL, no target application';willExecute=[bool]$Execute}
$plan['evidenceProtocol']='cleanup-ordering.v1';$plan['externalLiveDescendantIntervalClaimed']=$false
if(-not $Execute){[pscustomobject]$plan;return}
if($Scenario -ceq 'normal'){Assert-Fixture ([string]::IsNullOrEmpty($NormalReceiptPath) -and [string]::IsNullOrEmpty($NormalReceiptSha256)) 'normal execution does not accept a prerequisite receipt'}
Assert-Fixture ([Environment]::Is64BitProcess -and $PSVersionTable.PSEdition -ceq 'Core' -and $PSVersionTable.PSVersion.Major -ge 7) 'fixture outer controller requires direct x64 PS7'
Assert-Fixture ($ReviewedPackageSha256 -cmatch '^[a-f0-9]{64}$' -and (Get-FixtureHash (Join-Path $build 'manifest.json')) -ceq $ReviewedPackageSha256) 'separately reviewed package digest'
$manifest=Read-FixtureJson (Join-Path $build 'manifest.json')
Assert-Fixture ($manifest.generatedNativeCreateRestrictedTokenFlags -eq 1 -and $manifest.productionFullRestrictionQualificationClaimed -is [bool] -and -not $manifest.productionFullRestrictionQualificationClaimed) 'fixed original Full token semantics must be explicit'
Assert-Fixture ($manifest.diagnosticProtocol -ceq 'fixed-nt-errors.v1' -and $manifest.runtimeVersion -ceq '6.0.36') 'fixed wait diagnostic package required'
Assert-Fixture ($manifest.diagnosticMode -ceq 'control') 'immutable fixed NT observer condition binding'
Assert-FixtureWaitRuntimePins $manifest.runtimePins;Assert-FixtureObserverSystemPins $manifest.observerSystemPins
Assert-Fixture ($manifest.evidenceProtocol -ceq 'cleanup-ordering.v1' -and $manifest.externalLiveDescendantIntervalClaimed -is [bool] -and -not $manifest.externalLiveDescendantIntervalClaimed) 'explicit cleanup-ordering package scope'
Assert-Fixture ((Get-FixtureHash (Join-Path $repo 'tools\headless\CurrentAccountCli.psm1')) -ceq $manifest.controllerDependencies.'CurrentAccountCli.psm1') 'accepted current-account source changed'
$normalReceipt=$null;$normalBinding=$null
if($Scenario -ceq 'bootstrap-exit'){
 Assert-Fixture (-not [string]::IsNullOrWhiteSpace($NormalReceiptPath) -and $NormalReceiptSha256 -cmatch '^[a-f0-9]{64}$') 'same-package normal final receipt path and digest required'
 $normalBinding=Read-FixtureNormalReceipt $NormalReceiptPath $NormalReceiptSha256 $ReviewedPackageSha256 $manifest.productionSources ($base+'\evidence')
 $normalReceipt=$normalBinding.receipt
 Assert-Fixture ($normalReceipt.evidenceProtocol -ceq 'cleanup-ordering.v1' -and $normalReceipt.externalLiveDescendantIntervalClaimed -is [bool] -and -not $normalReceipt.externalLiveDescendantIntervalClaimed) 'same cleanup-ordering normal prerequisite'
 Assert-FixtureCleanupOrdering $normalReceipt.outer.FullDesktopMonitorEvidence.outerDrain $normalReceipt.outer $normalReceipt.runId
}
foreach($f in $manifest.files){$p=Join-Path $build $f.path;Assert-Fixture ((Get-FixtureHash $p) -ceq $f.sha256 -and (Get-Item $p).Length -eq $f.bytes) 'frozen package member mismatch'}
foreach($name in @('Run-Fixture.ps1','FixtureRules.psm1','FixtureBootstrap.ps1','FixtureAcl.psm1')){Assert-Fixture ((Get-FixtureHash (Join-Path $PSScriptRoot $name)) -ceq (Get-FixtureHash (Join-Path $build ('source\'+$name)))) 'executed fixture source differs from package'}
Assert-Fixture ((Get-FixtureHash (Join-Path $build 'FullRestrictedStageFileSecurity.dll')) -ceq 'eef4c21387daef216ef7bcc7870b331e123d69e7be852498adcd07f253ef4c8f') 'reviewed same-handle descriptor helper'
Import-Module (Join-Path $PSScriptRoot 'FixtureAcl.psm1') -Force -DisableNameChecking
Add-Type -Path (Join-Path $build 'FullRestrictedStageFileSecurity.dll')
$runId=[guid]::NewGuid().ToString('N');$run=$lab+'\runs\restricted-'+$runId
$evidence=Join-Path $base ('evidence\'+$runId);[void][IO.Directory]::CreateDirectory($evidence)
$r=[ordered]@{schema=1;fixtureOnly=$true;productionTargetExecuted=$false;aaAdmission=$false;runId=$runId;scenario=$Scenario;packageSha256=$ReviewedPackageSha256;passed=$false;run=$run;nativeSourceLineage=$manifest.productionSources;controllerDependencies=$manifest.controllerDependencies;outerHost=$PSVersionTable.PSVersion.ToString();outerFramework=[Runtime.InteropServices.RuntimeInformation]::FrameworkDescription;outerNativeInvocation='direct in PS7 controller';error=$null;cleanupVerified=$false}
$r['evidenceProtocol']='cleanup-ordering.v1';$r['externalLiveDescendantIntervalClaimed']=$false
$r['diagnosticOnly']=$true;$r['applicationAccepted']=$false;$r['diagnosticProtocol']='fixed-nt-errors.v1'
$r['generatedNativeCreateRestrictedTokenFlags']=$manifest.generatedNativeCreateRestrictedTokenFlags;$r['productionFullRestrictionQualificationClaimed']=$false
$r['outerBootstrapBudgetMs']=30000;$r['innerNativeBudgetMs']=10000;$r['childLifetimeMs']=12000;$r['bootstrapHandshakeMs']=5000;$r['cleanupGraceMs']=5000
$mutex=[Threading.Mutex]::new($false,'Global\AzuriteRestrictedCli-AA');$held=$false;$pending=$lab+'\pending.json';$before=[Collections.Generic.List[object]]::new();$oldPriority=[Diagnostics.Process]::GetCurrentProcess().PriorityClass
$script:retainedMutexes=[Collections.Generic.List[object]]::new();$script:privateFile=$null
function Assert-NewOwnedPath([string]$Path){Assert-Fixture ($Path -ceq $lab -or $Path.StartsWith($lab+'\',[StringComparison]::Ordinal)) 'mutation must be inside exact fixed lab'}
function Protect([string]$Path,[string]$Sddl){
 Assert-NewOwnedPath $Path
 $writeRecord=Get-Command Write-FixtureJson
 $backend={param($action,$a)
  switch($action){
   Observe {return [Azurite.Stage.FileSecurity]::Read($a.path,$false)}
   PreserveBefore {$before.Add([ordered]@{path=$a.path;identity=$a.before.identity;sddl=$a.before.sddl;rawDescriptor=$a.before.rawDescriptor;expectedSddl=$a.expectedSddl;wasCreatedByThisFixture=$true});& $writeRecord (Join-Path $evidence ('acl-before-'+$before.Count.ToString('D3')+'.json')) $before[($before.Count-1)];return}
   SetDescriptor {[Azurite.Stage.FileSecurity]::SetDescriptor($a.path,$a.identity,$a.beforeSddl,$a.expectedSddl);return}
   default {throw 'Unknown fixture descriptor operation'}
  }
 }.GetNewClosure()
 $null=Invoke-FixtureDescriptorChange $Path $Sddl $true $backend
}
function NewDir([string]$Path,[string]$Sddl){Assert-NewOwnedPath $Path;Assert-Fixture (-not(Test-Path -LiteralPath $Path)) 'fresh fixture directory required';[void][IO.Directory]::CreateDirectory($Path);Protect $Path $Sddl}
function NewFile([string]$Path,[byte[]]$Bytes,[string]$Sddl){Assert-NewOwnedPath $Path;$s=[IO.FileStream]::new($Path,'CreateNew','Write','Read');try{$s.Write($Bytes,0,$Bytes.Length);$s.Flush($true)}finally{$s.Dispose()};Protect $Path $Sddl}
function AssertExistingAcl([string]$Path,[string]$Sddl){
 Assert-NewOwnedPath $Path;$item=Get-Item -LiteralPath $Path -Force;Assert-Fixture (-not($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'owned fixture reuse must not be reparse'
 $actual=[Azurite.Stage.FileSecurity]::Read($Path,$false);$expected=New-FixtureExpectedDescriptor $Sddl $actual.sddl
 Assert-Fixture ($actual.sddl -ceq $expected) 'owned fixture reuse requires original exact descriptor, no mutation/adoption'
}
try{
 try{$held=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$held=$true};Assert-Fixture $held 'one-test mutex must be held'
 Assert-Fixture (@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'" -ErrorAction Stop).Count -eq 0) 'fresh actual AA/probe0'
 Assert-Fixture (-not(Test-Path -LiteralPath $pending)) 'uncertain prior fixture blocks retry'
 $cursor=$base;while($cursor){$item=Get-Item -LiteralPath $cursor -Force;Assert-Fixture ($item.PSIsContainer -and -not($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'existing C ancestor must be nonreparse';$cursor=Split-Path -Parent $cursor}
 [Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
 Add-Type -Path (Join-Path $build 'AzuriteLifecycle.FixtureOnly.dll')
 Assert-Fixture ([Azurite.Restricted.LifecycleFixture]::Lab -ceq $lab) 'compiled fixture constant'
 $identity=[Azurite.Restricted.FullBootstrapIdentity]::Read($runId);$token=$identity['token'];$sid=$identity['identitySid'];$logon=$token['logon_sid']
 Assert-Fixture (-not $identity['isAdministrator'] -and $token['is_restricted'] -eq $false -and $token['users_enabled'] -eq $true -and @($identity['unexpectedPrivileges']).Count -eq 0) 'current unelevated original subject'
 $privateDir='O:'+ $sid+'D:P(A;OICI;FA;;;'+$sid+')(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)'
 $privateFile='O:'+ $sid+'D:P(A;;FA;;;'+$sid+')(A;;FA;;;SY)(A;;FA;;;BA)'
 $traverse=$privateDir+'(A;;0x1200A9;;;'+$logon+')';$readFile=$privateFile+'(A;;0x120089;;;'+$logon+')';$readExe=$privateFile+'(A;;0x1200A9;;;'+$logon+')'
 $requestAcl=$privateDir+'(A;;0x1200AB;;;'+$logon+')(A;OIIO;0x13019F;;;'+$logon+')';$mutable=$privateFile+'(A;;0x12019F;;;'+$logon+')'
 $protectedPath=$lab+'\install\protected';$canaryPath=$protectedPath+'\proof.bin';$canaryAcl='O:'+$sid+'D:P(A;;FA;;;'+$sid+')';$canaryBytes=[Text.Encoding]::ASCII.GetBytes(('AZURITE_WRITE_RESTRICTION_CANARY_V1'+[char]10));$canaryHash=[Security.Cryptography.SHA256]::Create();try{$expectedCanaryHash=([BitConverter]::ToString($canaryHash.ComputeHash($canaryBytes))).Replace('-','').ToLowerInvariant()}finally{$canaryHash.Dispose()}
 if(-not(Test-Path -LiteralPath $lab)){
  NewDir $lab $traverse;NewDir ($lab+'\install') $traverse;NewDir ($lab+'\runs') $traverse
  NewFile ($lab+'\install\AzuriteLifecycleProbe.exe') ([IO.File]::ReadAllBytes((Join-Path $build 'AzuriteLifecycleProbe.exe'))) $readExe
  foreach($dependency in @('WaitNative.dll','WaitProbe.Managed.dll','WaitProbe.Managed.runtimeconfig.json')){NewFile ($lab+'\install\'+$dependency) ([IO.File]::ReadAllBytes((Join-Path $build $dependency))) $(if($dependency.EndsWith('.dll')){$readExe}else{$readFile})}
  NewDir $protectedPath $canaryAcl;NewFile $canaryPath $canaryBytes $canaryAcl
  Write-FixtureJson ($lab+'\fixture.marker.json') ([ordered]@{fixtureOnly=$true;userSid=$sid;logonSid=$logon;packageSha256=$ReviewedPackageSha256});Protect ($lab+'\fixture.marker.json') $privateFile
 }else{
  $marker=Read-FixtureJson ($lab+'\fixture.marker.json');Assert-Fixture ($marker.fixtureOnly -eq $true -and $marker.userSid -ceq $sid -and $marker.logonSid -ceq $logon -and $marker.packageSha256 -ceq $ReviewedPackageSha256) 'prior exact fixture lab cannot be adopted with drift'
  foreach($p in @($lab,($lab+'\install'),($lab+'\runs'))){AssertExistingAcl $p $traverse}
  AssertExistingAcl ($lab+'\install\AzuriteLifecycleProbe.exe') $readExe;AssertExistingAcl ($lab+'\fixture.marker.json') $privateFile
  foreach($dependency in @('WaitNative.dll','WaitProbe.Managed.dll','WaitProbe.Managed.runtimeconfig.json')){AssertExistingAcl ($lab+'\install\'+$dependency) $(if($dependency.EndsWith('.dll')){$readExe}else{$readFile})}
  AssertExistingAcl $protectedPath $canaryAcl;AssertExistingAcl $canaryPath $canaryAcl
 }
 Assert-Fixture ((Get-FixtureHash ($lab+'\install\AzuriteLifecycleProbe.exe')) -ceq (Get-FixtureHash (Join-Path $build 'AzuriteLifecycleProbe.exe'))) 'harmless executable fixed pin'
 foreach($dependency in @('WaitNative.dll','WaitProbe.Managed.dll','WaitProbe.Managed.runtimeconfig.json')){Assert-Fixture ((Get-FixtureHash ($lab+'\install\'+$dependency)) -ceq (Get-FixtureHash (Join-Path $build $dependency))) 'fixed wait dependency pin before launch'}
 $canaryBefore=[pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read($canaryPath,$false);attributes=[int](Get-Item -LiteralPath $canaryPath -Force).Attributes;captureHandleRetained=$false}
 Assert-Fixture ($canaryBefore.object.sha256 -ceq $expectedCanaryHash -and $canaryBefore.object.bytes -eq $canaryBytes.Length -and $canaryBefore.attributes -in @(32,128) -and -not $canaryBefore.object.directory -and -not $canaryBefore.object.reparse -and $canaryBefore.object.links -eq 1) 'canary must be fixed normal/archive single-link non-reparse bytes without ReadOnly'
 Write-FixtureJson (Join-Path $evidence 'canary-before.json') $canaryBefore
 $directoryBefore=[pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read($protectedPath,$false);attributes=[int](Get-Item -LiteralPath $protectedPath -Force).Attributes;children=@(Get-ChildItem -LiteralPath $protectedPath -Force|Select-Object -ExpandProperty Name|Sort-Object);captureHandleRetained=$false}
 $anchorsBefore=@($lab,($lab+'\install'))|ForEach-Object{[Azurite.Stage.FileSecurity]::Read($_,$false)}
 Assert-Fixture ($directoryBefore.attributes -eq 16 -and $directoryBefore.children.Count -eq 1 -and $directoryBefore.children[0] -ceq 'proof.bin') 'protected directory must initially contain only the fixed file'
 Write-FixtureJson (Join-Path $evidence 'directory-before.json') $directoryBefore;Write-FixtureJson (Join-Path $evidence 'anchors-before.json') $anchorsBefore
 Write-FixtureJson $pending ([ordered]@{fixtureOnly=$true;runId=$runId;scenario=$Scenario;state='fixture-pending'});Protect $pending $privateFile
 NewDir $run $traverse;foreach($name in @('request','output','workspace','tooling')){NewDir ($run+'\'+$name) $(if($name -ceq 'tooling'){$privateDir}elseif($name -ceq 'request'){$requestAcl}else{$traverse})}
 foreach($pair in @(@('FixtureBootstrap.ps1','RestrictedCliBootstrap.ps1'),@('FixtureRules.psm1','FixtureRules.psm1'))){NewFile ($run+'\tooling\'+$pair[1]) ([IO.File]::ReadAllBytes((Join-Path $build ('source\'+$pair[0])))) $privateFile}
 NewFile ($run+'\tooling\AzuriteLifecycle.FixtureOnly.dll') ([IO.File]::ReadAllBytes((Join-Path $build 'AzuriteLifecycle.FixtureOnly.dll'))) $privateFile
 $fixtureArgs=[ordered]@{argv=@('capabilities');cwd=$run+'\workspace'};$input='runId='+$runId+[char]10+'scenario='+$Scenario+[char]10+'userSid='+$sid+[char]10+'logonSid='+$logon+[char]10+'session='+$token['session_id']+[char]10+'integrityRid='+$token['integrity_rid']+[char]10+'mandatoryPolicy='+$token['mandatory_policy']+[char]10
 NewFile ($run+'\request\arguments.json') ([Text.UTF8Encoding]::new($false).GetBytes(($fixtureArgs|ConvertTo-Json -Compress))) $readFile
 NewFile ($run+'\request\fixture-input.txt') ([Text.UTF8Encoding]::new($false).GetBytes($input)) $readFile
 NewFile ($run+'\output\unity.log') ([byte[]]@()) $mutable
 $hashes=[ordered]@{};foreach($name in @('RestrictedCliBootstrap.ps1','FixtureRules.psm1','AzuriteLifecycle.FixtureOnly.dll')){$hashes[$name]=Get-FixtureHash ($run+'\tooling\'+$name)}
 $control=[ordered]@{fixtureOnly=$true;productionTargetExecuted=$false;runId=$runId;scenario=$Scenario;userSid=$sid;logonSid=$logon;session=$token['session_id'];integrityRid=$token['integrity_rid'];mandatoryPolicy=$token['mandatory_policy'];argumentsSha256=(Get-FixtureHash ($run+'\request\arguments.json'));inputSha256=(Get-FixtureHash ($run+'\request\fixture-input.txt'));toolHashes=$hashes;normalReceiptBase64=$(if($normalBinding){$normalBinding.bytesBase64}else{$null});normalReceiptPath=$(if($normalBinding){$normalBinding.path}else{$null});normalReceiptSha256=$NormalReceiptSha256;packageSha256=$ReviewedPackageSha256;productionSources=$manifest.productionSources}
 $control['evidenceProtocol']='cleanup-ordering.v1';$control['externalLiveDescendantIntervalClaimed']=$false
 Write-FixtureJson ($run+'\tooling\control.json') $control;Protect ($run+'\tooling\control.json') $privateFile
 Write-FixtureJson (Join-Path $evidence 'created-object-before-acls.json') $before.ToArray()
 $hash=Get-FixtureHash ($run+'\tooling\control.json');$shell=Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe'
 $psi=New-FixtureStart $shell ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+$run+'\tooling\RestrictedCliBootstrap.ps1 -ControlPath '+$run+'\tooling\control.json -ReviewedControlSha256 '+$hash) $run
 # Let the Framework bootstrap discover its native Desktop module directory;
 # do not inherit PS7's Core-first PSModulePath. No global environment change.
 $psi.EnvironmentVariables.Remove('PSModulePath')
 Assert-Fixture (@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'" -ErrorAction Stop).Count -eq 0) 'final fresh AA/probe0'
 if($Scenario -ceq 'bootstrap-exit'){Assert-FixtureNormalReceipt $normalReceipt $ReviewedPackageSha256 $manifest.productionSources}
 Assert-FixtureWaitRuntimePins $manifest.runtimePins;Assert-FixtureObserverSystemPins $manifest.observerSystemPins
 Assert-Fixture (-not(Test-Path -LiteralPath ($run+'\request\protection-result.json'))) 'positive-control output must be absent before this child'
 $outer=[Azurite.Restricted.ProcessPump]::RunBootstrapFullRestricted($psi,30000,$runId,$hash,262144,@($run+'\request',$run+'\output'),4194304)
 foreach($leaf in @('nt-observer-startup.json','nt-observer-result.json')){$p=$run+'\request\'+$leaf;if(Test-Path -LiteralPath $p){$r[$leaf]=Read-FixtureJson $p 32768}}
 $r.outer=$outer;$r.cleanupVerified=$outer.CleanupVerified;Write-FixtureJson (Join-Path $evidence 'outer.json') $outer
 Assert-FixtureOuter $outer $Scenario
 Assert-FixtureMonitorEvidence $outer.FullDesktopMonitorEvidence $runId
 Assert-FixtureCleanupOrdering $outer.FullDesktopMonitorEvidence.outerDrain $outer $runId
 $entry=Read-FixtureJson ($run+'\request\entry.json') 32768;Assert-FixtureChild $entry ([pscustomobject]$control);$r.child=$entry
 Assert-Fixture ((Get-FixtureHash ($run+'\request\arguments.json')) -ceq $control.argumentsSha256 -and (Get-FixtureHash ($run+'\request\fixture-input.txt')) -ceq $control.inputSha256) 'protected input preservation'
 if($Scenario -ceq 'normal'){
  $b=Read-FixtureJson ($run+'\output\fixture-bootstrap-result.json')
  Assert-Fixture ($b.fixtureOnly -and $b.passed -and $b.bootstrapPid -eq $outer.Pid -and $b.native.Process.Pid -eq $entry.pid -and $b.native.StreamsComplete -and $b.native.NativeHandlesClosed -and $b.native.Evidence.resumeCalls -eq 1 -and $b.native.Evidence.resumeVerified) 'real normal public spawn outcome'
  Assert-FixtureNativeEvidence $b.native.Evidence $entry;Assert-FixtureCaptured $b.native.Process.Stdout $b.native.Process.Stderr $runId;$r.native=$b.native
  Assert-FixtureMonitorEvidence $b.native.Evidence.fullDesktopMonitor $runId
  Assert-FixtureMonitorEvidence $b.native.Process.FullDesktopMonitorEvidence $runId
  Assert-Fixture (($b.native.Evidence.fullDesktopMonitor|ConvertTo-Json -Depth 20 -Compress) -ceq ($b.native.Process.FullDesktopMonitorEvidence|ConvertTo-Json -Depth 20 -Compress)) 'same inner monitor evidence serialized consistently'
  $r.monitorQualification=[ordered]@{outer=$outer.FullDesktopMonitorEvidence;inner=$b.native.Evidence.fullDesktopMonitor;scope='actual normal fixture full-only pinned-empty observation';productionTargetExecuted=$false}
  $probePath=$run+'\request\wait-probe.json'
  $diagnostic=Assert-FixtureWaitProbe (Read-FixtureJson ($run+'\request\wait-host-entry.json') 32768) (Read-FixtureJson ($run+'\request\wait-host-result.json') 32768) (Read-FixtureJson $probePath 32768) $runId $entry.pid $b.native.Evidence.threadId (Get-Item -LiteralPath $probePath).Length
  $r.waitProbe=$diagnostic
  $r.ntObserver=Assert-FixtureNtObserver (Read-FixtureJson ($run+'\request\nt-observer-startup.json') 32768) (Read-FixtureJson ($run+'\request\nt-observer-result.json') 32768) 'control' $runId $entry.pid $b.native.Evidence.threadId
  Assert-Fixture ($r.ntObserver.completed -and $r.ntObserver.coverageCompleteForSelectedWindow) 'fixed observer window requires complete bounded records'
  $canaryAfter=[pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read($canaryPath,$false);attributes=[int](Get-Item -LiteralPath $canaryPath -Force).Attributes;captureHandleRetained=$false}
  Write-FixtureJson (Join-Path $evidence 'canary-after.json') $canaryAfter
  $directoryAfter=[pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read($protectedPath,$false);attributes=[int](Get-Item -LiteralPath $protectedPath -Force).Attributes;children=@(Get-ChildItem -LiteralPath $protectedPath -Force|Select-Object -ExpandProperty Name|Sort-Object);captureHandleRetained=$false}
  $anchorsAfter=@($lab,($lab+'\install'))|ForEach-Object{[Azurite.Stage.FileSecurity]::Read($_,$false)}
  Write-FixtureJson (Join-Path $evidence 'directory-after.json') $directoryAfter;Write-FixtureJson (Join-Path $evidence 'anchors-after.json') $anchorsAfter
  $positive=[pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read(($run+'\request\protection-result.json'),$true);absentBeforeLaunch=$true;controllerCreatedResult=$false;captureHandleRetained=$false}
  $protectionRecord=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($positive.object.content))|ConvertFrom-Json
  $r.writeProtection=Assert-FixtureProtection $protectionRecord $canaryBefore $canaryAfter $directoryBefore $directoryAfter $anchorsBefore $anchorsAfter $positive $runId $entry.pid $b.native.Evidence.threadId $sid $logon $expectedCanaryHash $canaryBytes.Length
 }else{
  $pre=Read-FixtureJson ($run+'\output\pre-resume.json');$resumed=Read-FixtureJson ($run+'\output\resume.json');$last=Read-FixtureJson ($run+'\output\before-self-exit.json')
  Assert-Fixture ($pre.bootstrapPid -eq $outer.Pid -and $pre.childPid -eq $entry.pid -and $resumed.previousCount -eq 1 -and $last.childEntryObserved -and $last.selfExitCode -eq 73) 'actual stage ordering/self-exit'
  Assert-FixtureNativeEvidence $pre.nativeEvidence $entry;Assert-FixtureCaptured $last.stdout $last.stderr $runId
  $normalProof=Read-FixtureJson ($run+'\output\normal-prerequisite.json')
  Assert-Fixture ($normalProof.runId -ceq $runId -and $normalProof.normalRunId -ceq $normalReceipt.runId -and $normalProof.normalReceiptSha256 -ceq $normalBinding.sha256 -and $normalProof.normalPackageSha256 -ceq $ReviewedPackageSha256 -and $normalProof.currentPackageSha256 -ceq $ReviewedPackageSha256) 'actual bootstrap prerequisite digest and same-package binding'
  $r.preResume=$pre;$r.beforeSelfExit=$last;$r.normalPrerequisite=[ordered]@{path=$normalBinding.path;sha256=$normalBinding.sha256;runId=$normalReceipt.runId;packageSha256=$normalReceipt.packageSha256}
 }
 $wanted=@('arguments.json','fixture-input.txt','entry-start.json','entry.json');if($Scenario -ceq 'normal'){$wanted+=@('normal-complete.json','wait-host-entry.json','wait-host-result.json','wait-probe.json','protection-result.json','nt-observer-startup.json','nt-observer-result.json')}
 $actual=@(Get-ChildItem -LiteralPath ($run+'\request') -Force);Assert-Fixture ($actual.Count -eq $wanted.Count -and @($actual|Where-Object{$_.PSIsContainer -or $_.Length -gt 32768 -or $_.Name -cnotin $wanted}).Count -eq 0) 'bounded exact fixture request inventory'
 $outputs=if($Scenario -ceq 'normal'){@('unity.log','fixture-bootstrap-result.json')}else{@('unity.log','normal-prerequisite.json','pre-resume.json','resume.json','before-self-exit.json')}
 foreach($inventory in @(@('output',$outputs),@('tooling',@('RestrictedCliBootstrap.ps1','FixtureRules.psm1','AzuriteLifecycle.FixtureOnly.dll','control.json')),@('workspace',@()))){
  $items=@(Get-ChildItem -LiteralPath ($run+'\'+$inventory[0]) -Force);$expected=@($inventory[1])
  Assert-Fixture ($items.Count -eq $expected.Count -and @($items|Where-Object{$_.PSIsContainer -or $_.Length -gt 1048576 -or $_.Name -cnotin $expected -or ($_.Attributes -band [IO.FileAttributes]::ReparsePoint)}).Count -eq 0) 'finite final fixture inventory'
 }
 Assert-Fixture ((Get-FixtureHash ($lab+'\install\AzuriteLifecycleProbe.exe')) -ceq (Get-FixtureHash (Join-Path $build 'AzuriteLifecycleProbe.exe'))) 'harmless executable preserved after drain'
 foreach($dependency in @('WaitNative.dll','WaitProbe.Managed.dll','WaitProbe.Managed.runtimeconfig.json')){Assert-Fixture ((Get-FixtureHash ($lab+'\install\'+$dependency)) -ceq (Get-FixtureHash (Join-Path $build $dependency))) 'fixed wait dependency preserved after drain'}
 Assert-FixtureWaitRuntimePins $manifest.runtimePins;Assert-FixtureObserverSystemPins $manifest.observerSystemPins
 $after=[Azurite.Restricted.FullBootstrapIdentity]::Read($runId);Assert-Fixture (($after['token']|ConvertTo-Json -Depth 20 -Compress) -ceq ($token|ConvertTo-Json -Depth 20 -Compress)) 'original controller token unchanged'
 $r.passed=$true;Write-FixtureJson (Join-Path $evidence 'result-before-release.json') $r
 $pendingNow=Read-FixtureJson $pending;Assert-Fixture ($pendingNow.runId -ceq $runId -and $outer.CleanupVerified) 'matching pending cleanup';Remove-Item -LiteralPath $pending
}catch{$r.error=$_.Exception.ToString();$r.passed=$false}
finally{
 try{
  if($held){try{$mutex.ReleaseMutex();$held=$false}catch{$r.passed=$false;$r.error+=' Mutex release: '+$_.Exception.ToString();$script:retainedMutexes.Add($mutex);if(-not(Test-Path -LiteralPath $pending) -and (Test-Path -LiteralPath $lab)){try{Write-FixtureJson $pending ([ordered]@{fixtureOnly=$true;runId=$runId;scenario=$Scenario;state='fixture-mutex-release-failed'});if($privateFile){Protect $pending $privateFile}}catch{$r.error+=' Pending CreateNew compensation: '+$_.Exception.ToString()}}}}
  if(-not $held){try{$mutex.Dispose()}catch{$r.passed=$false;$r.error+=' Mutex disposal after release: '+$_.Exception.ToString();$script:retainedMutexes.Add($mutex)}}
 }catch{$r.passed=$false;$r.error+=' Mutex finalization: '+$_.Exception.ToString()}
 try{[Diagnostics.Process]::GetCurrentProcess().PriorityClass=$oldPriority}catch{$r.passed=$false;$r.error+=' Controller priority restoration: '+$_.Exception.Message}
 Write-FixtureJson (Join-Path $evidence 'created-object-acl-history-final.json') $before.ToArray()
 Write-FixtureJson (Join-Path $evidence 'result.json') $r
}
[pscustomobject]$r
if(-not $r.passed){throw ('Fixture did not qualify; preserved evidence: '+$evidence)}
