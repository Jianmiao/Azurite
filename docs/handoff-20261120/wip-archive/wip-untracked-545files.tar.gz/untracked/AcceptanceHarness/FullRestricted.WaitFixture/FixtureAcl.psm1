Set-StrictMode -Version Latest
function New-FixtureExpectedDescriptor([string]$Template,[string]$BeforeSddl) {
 $before=[Security.AccessControl.RawSecurityDescriptor]::new($BeforeSddl)
 $expected=[Security.AccessControl.RawSecurityDescriptor]::new($Template)
 if($null -eq $before.Owner -or $null -eq $before.Group -or $null -eq $expected.Owner -or $expected.Owner.Value -cne $before.Owner.Value){throw 'Fixture ACL may not adopt a different owner or missing group.'}
 if($null -ne $expected.Group -and $expected.Group.Value -cne $before.Group.Value){throw 'Fixture ACL may not change the original group.'}
 if(([int]$expected.ControlFlags -band 0x1000) -eq 0 -or ([int]$expected.ControlFlags -band 0x400) -ne 0 -or $null -eq $expected.DiscretionaryAcl){throw 'Fixture target must be the exact protected, non-AI template.'}
 foreach($ace in $expected.DiscretionaryAcl){if(([int]$ace.AceFlags -band 0x10) -ne 0){throw 'Fixture target template may not retain inherited ACEs.'}}
 $expected.Group=$before.Group
 return $expected.GetSddlForm([Security.AccessControl.AccessControlSections]'Owner,Group,Access')
}
function Assert-FixtureDescriptorReadback($Before,$After,[string]$Expected,[string]$Path) {
 if($Before.path -cne $Path -or $After.path -cne $Path -or $After.identity -cne $Before.identity -or $After.owner -cne $Before.owner -or $After.directory -ne $Before.directory -or $After.volume -cne $Before.volume -or $After.reparse -ne $false -or $After.sddl -cne $Expected){throw 'Exact same-object fixture descriptor readback differs.'}
}
function Invoke-FixtureDescriptorChange([string]$Path,[string]$Template,[bool]$CreatedByThisAttempt,[scriptblock]$Backend) {
 $lab='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\lab-wait1'
 if(-not $CreatedByThisAttempt -or -not($Path -ceq $lab -or $Path.StartsWith($lab+'\',[StringComparison]::Ordinal)) -or $Path -match '\\\.\.?\\'){throw 'Fixture descriptor changes require this attempt''s new exact lab object.'}
 $before=& $Backend Observe @{path=$Path}
 if($before.path -cne $Path -or $before.reparse -ne $false -or [string]::IsNullOrEmpty($before.identity)){throw 'Fixture created object identity cannot be proven.'}
 $expected=New-FixtureExpectedDescriptor $Template $before.sddl
 $null=& $Backend PreserveBefore @{path=$Path;before=$before;expectedSddl=$expected}
 $null=& $Backend SetDescriptor @{path=$Path;identity=$before.identity;beforeSddl=$before.sddl;expectedSddl=$expected}
 $after=& $Backend Observe @{path=$Path}
 Assert-FixtureDescriptorReadback $before $after $expected $Path
 return $after
}
Export-ModuleMember -Function New-FixtureExpectedDescriptor,Assert-FixtureDescriptorReadback,Invoke-FixtureDescriptorChange
