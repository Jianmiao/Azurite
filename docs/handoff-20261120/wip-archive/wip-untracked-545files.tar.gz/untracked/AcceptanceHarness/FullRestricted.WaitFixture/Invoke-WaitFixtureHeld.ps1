#requires -Version 7.0
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('normal')][string]$Scenario,[switch]$Execute,[Parameter(Mandatory)][string]$ReviewedPackageSha256,[string]$NormalReceiptPath,[string]$NormalReceiptSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$wrapperRepo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$wrapperRunner=$wrapperRepo+'\AcceptanceHarness\FullRestricted.WaitFixture\Run-Fixture.ps1'
$wrapperBuild=$wrapperRepo+'\artifacts\aa-fr-native-lifecycle-fixture\build-wait1'
function Get-StructuredFixtureHoldReasons([bool]$Held,[int]$RetainedMutexCount,$Outer,$Observed,[bool]$DispatchPrepared,$NativeCounts){
 $reasons=[Collections.Generic.List[string]]::new()
 if($Held){$reasons.Add('Fixture global lease remains held')}
 if($RetainedMutexCount -gt 0){$reasons.Add('Fixture mutex references remain retained')}
 foreach($row in $NativeCounts){if($row.error -or $row.count -gt 0){$reasons.Add('Native retained ownership or unknown reflection state: '+$row.type+'.'+$row.field)}}
 if($DispatchPrepared -and $null -eq $Outer){$reasons.Add('Native dispatch prepared but outer result is unavailable')}
 if($Outer){
  foreach($name in @('CleanupVerified','DirectProcessExited','JobDrained','StreamCaptureComplete','DesktopLeaseClosed','FullJobObserverClosed')){if(-not $Outer.$name){$reasons.Add('Outer ownership not verified: '+$name)}}
  if($Outer.RemainingOwnedProcesses -ne 0 -or $Outer.DesktopLeaseRetained -or $Outer.FullJobObserverRetained){$reasons.Add('Outer descendants or native references remain')}
 }
 if($Observed){
  if(-not $Observed.ReturnedWithinBound -or $null -eq $Observed.Outer){$reasons.Add('Observed outer task has not confirmed return')}
  if($null -eq $Observed.Observation -or @($Observed.Observation.Closes).Count -ne 4 -or @($Observed.Observation.Closes|Where-Object {-not $_.closed -or $_.error -ne 0}).Count -gt 0){$reasons.Add('Observer handle closure is incomplete')}
 }
 return ,$reasons.ToArray()
}
if($ReviewedPackageSha256 -cne '6fc9eb43ebc99a719c656e926e773159ad2933c35b5331d592c15cf126ec8643' -or (Get-FileHash ($wrapperBuild+'\manifest.json')).Hash.ToLowerInvariant() -cne $ReviewedPackageSha256 -or (Get-FileHash $wrapperRunner).Hash.ToLowerInvariant() -cne 'f731a26f7112f53772c2f99d36e326454636e766503148116c9e5e007abf9a47'){throw 'Exact reviewed structured fixture package/runner required'}
$wrapperParameters=@{Scenario=$Scenario;ReviewedPackageSha256=$ReviewedPackageSha256}
if($NormalReceiptPath){$wrapperParameters.NormalReceiptPath=$NormalReceiptPath};if($NormalReceiptSha256){$wrapperParameters.NormalReceiptSha256=$NormalReceiptSha256}
if(-not $Execute){& $wrapperRunner @wrapperParameters;return}
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Core'){throw 'Fresh direct x64 PS7 wrapper required'}
if('Azurite.Restricted.ProcessPump' -as [type]){throw 'Fresh host required; native types already loaded'}
$wrapperOutput=$wrapperRepo+'\artifacts\aa-fr-native-lifecycle-fixture\wait1-controller-evidence\'+[guid]::NewGuid().ToString('N')
[void][IO.Directory]::CreateDirectory($wrapperOutput)
$wrapperPrimary=$null;$wrapperResult=$null;$wrapperDisposition=$null;$wrapperHold=$false
# Dot-sourcing deliberately leaves the exact runner's live owners in this same
# script scope. Do not invoke it inside a nested function or another host.
$held=$false;$outer=$null;$observed=$null;$psi=$null;$r=$null;$script:retainedMutexes=[Collections.Generic.List[object]]::new()
try{
 $wrapperParameters.Execute=$true
 $wrapperResult=. $wrapperRunner @wrapperParameters
}catch{$wrapperPrimary=$_.Exception.ToString()}
finally{
 try{
  $wrapperCounts=[Collections.Generic.List[object]]::new();$wrapperNative='Azurite.Restricted.ProcessPump' -as [type]
  if($wrapperNative){
   $wrapperAssembly=$wrapperNative.Assembly
   foreach($pair in @(@('Azurite.Restricted.ProcessPump','fullQuarantineOwners'),@('Azurite.Restricted.FullOwnedHandle','retained'),@('Azurite.Restricted.FullDesktopLease','quarantine'),@('Azurite.Restricted.BoundedPipeCapture','retained'),@('Azurite.Restricted.FullRestrictedSpawn','retainedOwners'),@('Azurite.Restricted.LifecycleFixture','retained'))){
    $wrapperRow=[ordered]@{type=$pair[0];field=$pair[1];count=0;error=$null}
    try{$wrapperType=$wrapperAssembly.GetType($pair[0],$true);$wrapperField=$wrapperType.GetField($pair[1],[Reflection.BindingFlags]'NonPublic,Static');if(-not $wrapperField){throw 'Expected retained-owner field missing'};$wrapperValue=$wrapperField.GetValue($null);$wrapperRow.count=$wrapperValue.Count}catch{$wrapperRow.error=$_.Exception.ToString()}
    $wrapperCounts.Add([pscustomobject]$wrapperRow)
   }
  }
  $wrapperReasons=Get-StructuredFixtureHoldReasons $held $script:retainedMutexes.Count $outer $observed ($null -ne $psi) $wrapperCounts.ToArray()
  $wrapperHold=$wrapperReasons.Count -gt 0
  $wrapperDisposition=[ordered]@{schema=1;scope='same-host fixture owner retention wrapper';scenario=$Scenario;packageSha256=$ReviewedPackageSha256;utc=[DateTimeOffset]::UtcNow.ToString('o');primaryError=$wrapperPrimary;fixturePassed=($null -ne $r -and $r.passed);holdHost=$wrapperHold;reasons=$wrapperReasons;leaseHeld=$held;retainedMutexCount=$script:retainedMutexes.Count;nativeRetained=$wrapperCounts.ToArray();dispatchPrepared=($null -ne $psi);outerResultAvailable=($null -ne $outer);actualFixtureResult=$r;automaticKill=$false;automaticRetry=$false;automaticRecovery=$false}
  try{$wrapperBytes=[Text.UTF8Encoding]::new($false).GetBytes(($wrapperDisposition|ConvertTo-Json -Depth 90));$wrapperStream=[IO.File]::Open(($wrapperOutput+'\wrapper-result.json'),'CreateNew','Write','Read');try{$wrapperStream.Write($wrapperBytes,0,$wrapperBytes.Length);$wrapperStream.Flush($true)}finally{$wrapperStream.Dispose()}}catch{if(-not $wrapperPrimary){$wrapperPrimary=$_.Exception.ToString()};try{[Console]::Error.WriteLine('Wrapper evidence persistence failed: '+$_.Exception.Message)}catch{}}
  try{[pscustomobject]@{resultPath=($wrapperOutput+'\wrapper-result.json');passed=($wrapperDisposition.fixturePassed -and -not $wrapperPrimary);holdHost=$wrapperHold;error=$wrapperPrimary;reasons=$wrapperReasons}|ConvertTo-Json -Depth 8}catch{}
 }catch{$wrapperHold=$true;try{[Console]::Error.WriteLine('Ownership inspection is uncertain: '+$_.Exception.ToString())}catch{}}
 finally{
  if($wrapperHold){try{[Console]::Error.WriteLine('Fixture ownership is unconfirmed. Same PS7 host retained for root inspection; no next case, kill or retry will run.')}catch{};while($true){[Threading.Thread]::Sleep(30000)}}
 }
}
if($wrapperPrimary -or $null -eq $r -or -not $r.passed){exit 1}
