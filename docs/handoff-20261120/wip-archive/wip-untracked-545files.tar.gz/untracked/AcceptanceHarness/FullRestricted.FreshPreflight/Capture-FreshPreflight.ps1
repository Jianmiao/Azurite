[CmdletBinding()]
param(
 [string]$Repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38',
 [string]$RunId='2fc0eb21404d4efaaf527c07c295d147',
 [string]$BaselineCaptureResultPath,
 [string]$ExpectedBaselineCaptureResultSha256,
 [string]$BuildDirectory='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-fresh-preflight-tooling\build3',
 [switch]$Execute,
 [string]$ReviewedSourceIndexSha256,
 [string]$ReviewedBuildManifestSha256,
 [string]$HarmlessReceiptPath,
 [string]$HarmlessReceiptSha256,
 [string]$SharedBeforePath,
 [string]$SharedBeforeSha256,
 [string]$DotnetPath,
 [string]$DotnetSha256
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$expectedRepo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
if([IO.Path]::GetFullPath($Repo).TrimEnd('\') -cne $expectedRepo){throw 'Exact reviewed repo required'}
if($RunId -cnotmatch '\A[a-f0-9]{32}\z' -or $RunId -ceq ('0'*32)){throw 'RunId must be canonical nonzero lowercase 32-hex'}
$lab='F:\AzuriteLabs\Editor-20261108-normal'
$install=$lab+'\install'
$build=[IO.Path]::GetFullPath($BuildDirectory)
if($build -cne $BuildDirectory -or (Split-Path -Parent $build) -cne ($Repo+'\artifacts\aa-fr-fresh-preflight-tooling') -or [IO.Path]::GetFileName($build) -cnotmatch '\A[A-Za-z0-9][A-Za-z0-9_.-]*\z'){throw 'Build directory must be an exact direct child of the fixed C tooling directory'}
if(-not $Execute){[ordered]@{scope='fresh-preflight-source-only-plan';runId=$runId;outputParent=($Repo+'\artifacts\aa-fr-fresh-preflight');helperBuild=$build;baselineCaptureResultPath=$BaselineCaptureResultPath;expectedBaselineCaptureResultSha256=$ExpectedBaselineCaptureResultSha256;acceptanceStatus='not-reviewed-not-built-not-collected';willExecute=$false;willReadStage=$false;harmlessReceiptRequired=$true;harmlessReceiptSupplied=([bool]$HarmlessReceiptPath);inputReady=$false;selectedOptionsExecuted=$false;identityAndSharedCapture='separate existing producers; not called here'}|ConvertTo-Json;return}
foreach($name in @('RunId','BaselineCaptureResultPath','ExpectedBaselineCaptureResultSha256','BuildDirectory')){if(-not $PSBoundParameters.ContainsKey($name)){throw ('Execute requires explicit '+$name)}}
function Assert-True([bool]$Condition,[string]$Message){if(-not $Condition){throw $Message}}
function Hash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read-Pinned([string]$Path,[string]$Expected,[long]$MaxBytes){
 Assert-True ($Expected -cmatch '^[a-f0-9]{64}$') 'Explicit reviewed SHA-256 required'
 $item=Get-Item -LiteralPath $Path
 Assert-True (-not $item.PSIsContainer -and ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0 -and $item.Length -le $MaxBytes) 'Pinned file bound/reparse failure'
 $bytes=[IO.File]::ReadAllBytes($item.FullName)
 Assert-True ($bytes.Length -gt 1 -and $bytes.Length -le $MaxBytes) 'Pinned bytes bound'
 $sha=[Security.Cryptography.SHA256]::Create();try{$actual=[BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
 Assert-True ($actual -ceq $Expected) ('Pinned bytes mismatch: '+$Path)
 $text=[Text.UTF8Encoding]::new($false,$true).GetString($bytes)
 $parameters=@{InputObject=$text};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$parameters.DateKind='String'}
 return (ConvertFrom-Json @parameters)
}
function Write-New([string]$Path,$Value){
 $bytes=[Text.Encoding]::UTF8.GetBytes(($Value|ConvertTo-Json -Depth 40)+"`n")
 $f=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}
}
function Assert-CPath([string]$Path){
 $full=[IO.Path]::GetFullPath($Path)
 Assert-True ($full.StartsWith($Repo+'\',[StringComparison]::OrdinalIgnoreCase)) 'Evidence/tool path must remain inside the exact C repo'
 $cursor=Get-Item -LiteralPath $full
 while($null -ne $cursor){Assert-True (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) 'Reparse ancestry refused';$cursor=if($cursor -is [IO.FileInfo]){$cursor.Directory}else{$cursor.Parent}}
}
function Test-HarmlessReceiptKind($Receipt) {
 if($null -eq $Receipt){return $false}
 foreach($name in @('schema','scope','passed','productionTargetExecuted','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified')){if(-not $Receipt.PSObject.Properties[$name]){return $false}}
 if($Receipt.schema -isnot [int] -and $Receipt.schema -isnot [long]){return $false}
 foreach($name in @('passed','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified')){if($Receipt.$name -isnot [bool] -or -not $Receipt.$name){return $false}}
 if($Receipt.productionTargetExecuted -isnot [bool] -or $Receipt.productionTargetExecuted){return $false}
 if($Receipt.schema -eq 1){return ($Receipt.scope -ceq 'actual-native-full-restricted-harmless-lifecycle' -and $Receipt.PSObject.Properties['desktopLeaseAcrossBootstrapExit'] -and $Receipt.desktopLeaseAcrossBootstrapExit -is [bool] -and $Receipt.desktopLeaseAcrossBootstrapExit)}
 if($Receipt.schema -ne 2 -or $Receipt.scope -cne 'actual-native-full-restricted-cleanup-lifecycle' -or $Receipt.PSObject.Properties['desktopLeaseAcrossBootstrapExit']){return $false}
 foreach($name in @('cleanupEvidenceProtocol','outerDesktopHeldUntilJobDrain','bootstrapExitCleanupObserved','cleanupTraceComplete','externalLiveDescendantIntervalClaimed')){if(-not $Receipt.PSObject.Properties[$name]){return $false}}
 if($Receipt.cleanupEvidenceProtocol -cne 'cleanup-ordering.v1'){return $false}
 foreach($name in @('outerDesktopHeldUntilJobDrain','bootstrapExitCleanupObserved','cleanupTraceComplete')){if($Receipt.$name -isnot [bool] -or -not $Receipt.$name){return $false}}
 return ($Receipt.externalLiveDescendantIntervalClaimed -is [bool] -and -not $Receipt.externalLiveDescendantIntervalClaimed)
}
function Assert-HarmlessReceipt($Receipt,[string]$NativePin,[string]$SharedPin){
 Assert-True ((Test-HarmlessReceiptKind $Receipt) -and $Receipt.nativeSourceSha256 -ceq $NativePin -and $Receipt.sharedNativeSourceSha256 -ceq $SharedPin) 'Complete same-source harmless receipt version/identity required'
}
function Read-FreshPreflightRunInputs([string]$RunId,[string]$BaselineCaptureResultPath,[string]$ExpectedBaselineCaptureResultSha256,[string]$SharedBeforePath,[string]$SharedBeforeSha256,[DateTimeOffset]$Now){
 Assert-True ($RunId -cmatch '\A[a-f0-9]{32}\z' -and $RunId -cne ('0'*32)) 'RunId must be canonical nonzero lowercase 32-hex'
 Assert-CPath $BaselineCaptureResultPath
 $baseline=Read-Pinned $BaselineCaptureResultPath $ExpectedBaselineCaptureResultSha256 1048576
 Assert-True ($baseline.schema -eq 1 -and $baseline.scope -ceq 'read-only-stage-baseline-capture' -and $baseline.runId -ceq $RunId -and $baseline.success -is [bool] -and $baseline.success -and ($baseline.observedObjects -is [int] -or $baseline.observedObjects -is [long]) -and $baseline.observedObjects -eq 1228 -and [string]::IsNullOrEmpty($baseline.error) -and $baseline.baselineSha256 -cmatch '\A[a-f0-9]{64}\z' -and $baseline.baselineSha256 -cne ('0'*64)) 'Completed same-run 1228-object baseline capture required'
 foreach($field in @('willWriteF','runtimeAllowed','launchPermission')){Assert-True ($baseline.$field -is [bool] -and -not $baseline.$field) ('Baseline must not claim '+$field)}
 Assert-True ($baseline.lease.mutex -ceq 'Global\AzuriteRestrictedCli-AA' -and $baseline.lease.state -ceq 'released') 'Completed baseline lease release required'
 Assert-CPath $SharedBeforePath
 $sharedBefore=Read-Pinned $SharedBeforePath $SharedBeforeSha256 67108864
 Assert-True ($sharedBefore.schema -eq 1 -and $sharedBefore.runId -ceq $RunId -and $sharedBefore.phase -ceq 'Before') 'Actual same-run shared Before capture required'
 foreach($value in @($baseline.observedUtc,$baseline.lease.heldFromUtc,$baseline.lease.releasedUtc,$sharedBefore.capturedUtc)){Assert-True ($value -is [string] -and $value -cmatch '\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,7})?(Z|[+-]\d{2}:\d{2})\z') 'Explicit-offset input chronology required'}
 $baselineTime=[DateTimeOffset]::Parse($baseline.observedUtc,[Globalization.CultureInfo]::InvariantCulture)
 $heldFrom=[DateTimeOffset]::Parse($baseline.lease.heldFromUtc,[Globalization.CultureInfo]::InvariantCulture)
 $released=[DateTimeOffset]::Parse($baseline.lease.releasedUtc,[Globalization.CultureInfo]::InvariantCulture)
 $sharedTime=[DateTimeOffset]::Parse($sharedBefore.capturedUtc,[Globalization.CultureInfo]::InvariantCulture)
 Assert-True ($heldFrom -le $baselineTime -and $heldFrom -le $released -and $released -le $baselineTime.AddSeconds(2)) 'Baseline observed/lease chronology differs'
 Assert-True ($sharedTime -ge $baselineTime -and $sharedTime -ge $released -and $baselineTime -le $Now -and $released -le $Now -and $sharedTime -le $Now) 'Shared Before/baseline chronology differs or is in the future'
 return [pscustomobject]@{runId=$RunId;baseline=$baseline;sharedBefore=$sharedBefore;sharedTime=$sharedTime}
}
function Get-SelectedObservation($Environment,[string[]]$Argv,[string]$WorkingDirectory,[string]$Command){
 $present=$Environment.ContainsKey('BEPINEX_GAME_ASSEMBLY_PATH')
 $value=if($present){$Environment['BEPINEX_GAME_ASSEMBLY_PATH']}else{$null}
 Assert-True ($Environment.ContainsKey('AZUREARCHIVE_CLI_DIRECTORY')) 'Selected transport environment key missing'
 return [pscustomobject]@{actualEnvironment=[ordered]@{BEPINEX_GAME_ASSEMBLY_PATH=[ordered]@{present=[bool]$present;value=$value}};actualArgv=$Argv;sidecar=[ordered]@{environmentKey='AZUREARCHIVE_CLI_DIRECTORY';directory=$Environment['AZUREARCHIVE_CLI_DIRECTORY'];command=$Command;cwd=$WorkingDirectory}}
}
function New-FreshReaderState {
 return [pscustomobject]@{ownsProcess=$false;startAttempted=$false;startReturned=$false;started=$false;waitAttempted=$false;waitCompleted=$false;exitConfirmed=$false;streamsStarted=$false;streamsCompleted=$false;processDisposed=$false;mutexDisposed=$false;held=$false;retained=$false;primaryError=$null;cleanupErrors=[Collections.Generic.List[string]]::new()}
}
function Confirm-FreshReaderExit($State,[scriptblock]$Backend){
 $State.waitAttempted=$true
 $wait=& $Backend 'Wait' $State
 Assert-True ($wait -is [bool] -and $wait) 'Owned reader wait did not complete successfully'
 $State.waitCompleted=$true
 $exited=& $Backend 'HasExited' $State
 Assert-True ($exited -is [bool] -and $exited) 'Owned reader exit is unconfirmed'
 $State.exitConfirmed=$true
}
function Invoke-FreshOwnedReader($State,[scriptblock]$Backend){
 try{
  $State.startAttempted=$true
  $started=& $Backend 'Start' $State
  Assert-True ($started -is [bool]) 'Owned reader start outcome is unknown'
  $State.startReturned=$true;$State.started=$started
  Assert-True $started 'Warm helper failed to start'
  & $Backend 'BeginStreams' $State
  $State.streamsStarted=$true
  Confirm-FreshReaderExit $State $Backend
  $result=& $Backend 'CompleteStreamsAndResult' $State
  $State.streamsCompleted=$true
  return $result
 }catch{$State.primaryError=$_.Exception.ToString();throw}
 finally{
  # If setup failed after a known start, make one real exit observation. A failed
  # wait/status observation is never upgraded by catch/finally or retried blindly.
  if($State.started -and -not $State.waitAttempted){try{Confirm-FreshReaderExit $State $Backend}catch{$State.cleanupErrors.Add($_.Exception.ToString())}}
 }
}
function Complete-FreshReaderLease($State,[scriptblock]$Backend){
 $safe=(-not $State.startAttempted) -or ($State.startReturned -and -not $State.started) -or $State.exitConfirmed
 if(-not $safe){$State.cleanupErrors.Add('Owned reader exit unconfirmed; process reference and held lease retained')}
 if($State.ownsProcess -and $safe -and (-not $State.started -or $State.streamsCompleted)){
  try{& $Backend 'DisposeProcess' $State;$State.processDisposed=$true}catch{$State.cleanupErrors.Add($_.Exception.ToString())}
 }
 if($State.held -and $safe){try{& $Backend 'ReleaseMutex' $State;$State.held=$false}catch{$State.cleanupErrors.Add($_.Exception.ToString())}}
 if(-not $State.held){try{& $Backend 'DisposeMutex' $State;$State.mutexDisposed=$true}catch{$State.cleanupErrors.Add($_.Exception.ToString())}}
 if(($State.ownsProcess -and -not $State.processDisposed) -or $State.held -or -not $State.mutexDisposed){
  $State.retained=$true
  & $Backend 'Retain' $State
 }
}
function Assert-FreshCacheLeaves($Fresh,$Contract){
 Assert-True ($Fresh.selected_profile -ceq $Contract.selected_profile -and $Fresh.selected_mod_directory -ceq $Contract.selected_mod_directory) 'Fresh selected profile/mod directory differs'
 $normalized=[IO.Path]::GetFullPath($Contract.selected_mod_directory).TrimEnd('\','/')
 $sha=[Security.Cryptography.SHA256]::Create();try{$digest=$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($normalized))}finally{$sha.Dispose()}
 $modLeaf='mod-the-azure-archive-'+[BitConverter]::ToString($digest,0,12).Replace('-','')+'_typeloader.dat'
 $expected=@($Contract.cache_leaves);$actual=@($Fresh.cache_leaves)
 Assert-True ($expected.Count -eq 2 -and $actual.Count -eq 2 -and $expected[0].leaf -ceq 'chainloader_typeloader.dat' -and $expected[1].leaf -ceq $modLeaf) 'Exact two canonical cache rows required'
 for($i=0;$i -lt 2;$i++){
  Assert-True ($actual[$i].leaf -ceq $expected[$i].leaf) 'Fresh cache leaf/order differs'
  foreach($field in @('in_saved_manifest','exists_now','needs_precreation')){Assert-True ($actual[$i].$field -is [bool] -and $actual[$i].$field -eq $expected[$i].$field) ('Fresh typed cache disposition differs: '+$field)}
  Assert-True ($actual[$i].sha256 -ceq $expected[$i].sha256) 'Fresh cache hash differs'
 }
 Assert-True ($actual[0].in_saved_manifest -and $actual[0].exists_now -and -not $actual[0].needs_precreation -and $actual[0].sha256 -cmatch '^[a-f0-9]{64}$') 'Existing pinned chainloader cache required'
 Assert-True (-not $actual[1].in_saved_manifest -and -not $actual[1].exists_now -and $actual[1].needs_precreation -and $null -eq $actual[1].sha256) 'Canonical new mod cache must actually be absent'
}
function Observe-AA0 {
 $processes=@(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'" -ErrorAction Stop)
 Assert-True ($processes.Count -eq 0) 'Fresh AA/probe absence gate failed'
 [ordered]@{utc=[DateTime]::UtcNow.ToString('o');aaCount=0;probeCount=0;processControlPerformed=$false}
}
Assert-CPath $PSScriptRoot
$sourceIndex=Read-Pinned ($PSScriptRoot+'\source-index.json') $ReviewedSourceIndexSha256 1048576
foreach($entry in $sourceIndex.files){
 Assert-True ($entry.path -cmatch '^[A-Za-z0-9_.-]+$') 'Source member must be one leaf'
 $p=$PSScriptRoot+'\'+$entry.path;Assert-CPath $p
 Assert-True ((Hash $p) -ceq $entry.sha256) ('Source member changed: '+$entry.path)
}
Assert-CPath $HarmlessReceiptPath
$receipt=Read-Pinned $HarmlessReceiptPath $HarmlessReceiptSha256 131072
$nativePin='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533'
$sharedPin='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'
Assert-HarmlessReceipt $receipt $nativePin $sharedPin
Assert-True ((Hash ($Repo+'\tools\headless\RestrictedCliNative.cs')) -ceq $sharedPin -and (Hash ($Repo+'\tools\headless\RestrictedCliFullRestricted.cs')) -ceq $nativePin) 'Current production source pins drifted'
$runInputs=Read-FreshPreflightRunInputs $RunId $BaselineCaptureResultPath $ExpectedBaselineCaptureResultSha256 $SharedBeforePath $SharedBeforeSha256 ([DateTimeOffset]::UtcNow)
$sharedBefore=$runInputs.sharedBefore;$sharedTime=$runInputs.sharedTime
Assert-CPath $build
$buildManifest=Read-Pinned ($build+'\manifest.json') $ReviewedBuildManifestSha256 1048576
Assert-True ($buildManifest.sourceIndexSha256 -ceq $ReviewedSourceIndexSha256 -and $buildManifest.runtimeExecuted -eq $false) 'Build must bind reviewed source and record no collection execution'
$required=@('CachePrerequisites.dll','CachePrerequisites.deps.json','CachePrerequisites.runtimeconfig.json')
foreach($name in $required){Assert-True (@($buildManifest.files|Where-Object {$_.path -ceq $name}).Count -eq 1) 'Required helper runtime member missing/duplicate'}
foreach($entry in $buildManifest.files){Assert-True ($entry.path -cmatch '^[A-Za-z0-9_.-]+$') 'Build member must be one leaf';$p=$build+'\'+$entry.path;Assert-CPath $p;Assert-True ((Hash $p) -ceq $entry.sha256) 'Build member mismatch'}
Assert-True ($DotnetSha256 -cmatch '^[a-f0-9]{64}$' -and (Hash $DotnetPath) -ceq $DotnetSha256) 'Actual selected dotnet host pin required'
$core=$Repo+'\tools\headless\RestrictedCliCore.psm1'
Assert-True ((Hash $core) -ceq '452a4255fd950c9b6d1e3e35c537fdb93bd4b40874fb4536dfcc44c754ab1f59') 'Production ProcessStartInfo/environment function source drift'
Import-Module $core -Force
$old=$Repo+'\artifacts\aa-fr-cache-prerequisites'
$stagePin='0bddb4285f5cee0c79c3f2ab6f6ab8c346937ae8ff12b4f49f29a6f102bd33dd'
$cachePin='11476211f744e7009fe1bd21b7bc4b786d3f73c89a747f6ecab955e43754c5f4'
$warmPin='ae20a85d28f254d14851deeb9d4ff0627bb7d821bd04154814c8fdfcca830fb6'
$cacheContract=Read-Pinned ($old+'\cache-prerequisites-contract.json') $cachePin 1048576
$historical=Read-Pinned ($old+'\warm-stamp-result.json') $warmPin 1048576
$null=Read-Pinned ($old+'\intake-metadata.json') 'cfeda699fe86cb3b55c9fe36ddffcb7060313d243fc572a591cdae93af79cca5' 1048576
$null=Read-Pinned ($Repo+'\artifacts\editor-normal-install-preparation\source-bound-manifest-v2.json') $stagePin 16777216
$mutex=$null;$output=$null;$primary=$null;$aaBefore=$null;$aaAfter=$null;$passed=$false
$reader=New-FreshReaderState;$cleanup=$reader.cleanupErrors
$owned=[pscustomobject]@{process=$null;mutex=$null;stdout=$null;stderr=$null;reader=$reader}
$backend={param($action,$state)
 switch($action){
  Start {return $owned.process.Start()}
  BeginStreams {$owned.stdout=$owned.process.StandardOutput.ReadToEndAsync();$owned.stderr=$owned.process.StandardError.ReadToEndAsync();return}
  Wait {$owned.process.WaitForExit();return $true}
  HasExited {return $owned.process.HasExited}
  CompleteStreamsAndResult {return [ordered]@{pid=$owned.process.Id;exitCode=$owned.process.ExitCode;stdout=$owned.stdout.GetAwaiter().GetResult();stderr=$owned.stderr.GetAwaiter().GetResult()}}
  DisposeProcess {$owned.process.Dispose();return}
  ReleaseMutex {$owned.mutex.ReleaseMutex();return}
  DisposeMutex {if($null -ne $owned.mutex){$owned.mutex.Dispose()};return}
  Retain {
   if(-not (Get-Variable -Scope Global -Name AzuriteFreshPreflightRetainedOwners -ErrorAction SilentlyContinue)){$global:AzuriteFreshPreflightRetainedOwners=[Collections.Generic.List[object]]::new()}
   $global:AzuriteFreshPreflightRetainedOwners.Add($owned);return
  }
  default {throw 'Unknown owned-reader operation'}
 }
}.GetNewClosure()
try{
 $mutex=[Threading.Mutex]::new($false,'Global\AzuriteRestrictedCli-AA');$owned.mutex=$mutex
 try{$reader.held=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$reader.held=$true;throw 'Abandoned shared lease refused; separately inspect existing pending state'}
 Assert-True $reader.held 'Global restricted CLI lease is busy'
 $aaBefore=Observe-AA0
 $parent=$Repo+'\artifacts\aa-fr-fresh-preflight'
 Assert-CPath ($Repo+'\artifacts')
 if(-not (Test-Path -LiteralPath $parent)){[void][IO.Directory]::CreateDirectory($parent)}
 Assert-CPath $parent
 $output=$parent+'\capture-'+[Guid]::NewGuid().ToString('N')
 Assert-True (-not (Test-Path -LiteralPath $output)) 'Fresh capture output already exists'
 [void][IO.Directory]::CreateDirectory($output)
 Assert-CPath $output
 $run=$lab+'\runs\restricted-'+$runId
 $selectedArgv=@('-batchmode','-nographics','-disableaudio','-logFile',($run+'\output\unity.log'))
 $selectedCommand='capabilities'
 $selected=New-AzuriteProcessInfo ($install+'\AzureArchive.exe') $selectedArgv ($run+'\workspace')
 Set-AzuriteCliChildEnvironment $selected ($run+'\request')
 $observed=Get-SelectedObservation $selected.EnvironmentVariables $selectedArgv $selected.WorkingDirectory $selectedCommand
 $actualEnvironment=$observed.actualEnvironment;$sidecar=$observed.sidecar
 $present=$actualEnvironment.BEPINEX_GAME_ASSEMBLY_PATH.present;$value=$actualEnvironment.BEPINEX_GAME_ASSEMBLY_PATH.value
 Write-New ($output+'\selected-options.json') ([ordered]@{schema=1;scope='actual-selected-options-not-executed';observedUtc=[DateTime]::UtcNow.ToString('o');fileName=$selected.FileName;serializedArguments=$selected.Arguments;actualArgv=$selectedArgv;actualEnvironment=$actualEnvironment;sidecar=$sidecar;processStartInfoCreated=$true;processStarted=$false;sidecarFileCreated=$false;productionTargetExecuted=$false})
 Assert-True (-not $present -and $null -eq $value) 'GameAssembly override key must be absent; presence/value retained in selected-options evidence'
 $helperArgs=@(($build+'\CachePrerequisites.dll'),'stamp',$output,$Repo)
 $helper=New-AzuriteProcessInfo $DotnetPath $helperArgs $build
 $owned.process=[Diagnostics.Process]::new();$reader.ownsProcess=$true;$owned.process.StartInfo=$helper
 $helperResult=Invoke-FreshOwnedReader $reader $backend
 Write-New ($output+'\helper-process.json') ([ordered]@{pid=$helperResult.pid;exitCode=$helperResult.exitCode;stdout=$helperResult.stdout;stderr=$helperResult.stderr;fileName=$DotnetPath;hostSha256=$DotnetSha256;argv=$helperArgs;productionTargetExecuted=$false})
 Assert-True ($helperResult.exitCode -eq 0) 'Fresh helper returned failure'
 $aaAfter=Observe-AA0
 $fresh=Read-Pinned ($output+'\warm-stamp-result.json') (Hash ($output+'\warm-stamp-result.json')) 1048576
 Assert-True ($fresh.stamp_matches -eq $true -and $fresh.input_events.Count -eq 147 -and $fresh.input_files.Count -eq 73 -and $fresh.unity_dll_count -eq 72 -and $fresh.priority -ceq 'BelowNormal' -and $fresh.read_limit_bytes_per_second -eq 4194304 -and $fresh.sort_applied -eq $false) 'Fresh actual warm evidence incomplete'
 Assert-True (($fresh.input_events|ConvertTo-Json -Depth 20 -Compress) -ceq ($historical.input_events|ConvertTo-Json -Depth 20 -Compress)) 'Fresh actual event order differs from recorded source-linked proof'
 $projectFiles=@(foreach($f in $fresh.input_files){[ordered]@{relative_path=$f.relative_path;bytes=[long]$f.bytes;sha256=$f.sha256}})
 $priorFiles=@(foreach($f in $historical.input_files){[ordered]@{relative_path=$f.relative_path;bytes=[long]$f.bytes;sha256=$f.sha256}})
 Assert-True (($projectFiles|ConvertTo-Json -Depth 20 -Compress) -ceq ($priorFiles|ConvertTo-Json -Depth 20 -Compress)) 'Fresh actual file pins differ'
 Assert-True ($fresh.generator_version -ceq '1.5.3.0' -and $fresh.cpp2il_version -ceq '2022.1.0.0' -and $fresh.optional_rename_map_present -eq $false) 'Fresh pinned versions or rename-map changed'
 Assert-FreshCacheLeaves $fresh $cacheContract
 Assert-True ([DateTimeOffset]::UtcNow -ge $sharedTime) 'Fresh observation clock precedes actual shared Before capture'
 $preflight=[ordered]@{schema=1;scope='fresh-full-capabilities-pretransition-observation';evidenceClass='reviewed-real';runId=$runId;labRoot=$lab;installRoot=$install;observedUtc=[DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ');stageManifestSha256=$stagePin;cacheContractSha256=$cachePin;historicalWarmResultSha256=$warmPin;actualEnvironment=$actualEnvironment;actualArgv=$selectedArgv;sidecar=$sidecar;warmInterop=[ordered]@{computedStamp=$fresh.computed_stamp;generatorVersion=$fresh.generator_version;cpp2ilVersion=$fresh.cpp2il_version;optionalRenameMapPresent=$fresh.optional_rename_map_present;orderedEvents=$fresh.input_events;inputFiles=$projectFiles}}
 $passed=$true
}catch{$primary=$_.Exception.ToString()}finally{
 Complete-FreshReaderLease $reader $backend
 if($passed -and $cleanup.Count -eq 0){Write-New ($output+'\preflight-warm-order.json') $preflight}
 if($output){Write-New ($output+'\capture-result.json') ([ordered]@{schema=1;scope='fresh-warm-preflight-capture';runId=$RunId;baselineCaptureResultPath=$BaselineCaptureResultPath;baselineCaptureResultSha256=$ExpectedBaselineCaptureResultSha256;passed=($passed -and $cleanup.Count -eq 0);primaryError=$primary;cleanupErrors=@($cleanup);ownedReader=$reader;leaseStillHeld=$reader.held;aaBefore=$aaBefore;aaAfter=$aaAfter;sourceIndexSha256=$ReviewedSourceIndexSha256;buildManifestSha256=$ReviewedBuildManifestSha256;harmlessReceiptSha256=$HarmlessReceiptSha256;sharedBeforeSha256=$SharedBeforeSha256;identityAndSharedCaptured=$false;productionTargetExecuted=$false;selectedOptionsExecuted=$false;inputReady=$false})}
}
if($primary){throw $primary};if($cleanup.Count){throw ($cleanup -join '; ')}
