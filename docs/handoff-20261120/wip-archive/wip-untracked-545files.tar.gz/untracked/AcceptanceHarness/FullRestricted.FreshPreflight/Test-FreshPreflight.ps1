param([string]$SourceDirectory=$PSScriptRoot)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$Repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$count=0
function Check($Okay,[string]$Why){$script:count++;if(-not $Okay){throw ('Pure check: '+$Why)}}
function Refuse([scriptblock]$Action,[string]$Why){$failed=$false;try{& $Action|Out-Null}catch{$failed=$true};Check $failed $Why}
# Extract only named functions. Never dot-source or invoke the capture entrypoint.
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $SourceDirectory 'Capture-FreshPreflight.ps1'),[ref]$tokens,[ref]$errors)
Check ($errors.Count -eq 0) 'capture parses'
foreach($name in @('Assert-True','Hash','Read-Pinned','Assert-CPath','Test-HarmlessReceiptKind','Assert-HarmlessReceipt','Get-SelectedObservation','New-FreshReaderState','Confirm-FreshReaderExit','Invoke-FreshOwnedReader','Complete-FreshReaderLease','Assert-FreshCacheLeaves')){
 $nodes=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object Name -CEQ $name)
 Check ($nodes.Count -eq 1) ('one production function '+$name)
 . ([scriptblock]::Create($nodes[0].Extent.Text))
}
$native='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533';$shared='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'
$receipt=[pscustomobject]@{schema=1;scope='actual-native-full-restricted-harmless-lifecycle';nativeSourceSha256=$native;sharedNativeSourceSha256=$shared;passed=$true;desktopLeaseAcrossBootstrapExit=$true;actualSuspendedTokenAndJob=$true;pipeHandleListAndEOF=$true;cleanupVerified=$true;productionTargetExecuted=$false}
$assignment=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -ceq 'nativePin'},$true))
Check ($assignment.Count -eq 1) 'one actual production Full lineage assignment'
$literal=@($assignment[0].Right.FindAll({param($n)$n -is [Management.Automation.Language.StringConstantExpressionAst]},$true))
Check ($literal.Count -eq 1) 'production lineage is an explicit literal'
Assert-HarmlessReceipt $receipt $literal[0].Value $shared;Check $true 'current cf95 synthetic input uses actual collector lineage guard'
foreach($old in @('d599e0431f075c5941d55b761307881213035fcaaaf5189c73babe6eb6710892','460694d0abd2771580c4989485cba134ed01a525c310f4c136adc4123970c73f')){
 $bad=$receipt|ConvertTo-Json|ConvertFrom-Json;$bad.nativeSourceSha256=$old;Refuse {Assert-HarmlessReceipt $bad $literal[0].Value $shared} 'old Full lineage cannot stand in for cf95'
}
Assert-HarmlessReceipt $receipt $native $shared;Check $true 'synthetic full receipt accepted by actual predicate'
foreach($field in @('passed','desktopLeaseAcrossBootstrapExit','actualSuspendedTokenAndJob','pipeHandleListAndEOF','cleanupVerified')){
 $bad=$receipt|ConvertTo-Json|ConvertFrom-Json;$bad.$field=$false;Refuse {Assert-HarmlessReceipt $bad $native $shared} ('false '+$field)
 $bad.$field='true';Refuse {Assert-HarmlessReceipt $bad $native $shared} ('string boolean '+$field)
}
Refuse {Assert-HarmlessReceipt $receipt ('0'*64) $shared} 'wrong native source'
$bad=$receipt|ConvertTo-Json|ConvertFrom-Json;$bad.scope='normal-only';Refuse {Assert-HarmlessReceipt $bad $native $shared} 'normal alone insufficient'
$argv=@('-batchmode','-nographics','-disableaudio','-logFile','C:\synthetic\unity.log')
$envMap=@{AZUREARCHIVE_CLI_DIRECTORY='C:\synthetic\request'}
$obs=Get-SelectedObservation $envMap $argv 'C:\synthetic\workspace' capabilities
Check (-not $obs.actualEnvironment.BEPINEX_GAME_ASSEMBLY_PATH.present -and $null -eq $obs.actualEnvironment.BEPINEX_GAME_ASSEMBLY_PATH.value) 'absent remains absent'
foreach($value in @('','C:\synthetic\override.dll')){$envMap['BEPINEX_GAME_ASSEMBLY_PATH']=$value;$obs=Get-SelectedObservation $envMap $argv 'C:\synthetic\workspace' capabilities;Check ($obs.actualEnvironment.BEPINEX_GAME_ASSEMBLY_PATH.present -and $obs.actualEnvironment.BEPINEX_GAME_ASSEMBLY_PATH.value -ceq $value) 'present empty/nonempty never defaulted away'}
Check (($obs.actualArgv -join '|') -ceq ($argv -join '|') -and $obs.sidecar.directory -ceq $envMap.AZUREARCHIVE_CLI_DIRECTORY -and $obs.sidecar.cwd -ceq 'C:\synthetic\workspace') 'selected values projected unchanged'
Refuse {Get-SelectedObservation @{} $argv 'C:\synthetic' capabilities} 'missing transport key refused'
Assert-CPath (Join-Path $SourceDirectory 'Program.cs');Check $true 'real C FileInfo ancestry accepted'
Assert-CPath $SourceDirectory;Check $true 'real C DirectoryInfo ancestry accepted'
Refuse {Assert-CPath 'C:\outside-reviewed-workspace\missing.json'} 'outside boundary rejected before reading'
$json=Join-Path $Repo 'artifacts\aa-fr-cache-prerequisites\intake-metadata.json'
$data=Read-Pinned $json (Hash $json) 1048576;Check ($null -ne $data) 'existing C pinned bytes parse'
Refuse {Read-Pinned $json ('0'*64) 1048576} 'wrong digest refused'
Refuse {Read-Pinned $json (Hash $json) 2} 'oversize refused'
foreach($name in @('Build-FreshPreflight.ps1','Capture-FreshPreflight.ps1','Test-FreshPreflight.ps1')){$e=$null;$t=$null;[void][Management.Automation.Language.Parser]::ParseFile((Join-Path $SourceDirectory $name),[ref]$t,[ref]$e);Check ($e.Count -eq 0) ('parse '+$name)}
foreach($name in @('SourceLinkedInterop.cs','SourceLinkedCache.cs','FixtureSupport.cs','NuGet.Config')){Check ((Hash (Join-Path $SourceDirectory $name)) -ceq (Hash (Join-Path $Repo ('artifacts\aa-fr-cache-prerequisites\'+$name)))) ('old algorithm/support bytes preserved '+$name)}
[xml]$project=Get-Content -LiteralPath (Join-Path $SourceDirectory 'CachePrerequisites.csproj') -Raw
Check (($project.Project.ItemGroup.Compile.Include -join ',') -ceq 'Program.cs,SourceLinkedInterop.cs,SourceLinkedCache.cs,FixtureSupport.cs') 'exact four compile inputs'
$ownershipCases=@()
foreach($fault in @('none','start-false','start-throw','wait-throw','wait-false','status-throw','status-false','streams-start','streams-result','release','process-dispose','mutex-dispose')){
 $state=New-FreshReaderState;$state.ownsProcess=$true;$state.held=$true
 $fake=[pscustomobject]@{fault=$fault;calls=[Collections.Generic.List[string]]::new();retainedState=$null}
 $backend={param($action,$s)
  $fake.calls.Add($action)
  switch($action){
   Start {if($fake.fault -eq 'start-throw'){throw 'injected start unknown'};return ($fake.fault -ne 'start-false')}
   BeginStreams {if($fake.fault -eq 'streams-start'){throw 'injected stream setup'};return}
   Wait {if($fake.fault -eq 'wait-throw'){throw 'injected wait failure'};return ($fake.fault -ne 'wait-false')}
   HasExited {if($fake.fault -eq 'status-throw'){throw 'injected exit observation failure'};return ($fake.fault -ne 'status-false')}
   CompleteStreamsAndResult {if($fake.fault -eq 'streams-result'){throw 'injected stream completion'};return [pscustomobject]@{exitCode=0}}
   DisposeProcess {if($fake.fault -eq 'process-dispose'){throw 'injected process dispose'};return}
   ReleaseMutex {if($fake.fault -eq 'release'){throw 'injected release'};return}
   DisposeMutex {if($fake.fault -eq 'mutex-dispose'){throw 'injected mutex dispose'};return}
   Retain {$fake.retainedState=$s;return}
   default {throw 'Unexpected fake action'}
  }
 }.GetNewClosure()
 $errorText=$null
 try{$null=Invoke-FreshOwnedReader $state $backend}catch{$errorText=$_.Exception.Message}finally{Complete-FreshReaderLease $state $backend}
 $unknown=$fault -in @('start-throw','wait-throw','wait-false','status-throw','status-false')
 if($unknown){
  Check (-not $state.exitConfirmed -and $state.held -and $state.retained -and -not $state.processDisposed -and -not $state.mutexDisposed) ('unconfirmed keeps ownership '+$fault)
  Check (-not $fake.calls.Contains('ReleaseMutex') -and -not $fake.calls.Contains('DisposeMutex') -and -not $fake.calls.Contains('DisposeProcess')) ('no release/dispose on unknown '+$fault)
  Check ([object]::ReferenceEquals($state,$fake.retainedState) -and $null -ne $state.primaryError -and $state.cleanupErrors.Count -gt 0) ('retains exact state and failure '+$fault)
 }elseif($fault -eq 'none'){
  Check ($state.exitConfirmed -and $state.waitCompleted -and $state.streamsCompleted -and $state.processDisposed -and $state.mutexDisposed -and -not $state.held -and -not $state.retained) 'normal positively completes'
  Check (($fake.calls -join ',') -ceq 'Start,BeginStreams,Wait,HasExited,CompleteStreamsAndResult,DisposeProcess,ReleaseMutex,DisposeMutex') 'production orchestration order'
 }elseif($fault -eq 'start-false'){
  Check ($state.startReturned -and -not $state.started -and -not $state.exitConfirmed -and $state.processDisposed -and -not $state.held -and $state.mutexDisposed) 'explicit no-start safely releases without fake exit'
  Check (-not $fake.calls.Contains('Wait') -and $null -ne $state.primaryError) 'no-start preserves failure'
 }elseif($fault -in @('streams-start','streams-result')){
  Check ($state.exitConfirmed -and -not $state.streamsCompleted -and $state.retained -and -not $state.processDisposed -and -not $state.held) ('actual exit safe but stream refs retained '+$fault)
  Check ($null -ne $state.primaryError -and [object]::ReferenceEquals($state,$fake.retainedState)) ('primary stream failure retained '+$fault)
 }else{
  Check ($state.exitConfirmed -and $state.retained -and $state.cleanupErrors.Count -gt 0) ('cleanup failure retained '+$fault)
  if($fault -eq 'release'){Check ($state.held -and -not $fake.calls.Contains('DisposeMutex')) 'failed release never disposes held mutex'}
 }
 Check (@($fake.calls|Where-Object {$_ -eq 'Wait'}).Count -le 1) ('failed wait not silently retried '+$fault)
 $ownershipCases+=[ordered]@{fault=$fault;exitConfirmed=$state.exitConfirmed;leaseStillHeld=$state.held;retained=$state.retained;calls=@($fake.calls);primaryError=$errorText}
}
$state=New-FreshReaderState;$state.held=$true;$calls=[Collections.Generic.List[string]]::new()
Complete-FreshReaderLease $state {param($action,$s)$calls.Add($action)}
Check (-not $state.startAttempted -and -not $state.exitConfirmed -and -not $state.held -and ($calls -join ',') -ceq 'ReleaseMutex,DisposeMutex') 'pre-start failure releases without claiming reader exit'
$contract=Get-Content -LiteralPath (Join-Path $Repo 'artifacts\aa-fr-cache-prerequisites\cache-prerequisites-contract.json') -Raw|ConvertFrom-Json
$warm=Get-Content -LiteralPath (Join-Path $Repo 'artifacts\aa-fr-cache-prerequisites\warm-stamp-result.json') -Raw|ConvertFrom-Json
Assert-FreshCacheLeaves $warm $contract;Check $true 'actual retained-C absent-leaf sample satisfies new predicate only'
foreach($fault in @('present','wrong-leaf','duplicate','missing','extra','chain-hash','chain-absent','chain-manifest','chain-precreate','mod-manifest','mod-hash','mod-precreate','string-boolean','profile','mod-directory')){
 $bad=$warm|ConvertTo-Json -Depth 50|ConvertFrom-Json
 switch($fault){
  present {$bad.cache_leaves[1].exists_now=$true;$bad.cache_leaves[1].needs_precreation=$false}
  wrong-leaf {$bad.cache_leaves[1].leaf='other.dat'}
  duplicate {$bad.cache_leaves=@($bad.cache_leaves[0],$bad.cache_leaves[0])}
  missing {$bad.cache_leaves=@($bad.cache_leaves[0])}
  extra {$bad.cache_leaves=@($bad.cache_leaves)+@($bad.cache_leaves[1])}
  chain-hash {$bad.cache_leaves[0].sha256='0'*64}
  chain-absent {$bad.cache_leaves[0].exists_now=$false}
  chain-manifest {$bad.cache_leaves[0].in_saved_manifest=$false}
  chain-precreate {$bad.cache_leaves[0].needs_precreation=$true}
  mod-manifest {$bad.cache_leaves[1].in_saved_manifest=$true}
  mod-hash {$bad.cache_leaves[1].sha256='0'*64}
  mod-precreate {$bad.cache_leaves[1].needs_precreation=$false}
  string-boolean {$bad.cache_leaves[1].exists_now='false'}
  profile {$bad.selected_profile='other'}
  mod-directory {$bad.selected_mod_directory+='-other'}
 }
 Refuse {Assert-FreshCacheLeaves $bad $contract} ('fresh cache rejects '+$fault)
}
[pscustomobject]@{scope='source functions with synthetic data and C file reads only';passed=$true;checks=$count;ownershipCases=$ownershipCases;host=$PSVersionTable.PSVersion.ToString();collectorExecuted=$false;liveEnvironmentRead=$false;stageRead=$false;nativeExecuted=$false}|ConvertTo-Json -Depth 7 -Compress
