param([Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$Repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$artifact=$Repo+'\artifacts\aa-fr-fresh-preflight-next-run-20261113';$ResultPath=[IO.Path]::GetFullPath($ResultPath)
if(-not $ResultPath.StartsWith($artifact+'\',[StringComparison]::Ordinal) -or (Test-Path -LiteralPath $ResultPath)){throw 'New bounded C test result required'}
$checks=[Collections.Generic.List[object]]::new();$fixture=Join-Path $artifact ('fixture-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($fixture)
$report=[ordered]@{schema=1;scope='new-run caller and production input validation, synthetic C-only fixtures';host=$PSVersionTable.PSVersion.ToString();passed=$false;error=$null;collectorExecuted=$false;stageRead=$false;identityCaptured=$false;sharedCaptured=$false;registryAccess=$false;nativeExecuted=$false;fixture=$fixture}
function Check([bool]$ok,[string]$name){$checks.Add([pscustomobject]@{name=$name;passed=$ok});if(-not $ok){throw ('ASSERT '+$name)}}
function Refuse([scriptblock]$body,[string]$name,[string]$expected){$errorText=$null;try{& $body|Out-Null}catch{$errorText=$_.Exception.Message};Check ($errorText -and $errorText -like ('*'+$expected+'*')) $name}
function Load-Function([string]$path,[string]$name){$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Source parse failed'};$nodes=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object Name -CEQ $name);if($nodes.Count -ne 1){throw ('Production function missing: '+$name)};return [scriptblock]::Create($nodes[0].Extent.Text)}
function Save([string]$path,$value){[IO.File]::WriteAllText($path,($value|ConvertTo-Json -Depth 15 -Compress),[Text.UTF8Encoding]::new($false))}
function Test-FreshPreflightSourceLineage([string]$SourceDirectory){
 # This function can be extracted independently by SOURCE checks. It never
 # invokes the collector entrypoint or writes a harmless receipt.
 $path=Join-Path $SourceDirectory 'Capture-FreshPreflight.ps1'
 foreach($name in @('Assert-True','Test-HarmlessReceiptKind','Assert-HarmlessReceipt')){. (Load-Function $path $name)}
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
 Check ($errors.Count -eq 0) 'lineage source parses'
 $assignment=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left -is [Management.Automation.Language.VariableExpressionAst] -and $n.Left.VariablePath.UserPath -ceq 'nativePin'},$true))
 Check ($assignment.Count -eq 1) 'one actual Full pin assignment'
 $values=@($assignment[0].Right.FindAll({param($n)$n -is [Management.Automation.Language.StringConstantExpressionAst]},$true));Check ($values.Count -eq 1) 'one literal Full pin'
 $shared='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'
 $sample=[pscustomobject]@{schema=2;scope='actual-native-full-restricted-cleanup-lifecycle';passed=$true;productionTargetExecuted=$false;actualSuspendedTokenAndJob=$true;pipeHandleListAndEOF=$true;cleanupVerified=$true;cleanupEvidenceProtocol='cleanup-ordering.v1';outerDesktopHeldUntilJobDrain=$true;bootstrapExitCleanupObserved=$true;cleanupTraceComplete=$true;externalLiveDescendantIntervalClaimed=$false;nativeSourceSha256='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533';sharedNativeSourceSha256=$shared;testOnlySimulated=$true}
 Assert-HarmlessReceipt $sample $values[0].Value $shared;Check $true 'cf95 in-memory source vector uses actual lineage predicate'
 $sample.nativeSourceSha256='d599e0431f075c5941d55b761307881213035fcaaaf5189c73babe6eb6710892'
 Refuse {Assert-HarmlessReceipt $sample $values[0].Value $shared} 'old cleanup source lineage rejected' 'same-source'
}
try{
 Test-FreshPreflightSourceLineage $PSScriptRoot
 $run='963b80c1ea494ed48098f2ee11bb8997';$build=$Repo+'\artifacts\aa-fr-fresh-preflight-tooling\build4'
 $baselinePath=Join-Path $fixture 'baseline.json';$beforePath=Join-Path $fixture 'before.json'
 $plan=& (Join-Path $PSScriptRoot 'Capture-FreshPreflight.ps1') -RunId $run -BuildDirectory $build -BaselineCaptureResultPath $baselinePath -ExpectedBaselineCaptureResultSha256 ('1'*64)
 $plan=($plan -join "`n")|ConvertFrom-Json
 Check ($plan.runId -ceq $run -and $plan.helperBuild -ceq $build -and $plan.baselineCaptureResultPath -ceq $baselinePath -and -not $plan.willExecute -and -not $plan.willReadStage) 'actual new-run public Plan binds supplied paths without executing'
 $legacy=& (Join-Path $PSScriptRoot 'Capture-FreshPreflight.ps1');$legacy=($legacy -join "`n")|ConvertFrom-Json
 Check ($legacy.runId -ceq '2fc0eb21404d4efaaf527c07c295d147' -and -not $legacy.willExecute) 'legacy defaults remain Plan-only compatible'
 foreach($badRun in @(('0'*32),$run.ToUpperInvariant(),$run.Substring(1),($run+'a'),($run+"`n"),'')){Refuse {& (Join-Path $PSScriptRoot 'Capture-FreshPreflight.ps1') -RunId $badRun} ('public Plan refuses invalid run '+$badRun.Length) 'canonical nonzero'}
 Refuse {& (Join-Path $PSScriptRoot 'Capture-FreshPreflight.ps1') -RunId $run -BuildDirectory 'F:\unrelated\build4'} 'capture refuses out-of-bound build before filesystem access' 'Build directory'
 foreach($name in @('Assert-True','Hash','Read-Pinned','Assert-CPath','Read-FreshPreflightRunInputs')){. (Load-Function (Join-Path $PSScriptRoot 'Capture-FreshPreflight.ps1') $name)}
 $baseline=[pscustomobject]@{schema=1;scope='read-only-stage-baseline-capture';runId=$run;success=$true;observedObjects=1228;observedUtc='2030-01-01T00:00:10Z';lease=[pscustomobject]@{mutex='Global\AzuriteRestrictedCli-AA';heldFromUtc='2030-01-01T00:00:00Z';releasedUtc='2030-01-01T00:00:10.9Z';state='released'};error=$null;willWriteF=$false;runtimeAllowed=$false;launchPermission=$false;baselineSha256=('b'*64)}
 $before=[pscustomobject]@{schema=1;runId=$run;phase='Before';capturedUtc='2030-01-01T00:00:11Z'}
 Save $baselinePath $baseline;Save $beforePath $before;$now=[DateTimeOffset]::Parse('2030-01-01T00:00:12Z')
 $inputs=Read-FreshPreflightRunInputs $run $baselinePath (Hash $baselinePath) $beforePath (Hash $beforePath) $now
 Check ($inputs.runId -ceq $run -and $inputs.baseline.success -and $inputs.sharedBefore.runId -ceq $run -and $inputs.sharedTime -eq [DateTimeOffset]::Parse('2030-01-01T00:00:11Z')) 'actual production C readers accept same-run completed chronology'
 Check ((Read-Pinned $baselinePath (Hash $baselinePath) 1048576).observedUtc -is [string]) 'pinned JSON preserves instant strings on this host'
 Refuse {Read-FreshPreflightRunInputs ('0'*32) $baselinePath (Hash $baselinePath) $beforePath (Hash $beforePath) $now} 'production validation rejects zero run' 'canonical nonzero'
 Refuse {Read-FreshPreflightRunInputs $run $baselinePath ('0'*64) $beforePath (Hash $beforePath) $now} 'baseline wrong external digest' 'Pinned bytes mismatch'
 Refuse {Read-FreshPreflightRunInputs $run $baselinePath (Hash $baselinePath) $beforePath ('0'*64) $now} 'shared Before wrong external digest' 'Pinned bytes mismatch'
 $originalBaseline=[IO.File]::ReadAllText($baselinePath);$originalBefore=[IO.File]::ReadAllText($beforePath)
 foreach($fault in @('wrong-run','failed','string-success','wrong-scope','wrong-count','string-count','error','lease-held','lease-inverted','lease-too-late','baseline-after-shared','baseline-future','invalid-observed','write-claim','runtime-claim','launch-claim')){
  $b=$originalBaseline|ConvertFrom-Json;$s=$originalBefore|ConvertFrom-Json
  switch($fault){
   'wrong-run' {$b.runId='a'*32}
   'failed' {$b.success=$false}
   'string-success' {$b.success='true'}
   'wrong-scope' {$b.scope='other'}
   'wrong-count' {$b.observedObjects=1227}
   'string-count' {$b.observedObjects='1228'}
   'error' {$b.error='capture failed'}
   'lease-held' {$b.lease.state='held'}
   'lease-inverted' {$b.lease.heldFromUtc='2030-01-01T00:00:11Z'}
   'lease-too-late' {$b.lease.releasedUtc='2030-01-01T00:00:13Z'}
   'baseline-after-shared' {$b.observedUtc='2030-01-01T00:00:12Z';$b.lease.releasedUtc='2030-01-01T00:00:12Z'}
   'baseline-future' {$b.observedUtc='2031-01-01T00:00:10Z';$b.lease.releasedUtc='2031-01-01T00:00:10Z';$s.capturedUtc='2031-01-01T00:00:11Z'}
   'invalid-observed' {$b.observedUtc='not-a-time'}
   'write-claim' {$b.willWriteF=$true}
   'runtime-claim' {$b.runtimeAllowed=$true}
   'launch-claim' {$b.launchPermission=$true}
  }
  Save $baselinePath $b;Save $beforePath $s
  Refuse {Read-FreshPreflightRunInputs $run $baselinePath (Hash $baselinePath) $beforePath (Hash $beforePath) $now} ('baseline rejects '+$fault) ''
 }
 [IO.File]::WriteAllText($baselinePath,$originalBaseline,[Text.UTF8Encoding]::new($false))
 foreach($fault in @('wrong-run','wrong-phase','before-baseline','before-release','future','invalid-time')){
  $s=$originalBefore|ConvertFrom-Json
  switch($fault){'wrong-run'{$s.runId='c'*32};'wrong-phase'{$s.phase='After'};'before-baseline'{$s.capturedUtc='2030-01-01T00:00:09Z'};'before-release'{$s.capturedUtc='2030-01-01T00:00:10.5Z'};'future'{$s.capturedUtc='2030-01-01T00:00:13Z'};'invalid-time'{$s.capturedUtc='invalid'}}
  Save $beforePath $s;Refuse {Read-FreshPreflightRunInputs $run $baselinePath (Hash $baselinePath) $beforePath (Hash $beforePath) $now} ('shared Before rejects '+$fault) ''
 }
 $output=$Repo+'\artifacts\aa-fr-fresh-preflight-tooling\candidate-'+[guid]::NewGuid().ToString('N')
 $buildPlan=& (Join-Path $PSScriptRoot 'Build-FreshPreflight.ps1') -OutputDirectory $output;$buildPlan=($buildPlan -join "`n")|ConvertFrom-Json
 Check ($buildPlan.output -ceq $output -and -not $buildPlan.willBuild -and -not(Test-Path -LiteralPath $output)) 'public build Plan uses new output without creating it'
 Refuse {& (Join-Path $PSScriptRoot 'Build-FreshPreflight.ps1') -Build -OutputDirectory ($Repo+'\artifacts\aa-fr-fresh-preflight-tooling\build3')} 'actual build caller refuses existing output before compilation' 'output must be new'
 Refuse {& (Join-Path $PSScriptRoot 'Build-FreshPreflight.ps1') -Build} 'actual build caller requires explicit output' 'explicit OutputDirectory'
 foreach($outside in @('F:\unrelated\build4',($Repo+'\artifacts\other\build4'),($Repo+'\artifacts\aa-fr-fresh-preflight-tooling\nested\build4'),($Repo+'\artifacts\aa-fr-fresh-preflight-tooling\..\escape'),($Repo+'\artifacts\aa-fr-fresh-preflight-tooling'))){Refuse {& (Join-Path $PSScriptRoot 'Build-FreshPreflight.ps1') -OutputDirectory $outside} 'build caller rejects outside/nested/noncanonical output' 'Build output'}
 Check (-not(Test-Path -LiteralPath $output)) 'all caller tests left proposed build output absent'
 $report.passed=$true
}catch{$report.error=[pscustomobject]@{message=$_.Exception.ToString();stack=$_.ScriptStackTrace};$report.passed=$false}
$report.checks=$checks.ToArray();$report.checkCount=$checks.Count;$report.captureSha256=(Get-FileHash (Join-Path $PSScriptRoot 'Capture-FreshPreflight.ps1')).Hash.ToLowerInvariant();$report.buildScriptSha256=(Get-FileHash (Join-Path $PSScriptRoot 'Build-FreshPreflight.ps1')).Hash.ToLowerInvariant();$report.testSha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant()
[IO.File]::WriteAllText($ResultPath,($report|ConvertTo-Json -Depth 15),[Text.UTF8Encoding]::new($false))
[ordered]@{passed=$report.passed;checks=$report.checkCount;host=$report.host;result=$ResultPath;error=$report.error}|ConvertTo-Json -Depth 5
if(-not $report.passed){exit 1}
