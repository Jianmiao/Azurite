[CmdletBinding()]
param([switch]$Build,[string]$ReviewedSourceIndexSha256,[string]$DotnetPath,[string]$DotnetSha256,[string]$OutputDirectory='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-fresh-preflight-tooling\build3')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$destination=[IO.Path]::GetFullPath($OutputDirectory)
if($destination -cne $OutputDirectory -or (Split-Path -Parent $destination) -cne ($repo+'\artifacts\aa-fr-fresh-preflight-tooling') -or [IO.Path]::GetFileName($destination) -cnotmatch '\A[A-Za-z0-9][A-Za-z0-9_.-]*\z'){throw 'Build output must be an exact direct child of the fixed C tooling directory'}
if($Build -and -not $PSBoundParameters.ContainsKey('OutputDirectory')){throw 'Build requires explicit OutputDirectory'}
if($Build -and (Test-Path -LiteralPath $destination)){throw 'Preserve existing build; output must be new'}
if(-not $Build){[ordered]@{scope='fresh-preflight-build-plan';acceptanceStatus='not-reviewed-not-built-not-collected';output=$destination;willBuild=$false;willReadStage=$false;willCollect=$false}|ConvertTo-Json;return}
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Require([bool]$b,[string]$why){if(-not $b){throw $why}}
Require ($PSScriptRoot -ceq ($repo+'\AcceptanceHarness\FullRestricted.FreshPreflight')) 'Exact source directory required'
Require ($ReviewedSourceIndexSha256 -cmatch '^[a-f0-9]{64}$' -and (Hash ($PSScriptRoot+'\source-index.json')) -ceq $ReviewedSourceIndexSha256) 'Reviewed source index required'
$index=Get-Content -LiteralPath ($PSScriptRoot+'\source-index.json') -Raw -Encoding UTF8|ConvertFrom-Json
foreach($f in $index.files){Require ($f.path -cmatch '^[A-Za-z0-9_.-]+$') 'Source must be one leaf';Require ((Hash ($PSScriptRoot+'\'+$f.path)) -ceq $f.sha256) ('Source changed: '+$f.path)}
Require ($DotnetSha256 -cmatch '^[a-f0-9]{64}$' -and (Hash $DotnetPath) -ceq $DotnetSha256) 'Explicit compiler host pin required'
$sourceProcess=$repo+'\AcceptanceHarness\FullRestricted.NativeFixture\DesktopMonitor9974\SourceProcess.psm1'
$sourceProcessHash='ce2a95b4674847d02625de2dac258427223fe753e15e1aa1c3dd118046349e9c'
Require ((Hash $sourceProcess) -ceq $sourceProcessHash) 'Reviewed SOURCE process supervisor changed'
Import-Module $sourceProcess -Force
Require (-not (Test-Path -LiteralPath $destination)) 'Preserve existing build; output must be new'
$parent=Split-Path -Parent $destination
$cursor=Get-Item -LiteralPath (Split-Path -Parent $parent)
while($null -ne $cursor){Require (($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) 'Reparse output ancestry';$cursor=$cursor.Parent}
if(-not (Test-Path -LiteralPath $parent)){[void][IO.Directory]::CreateDirectory($parent)}
Require (((Get-Item -LiteralPath $parent).Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) 'Reparse build parent'
[void][IO.Directory]::CreateDirectory($destination)
$source=$destination+'\source';[void][IO.Directory]::CreateDirectory($source)
foreach($name in @('Program.cs','SourceLinkedInterop.cs','SourceLinkedCache.cs','FixtureSupport.cs','CachePrerequisites.csproj','NuGet.Config')){[IO.File]::Copy(($PSScriptRoot+'\'+$name),($source+'\'+$name),$false)}
# Build only. Never invoke CachePrerequisites.dll or its apphost here.
$buildArguments=@('build',($source+'\CachePrerequisites.csproj'),'--configuration','Release','--output',$destination,('/p:RestoreConfigFile='+$source+'\NuGet.Config'),'/p:UseAppHost=false','/p:NuGetAudit=false')
$buildProcess=Invoke-FixtureSourceProcess -File $DotnetPath -Arguments $buildArguments -Record ($destination+'\build-process.json') -Directory $source -BoundMs 60000
[IO.File]::WriteAllText(($destination+'\build.log'),($buildProcess.stdout+$buildProcess.stderr),[Text.UTF8Encoding]::new($false))
$buildExit=$buildProcess.exitCode
if($buildExit -ne 0){throw ('Build failed; directory/log retained; exit '+$buildExit)}
$versionProcess=Invoke-FixtureSourceProcess -File $DotnetPath -Arguments @('--version') -Record ($destination+'\version-process.json') -Directory $source -BoundMs 30000
Require ($versionProcess.exitCode -eq 0) 'Compiler version query failed'
$compilerVersion=$versionProcess.stdout.Trim()
$provenance=[ordered]@{schema=1;sourceIndexSha256=$ReviewedSourceIndexSha256;dotnetPath=$DotnetPath;dotnetSha256=$DotnetSha256;compilerVersion=$compilerVersion;sourceProcessSha256=$sourceProcessHash;buildProcessSha256=(Hash ($destination+'\build-process.json'));versionProcessSha256=(Hash ($destination+'\version-process.json'));buildExitCode=$buildExit;runtimeExecuted=$false;stageRead=$false;productionTargetExecuted=$false;sourceFiles=@(Get-ChildItem -LiteralPath $source -File|Sort-Object Name|ForEach-Object {[ordered]@{path=$_.Name;sha256=(Hash $_.FullName)}})}
[IO.File]::WriteAllText(($destination+'\build-provenance.json'),(($provenance|ConvertTo-Json -Depth 6)+"`n"),(New-Object Text.UTF8Encoding($false)))
$files=@(Get-ChildItem -LiteralPath $destination -File|Sort-Object Name|ForEach-Object {[ordered]@{path=$_.Name;bytes=$_.Length;sha256=(Hash $_.FullName)}})
$manifest=[ordered]@{schema=1;sourceIndexSha256=$ReviewedSourceIndexSha256;runtimeExecuted=$false;stageRead=$false;files=$files}
[IO.File]::WriteAllText(($destination+'\manifest.json'),(($manifest|ConvertTo-Json -Depth 6)+"`n"),(New-Object Text.UTF8Encoding($false)))
[ordered]@{manifestPath=($destination+'\manifest.json');sha256=(Hash ($destination+'\manifest.json'));runtimeExecuted=$false;stageRead=$false}|ConvertTo-Json
