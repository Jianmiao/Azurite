using System; using System.IO; using System.Text; using System.Collections.Generic; using System.Security.Cryptography; using BepInEx.Logging; using BepInEx.Core.Logging.Interpolation;
public static class SourceLinkedCache {
 public sealed class Flag { public bool Value=true; }
 static readonly Flag EnableAssemblyCache=new Flag();
public static Dictionary<string, CachedAssembly<T>> LoadAssemblyCache<T>(string cacheName) where T : ICacheable, new()
		{
			if (!EnableAssemblyCache.Value)
			{
				return null;
			}
			Dictionary<string, CachedAssembly<T>> dictionary = new Dictionary<string, CachedAssembly<T>>();
			try
			{
				string path = Path.Combine(Paths.CachePath, cacheName + "_typeloader.dat");
				if (!File.Exists(path))
				{
					return null;
				}
				using BinaryReader binaryReader = new BinaryReader(File.OpenRead(path));
				int num = binaryReader.ReadInt32();
				for (int i = 0; i < num; i++)
				{
					string key = binaryReader.ReadString();
					string hash = binaryReader.ReadString();
					int num2 = binaryReader.ReadInt32();
					List<T> list = new List<T>();
					for (int j = 0; j < num2; j++)
					{
						T item = new T();
						item.Load(binaryReader);
						list.Add(item);
					}
					dictionary[key] = new CachedAssembly<T>
					{
						Hash = hash,
						CacheItems = list
					};
				}
			}
			catch (Exception ex)
			{
				LogLevel logLevel = LogLevel.Warning;
				bool isEnabled;
				BepInExLogInterpolatedStringHandler bepInExLogInterpolatedStringHandler = new BepInExLogInterpolatedStringHandler(58, 2, logLevel, out isEnabled);
				if (isEnabled)
				{
					bepInExLogInterpolatedStringHandler.AppendLiteral("Failed to load cache \"");
					bepInExLogInterpolatedStringHandler.AppendFormatted(cacheName);
					bepInExLogInterpolatedStringHandler.AppendLiteral("\"; skipping loading cache. Reason: ");
					bepInExLogInterpolatedStringHandler.AppendFormatted(ex.Message);
					bepInExLogInterpolatedStringHandler.AppendLiteral(".");
				}
				BepInEx.Logging.Logger.Log(logLevel, bepInExLogInterpolatedStringHandler);
			}
			return dictionary;
		}
public static void SaveAssemblyCache<T>(string cacheName, Dictionary<string, List<T>> entries, Dictionary<string, string> hashes) where T : ICacheable
		{
			if (!EnableAssemblyCache.Value)
			{
				return;
			}
			try
			{
				if (!Directory.Exists(Paths.CachePath))
				{
					Directory.CreateDirectory(Paths.CachePath);
				}
				using BinaryWriter binaryWriter = new BinaryWriter(File.OpenWrite(Path.Combine(Paths.CachePath, cacheName + "_typeloader.dat")));
				binaryWriter.Write(entries.Count);
				foreach (KeyValuePair<string, List<T>> entry in entries)
				{
					binaryWriter.Write(entry.Key);
					binaryWriter.Write(hashes.TryGetValue(entry.Key, out var value) ? value : "");
					binaryWriter.Write(entry.Value.Count);
					foreach (T item in entry.Value)
					{
						item.Save(binaryWriter);
					}
				}
			}
			catch (Exception ex)
			{
				LogLevel logLevel = LogLevel.Warning;
				bool isEnabled;
				BepInExLogInterpolatedStringHandler bepInExLogInterpolatedStringHandler = new BepInExLogInterpolatedStringHandler(57, 2, logLevel, out isEnabled);
				if (isEnabled)
				{
					bepInExLogInterpolatedStringHandler.AppendLiteral("Failed to save cache \"");
					bepInExLogInterpolatedStringHandler.AppendFormatted(cacheName);
					bepInExLogInterpolatedStringHandler.AppendLiteral("\"; skipping saving cache. Reason: ");
					bepInExLogInterpolatedStringHandler.AppendFormatted(ex.Message);
					bepInExLogInterpolatedStringHandler.AppendLiteral(".");
				}
				BepInEx.Logging.Logger.Log(logLevel, bepInExLogInterpolatedStringHandler);
			}
		}
}
