using System; using System.IO; using System.Text; using System.Collections.Generic;
public interface ICacheable { void Save(BinaryWriter writer); void Load(BinaryReader reader); }
public class CachedAssembly<T> where T:ICacheable { public List<T> CacheItems {get;set;} public string Hash {get;set;} }
public static class Paths { public static string CachePath; }
namespace BepInEx.Logging {
 public enum LogLevel { Warning }
 public static class Logger { public static readonly List<string> Warnings=new List<string>(); public static void Log(LogLevel level,object message){Warnings.Add(message.ToString());} }
}
namespace BepInEx.Core.Logging.Interpolation {
 public class BepInExLogInterpolatedStringHandler {
  readonly StringBuilder text=new StringBuilder();
  public BepInExLogInterpolatedStringHandler(int literal,int formatted,BepInEx.Logging.LogLevel level,out bool enabled){enabled=true;}
  public void AppendLiteral(string s){text.Append(s);} public void AppendFormatted<T>(T value){text.Append(value);} public override string ToString(){return text.ToString();}
 }
}
