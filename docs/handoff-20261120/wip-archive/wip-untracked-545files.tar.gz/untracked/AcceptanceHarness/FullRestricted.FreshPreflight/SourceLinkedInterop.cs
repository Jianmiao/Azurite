using System; using System.IO; using System.Text; using System.Collections.Generic; using System.Security.Cryptography; using BepInEx.Logging; using BepInEx.Core.Logging.Interpolation;
public static class SourceLinkedInterop {
 static string GameAssemblyPath=>Path.Combine(StampProgram.Install,"GameAssembly.dll");
 static string UnityBaseLibsDirectory=>Path.Combine(StampProgram.Install,"BepInEx","unity-libs");
 static string RenameMapPath=>Path.Combine(StampProgram.Install,"BepInEx","DeobfuscationMap.csv.gz");
public static string ComputeHash()
		{
			using (MD5 mD = MD5.Create())
			{
				HashFile(mD, GameAssemblyPath);
				if (Directory.Exists(UnityBaseLibsDirectory))
				{
					foreach (string item in Directory.EnumerateFiles(UnityBaseLibsDirectory, "*.dll", SearchOption.TopDirectoryOnly))
					{
						HashString(mD, Path.GetFileName(item));
						HashFile(mD, item);
					}
				}
				if (File.Exists(RenameMapPath))
				{
					HashFile(mD, RenameMapPath);
				}
				HashString(mD, StampProgram.GeneratorVersion);
				HashString(mD, StampProgram.Cpp2IlVersion);
				mD.TransformFinalBlock(new byte[0], 0, 0);
				return Utility.ByteArrayToString(mD.Hash);
			}
			static void HashFile(ICryptoTransform hash, string file) { StampProgram.FeedPinnedFile(hash, file); }
			static void HashString(ICryptoTransform hash, string str)
			{
				StampProgram.RecordString(str);
            byte[] bytes = Encoding.UTF8.GetBytes(str);
				hash.TransformBlock(bytes, 0, bytes.Length, bytes, 0);
			}
		}
}
public static class Utility {
public static string ByteArrayToString(byte[] data)
		{
			StringBuilder stringBuilder = new StringBuilder(data.Length * 2);
			foreach (byte b in data)
			{
				stringBuilder.AppendFormat("{0:x2}", b);
			}
			return stringBuilder.ToString();
		}
}
