using System;
using System.Collections.Generic;
using Azurite.NativeControl;
public static class AtomicPreparationTests {
 static int count;
 static void Check(bool b,string m){if(!b)throw new Exception(m);count++;}
 static void Reject(Action a,string m){bool rejected=false;try{a();}catch(Exception){rejected=true;}Check(rejected,m);}
 sealed class FakeApi:IAtomicApi {
  public readonly Dictionary<string,ObjectEvidence> Rows=new Dictionary<string,ObjectEvidence>();
  public AtomicRequest Last;public bool WrongLinks,WrongDescriptor,Reparse,Fail;
  public ObjectEvidence Create(AtomicRequest r){Last=r;if(Fail||Rows.ContainsKey(r.Path))throw new InvalidOperationException("create failed; no adoption");
   var e=new ObjectEvidence{path=r.Path,finalPath=r.Path,identity="123456780000000000000001",directory=r.Directory,reparse=Reparse,links=WrongLinks?2u:1u,owner="S-1-5-21-1-2-3-1001",ownerAccessSddl=WrongDescriptor?"O:SYD:P(A;;FA;;;SY)":AtomicCreator.CanonicalDescriptor(r.Sddl),sha256=r.Directory?null:AtomicCreator.Hash(r.Bytes),bytes=r.Directory?0:r.Bytes.Length,attributes=r.Directory?16u:32u,rawDescriptor=Convert.ToBase64String(r.Descriptor)};Rows.Add(r.Path,e);return e;}
 }
 sealed class FakeWin32:IWin32CreationApi {
  public bool DirectoryOkay=true,OpenFails,FileFails,ObserveFails;public int OpenCalls;public readonly List<IntPtr> Retained=new List<IntPtr>();
  public bool CreateDirectory(AtomicRequest r,out int error){error=DirectoryOkay?0:183;return DirectoryOkay;}
  public IntPtr CreateFile(AtomicRequest r,out int error){error=FileFails?80:0;return FileFails?new IntPtr(-1):new IntPtr(12);}
  public IntPtr OpenCreatedDirectory(AtomicRequest r,out int error){OpenCalls++;error=OpenFails?5:0;return OpenFails?new IntPtr(-1):new IntPtr(11);}
  public void Retain(IntPtr h){Retained.Add(h);}
  public ObjectEvidence WriteAndObserve(IntPtr h,AtomicRequest r){if(ObserveFails)throw new InvalidOperationException("readback mismatch");return new ObjectEvidence{path=r.Path,finalPath=r.Path,directory=r.Directory};}
 }
 public static string Run(){
  const string lab="C:\\fixed\\lab2",sd="O:S-1-5-21-1-2-3-1001D:P(A;;FA;;;S-1-5-21-1-2-3-1001)";
  var f=new FakeApi();var c=new AtomicCreator(lab,f);
  Reject(delegate{AtomicCreator.ValidateMetadata(lab,"\\\\?\\"+lab,0x410,1,1);},"native reparse attribute refuses");
  Reject(delegate{AtomicCreator.ValidateMetadata(lab,"\\\\?\\C:\\other",16,1,1);},"resolved path escape refuses");
  Reject(delegate{AtomicCreator.RequireAncestor(new ObjectEvidence{path=lab,finalPath=lab,directory=false,reparse=false});},"file ancestor refuses");
  Reject(delegate{c.New(lab+"\\..\\escape",false,sd,new byte[0]);},"path escape");
  Reject(delegate{c.New(lab+"-alias\\x",false,sd,new byte[0]);},"prefix confusion");
  Reject(delegate{c.New(lab+"\\x:stream",false,sd,new byte[0]);},"alternate stream");
  Reject(delegate{c.New(lab+"\\x.",false,sd,new byte[0]);},"trailing dot");
  Reject(delegate{c.New(lab,false,"O:SYD:(A;;FA;;;SY)",new byte[0]);},"unprotected DACL");
  c.New(lab,true,sd,null);Check(f.Last.Disposition==0&&f.Last.Flags==0x02200000&&f.Last.Share==1&&f.Last.Access==0x1200A9&&f.Last.Descriptor.Length>0&&!f.Last.Inherit,"atomic protected directory request and separate query flags");
  c.New(lab+"\\x",false,sd,new byte[]{1,2,3});Check(f.Last.Disposition==1&&f.Last.Flags==0x00200000&&f.Last.Share==1&&f.Last.Access==0xC0020000&&f.Last.Descriptor.Length>0&&!f.Last.Inherit,"atomic CREATE_NEW file descriptor");
  Reject(delegate{c.New(lab+"\\x",false,sd,new byte[0]);},"existing object refused");
  f.WrongLinks=true;Reject(delegate{c.New(lab+"\\links",false,sd,new byte[0]);},"run files single link");f.WrongLinks=false;
  f.Reparse=true;Reject(delegate{c.New(lab+"\\reparse",true,sd,null);},"reparse result refused");f.Reparse=false;
  f.WrongDescriptor=true;Reject(delegate{c.New(lab+"\\acl",false,sd,new byte[0]);},"descriptor mismatch refused");f.WrongDescriptor=false;
  f.Fail=true;Reject(delegate{c.New(lab+"\\failed",false,sd,new byte[0]);},"partial create error propagated");
  Check(c.Attempts.Count==7&&c.Attempts[c.Attempts.Count-1].Path==lab+"\\failed"&&!c.Attempts[c.Attempts.Count-1].Verified,"partial failure journal preserved");
  Check(WindowsAtomicApi.ValidateX64Layout().Contains("Descriptor+8"),"x64 SECURITY_ATTRIBUTES layout without native calls");
  var native=new FakeWin32();var request=new AtomicRequest{Path=lab,Directory=true,Creation=new CreationCall()};
  var directory=Win32AtomicCreate.Create(request,native);Check(directory.creationCallSucceeded&&directory.creationApi=="CreateDirectoryW"&&directory.handleOrigin=="post-create-query-handle"&&native.Retained.Count==1,"directory creation success never claims returned creation handle");
  native.DirectoryOkay=false;int before=native.OpenCalls;Reject(delegate{Win32AtomicCreate.Create(request,native);},"existing directory refused");Check(native.OpenCalls==before&&native.Retained.Count==1,"failed directory create cannot query/adopt existing object");native.DirectoryOkay=true;
  native.OpenFails=true;Reject(delegate{Win32AtomicCreate.Create(request,native);},"post-create open failure retained");Check(request.Creation.Succeeded&&request.Creation.HandleOrigin=="post-create-query-handle"&&native.Retained.Count==1,"directory creation success survives later query failure");native.OpenFails=false;
  native.ObserveFails=true;Reject(delegate{Win32AtomicCreate.Create(request,native);},"directory query mismatch refused");Check(native.Retained.Count==2,"query reference retained before mismatched object readback");native.ObserveFails=false;
  request=new AtomicRequest{Path=lab+"\\file",Directory=false,Creation=new CreationCall()};var file=Win32AtomicCreate.Create(request,native);Check(file.creationApi=="CreateFileW(CREATE_NEW)"&&file.handleOrigin=="creation-returned-handle"&&native.Retained.Count==3,"file owns actual creation handle");
  native.FileFails=true;Reject(delegate{Win32AtomicCreate.Create(request,native);},"file collision refused");Check(native.Retained.Count==3&&!request.Creation.Succeeded,"failed file creation invents no owner");native.FileFails=false;
  native.ObserveFails=true;Reject(delegate{Win32AtomicCreate.Create(request,native);},"file payload/descriptor readback failure");Check(native.Retained.Count==4,"actual created file handle retained before readback failure");
  return count+" atomic policy checks passed; fake API only";
 }
}
