#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)]$Context,[Parameter(Mandatory)][scriptblock]$Backend)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -DisableNameChecking
$l=Get-NativeLayout;$lab=$l.lab
Require-Native ($Context.mutexHeld -eq $true -and $Context.abandoned -eq $false -and $Context.originQpc -gt 0) 'Original nonabandoned mutex/clock required'
$null=Assert-NativeDeadline $Context.originQpc (& $Backend 'Qpc' $null) $Context.frequency
Assert-NativePreflight $Backend $lab $true
& $Backend 'LockAncestors' $lab | Out-Null
$id=& $Backend 'Identity' $Context.runId;Assert-NativeIdentity $id;$Context.identity=$id
$sid=$id.identitySid;$logon=$id.token.logon_sid
$privateDir='O:'+$sid+'D:P(A;OICI;FA;;;'+$sid+')(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)'
$privateFile='O:'+$sid+'D:P(A;;FA;;;'+$sid+')(A;;FA;;;SY)(A;;FA;;;BA)'
$traverse=$privateDir+'(A;;0x1200A9;;;'+$logon+')';$readFile=$privateFile+'(A;;0x120089;;;'+$logon+')';$readExe=$privateFile+'(A;;0x1200A9;;;'+$logon+')'
$request=$privateDir+'(A;;0x1200AB;;;'+$logon+')(A;OIIO;0x13019F;;;'+$logon+')';$mutable=$privateFile+'(A;;0x12019F;;;'+$logon+')'
$gate=& $Backend 'GateAcl' ([pscustomobject]@{userSid=$sid;logonSid=$logon})
$Context.privateFile=$privateFile;$Context.preparationStarted=$true
$run=$lab+'\runs\restricted-'+$Context.runId;$Context.run=$run
function Create-Prepared([string]$Path,[bool]$Directory,[string]$Sddl,[byte[]]$Bytes){
 $null=Assert-NativeOwnedPath $Path $lab
 $null=Assert-NativeDeadline $Context.originQpc (& $Backend 'Qpc' $null) $Context.frequency
 $attempt=[ordered]@{path=$Path;verified=$false;object=$null};$Context.attempts.Add($attempt)
 $o=& $Backend 'Create' ([pscustomobject]@{path=$Path;directory=$Directory;sddl=$Sddl;bytes=$Bytes})
 $attempt.object=$o;$Context.objects.Add($o)
 Assert-NativeObject $o $Path $Directory $sid ([Azurite.NativeControl.AtomicCreator]::CanonicalDescriptor($Sddl)) $(if($Directory){''}else{Get-NativeHash $Bytes})
 $attempt.verified=$true
}
Create-Prepared $lab $true $traverse $null
Create-Prepared ($lab+'\pending.json') $false $privateFile (ConvertTo-NativeBytes ([ordered]@{schema='native-control-pending.v1';runId=$Context.runId;packageSha256=$Context.packageSha256;hostPid=$Context.hostPid;hostCreationFileTime=$Context.hostCreationFileTime;originQpc=$Context.originQpc}))
foreach($dir in @('install','runs')){Create-Prepared ($lab+'\'+$dir) $true $traverse $null}
Create-Prepared $run $true $traverse $null
foreach($dir in @('request','output','workspace','tooling','control')){$acl=if($dir -ceq 'request'){$request}elseif($dir -ceq 'tooling'){$privateDir}elseif($dir -ceq 'control'){$gate.controlDirectory}else{$traverse};Create-Prepared ($run+'\'+$dir) $true $acl $null}
Create-Prepared ($run+'\tooling\evidence') $true $privateDir $null
foreach($name in @('AzuriteLifecycleProbe.exe','WaitNative.dll','WaitProbe.Managed.dll','WaitProbe.Managed.runtimeconfig.json')){$copy=& $Backend 'ReadPackage' $name;$Context.sources.Add($copy.evidence);Create-Prepared ($lab+'\install\'+$name) $false $(if($name.EndsWith('.json')){$readFile}else{$readExe}) $copy.bytes}
$canary='O:'+$sid+'D:P(A;;FA;;;'+$sid+')'
Create-Prepared ($lab+'\install\protected') $true $canary $null
Create-Prepared ($lab+'\install\protected\proof.bin') $false $canary ([Text.Encoding]::ASCII.GetBytes("AZURITE_WRITE_RESTRICTION_CANARY_V1`n"))
foreach($pair in @(@('source\FixtureBootstrap.ps1','RestrictedCliBootstrap.ps1'),@('source\FixtureRules.psm1','FixtureRules.psm1'),@('AzuriteLifecycle.FixtureOnly.dll','AzuriteLifecycle.FixtureOnly.dll'))){$copy=& $Backend 'ReadPackage' $pair[0];$Context.sources.Add($copy.evidence);Create-Prepared ($run+'\tooling\'+$pair[1]) $false $privateFile $copy.bytes}
$argsBytes=ConvertTo-NativeBytes ([ordered]@{argv=@('capabilities');cwd=($run+'\workspace')})
$input='runId='+$Context.runId+"`nscenario=normal`nuserSid="+$sid+"`nlogonSid="+$logon+"`nsession="+$id.token.session_id+"`nintegrityRid="+$id.token.integrity_rid+"`nmandatoryPolicy="+$id.token.mandatory_policy+"`n"
$inputBytes=[Text.UTF8Encoding]::new($false).GetBytes($input)
Create-Prepared ($run+'\request\arguments.json') $false $readFile $argsBytes
Create-Prepared ($run+'\request\fixture-input.txt') $false $readFile $inputBytes
Create-Prepared ($run+'\output\unity.log') $false $mutable ([byte[]]@())
$toolHashes=[ordered]@{};foreach($name in @('RestrictedCliBootstrap.ps1','FixtureRules.psm1','AzuriteLifecycle.FixtureOnly.dll')){$toolHashes[$name]=@($Context.objects|Where-Object{$_.path -ceq ($run+'\tooling\'+$name)})[0].sha256}
$control=[ordered]@{fixtureOnly=$true;productionTargetExecuted=$false;protocol='lease-control.v1';scenario='normal';runId=$Context.runId;packageSha256=$Context.packageSha256;userSid=$sid;logonSid=$logon;session=$id.token.session_id;integrityRid=$id.token.integrity_rid;mandatoryPolicy=$id.token.mandatory_policy;argumentsSha256=(Get-NativeHash $argsBytes);inputSha256=(Get-NativeHash $inputBytes);probeSha256=$Context.manifest.probeSha256;bootstrapSha256=$Context.manifest.bootstrapSha256;toolHashes=$toolHashes}
$controlBytes=ConvertTo-NativeBytes $control;$Context.control=$control;$Context.controlSha256=Get-NativeHash $controlBytes
Create-Prepared ($run+'\tooling\control.json') $false $privateFile $controlBytes
& $Backend 'AssertGatesAbsent' $run | Out-Null
$again=& $Backend 'Identity' $Context.runId;Require-Native ((Get-NativeHash (ConvertTo-NativeBytes $id)) -ceq (Get-NativeHash (ConvertTo-NativeBytes $again))) 'Original token changed during preparation'
$receipt=[ordered]@{schema='native-control-prepared.v1';prepared=$true;nativeExecuted=$false;packageSha256=$Context.packageSha256;controlSha256=$Context.controlSha256;runId=$Context.runId;run=$run;originQpc=$Context.originQpc;frequency=$Context.frequency;hostPid=$Context.hostPid;hostCreationFileTime=$Context.hostCreationFileTime;mutexHeld=$true;originalIdentity=$id;expectedChildContract=(Get-NativeExpectedChild $id);sources=$Context.sources.ToArray();objects=$Context.objects.ToArray()}
$qBytes=ConvertTo-NativeBytes $receipt;$Context.receipt=$receipt;$Context.receiptSha256=Get-NativeHash $qBytes
Create-Prepared ($run+'\tooling\prepared-run.json') $false $privateFile $qBytes
$Context.prepared=$true
return $Context
