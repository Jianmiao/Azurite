#requires -Version 5.1
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1){throw 'fresh x64 PS5.1 only'}
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -Force -DisableNameChecking
$staged=(Get-NativeLayout).evidence+'\staged-9974-rq2'
Import-Module ($staged+'\source\FixtureAcl.psm1') -Force -DisableNameChecking
$frozenSchema=[IO.File]::ReadAllText($staged+'\input-schema.json')|ConvertFrom-Json
$source="#define NATIVE_CONTROL_PURE`n"+[IO.File]::ReadAllText($PSScriptRoot+'\AtomicPreparation.cs')+"`n"+[IO.File]::ReadAllText($PSScriptRoot+'\AtomicPreparation.Tests.cs').Replace('using System;','').Replace('using System.Collections.Generic;','').Replace('using Azurite.NativeControl;','')
# Place test class within the implementation namespace without changing methods.
$source=$source.Replace('public static class AtomicPreparationTests {','namespace Azurite.NativeControl { public static class AtomicPreparationTests {')+"`n}"
Add-Type -TypeDefinition $source -Language CSharp -ErrorAction Stop
$atomic=[Azurite.NativeControl.AtomicPreparationTests]::Run()
$script:checks=[Collections.Generic.List[string]]::new()
function Check([bool]$Value,[string]$Name){if(-not $Value){throw ('FAIL: '+$Name)};$script:checks.Add($Name)}
function Reject([scriptblock]$Action,[string]$Name){$bad=$false;try{& $Action|Out-Null}catch{$bad=$true};Check $bad $Name}
Reject {[Azurite.NativeControl.WindowsAtomicApi]::new('C:\fixed\lab2')} 'native adapter cannot be constructed in pure build'
foreach($p in @('C:\fixed\lab2\..\escape','C:\fixed\lab2-extra\x','C:\fixed\lab2\x:stream','C:\fixed\lab2\x.','C:\fixed\lab2\x ','F:\lab2\x')){Reject {Assert-NativeOwnedPath $p 'C:\fixed\lab2'} ('reject path '+$p)}
Check ((Assert-NativeDeadline 100 10100 1000) -eq 15000) 'preparation consumes original budget'
Reject {Assert-NativeDeadline 100 25100 1000} 'cleanup reserve cannot be reset'
Reject {Assert-NativeDeadline 100 30100 1000 0} 'outer absolute deadline cannot be extended'
$l=Get-NativeLayout;$h='a'*64;$id='1'*32
$m=[pscustomobject]@{schema='native-control-admission.v1';protocol='lease-control.v1';runtimeAllowed=$true;sourceBuildOnly=$false;fixedLab=$l.lab;fixedParent=$l.parent;fixedPackage=$l.package;scenario='normal';generatedNativeCreateRestrictedTokenFlags=1;innerMs=10000;childMs=12000;outerMs=30000;cleanupMs=5000;validFromUtcTicks=1000;expiresUtcTicks=2000;parentManifestSha256='e8c83e763e7477ff2057caad6dbede6d4795db1923ef1f8e9afb97862a78146c';aclCanonicalReviewSha256='2c6477a238c405ac8995cc9aa552b9c9392dbf9e6bfeb93c1144369809392cbc';pumpCaptureReviewSha256='0e69dbefc78bc5849f85dd058ad21a231bac79b7333eb6714a54779b159d0c86';releaseQueryReviewSha256='05caf656d85cb74649d80ad796bceffdafca14a6859d177c0fbfda4177108126';desktopMonitorQualificationSha256='69713e0b57cbf46c9b9939008ae8d33e3c5f32ca4e99b6ee77106539f7e8ef7a';consumerReviewSha256='598b02e3b43a3b2e9f92ab64b2bddc78f790be25ee011cb2510f0276e1ed5f05';consumerPackageReviewSha256='c03a51a081978458c5be52914982bfc209cc3af0da947f4a018d8e22be7f84b7';fixtureRulesSha256='cf16be42aa10ce38cef64ff52d955406ffdc8a8828e65ac9d591a859a508e10d';taskAReview1Sha256=$h;taskAReview2Sha256=$h;preparationReviewSha256=$h;rootAuthorizationSha256=$h;productionSources=@{'RestrictedCliFullRestricted.cs'='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533';'RestrictedCliNative.cs'='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921'};files=@(@{path='source\Run-Fixture.ps1';sha256=$h;bytes=100});probeSha256=$h;bootstrapSha256=$h}
Assert-NativeManifest $m $h 1500;Check $true 'valid finite admission'
Reject {Assert-NativeManifest $m $h 2000} 'expired admission'
$m.sourceBuildOnly=$true;Reject {Assert-NativeManifest $m $h 1500} 'source-build cannot admit';$m.sourceBuildOnly=$false
$m.fixedLab+='-wrong';Reject {Assert-NativeManifest $m $h 1500} 'wrong compiled lab';$m.fixedLab=$l.lab
$m.files+=@{path='control.json';sha256=$h;bytes=1};Reject {Assert-NativeManifest $m $h 1500} 'manifest control self cycle';$m.files=@($m.files[0])
$fake=[pscustomobject]@{rows=@{};now=100;createCount=0;failAt=0;queryError=$false;targetPresent=$false;mutexAcquired=$true;abandoned=$false;identity=[pscustomobject]@{identitySid='S-1-5-21-1-2-3-1001';isAdministrator=$false;unexpectedPrivileges=@();token=[pscustomobject]@{logon_sid='S-1-5-5-123-456';is_restricted=$false;users_enabled=$true;session_id=1;integrity_rid=8192;integrity_attributes=96;mandatory_policy=1}}}
$backend={param($action,$arg)
 switch($action){
  AcquireMutex {return @{acquired=$fake.mutexAcquired;abandoned=$fake.abandoned}}
  Qpc {return $fake.now}
  QueryTargetProcesses {if($fake.queryError){throw 'query denied'};if($fake.targetPresent){return @{Name='AzureArchive.exe'}};return}
  Exists {return $fake.rows.ContainsKey([string]$arg)}
  LockAncestors {return}
  Identity {return $fake.identity}
  GateAcl {$plan=Get-LeaseGateAclPlan $arg.userSid $arg.logonSid;Assert-LeaseGateAclPlan $plan;return $plan}
  ReadPackage {$bytes=[Text.Encoding]::ASCII.GetBytes('fixed fake source '+$arg);return @{bytes=$bytes;evidence=@{path=$arg;sha256=(Get-NativeHash $bytes)}}}
  AssertGatesAbsent {foreach($leaf in @('control\lease-offer.json','control\lease-ack.json','control\go.json','request\child-ready.json','request\protection-result.json')){if($fake.rows.ContainsKey($arg+'\'+$leaf)){throw 'gate preexists'}};return}
  Create {$fake.createCount++;if($fake.failAt -eq $fake.createCount -or $fake.rows.ContainsKey($arg.path)){throw 'simulated atomic create failure'};$o=[pscustomobject]@{path=$arg.path;finalPath=$arg.path;identity=('1234567800000000'+$fake.createCount.ToString('x8'));owner=$fake.identity.identitySid;ownerAccessSddl=[Azurite.NativeControl.AtomicCreator]::CanonicalDescriptor($arg.sddl);directory=$arg.directory;reparse=$false;links=1;sha256=$(if($arg.directory){''}else{Get-NativeHash $arg.bytes});bytes=$arg.bytes;attributes=$(if($arg.directory){16}else{32})};$fake.rows[$arg.path]=$o;return $o}
  default {throw ('unexpected fake operation '+$action)}
 }
}.GetNewClosure()
function Context { [pscustomobject]@{runId=$id;packageSha256=$h;manifest=$m;originQpc=100L;frequency=1000L;hostPid=123;hostCreationFileTime=999L;mutexHeld=$false;abandoned=$false;identity=$null;privateFile=$null;preparationStarted=$false;prepared=$false;run=$null;control=$null;controlSha256=$null;receipt=$null;receiptSha256=$null;objects=[Collections.Generic.List[object]]::new();sources=[Collections.Generic.List[object]]::new();attempts=[Collections.Generic.List[object]]::new()} }
$ctx=Context;$fake.mutexAcquired=$false;Reject {Enter-NativeAdmission $ctx $backend} 'busy mutex';Check (-not $ctx.mutexHeld) 'busy mutex not owned'
$fake.mutexAcquired=$true;$fake.abandoned=$true;Reject {Enter-NativeAdmission $ctx $backend} 'abandoned mutex rejects';Check $ctx.mutexHeld 'abandoned acquired mutex retained';$fake.abandoned=$false
$fake.queryError=$true;Reject {Assert-NativePreflight $backend $l.lab $true} 'query error refuses';$fake.queryError=$false
$fake.targetPresent=$true;Reject {Assert-NativePreflight $backend $l.lab $true} 'existing AA refuses without termination';$fake.targetPresent=$false
$fake.rows['C:\unrelated\old-failure\pending.json']=1;Assert-NativePreflight $backend $l.lab $true;Check $true 'unrelated preserved failure is not active pending'
$fake.rows[$l.lab+'\pending.json']=1;Reject {Assert-NativePreflight $backend $l.lab $true} 'exact pending refuses';$fake.rows.Remove($l.lab+'\pending.json')
$ctx=Context;Enter-NativeAdmission $ctx $backend;$ctx=& ($PSScriptRoot+'\Prepare-Control.ps1') $ctx $backend
Check ($ctx.prepared -and $ctx.objects.Count -eq 25) 'real producer completed in-memory preparation'
Check ($ctx.control.Count -eq $frozenSchema.controlRequiredFields.Count -and @($frozenSchema.controlRequiredFields|Where-Object{$ctx.control.Keys -cnotcontains $_}).Count -eq 0) 'control matches final frozen build2 schema exactly'
Check ($ctx.receipt.originalIdentity.token.integrity_rid -eq 8192 -and $ctx.receipt.expectedChildContract.integrityRid -eq 8192 -and $ctx.receipt.expectedChildContract.derivation -ceq 'inherited-original-token.v1') 'original identity separated from inherited child contract'
$fake.identity.token.integrity_rid=4096;$fake.identity.token.mandatory_policy=0;$low=Get-NativeExpectedChild $fake.identity;Check ($low.integrityRid -eq 4096 -and $low.mandatoryPolicy -eq 0 -and $low.integrityAttributes -eq 96) 'child expectation inherits queried original policy rather than guessed Medium or Low';$fake.identity.token.integrity_rid=8192;$fake.identity.token.mandatory_policy=1
Assert-NativeBinding $ctx.receipt ([pscustomobject]$ctx.control) $h $ctx.controlSha256 $id 100 1000 123 999;Check $true 'acyclic P/Q/control binding'
Reject {Assert-NativeBinding $ctx.receipt ([pscustomobject]$ctx.control) ('b'*64) $ctx.controlSha256 $id 100 1000 123 999} 'wrong package binding'
Reject {Assert-NativeBinding $ctx.receipt ([pscustomobject]$ctx.control) $h ('b'*64) $id 100 1000 123 999} 'control tamper binding'
Reject {Assert-NativeBinding $ctx.receipt ([pscustomobject]$ctx.control) $h $ctx.controlSha256 $id 101 1000 123 999} 'receipt clock reset rejected'
Reject {Assert-NativeBinding $ctx.receipt ([pscustomobject]$ctx.control) $h $ctx.controlSha256 $id 100 1000 124 999} 'different host rejected'
$controlBytes=$fake.rows[$ctx.run+'\tooling\control.json'].bytes;Check ((Get-NativeHash $controlBytes) -ceq $ctx.receipt.controlSha256) 'Q binds actual generated control bytes'
$text=[Text.Encoding]::UTF8.GetString($fake.rows[$ctx.run+'\request\fixture-input.txt'].bytes);Check ($text -ceq ('runId='+$id+"`nscenario=normal`nuserSid=S-1-5-21-1-2-3-1001`nlogonSid=S-1-5-5-123-456`nsession=1`nintegrityRid=8192`nmandatoryPolicy=1`n")) 'seven ordered LF input fields'
Check ((Get-NativeHash $fake.rows[$l.lab+'\install\protected\proof.bin'].bytes) -ceq 'f73c5b91dbc65bf121fd36cfa7da58fbd1f49986e564f5efd1276d2722ff70b5') 'exact canary bytes'
$fake.rows=@{};$fake.createCount=0;$fake.failAt=6;$ctx=Context;$ctx.mutexHeld=$true
Reject {& ($PSScriptRoot+'\Prepare-Control.ps1') $ctx $backend} 'partial prepare failure propagated'
Check ($ctx.attempts.Count -eq 6 -and -not $ctx.attempts[5].verified -and $ctx.objects.Count -eq 5 -and $fake.rows.ContainsKey($l.lab+'\pending.json') -and $ctx.mutexHeld) 'partial records and pending retained'
$holdState=@{held=0;secondary=0};$hold={$holdState.held++}.GetNewClosure();$secondary={param($e)$holdState.secondary++}.GetNewClosure()
$primaryMessage=$null;try{Invoke-NativeHeldBoundary {throw 'PRIMARY'} {$true} {throw 'SNAPSHOT'} {throw 'JSON'} $hold $secondary}catch{$primaryMessage=$_.Exception.Message};Check ($primaryMessage -ceq 'PRIMARY') 'primary preserved while snapshot fails'
Check ($holdState.held -eq 1 -and $holdState.secondary -eq 1) 'snapshot failure cannot skip hold'
$holdState.held=0;Reject {Invoke-NativeHeldBoundary {throw 'PRIMARY'} {throw 'DECISION'} {return @{ok=1}} {throw 'SINK'} $hold $secondary} 'decision/sink failures fail closed'
Check ($holdState.held -eq 1) 'evidence write failure cannot bypass owner hold'
$holdState.held=0;$primaryMessage=$null;try{Invoke-NativeHeldBoundary {throw 'FIRST'} {$true} {@{ok=1}} {throw 'WRITE'} $hold $secondary}catch{$primaryMessage=$_.Exception.Message};Check ($primaryMessage -ceq 'FIRST' -and $holdState.held -eq 1) 'JSON/write failure preserves first error and hold'
Reject {& ($PSScriptRoot+'\Build-Admission.ps1') -Freeze} 'missing final parent/root hash refuses freezing before copy'
[pscustomobject]@{passed=$true;atomic=$atomic;powershellChecks=$script:checks.Count;checks=$script:checks.ToArray();nativeExecuted=$false;actualIdentityRead=$false;actualProcessQuery=$false;actualAclCreated=$false;labCreated=$false;registryAccessed=$false}|ConvertTo-Json -Depth 20
