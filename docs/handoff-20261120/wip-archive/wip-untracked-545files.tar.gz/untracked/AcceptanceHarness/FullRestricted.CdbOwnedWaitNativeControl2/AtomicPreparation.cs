using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using Microsoft.Win32.SafeHandles;
namespace Azurite.NativeControl {
 public sealed class ObjectEvidence {public string path,finalPath,identity,owner,ownerAccessSddl,rawDescriptor,sha256,creationApi,handleOrigin;public bool directory,reparse,creationCallSucceeded;public uint links,attributes;public long bytes;}
 public sealed class ReadResult {public ObjectEvidence evidence;public byte[] bytes;}
 public sealed class BoundedTextCapture:TextWriter {
  readonly StringBuilder text=new StringBuilder();readonly object sync=new object();public override Encoding Encoding{get{return new UTF8Encoding(false);}}
  public override void Write(char value){lock(sync){AtomicCreator.Require(text.Length<131072,"controller raw stream bound exceeded");text.Append(value);}}
  public override void Write(string value){if(value!=null)foreach(char c in value)Write(c);}
  public string Snapshot(){lock(sync)return text.ToString();}
 }
 public sealed class CreationCall {public string Api,HandleOrigin;public bool Succeeded,QueryHandleOpened;public int Error,QueryError;}
 public sealed class AtomicRequest {public string Path,Sddl;public bool Directory,Inherit;public byte[] Descriptor,Bytes;public uint Disposition,Flags,Access,Share;public CreationCall Creation;}
 public sealed class Attempt {public string Path;public bool Verified;public ObjectEvidence Evidence;public CreationCall Creation;}
 public interface IAtomicApi {ObjectEvidence Create(AtomicRequest request);}
 public interface IWin32CreationApi {
  bool CreateDirectory(AtomicRequest request,out int error);
  IntPtr CreateFile(AtomicRequest request,out int error);
  IntPtr OpenCreatedDirectory(AtomicRequest request,out int error);
  void Retain(IntPtr handle);
  ObjectEvidence WriteAndObserve(IntPtr handle,AtomicRequest request);
 }
 public static class Win32AtomicCreate {
  public static ObjectEvidence Create(AtomicRequest request,IWin32CreationApi api){
   int error;IntPtr handle;request.Creation.Succeeded=false;request.Creation.QueryHandleOpened=false;request.Creation.Error=0;request.Creation.QueryError=0;request.Creation.HandleOrigin=null;
   if(request.Directory){request.Creation.Api="CreateDirectoryW";bool okay=api.CreateDirectory(request,out error);request.Creation.Error=error;request.Creation.Succeeded=okay;if(!okay)throw new Win32Exception(error,"CreateDirectoryW failed; never adopt existing object");
    // A directory creation API returns BOOL, not a HANDLE. Preserve success
    // before opening the separate post-create query reference; no same-create-
    // handle provenance is claimed, and a mismatch is never adopted/deleted.
    request.Creation.HandleOrigin="post-create-query-handle";handle=api.OpenCreatedDirectory(request,out error);request.Creation.QueryError=error;request.Creation.QueryHandleOpened=handle!=IntPtr.Zero&&handle!=new IntPtr(-1);
   }else{request.Creation.Api="CreateFileW(CREATE_NEW)";handle=api.CreateFile(request,out error);request.Creation.Error=error;request.Creation.Succeeded=handle!=IntPtr.Zero&&handle!=new IntPtr(-1);request.Creation.HandleOrigin="creation-returned-handle";}
   if(handle==IntPtr.Zero||handle==new IntPtr(-1))throw new Win32Exception(error,"Created object query/create HANDLE unavailable; preserve partial attempt");
   api.Retain(handle); // Actual query/create reference precedes every readback.
   var evidence=api.WriteAndObserve(handle,request);evidence.creationApi=request.Creation.Api;evidence.creationCallSucceeded=request.Creation.Succeeded;evidence.handleOrigin=request.Creation.HandleOrigin;return evidence;
  }
 }
 public sealed class AtomicCreator {
  readonly string lab;readonly IAtomicApi api;public readonly List<Attempt> Attempts=new List<Attempt>();
  public AtomicCreator(string fixedLab,IAtomicApi backend){lab=fixedLab;api=backend;}
  public static void Require(bool b,string m){if(!b)throw new InvalidOperationException(m);}
  public static string Hash(byte[] b){using(var s=SHA256.Create())return BitConverter.ToString(s.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
  public static string CanonicalDescriptor(string s){return new RawSecurityDescriptor(s).GetSddlForm(AccessControlSections.Owner|AccessControlSections.Access);}
  public static void ValidateMetadata(string path,string final,uint attributes,uint links,uint expectedLinks){Require(final=="\\\\?\\"+path,"final path differs");Require((attributes&0x400)==0,"reparse object");Require((attributes&16)!=0||links==expectedLinks,"hardlink count differs");}
  public static void RequireAncestor(ObjectEvidence e){Require(e.directory&&!e.reparse&&e.finalPath==e.path,"existing ancestor must be ordinary directory");}
  public static void ValidatePath(string p,string root){Require(p!=null&&root!=null&&p.StartsWith("C:\\",StringComparison.Ordinal)&&Path.GetFullPath(p)==p&&(p==root||p.StartsWith(root+"\\",StringComparison.Ordinal)),"fixed canonical C path required");foreach(string part in p.Substring(3).Split('\\'))Require(part.Length>0&&!part.EndsWith(".",StringComparison.Ordinal)&&!part.EndsWith(" ",StringComparison.Ordinal)&&part.IndexOfAny(new char[]{':','/','*','?','"','<','>','|'})<0,"ambiguous path");}
  public ObjectEvidence New(string p,bool directory,string sddl,byte[] bytes){
   ValidatePath(p,lab);var sd=new RawSecurityDescriptor(sddl);Require(sd.Owner!=null&&sd.DiscretionaryAcl!=null&&sd.DiscretionaryAcl.Count>0&&(sd.ControlFlags&ControlFlags.DiscretionaryAclProtected)!=0,"protected explicit owner DACL required");
   Require(directory||bytes!=null,"file bytes required");var binary=new byte[sd.BinaryLength];sd.GetBinaryForm(binary,0);
   var a=new Attempt{Path=p,Creation=new CreationCall()};Attempts.Add(a);
   var r=new AtomicRequest{Path=p,Directory=directory,Sddl=sddl,Descriptor=binary,Bytes=bytes,Disposition=directory?0u:1u,Flags=directory?0x02200000u:0x00200000u,Access=directory?0x1200A9u:0xC0020000u,Share=1u,Inherit=false,Creation=a.Creation};
   var e=api.Create(r);a.Evidence=e;
   Require(e.path==p&&e.finalPath==p&&e.directory==directory&&!e.reparse&&e.owner==sd.Owner.Value&&e.ownerAccessSddl==CanonicalDescriptor(sddl),"creation identity/descriptor readback differs");
   Require(directory||(e.links==1&&e.bytes==bytes.Length&&e.sha256==Hash(bytes)),"creation hash/single-link readback differs");a.Verified=true;return e;
  }
 }
 public sealed class PreparationHandleOwners {
  readonly Dictionary<string,IntPtr> directories=new Dictionary<string,IntPtr>(StringComparer.Ordinal);
  readonly List<IntPtr> owners=new List<IntPtr>();bool closeFailed,finalizationStarted;
  public bool HasUnresolvedHandles{get{return owners.Count!=0||closeFailed;}}
  public bool Contains(IntPtr h){return owners.Contains(h);}
  public void Track(IntPtr h){AtomicCreator.Require(h!=IntPtr.Zero&&h!=new IntPtr(-1),"invalid handle");owners.Add(h);}
  public void PinDirectory(string path,IntPtr h){AtomicCreator.Require(!finalizationStarted&&!closeFailed&&owners.Contains(h),"directory pin requires live unambiguous owner before finalization");directories.Add(path,h);}
  public IntPtr RequireParent(string path){AtomicCreator.Require(!finalizationStarted&&!closeFailed,"new creation forbidden after preparation finalization or close uncertainty");IntPtr parent;AtomicCreator.Require(directories.TryGetValue(path,out parent)&&owners.Contains(parent),"parent must remain actually owned and pinned without delete share");return parent;}
  public void Close(IntPtr h,Action<IntPtr> close){
   try{close(h);}catch{closeFailed=true;throw;}owners.Remove(h);
   // Successful close immediately invalidates every parent entry for that
   // reference, even if a later close in the same pass fails.
   var remove=new List<string>();foreach(var p in directories)if(p.Value==h)remove.Add(p.Key);foreach(string path in remove)directories.Remove(path);
  }
  public void CloseAll(Action<IntPtr> close){AtomicCreator.Require(!finalizationStarted&&!closeFailed,"no retry of preparation finalization or uncertain close");finalizationStarted=true;for(int i=owners.Count-1;i>=0;i--)Close(owners[i],close);directories.Clear();}
 }
 // This adapter is never constructed by pure tests. The DACL is installed by
 // SECURITY_ATTRIBUTES at creation, never repaired afterward. Parent references
 // prohibit rename/delete; directory creation and query remain distinct calls.
 public sealed class WindowsAtomicApi:IAtomicApi,IWin32CreationApi {
  const string FixedLab=@"C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\lab-cdb-owned-wait2";
  [StructLayout(LayoutKind.Sequential)]struct FT{public uint Low,High;}
  [StructLayout(LayoutKind.Sequential)]struct FI{public uint Attr;public FT Creation,Access,Write;public uint Volume,SizeHigh,SizeLow,Links,IdHigh,IdLow;}
  [StructLayout(LayoutKind.Sequential)]struct SA{public int Length;public IntPtr Descriptor;[MarshalAs(UnmanagedType.Bool)]public bool Inherit;}
  [StructLayout(LayoutKind.Sequential)]struct Disposition{[MarshalAs(UnmanagedType.U1)]public bool Delete;}
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool CreateDirectoryW(string p,ref SA security);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,EntryPoint="CreateFileW")]static extern IntPtr CreateFileSecure(string p,uint access,uint share,ref SA security,uint creation,uint flags,IntPtr template);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateFileW(string p,uint access,uint share,IntPtr security,uint creation,uint flags,IntPtr template);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(IntPtr h,out FI i);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetProcessTimes(IntPtr h,out FT created,out FT exited,out FT kernel,out FT user);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern uint GetFinalPathNameByHandleW(IntPtr h,StringBuilder b,uint length,uint flags);
  [DllImport("advapi32.dll")]static extern uint GetSecurityInfo(IntPtr h,uint type,uint parts,out IntPtr owner,out IntPtr group,out IntPtr dacl,out IntPtr sacl,out IntPtr descriptor);
  [DllImport("advapi32.dll")]static extern uint GetSecurityDescriptorLength(IntPtr descriptor);
  [DllImport("kernel32.dll")]static extern IntPtr LocalFree(IntPtr p);
  [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetFileInformationByHandle(IntPtr h,int type,ref Disposition info,uint length);
  readonly PreparationHandleOwners ownership=new PreparationHandleOwners();readonly string lab;
  public WindowsAtomicApi(string fixedLab){
   #if NATIVE_CONTROL_PURE
   lab=fixedLab;throw new InvalidOperationException("Native adapter prohibited in pure test compilation");
   #else
   AtomicCreator.Require(fixedLab==FixedLab,"only fixed new C lab2 may be mutated");lab=fixedLab;
   #endif
  }
  public bool HasUnresolvedHandles{get{return ownership.HasUnresolvedHandles;}}
  public static string ValidateX64Layout(){AtomicCreator.Require(IntPtr.Size==8&&Marshal.SizeOf(typeof(SA))==24&&Marshal.OffsetOf(typeof(SA),"Descriptor").ToInt32()==8&&Marshal.OffsetOf(typeof(SA),"Inherit").ToInt32()==16,"SECURITY_ATTRIBUTES x64 ABI differs");return "x64 SECURITY_ATTRIBUTES24 Descriptor+8 Inherit+16";}
  public long ReadHostCreationFileTime(){FT c,e,k,u;Win(GetProcessTimes(new IntPtr(-1),out c,out e,out k,out u));return ((long)c.High<<32)|c.Low;}
  static void Win(bool b){if(!b)throw new Win32Exception(Marshal.GetLastWin32Error());}
  void Track(IntPtr h){ownership.Track(h);}
  static void CloseNative(IntPtr h){if(!CloseHandle(h))throw new Win32Exception(Marshal.GetLastWin32Error(),"owned handle close failed; retain host");}
  void Close(IntPtr h){ownership.Close(h,CloseNative);}
  IntPtr Open(string p,uint access){IntPtr h=CreateFileW(p,access,1,IntPtr.Zero,3,0x02200000,IntPtr.Zero);if(h==new IntPtr(-1))throw new Win32Exception(Marshal.GetLastWin32Error(),p);Track(h);return h;}
  public void LockAncestors(){var chain=new List<string>();string p=Path.GetDirectoryName(lab);while(p!=null){chain.Add(p);p=Path.GetDirectoryName(p);}chain.Reverse();foreach(string item in chain){IntPtr h=Open(item,0x1200A9);var e=Examine(h,item,false,0);AtomicCreator.RequireAncestor(e);ownership.PinDirectory(item,h);}}
  static FI Info(IntPtr h){FI i;Win(GetFileInformationByHandle(h,out i));return i;}
  static byte[] Descriptor(IntPtr h){IntPtr o,g,d,s,p;uint err=GetSecurityInfo(h,1,7,out o,out g,out d,out s,out p);if(err!=0)throw new Win32Exception((int)err);try{var raw=new byte[GetSecurityDescriptorLength(p)];Marshal.Copy(p,raw,0,raw.Length);return raw;}finally{LocalFree(p);}}
  ObjectEvidence Examine(IntPtr h,string path,bool content,uint allowedLinks){
   FI before=Info(h);bool dir=(before.Attr&16)!=0;
   var b=new StringBuilder(32768);uint n=GetFinalPathNameByHandleW(h,b,(uint)b.Capacity,0);AtomicCreator.Require(n>0&&n<b.Capacity,"final path query failed");string final=b.ToString();AtomicCreator.ValidateMetadata(path,final,before.Attr,before.Links,allowedLinks);
   byte[] raw=Descriptor(h);var sd=new RawSecurityDescriptor(raw,0);
   var e=new ObjectEvidence{path=path,finalPath=path,identity=before.Volume.ToString("x8")+before.IdHigh.ToString("x8")+before.IdLow.ToString("x8"),directory=dir,reparse=false,links=before.Links,attributes=before.Attr,bytes=((long)before.SizeHigh<<32)|before.SizeLow,owner=sd.Owner.Value,ownerAccessSddl=sd.GetSddlForm(AccessControlSections.Owner|AccessControlSections.Access),rawDescriptor=Convert.ToBase64String(raw)};
   if(!dir&&content){AtomicCreator.Require(e.bytes<=16777216,"source/evidence bound exceeded");using(var safe=new SafeFileHandle(h,false))using(var fs=new FileStream(safe,FileAccess.Read,65536,false)){fs.Position=0;using(var hash=SHA256.Create())e.sha256=BitConverter.ToString(hash.ComputeHash(fs)).Replace("-","").ToLowerInvariant();}FI after=Info(h);AtomicCreator.Require(before.Volume==after.Volume&&before.IdHigh==after.IdHigh&&before.IdLow==after.IdLow&&before.SizeLow==after.SizeLow&&before.SizeHigh==after.SizeHigh&&before.Write.Low==after.Write.Low&&before.Write.High==after.Write.High,"object changed during same-handle read");}
   AtomicCreator.Require(Convert.ToBase64String(Descriptor(h))==e.rawDescriptor,"same-handle descriptor changed during readback");return e;
  }
  void ValidateCreation(AtomicRequest r){
   AtomicCreator.ValidatePath(r.Path,lab);AtomicCreator.Require(r.Disposition==(r.Directory?0u:1u)&&!r.Inherit&&r.Share==1&&r.Flags==(r.Directory?0x02200000u:0x00200000u)&&r.Access==(r.Directory?0x1200A9u:0xC0020000u),"fixed Win32 create parameters differ");
   ownership.RequireParent(Path.GetDirectoryName(r.Path));var sd=new RawSecurityDescriptor(r.Descriptor,0);AtomicCreator.Require(sd.Owner!=null&&sd.DiscretionaryAcl!=null&&(sd.ControlFlags&ControlFlags.DiscretionaryAclProtected)!=0&&sd.GetSddlForm(AccessControlSections.Owner|AccessControlSections.Access)==AtomicCreator.CanonicalDescriptor(r.Sddl),"exact protected creation descriptor required");ValidateX64Layout();
  }
  public ObjectEvidence Create(AtomicRequest r){ValidateCreation(r);return Win32AtomicCreate.Create(r,this);}
  bool IWin32CreationApi.CreateDirectory(AtomicRequest r,out int error){ValidateCreation(r);AtomicCreator.Require(r.Directory,"directory API requires directory request");var pin=GCHandle.Alloc(r.Descriptor,GCHandleType.Pinned);try{var sa=new SA{Length=Marshal.SizeOf(typeof(SA)),Descriptor=pin.AddrOfPinnedObject(),Inherit=false};bool okay=CreateDirectoryW(r.Path,ref sa);error=okay?0:Marshal.GetLastWin32Error();return okay;}finally{pin.Free();}}
  IntPtr IWin32CreationApi.CreateFile(AtomicRequest r,out int error){ValidateCreation(r);AtomicCreator.Require(!r.Directory,"file API requires file request");var pin=GCHandle.Alloc(r.Descriptor,GCHandleType.Pinned);try{var sa=new SA{Length=Marshal.SizeOf(typeof(SA)),Descriptor=pin.AddrOfPinnedObject(),Inherit=false};IntPtr h=CreateFileSecure(r.Path,r.Access,r.Share,ref sa,r.Disposition,r.Flags,IntPtr.Zero);error=h==new IntPtr(-1)?Marshal.GetLastWin32Error():0;return h;}finally{pin.Free();}}
  IntPtr IWin32CreationApi.OpenCreatedDirectory(AtomicRequest r,out int error){ValidateCreation(r);AtomicCreator.Require(r.Directory&&r.Creation.Succeeded,"query requires successful directory creation call");IntPtr h=CreateFileW(r.Path,r.Access,r.Share,IntPtr.Zero,3,r.Flags,IntPtr.Zero);error=h==new IntPtr(-1)?Marshal.GetLastWin32Error():0;return h;}
  void IWin32CreationApi.Retain(IntPtr h){Track(h);}
  ObjectEvidence IWin32CreationApi.WriteAndObserve(IntPtr h,AtomicRequest r){
   ValidateCreation(r);AtomicCreator.Require(ownership.Contains(h),"readback requires retained actual reference");
   if(!r.Directory){using(var safe=new SafeFileHandle(h,false))using(var fs=new FileStream(safe,FileAccess.ReadWrite,65536,false)){fs.Write(r.Bytes,0,r.Bytes.Length);fs.Flush(true);}}
   var e=Examine(h,r.Path,!r.Directory,1);AtomicCreator.Require(e.directory==r.Directory&&e.ownerAccessSddl==AtomicCreator.CanonicalDescriptor(r.Sddl),"created/query object descriptor/type mismatch; no adoption/deletion");
   if(r.Directory)ownership.PinDirectory(r.Path,h);else{AtomicCreator.Require(e.bytes==r.Bytes.Length&&e.sha256==AtomicCreator.Hash(r.Bytes),"same creation-handle payload mismatch");Close(h);}return e;
  }
  public ReadResult ReadFile(string path,uint links){AtomicCreator.Require(path.StartsWith("C:\\",StringComparison.Ordinal)&&Path.GetFullPath(path)==path,"read C path only");AtomicCreator.Require(links==1||(links==2&&path==@"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"),"two-link exception is only fixed read-only system PowerShell");IntPtr h=Open(path,0x80120000);var e=Examine(h,path,true,links);byte[] bytes=new byte[checked((int)e.bytes)];using(var safe=new SafeFileHandle(h,false))using(var fs=new FileStream(safe,FileAccess.Read,65536,false)){fs.Position=0;int pos=0,n;while(pos<bytes.Length&&(n=fs.Read(bytes,pos,bytes.Length-pos))>0)pos+=n;AtomicCreator.Require(pos==bytes.Length&&AtomicCreator.Hash(bytes)==e.sha256,"source changed during copy");}Close(h);return new ReadResult{evidence=e,bytes=bytes};}
  public ObjectEvidence ReadObject(string path){IntPtr h=Open(path,0x80120000);var e=Examine(h,path,true,1);Close(h);return e;}
  public void DeletePending(ObjectEvidence expected){AtomicCreator.Require(expected.path==lab+"\\pending.json","only exact owned pending may be removed");IntPtr h=Open(expected.path,0x80130000);var actual=Examine(h,expected.path,true,1);AtomicCreator.Require(actual.identity==expected.identity&&actual.sha256==expected.sha256&&actual.ownerAccessSddl==expected.ownerAccessSddl,"pending drift");var d=new Disposition{Delete=true};Win(SetFileInformationByHandle(h,4,ref d,(uint)Marshal.SizeOf(typeof(Disposition))));Close(h);}
  public void CloseAll(){ownership.CloseAll(CloseNative);}
 }
}
