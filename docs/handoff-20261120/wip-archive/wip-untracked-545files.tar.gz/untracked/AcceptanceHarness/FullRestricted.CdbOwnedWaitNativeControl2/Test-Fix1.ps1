#requires -Version 5.1
[CmdletBinding()]
param([switch]$VerifyLatestBuild)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1){throw 'Fresh x64 PS5.1 only'}
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -Force -DisableNameChecking
$l=Get-NativeLayout
$scenarioSource=@'
namespace Azurite.NativeControl.Fix1Tests {
 public sealed class LifetimeScenario {
  public readonly PreparationHandleOwners Owners=new PreparationHandleOwners();
  public readonly System.Collections.Generic.List<long> CloseCalls=new System.Collections.Generic.List<long>();
  public int NativeCreateCalls;
  public LifetimeScenario(){Owners.Track(new System.IntPtr(101));Owners.PinDirectory(@"C:\fixed\lab\control",new System.IntPtr(101));Owners.Track(new System.IntPtr(102));Owners.PinDirectory(@"C:\fixed\lab\tooling\evidence",new System.IntPtr(102));}
  public void RunPartialClose(){Owners.CloseAll(delegate(System.IntPtr h){CloseCalls.Add(h.ToInt64());if(h.ToInt64()==101)throw new System.InvalidOperationException("PRIMARY_CLOSE_FAILURE");});}
  public void TryCreateAfterClose(){Owners.RequireParent(@"C:\fixed\lab\tooling\evidence");NativeCreateCalls++;}
 }
}
'@
Add-Type -TypeDefinition ("#define NATIVE_CONTROL_PURE`n"+[IO.File]::ReadAllText($PSScriptRoot+'\AtomicPreparation.cs')+"`n"+$scenarioSource) -Language CSharp
$checks=[Collections.Generic.List[object]]::new()
function Check([bool]$Value,[string]$Name,[string]$Detail=''){$checks.Add([ordered]@{name=$Name;passed=$Value;detail=$Detail})}
function Reject([scriptblock]$Action,[string]$Name){$rejected=$false;$message='';try{& $Action|Out-Null}catch{$rejected=$true;$message=$_.Exception.Message};Check $rejected $Name $message}
$scenario=[Azurite.NativeControl.Fix1Tests.LifetimeScenario]::new();$hold=@{count=0;secondary=[Collections.Generic.List[string]]::new()};$primary=''
$run={$scenario.RunPartialClose()}.GetNewClosure();$decision={$scenario.Owners.HasUnresolvedHandles}.GetNewClosure();$sink={param($state)$scenario.TryCreateAfterClose()}.GetNewClosure();$holdAction={$hold.count++}.GetNewClosure();$secondary={param($e)$hold.secondary.Add($e.Exception.Message)}.GetNewClosure()
try{Invoke-NativeHeldBoundary $run $decision {@{state='partial-close'}} $sink $holdAction $secondary|Out-Null}catch{$primary=$_.Exception.ToString()}
Check ($scenario.NativeCreateCalls -eq 0) 'L1 partial close rejects creation before native API' ('nativeCalls='+$scenario.NativeCreateCalls)
Check ($scenario.CloseCalls.Count -eq 2 -and $scenario.CloseCalls[0] -eq 102 -and $scenario.CloseCalls[1] -eq 101) 'L1 real reverse-close bookkeeping reached later close failure'
Check (-not $scenario.Owners.Contains([IntPtr]102) -and $scenario.Owners.Contains([IntPtr]101)) 'L1 successful owner removed and failed owner preserved'
Check ($hold.count -eq 1 -and $scenario.Owners.HasUnresolvedHandles) 'L1 original held boundary still retains unresolved owner'
Check ($primary -match 'PRIMARY_CLOSE_FAILURE' -and $hold.secondary.Count -eq 1) 'L1 primary close failure survives diagnostic creation refusal' $primary

$rows=@([ordered]@{path='AtomicPreparation.cs';sha256=('a'*64);bytes=111},[ordered]@{path='Build-Source.ps1';sha256=('b'*64);bytes=222},[ordered]@{path='Build-Admission.ps1';sha256=('c'*64);bytes=333})
$inventory=Get-NativeHash (ConvertTo-NativeBytes $rows);$folder=$l.evidence+'\source-build-987654';$helperHash='d'*64;$recordHash='e'*64
$helper=[pscustomobject]@{schema='native-control-helper-binding.v1';sourceInventorySha256=$inventory;path=($folder+'\NativeControl.Preparation.dll');sha256=$helperHash}
$build=[pscustomobject]@{schema='native-control-source-build.v1';sourceBuildOnly=$true;runtimeAllowed=$false;nativeExecuted=$false;normalDllLoaded=$false;output=$folder;helperSha256=$helperHash;helperBytes=4096;compilerSha256=('f'*64);sourceInventorySha256=$inventory;compilerInputs=@([pscustomobject]@{name='AtomicPreparation.cs';sha256=('a'*64);bytes=111});sources=@($rows|ForEach-Object{[pscustomobject]@{name=$_.path;sha256=$_.sha256;bytes=$_.bytes}})}
function Clone($Value){ConvertFrom-Json (ConvertTo-Json -InputObject $Value -Depth 30)}
function Bind($ActualBuild,[string]$ActualHash=$helperHash,[string]$ActualRecordPath=($folder+'\source-build.json')){Assert-NativeHelperBuild $helper $ActualBuild $rows $inventory $ActualHash 4096 $ActualRecordPath $recordHash}
$positive=Bind $build;Check ($positive.helperSha256 -ceq $helperHash -and $positive.sourceBuildManifestSha256 -ceq $recordHash) 'B1 matching actual build produces provenance binding'
$wrong=Clone $build;$wrong.output=$l.evidence+'\source-build-1';Reject {Bind $wrong} 'B1 wrong build directory cannot be relabeled by helper JSON'
$wrong=Clone $build;$wrong.sourceInventorySha256='1'*64;Reject {Bind $wrong} 'B1 wrong actual source inventory rejected'
$wrong=Clone $build;$wrong.sources[0].sha256='2'*64;Reject {Bind $wrong} 'B1 stale compiled source row rejected despite current helper declaration'
$wrong=Clone $build;$wrong.sources[1].bytes=223;Reject {Bind $wrong} 'B1 source byte length mismatch rejected'
$wrong=Clone $build;$wrong.sources+=@($wrong.sources[0]);Reject {Bind $wrong} 'B1 duplicate or extra source row rejected'
$wrong=Clone $build;$wrong.compilerInputs[0].sha256='3'*64;Reject {Bind $wrong} 'B1 wrong compiler input rejected'
$wrong=Clone $build;$wrong.helperSha256='4'*64;Reject {Bind $wrong} 'B1 actual build output helper hash mismatch rejected'
Reject {Bind $build ('5'*64)} 'B1 actual selected DLL hash mismatch rejected'
Reject {Bind $build $helperHash ($l.evidence+'\source-build-1\source-build.json')} 'B1 record from another build rejected'
if($VerifyLatestBuild){
 $latest=Get-ChildItem -LiteralPath $l.evidence -Directory|Where-Object{$_.Name -cmatch '^source-build-[0-9]+$' -and (Test-Path -LiteralPath ($_.FullName+'\source-build.json'))}|Sort-Object {[int]$_.Name.Substring(13)} -Descending|Select-Object -First 1
 if($null -eq $latest){throw 'No actual source-build record'}
 $actualPath=$latest.FullName+'\source-build.json';$actualBytes=[IO.File]::ReadAllBytes($actualPath);$actual=[Text.Encoding]::UTF8.GetString($actualBytes).TrimStart([char]0xfeff)|ConvertFrom-Json
 $actualRows=@(Get-ChildItem -LiteralPath $PSScriptRoot -File|ForEach-Object{[ordered]@{path=$_.Name;sha256=(Get-NativeHash ([IO.File]::ReadAllBytes($_.FullName)));bytes=$_.Length}}|Sort-Object path)
 $actualInventory=Get-NativeHash (ConvertTo-NativeBytes $actualRows);$dll=$latest.FullName+'\NativeControl.Preparation.dll';$dllHash=Get-NativeHash ([IO.File]::ReadAllBytes($dll));$declared=[pscustomobject]@{schema='native-control-helper-binding.v1';sourceInventorySha256=$actualInventory;path=$dll;sha256=$dllHash}
 $actualBinding=Assert-NativeHelperBuild $declared $actual $actualRows $actualInventory $dllHash (Get-Item -LiteralPath $dll).Length $actualPath (Get-NativeHash $actualBytes)
 Check ($actualBinding.sourceBuildManifestSha256 -ceq (Get-NativeHash $actualBytes) -and $actualBinding.helperSha256 -ceq $dllHash) 'B1 actual new compiler record and DLL bind current source without loading DLL'
}
$failed=@($checks|Where-Object{-not $_.passed});[ordered]@{schema='native-control-fix1-pure.v1';passed=($failed.Count -eq 0);checks=$checks.ToArray();count=$checks.Count;nativeExecuted=$false;actualAclCreated=$false;normalDllLoaded=$false;actualIdentityRead=$false;registryAccessed=$false;actualBuildChecked=[bool]$VerifyLatestBuild}|ConvertTo-Json -Depth 30
if($failed.Count -gt 0){throw ('FIX1 regression failures: '+(($failed|ForEach-Object{$_.name}) -join '; '))}
