#requires -Version 5.1
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -Force -DisableNameChecking
$l=Get-NativeLayout;Require-Native ($PSScriptRoot -ceq $l.source) 'Fixed source path only'
Require-Native ([Environment]::Is64BitProcess -and $PSVersionTable.PSEdition -ceq 'Desktop' -and $PSVersionTable.PSVersion.Major -eq 5 -and $PSVersionTable.PSVersion.Minor -eq 1) 'Fresh x64 PS5.1 supervisor only'
$results=@()
foreach($entry in @(@('pure','Test-Pure.ps1'),@('red-now-green','Test-RedPath.ps1'),@('build','Build-Source.ps1'),@('fix1','Test-Fix1.ps1','-VerifyLatestBuild'),@('draft','Build-Admission.ps1'))){
 $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';$psi.Arguments='-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$PSScriptRoot+'\'+$entry[1]+'"'
 if($entry.Count -eq 3){$psi.Arguments+=' '+$entry[2]}
 $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.WindowStyle='Hidden';$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.StandardOutputEncoding=[Text.Encoding]::UTF8;$psi.StandardErrorEncoding=[Text.Encoding]::UTF8;$psi.EnvironmentVariables.Remove('PSModulePath')
 $n=1;while(Test-Path -LiteralPath ($l.evidence+'\'+$entry[0]+'-verification-'+$n+'.json')){$n++};$dest=$l.evidence+'\'+$entry[0]+'-verification-'+$n+'.json'
 $p=[Diagnostics.Process]::new();$p.StartInfo=$psi
 $r=[ordered]@{entry=$entry[1];pid=$null;creationFileTime=$null;started=$false;exited=$false;exitCode=$null;stdout='';stderr='';timedOut=$false;terminatedOwnedPureChild=$false;supervisorErrors=@();hidden=$true;priority='BelowNormal';boundMs=30000;freshX64PS51=$true;nativeExecuted=$false;normalFixtureLoaded=$false;labCreated=$false;actualIdentityRead=$false;actualTargetProcessQuery=$false;registryAccessed=$false;entrySha256=(Get-NativeHash ([IO.File]::ReadAllBytes($PSScriptRoot+'\'+$entry[1])))}
 function Save-SourceChildState{$bytes=ConvertTo-NativeBytes $r;$file=[IO.File]::Open($dest,'Create','Write','Read');try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}}
 try{
  [void]$p.Start();$r.started=$true;$r.pid=$p.Id;$r.creationFileTime=$p.StartTime.ToUniversalTime().ToFileTimeUtc();Save-SourceChildState
  $p.PriorityClass='BelowNormal';$stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  if(-not $p.WaitForExit(30000)){$r.timedOut=$true;Save-SourceChildState;$p.Kill();$r.terminatedOwnedPureChild=$true;if(-not $p.WaitForExit(5000)){throw 'Owned pure SOURCE child did not exit after bounded termination'}}
  $r.exited=$true;$r.exitCode=$p.ExitCode;$r.stdout=$stdout.Result;$r.stderr=$stderr.Result;Save-SourceChildState
 }catch{
  $r.supervisorErrors+=@($_.Exception.ToString());try{Save-SourceChildState}catch{}
  if($r.started -and -not $r.exited){
   try{if(-not $p.HasExited){$p.Kill();$r.terminatedOwnedPureChild=$true};if($p.WaitForExit(5000)){$r.exited=$true;$r.exitCode=$p.ExitCode;Save-SourceChildState}}catch{$r.supervisorErrors+=@($_.Exception.ToString());try{Save-SourceChildState}catch{}}
   if(-not $r.exited){[Console]::Error.WriteLine('Uncertain owned pure SOURCE child; original supervisor retains Process and record '+$dest);while($true){[Threading.Thread]::Sleep(1000)}}
  }
  throw
 }finally{if($r.exited -or -not $r.started){$p.Dispose()}}
 $bytes=[IO.File]::ReadAllBytes($dest)
 $results+=@{check=$entry[0];record=$dest;exitCode=$r.exitCode;sha256=(Get-NativeHash $bytes)}
 Require-Native (-not $r.timedOut -and $r.exited -and $r.exitCode -eq 0 -and [string]::IsNullOrEmpty($r.stderr)) ('Source check failed; preserved '+$dest)
}
ConvertTo-Json -InputObject $results -Depth 10
