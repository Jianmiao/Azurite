#requires -Version 5.1
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -Force
$lab='C:\fixed\lab2'; $refused=$false
try { Assert-NativeOwnedPath 'C:\fixed\lab2\..\escape' $lab | Out-Null } catch { $refused=$true }
if(-not $refused){throw 'RED: path escape accepted; production boundary must reject before native API'}
'PASS: path escape rejected'