#requires -Version 5.1
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not [Environment]::Is64BitProcess -or $PSVersionTable.PSEdition -cne 'Desktop' -or $PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1){throw 'fresh x64 PS5.1 only'}
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -Force -DisableNameChecking
$l=Get-NativeLayout;Require-Native ($PSScriptRoot -ceq $l.source) 'Fixed source directory only'
$attempt=1;while(Test-Path -LiteralPath ($l.evidence+'\source-build-'+$attempt)){$attempt++};$out=$l.evidence+'\source-build-'+$attempt
[void][IO.Directory]::CreateDirectory($out)
$parse=@();foreach($f in Get-ChildItem -LiteralPath $PSScriptRoot -File|Where-Object{$_.Extension -in @('.ps1','.psm1')}){$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$tokens,[ref]$errors);$parse+=@{name=$f.Name;sha256=(Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant();errors=@($errors|ForEach-Object{$_.ToString()})}}
$parse|ConvertTo-Json -Depth 10|Set-Content -LiteralPath ($out+'\parse.json') -Encoding UTF8
Require-Native (@($parse|Where-Object{@($_.errors).Count -gt 0}).Count -eq 0) 'PS5.1 parse failed'
function Read-SourceInventory { @(Get-ChildItem -LiteralPath $PSScriptRoot -File|ForEach-Object{[ordered]@{path=$_.Name;sha256=(Get-NativeHash ([IO.File]::ReadAllBytes($_.FullName)));bytes=$_.Length}}|Sort-Object path) }
$sourceBefore=Read-SourceInventory;$inventoryHash=Get-NativeHash (ConvertTo-NativeBytes $sourceBefore)
$compilerInput=@($sourceBefore|Where-Object{$_.path -ceq 'AtomicPreparation.cs'});Require-Native ($compilerInput.Count -eq 1) 'Exact helper compiler input required'
$csc='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
& $csc /nologo /target:library /platform:x64 /warn:4 /warnaserror+ ('/out:'+$out+'\NativeControl.Preparation.dll') ($PSScriptRoot+'\AtomicPreparation.cs') 2>&1|Tee-Object -FilePath ($out+'\compiler.log')
Require-Native ($LASTEXITCODE -eq 0) 'Managed helper compilation failed'
$sourceAfter=Read-SourceInventory;Require-Native ((Get-NativeHash (ConvertTo-NativeBytes $sourceAfter)) -ceq $inventoryHash) 'Source changed during helper compilation; do not issue a build record'
$manifest=[ordered]@{schema='native-control-source-build.v1';sourceBuildOnly=$true;runtimeAllowed=$false;nativeExecuted=$false;normalDllLoaded=$false;labCreated=$false;aclCreated=$false;actualIdentityRead=$false;registryAccessed=$false;output=$out;helperSha256=(Get-FileHash -LiteralPath ($out+'\NativeControl.Preparation.dll') -Algorithm SHA256).Hash.ToLowerInvariant();helperBytes=(Get-Item -LiteralPath ($out+'\NativeControl.Preparation.dll')).Length;compilerSha256=(Get-FileHash -LiteralPath $csc -Algorithm SHA256).Hash.ToLowerInvariant();compilerInputs=@([ordered]@{name='AtomicPreparation.cs';sha256=$compilerInput[0].sha256;bytes=$compilerInput[0].bytes});sourceInventorySha256=$inventoryHash;sources=@($sourceBefore|ForEach-Object{[ordered]@{name=$_.path;sha256=$_.sha256;bytes=$_.bytes}})}
$manifest|ConvertTo-Json -Depth 20|Set-Content -LiteralPath ($out+'\source-build.json') -Encoding UTF8
$manifest|ConvertTo-Json -Depth 20
