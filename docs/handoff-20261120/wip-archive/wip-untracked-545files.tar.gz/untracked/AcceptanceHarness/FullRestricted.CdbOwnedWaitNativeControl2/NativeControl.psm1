Set-StrictMode -Version Latest
$script:FixedRepo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
function Require-Native([bool]$Value,[string]$Why){if(-not $Value){throw $Why}}
function Get-NativeLayout {
 $b=$script:FixedRepo+'\artifacts\aa-fr-native-lifecycle-fixture'
 [pscustomobject]@{repo=$script:FixedRepo;parent=($b+'\build-cdb-owned-wait2-9974-cons1');package=($b+'\build-cdb-owned-wait2-9974-cons1-native1');lab=($b+'\lab-cdb-owned-wait2');source=($script:FixedRepo+'\AcceptanceHarness\FullRestricted.CdbOwnedWaitNativeControl2');evidence=($script:FixedRepo+'\artifacts\aa-cdb-native-control-preparation-20261113');mutex='Global\AzuriteRestrictedCli-AA'}
}
function Assert-NativeOwnedPath([string]$Path,[string]$Lab){
 Require-Native ($Path -cmatch '^C:\\' -and $Lab -cmatch '^C:\\') 'Only fixed C paths'
 Require-Native ($Path -ceq [IO.Path]::GetFullPath($Path) -and $Lab -ceq [IO.Path]::GetFullPath($Lab)) 'Canonical path required'
 Require-Native ($Path -ceq $Lab -or $Path.StartsWith($Lab+'\',[StringComparison]::Ordinal)) 'Path escapes fixed lab'
 Require-Native ($Path.Substring(3) -cnotmatch '[:/*?"<>|]' -and $Path -cnotmatch '[. ](?:\\|$)' -and $Path -cnotmatch '\\\\') 'Ambiguous path refused'
 return $Path
}
function Get-NativeHash([byte[]]$Bytes){$s=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($s.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
function ConvertTo-NativeBytes($Value){$b=[Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-Json -InputObject $Value -Depth 80 -Compress));Require-Native ($b.Length -le 4194304) 'JSON bound exceeded';return ,$b}
function Assert-NativeObject($O,[string]$Path,[bool]$Directory,[string]$Owner,[string]$Sddl,[string]$Hash='',[uint32]$Links=1){
 Require-Native ($O.path -ceq $Path -and $O.finalPath -ceq $Path -and $O.directory -eq $Directory -and -not $O.reparse) 'Path/type/reparse readback failed'
 Require-Native ($O.identity -cmatch '^[a-f0-9]{24}$' -and $O.owner -ceq $Owner -and $O.ownerAccessSddl -ceq $Sddl) 'Identity/owner/protected descriptor differs'
 if(-not $Directory){Require-Native ($O.links -eq $Links -and $O.sha256 -ceq $Hash) 'Hash/link count differs'}
}
function Assert-NativeDeadline([long]$Origin,[long]$Now,[long]$Frequency,[int]$ReserveMs=5000){
 Require-Native ($Origin -gt 0 -and $Frequency -gt 0 -and $Now -ge $Origin -and $ReserveMs -in @(0,5000)) 'Invalid original clock'
 $elapsed=([decimal]$Now-$Origin)*1000/$Frequency;Require-Native ($elapsed -lt 30000-$ReserveMs) 'Original 30-second budget exhausted; no reset'
 return [int][Math]::Floor(30000-$ReserveMs-$elapsed)
}
function Assert-NativeIdentity($I){
 Require-Native ($I.identitySid -cmatch '^S-1-5-21-(?:[0-9]+-){3}[0-9]+$' -and $I.token.logon_sid -cmatch '^S-1-5-5-[0-9]+-[0-9]+$') 'Actual user/logon identity required'
 Require-Native (-not $I.isAdministrator -and -not $I.token.is_restricted -and $I.token.users_enabled -and @($I.unexpectedPrivileges).Count -eq 0) 'Original unelevated unrestricted identity required'
 Require-Native ($I.token.session_id -ge 0 -and $I.token.integrity_rid -ge 0 -and $I.token.integrity_attributes -eq 96 -and ($I.token.mandatory_policy -band (-bnot 3)) -eq 0) 'Original inherited token policy malformed'
}
function Get-NativeExpectedChild($Original){
 Assert-NativeIdentity $Original
 # Fullcf950 ValidateChild calls RequireInheritedPolicy. Derive uses flags1;
 # only TokenDefaultDacl is configured. No Low integrity setter is present.
 [ordered]@{derivation='inherited-original-token.v1';userSid=$Original.identitySid;logonSid=$Original.token.logon_sid;session=$Original.token.session_id;integrityRid=$Original.token.integrity_rid;integrityAttributes=$Original.token.integrity_attributes;mandatoryPolicy=$Original.token.mandatory_policy;restricted=$true;tokenType=1;createRestrictedTokenFlags=1}
}
function Assert-NativeManifest($M,[string]$Hash,[long]$UtcTicks){
 $l=Get-NativeLayout
 Require-Native ($Hash -cmatch '^[a-f0-9]{64}$' -and $M.schema -ceq 'native-control-admission.v1' -and $M.protocol -ceq 'lease-control.v1') 'Manifest identity/protocol invalid'
 Require-Native ($M.runtimeAllowed -is [bool] -and $M.runtimeAllowed -and $M.sourceBuildOnly -is [bool] -and -not $M.sourceBuildOnly) 'Draft/SOURCE package never admits execution'
 Require-Native ($M.fixedLab -ceq $l.lab -and $M.fixedParent -ceq $l.parent -and $M.fixedPackage -ceq $l.package -and $M.scenario -ceq 'normal') 'Fixed paths/scenario differ'
 Require-Native ($M.parentManifestSha256 -ceq 'e8c83e763e7477ff2057caad6dbede6d4795db1923ef1f8e9afb97862a78146c' -and $M.aclCanonicalReviewSha256 -ceq '2c6477a238c405ac8995cc9aa552b9c9392dbf9e6bfeb93c1144369809392cbc') 'Reviewed consumer9974 parent and independent ACL review required'
 Require-Native ($M.pumpCaptureReviewSha256 -ceq '0e69dbefc78bc5849f85dd058ad21a231bac79b7333eb6714a54779b159d0c86' -and $M.releaseQueryReviewSha256 -ceq '05caf656d85cb74649d80ad796bceffdafca14a6859d177c0fbfda4177108126' -and $M.desktopMonitorQualificationSha256 -ceq '69713e0b57cbf46c9b9939008ae8d33e3c5f32ca4e99b6ee77106539f7e8ef7a') 'Exact Pump/release reviews and actual9974 monitor evidence required'
 Require-Native ($M.consumerReviewSha256 -is [string] -and $M.consumerReviewSha256 -ceq '598b02e3b43a3b2e9f92ab64b2bddc78f790be25ee011cb2510f0276e1ed5f05' -and $M.consumerPackageReviewSha256 -is [string] -and $M.consumerPackageReviewSha256 -ceq 'c03a51a081978458c5be52914982bfc209cc3af0da947f4a018d8e22be7f84b7' -and $M.fixtureRulesSha256 -is [string] -and $M.fixtureRulesSha256 -ceq 'cf16be42aa10ce38cef64ff52d955406ffdc8a8828e65ac9d591a859a508e10d') 'Exact current consumer review, package review and FixtureRules binding required'
 Require-Native ($M.generatedNativeCreateRestrictedTokenFlags -eq 1 -and $M.innerMs -eq 10000 -and $M.childMs -eq 12000 -and $M.outerMs -eq 30000 -and $M.cleanupMs -eq 5000) 'Original flags/deadlines required'
 Require-Native ($M.validFromUtcTicks -le $UtcTicks -and $UtcTicks -lt $M.expiresUtcTicks -and ($M.expiresUtcTicks-$M.validFromUtcTicks) -le [TimeSpan]::FromMinutes(10).Ticks) 'Admission validity failed'
 foreach($h in @($M.parentManifestSha256,$M.taskAReview1Sha256,$M.taskAReview2Sha256,$M.preparationReviewSha256,$M.rootAuthorizationSha256)){Require-Native ($h -cmatch '^[a-f0-9]{64}$') 'Review/authorization binding missing'}
 Require-Native ($M.productionSources.'RestrictedCliFullRestricted.cs' -ceq 'cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533' -and $M.productionSources.'RestrictedCliNative.cs' -ceq 'f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921') 'Production pins differ'
 $names=@($M.files|ForEach-Object{$_.path});Require-Native ($names.Count -eq @($names|Select-Object -Unique).Count -and $names -cnotcontains 'prepared-run.json' -and $names -cnotcontains 'control.json') 'Manifest cycle/duplicate'
 foreach($f in @($M.files)){Require-Native ($f.path -cmatch '^(?:source\\)?[A-Za-z0-9._-]+$' -and $f.sha256 -cmatch '^[a-f0-9]{64}$' -and $f.bytes -gt 0) 'Immutable member invalid'}
}
function Assert-NativeBinding($Q,$C,[string]$P,[string]$ControlHash,[string]$RunId,[long]$Origin,[long]$Frequency,[int]$HostPid,[long]$HostStart){
 $l=Get-NativeLayout
 Require-Native ($RunId -cmatch '^[a-f0-9]{32}$' -and $Q.schema -ceq 'native-control-prepared.v1' -and $Q.runId -ceq $RunId -and $Q.packageSha256 -ceq $P -and $Q.controlSha256 -ceq $ControlHash) 'P/Q/control/run binding failed'
 Require-Native ($C.packageSha256 -ceq $P -and $C.runId -ceq $RunId -and $C.scenario -ceq 'normal' -and $C.protocol -ceq 'lease-control.v1' -and $C.fixtureOnly -eq $true -and $C.productionTargetExecuted -eq $false) 'Normal control binding failed'
 Require-Native ($Q.run -ceq ($l.lab+'\runs\restricted-'+$RunId) -and $Q.originQpc -eq $Origin -and $Q.frequency -eq $Frequency -and $Q.hostPid -eq $HostPid -and $Q.hostCreationFileTime -eq $HostStart) 'Different host/path/original clock'
 Require-Native ($Q.prepared -eq $true -and $Q.nativeExecuted -eq $false -and $Q.mutexHeld -eq $true -and @($Q.objects).Count -gt 15) 'Incomplete receipt'
 foreach($f in @('userSid','logonSid','session','integrityRid','mandatoryPolicy')){Require-Native ($Q.expectedChildContract.$f -ceq $C.$f) ('Receipt child contract differs: '+$f)}
 $expected=Get-NativeExpectedChild $Q.originalIdentity
 Require-Native ((Get-NativeHash (ConvertTo-NativeBytes $expected)) -ceq (Get-NativeHash (ConvertTo-NativeBytes $Q.expectedChildContract))) 'Child expectation must derive from captured original identity'
}
function Assert-NativePreflight([scriptblock]$Backend,[string]$Lab,[bool]$Fresh){
 $rows=@(& $Backend 'QueryTargetProcesses' $null);Require-Native ($rows.Count -eq 0) 'Existing AA/probe blocks admission'
 Require-Native (-not (& $Backend 'Exists' ($Lab+'\pending.json'))) 'Exact lane pending blocks reentry'
 if($Fresh){Require-Native (-not (& $Backend 'Exists' $Lab)) 'Fresh lab only; no adoption'}
}
function Enter-NativeAdmission($Context,[scriptblock]$Backend){
 $r=& $Backend 'AcquireMutex' $null;$Context.mutexHeld=[bool]$r.acquired;$Context.abandoned=[bool]$r.abandoned
 Require-Native ($Context.mutexHeld -and -not $Context.abandoned) 'Mutex busy/abandoned; no adoption or retry'
 Assert-NativePreflight $Backend (Get-NativeLayout).lab $true
}
function Assert-NativeHelperBuild($Helper,$Build,$CurrentSources,[string]$InventoryHash,[string]$ActualHelperHash,[long]$ActualHelperBytes,[string]$BuildRecordPath,[string]$BuildRecordHash){
 $l=Get-NativeLayout
 Require-Native ($Helper.schema -ceq 'native-control-helper-binding.v1' -and $Helper.sourceInventorySha256 -ceq $InventoryHash -and $Helper.path -cmatch ([regex]::Escape($l.evidence)+'\\source-build-[0-9]+\\NativeControl\.Preparation\.dll$') -and $ActualHelperHash -ceq $Helper.sha256) 'Reviewed source-linked helper build required'
 $folder=[IO.Path]::GetDirectoryName($Helper.path)
 Require-Native ($BuildRecordPath -ceq ($folder+'\source-build.json') -and $Build.output -ceq $folder -and $BuildRecordHash -cmatch '^[a-f0-9]{64}$') 'Actual source-build record must belong to the selected helper directory'
 Require-Native ($Build.schema -ceq 'native-control-source-build.v1' -and $Build.sourceBuildOnly -is [bool] -and $Build.sourceBuildOnly -and $Build.runtimeAllowed -is [bool] -and -not $Build.runtimeAllowed -and $Build.nativeExecuted -is [bool] -and -not $Build.nativeExecuted -and $Build.normalDllLoaded -eq $false) 'Actual SOURCE-only compiler record required'
 Require-Native ($InventoryHash -ceq (Get-NativeHash (ConvertTo-NativeBytes $CurrentSources)) -and $Build.sourceInventorySha256 -ceq $InventoryHash) 'Actual source-build inventory differs from current reviewed source'
 $names=@($Build.sources|ForEach-Object{$_.name})
 Require-Native ($names.Count -eq @($CurrentSources).Count -and $names.Count -gt 0 -and @($names|Select-Object -Unique).Count -eq $names.Count) 'Actual build must contain the exact unique source inventory'
 foreach($source in @($CurrentSources)){
  $row=@($Build.sources|Where-Object{$_.name -ceq $source.path})
  Require-Native ($row.Count -eq 1 -and $row[0].sha256 -ceq $source.sha256 -and $row[0].bytes -eq $source.bytes) ('Actual compiled-source inventory mismatch: '+$source.path)
 }
 $input=@($Build.compilerInputs);$atomic=@($CurrentSources|Where-Object{$_.path -ceq 'AtomicPreparation.cs'})
 Require-Native ($input.Count -eq 1 -and $atomic.Count -eq 1 -and $input[0].name -ceq 'AtomicPreparation.cs' -and $input[0].sha256 -ceq $atomic[0].sha256 -and $input[0].bytes -eq $atomic[0].bytes -and $Build.compilerSha256 -cmatch '^[a-f0-9]{64}$') 'Actual helper compilation input differs from reviewed AtomicPreparation source'
 Require-Native ($ActualHelperBytes -gt 0 -and $Build.helperBytes -eq $ActualHelperBytes -and $Build.helperSha256 -ceq $ActualHelperHash -and $ActualHelperHash -cmatch '^[a-f0-9]{64}$') 'Actual compiler output does not match the selected helper DLL'
 [pscustomobject][ordered]@{schema='native-control-helper-provenance.v1';packageRecordPath='helper-source-build.json';sourceBuildManifestPath=$BuildRecordPath;sourceBuildManifestSha256=$BuildRecordHash;sourceInventorySha256=$InventoryHash;compilerSha256=$Build.compilerSha256;compilerInputs=$input;helperSha256=$ActualHelperHash;helperBytes=$ActualHelperBytes}
}
function Invoke-NativeHeldBoundary([scriptblock]$Run,[scriptblock]$NeedHold,[scriptblock]$Snapshot,[scriptblock]$Sink,[scriptblock]$Hold,[scriptblock]$Secondary){
 $primary=$null;$value=$null;$mustHold=$true
 try{$value=& $Run}catch{$primary=$_}
 finally{try{try{$mustHold=[bool](& $NeedHold)}catch{try{& $Secondary $_}catch{}}}finally{try{try{$state=& $Snapshot;& $Sink $state}catch{try{& $Secondary $_}catch{}}}finally{if($mustHold){& $Hold}}}}
 if($null -ne $primary){throw $primary};if($mustHold){throw 'Retained host callback returned unexpectedly'};return $value
}
Export-ModuleMember -Function Require-Native,Get-NativeLayout,Assert-NativeOwnedPath,Get-NativeHash,ConvertTo-NativeBytes,Assert-NativeObject,Assert-NativeDeadline,Assert-NativeIdentity,Get-NativeExpectedChild,Assert-NativeManifest,Assert-NativeBinding,Assert-NativePreflight,Enter-NativeAdmission,Assert-NativeHelperBuild,Invoke-NativeHeldBoundary
