#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)]$Context,[Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$VerifiedPreparedReceiptSha256,[Parameter(Mandatory)][scriptblock]$Backend)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -DisableNameChecking
$l=Get-NativeLayout;$build=$l.package;$lab=$l.lab;$manifest=$Context.manifest;$RunId=$Context.runId;$admissionQpc=$Context.originQpc
Require-Native ($Context.mutexHeld -and $Context.prepared -and $Context.hostPid -eq $PID -and $Context.mutexThreadId -eq [Threading.Thread]::CurrentThread.ManagedThreadId) 'Same original mutex-owning prepared controller only'
Assert-NativeManifest $manifest $Context.packageSha256 ([DateTime]::UtcNow.Ticks)
$null=Assert-NativeDeadline $admissionQpc (& $Backend 'Qpc' $null) $Context.frequency
# Q is runtime-produced-and-verified in this same host under reviewed P. It is
# not claimed to be manually pre-reviewed before its RunId/OS FILETIME existed.
$qRead=& $Backend 'ReadPrepared' 'tooling\prepared-run.json';Require-Native ($qRead.evidence.sha256 -ceq $VerifiedPreparedReceiptSha256 -and $VerifiedPreparedReceiptSha256 -ceq $Context.receiptSha256) 'Exact runtime Q digest required'
$q=[Text.Encoding]::UTF8.GetString($qRead.bytes)|ConvertFrom-Json
$controlRead=& $Backend 'ReadPrepared' 'tooling\control.json';$control=[Text.Encoding]::UTF8.GetString($controlRead.bytes)|ConvertFrom-Json
Assert-NativeBinding $q $control $Context.packageSha256 $controlRead.evidence.sha256 $RunId $admissionQpc $Context.frequency $PID (& $Backend 'HostCreationFileTime' $null)
foreach($object in @($q.objects)){$actual=& $Backend 'ReadObject' $object.path;Require-Native ($actual.identity -ceq $object.identity -and $actual.ownerAccessSddl -ceq $object.ownerAccessSddl -and $actual.directory -eq $object.directory -and -not $actual.reparse -and ($actual.directory -or ($actual.links -eq 1 -and $actual.sha256 -ceq $object.sha256))) 'Prepared object identity/ACL/hash drift'}
$run=$q.run;$controlPath=$run+'\tooling\control.json'
& $Backend 'AssertGatesAbsent' $run|Out-Null
$identity=& $Backend 'Identity' $RunId;Require-Native ((Get-NativeHash (ConvertTo-NativeBytes $identity)) -ceq (Get-NativeHash (ConvertTo-NativeBytes $Context.identity))) 'Original token changed before dispatch'
Require-Native (@(& $Backend 'QueryTargetProcesses' $null).Count -eq 0) 'Immediate AA/probe0 query required before dispatch'
Import-Module ($build+'\source\FixtureRules.psm1') -Force -DisableNameChecking
Assert-FixtureHost
function Capture-ProtectedFile { [pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read(($lab+'\install\protected\proof.bin'),$false);attributes=[int](Get-Item -LiteralPath ($lab+'\install\protected\proof.bin')).Attributes;captureHandleRetained=$false} }
function Capture-ProtectedDirectory { [pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read(($lab+'\install\protected'),$false);attributes=[int](Get-Item -LiteralPath ($lab+'\install\protected')).Attributes;children=@(Get-ChildItem -LiteralPath ($lab+'\install\protected') -Force|Select-Object -ExpandProperty Name|Sort-Object);captureHandleRetained=$false} }
$canaryBefore=Capture-ProtectedFile;$directoryBefore=Capture-ProtectedDirectory;$anchorsBefore=@($lab,($lab+'\install'))|ForEach-Object{[Azurite.Stage.FileSecurity]::Read($_,$false)}
Assert-Fixture (-not(Test-Path -LiteralPath ($run+'\request\protection-result.json'))) 'child positive control must not preexist'
Assert-FixtureWaitRuntimePins $manifest.runtimePins
$shell=Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell\v1.0\powershell.exe'
$psi=New-FixtureStart $shell ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+$run+'\tooling\RestrictedCliBootstrap.ps1 -ControlPath '+$controlPath+' -ReviewedControlSha256 '+(Get-FixtureHash $controlPath)) $run
$psi.EnvironmentVariables.Remove('PSModulePath')
$null=Assert-NativeDeadline $admissionQpc (& $Backend 'Qpc' $null) $Context.frequency
Require-Native (@(& $Backend 'QueryTargetProcesses' $null).Count -eq 0) 'Final immediate AA/probe0 query'
$Context.nativeInvoked=$true
$outer=[Azurite.Restricted.CdbOwnedWait]::RunPrepared($psi,$RunId,(Get-FixtureHash $controlPath),$manifest.probeSha256,$manifest.bootstrapSha256,$control.userSid,$control.logonSid,$admissionQpc)
$Context.outer=$outer
& $Backend 'WriteEvidence' @{name='outer-result.json';bytes=(ConvertTo-NativeBytes $outer)}|Out-Null
foreach($pair in @(@('bootstrap-stdout.raw',$outer.Stdout),@('bootstrap-stderr.raw',$outer.Stderr))){$raw=[Text.UTF8Encoding]::new($false).GetBytes([string]$pair[1]);Require-Native ($raw.Length -le 262144) 'Raw capture exceeded fixed bound';& $Backend 'WriteEvidence' @{name=$pair[0];bytes=$raw}|Out-Null}
$gate=[Azurite.Restricted.CdbOwnedWait]::Snapshot();$bootstrap=Read-FixtureJson ($run+'\output\fixture-bootstrap-result.json') 1048576
Assert-LeaseGateResult $outer $bootstrap $gate
$entry=Read-FixtureJson ($run+'\request\entry.json');Assert-FixtureChild $entry $control;Assert-FixtureNativeEvidence $bootstrap.native.Evidence $entry;Assert-FixtureCaptured $bootstrap.native.Process.Stdout $bootstrap.native.Process.Stderr $RunId
Assert-FixtureMonitorEvidence $outer.FullDesktopMonitorEvidence $RunId;Assert-FixtureMonitorEvidence $bootstrap.native.Evidence.fullDesktopMonitor $RunId;Assert-FixtureCleanupOrdering $outer.FullDesktopMonitorEvidence.outerDrain $outer $RunId
$wait=Assert-FixtureWaitProbe (Read-FixtureJson ($run+'\request\wait-host-entry.json')) (Read-FixtureJson ($run+'\request\wait-host-result.json')) (Read-FixtureJson ($run+'\request\wait-probe.json')) $RunId $entry.pid $bootstrap.native.Evidence.threadId (Get-Item ($run+'\request\wait-probe.json')).Length
$canaryAfter=Capture-ProtectedFile;$directoryAfter=Capture-ProtectedDirectory;$anchorsAfter=@($lab,($lab+'\install'))|ForEach-Object{[Azurite.Stage.FileSecurity]::Read($_,$false)}
$positive=[pscustomobject]@{object=[Azurite.Stage.FileSecurity]::Read(($run+'\request\protection-result.json'),$true);absentBeforeLaunch=$true;controllerCreatedResult=$false;captureHandleRetained=$false}
$protection=Assert-FixtureProtection (Read-FixtureJson ($run+'\request\protection-result.json')) $canaryBefore $canaryAfter $directoryBefore $directoryAfter $anchorsBefore $anchorsAfter $positive $RunId $entry.pid $bootstrap.native.Evidence.threadId $control.userSid $control.logonSid $manifest.canarySha256 36
Assert-FixtureWaitRuntimePins $manifest.runtimePins
[pscustomobject][ordered]@{passed=$true;outer=$outer;bootstrap=$bootstrap;gate=$gate;wait=$wait;protection=$protection;debuggerAttached=$false;aaExecuted=$false}
