#requires -Version 5.1
[CmdletBinding()]
param([switch]$Execute,[ValidatePattern('^[a-f0-9]{64}$')][string]$ReviewedPackageSha256)
# One monotonic origin precedes every preparation operation; no later origin.
$originQpc=[Diagnostics.Stopwatch]::GetTimestamp()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module ($PSScriptRoot+'\NativeControl.psm1') -DisableNameChecking
$l=Get-NativeLayout
if(-not $Execute){[pscustomobject]@{sourceBuildOnly=$true;runtimeAllowed=$false;fixedLab=$l.lab;protocol='lease-control.v1';normalOnly=$true;outerIncludesPreparation=$true;dynamicQ='runtime-produced-and-verified';nativeExecuted=$false};return}
Require-Native ([Environment]::Is64BitProcess -and $PSVersionTable.PSEdition -ceq 'Desktop' -and $PSVersionTable.PSVersion.Major -eq 5 -and $PSVersionTable.PSVersion.Minor -eq 1) 'Fresh x64 PS5.1 only'
Require-Native (-not('Azurite.Restricted.ProcessPump' -as [type]) -and -not('Azurite.NativeControl.WindowsAtomicApi' -as [type])) 'Fresh host required; no earlier native/helper owners'
$manifestPath=$l.package+'\manifest.json';$manifestBytes=[IO.File]::ReadAllBytes($manifestPath)
Require-Native ($ReviewedPackageSha256 -and $manifestBytes.Length -le 4194304 -and (Get-NativeHash $manifestBytes) -ceq $ReviewedPackageSha256) 'Exact separately reviewed immutable P required'
$manifest=[Text.Encoding]::UTF8.GetString($manifestBytes)|ConvertFrom-Json
Assert-NativeManifest $manifest $ReviewedPackageSha256 ([DateTime]::UtcNow.Ticks)
foreach($row in $manifest.files){$p=$l.package+'\'+$row.path;$i=Get-Item -LiteralPath $p -Force;Require-Native (-not $i.PSIsContainer -and -not($i.Attributes -band [IO.FileAttributes]::ReparsePoint) -and $i.Length -eq $row.bytes -and (Get-NativeHash ([IO.File]::ReadAllBytes($p))) -ceq $row.sha256) 'Frozen package drift'}
foreach($name in @('Invoke-NativeControlHeld.ps1','Prepare-Control.ps1','Run-Fixture.ps1','NativeControl.psm1')){Require-Native ((Get-NativeHash ([IO.File]::ReadAllBytes($PSScriptRoot+'\'+$name))) -ceq (Get-NativeHash ([IO.File]::ReadAllBytes($l.package+'\source\'+$name)))) 'Executed source differs from P'}
$cursor=$l.package;while($cursor){$i=Get-Item -LiteralPath $cursor -Force;Require-Native ($i.PSIsContainer -and -not($i.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'Existing package ancestors must be ordinary';$cursor=Split-Path -Parent $cursor}
Add-Type -Path ($l.package+'\NativeControl.Preparation.dll')
# Both sibling closures must capture their callable module bindings before use.
Import-Module ($l.package+'\source\FixtureAcl.psm1') -DisableNameChecking
$ctx=[pscustomobject]@{runId=[guid]::NewGuid().ToString('N');packageSha256=$ReviewedPackageSha256;manifest=$manifest;originQpc=$originQpc;frequency=[Diagnostics.Stopwatch]::Frequency;hostPid=$PID;hostCreationFileTime=0L;mutexThreadId=[Threading.Thread]::CurrentThread.ManagedThreadId;mutexHeld=$false;abandoned=$false;identity=$null;privateFile=$null;preparationStarted=$false;prepared=$false;run=$null;control=$null;controlSha256=$null;receipt=$null;receiptSha256=$null;objects=[Collections.Generic.List[object]]::new();sources=[Collections.Generic.List[object]]::new();attempts=[Collections.Generic.List[object]]::new();diagnosticErrors=[Collections.Generic.List[string]]::new();primaryError=$null;outer=$null;nativeInvoked=$false;nativeOwnersResolved=$false;finalEvidenceDurable=$false;releaseComplete=$false;failureCleanupAttempted=$false;failureCleanupComplete=$false;api=$null;creator=$null;mutex=$null}
$ctx.api=[Azurite.NativeControl.WindowsAtomicApi]::new($l.lab);$ctx.creator=[Azurite.NativeControl.AtomicCreator]::new($l.lab,$ctx.api)
$originalOut=[Console]::Out;$originalError=[Console]::Error;$rawOut=[Azurite.NativeControl.BoundedTextCapture]::new();$rawError=[Azurite.NativeControl.BoundedTextCapture]::new()
[Console]::SetOut($rawOut);[Console]::SetError($rawError)
$backend={param($action,$arg)
 switch($action){
  AcquireMutex {$ctx.mutex=[Threading.Mutex]::new($false,$l.mutex);$held=$false;$abandoned=$false;try{$held=$ctx.mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$held=$true;$abandoned=$true};return @{acquired=$held;abandoned=$abandoned}}
  Qpc {return [Diagnostics.Stopwatch]::GetTimestamp()}
  HostCreationFileTime {return $ctx.api.ReadHostCreationFileTime()}
  QueryTargetProcesses {return @(Get-CimInstance Win32_Process -Filter "Name='AzureArchive.exe' OR Name='AzuriteLifecycleProbe.exe'" -ErrorAction Stop)}
  Exists {try{$null=[IO.File]::GetAttributes([string]$arg);return $true}catch [IO.FileNotFoundException]{return $false}catch [IO.DirectoryNotFoundException]{return $false}}
  LockAncestors {$ctx.api.LockAncestors();return}
  Identity {return [Azurite.Restricted.FullBootstrapIdentity]::Read([string]$arg)}
  GateAcl {$p=Get-LeaseGateAclPlan $arg.userSid $arg.logonSid;Assert-LeaseGateAclPlan $p;return $p}
  Create {return $ctx.creator.New($arg.path,$arg.directory,$arg.sddl,$arg.bytes)}
  ReadPackage {$row=@($manifest.files|Where-Object{$_.path -ceq $arg});Require-Native ($row.Count -eq 1) 'Exact package member only';$r=$ctx.api.ReadFile(($l.package+'\'+$arg),1);Require-Native ($r.evidence.sha256 -ceq $row[0].sha256 -and $r.evidence.bytes -eq $row[0].bytes) 'Pinned source copy readback failed';return $r}
  ReadPrepared {Require-Native ($arg -cin @('tooling\prepared-run.json','tooling\control.json')) 'Fixed prepared receipt/control only';return $ctx.api.ReadFile(($ctx.run+'\'+$arg),1)}
  ReadObject {$null=Assert-NativeOwnedPath $arg $l.lab;return $ctx.api.ReadObject($arg)}
  AssertGatesAbsent {foreach($leaf in @('control\lease-offer.json','control\lease-ack.json','control\go.json','request\child-ready.json','request\protection-result.json')){try{$null=[IO.File]::GetAttributes($arg+'\'+$leaf);throw 'Gate/positive-control already exists'}catch [IO.FileNotFoundException]{}catch [IO.DirectoryNotFoundException]{throw 'Prepared gate directory missing'}};return}
  WriteEvidence {Require-Native ($arg.name -cmatch '^[a-z0-9-]+\.(?:json|raw)$' -and $arg.bytes.Length -le 4194304) 'Finite evidence leaf/size only';return $ctx.creator.New(($ctx.run+'\tooling\evidence\'+$arg.name),$false,$ctx.privateFile,[byte[]]$arg.bytes)}
  default {throw ('Unknown fixed native preparation action '+$action)}
 }
}.GetNewClosure()
$run={
 try{
  $ctx.hostCreationFileTime=$ctx.api.ReadHostCreationFileTime()
  $shell='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';Require-Native ([Diagnostics.Process]::GetCurrentProcess().MainModule.FileName -ceq $shell) 'Exact pinned system x64 PowerShell host only'
  $shellRead=$ctx.api.ReadFile($shell,2);Require-Native ($shellRead.evidence.sha256 -ceq $manifest.systemPowerShell.sha256 -and $manifest.systemPowerShell.links -eq 2 -and $manifest.systemPowerShell.bytes -eq 495616 -and $shellRead.evidence.bytes -eq 495616) 'Read-only pinned system PowerShell has exactly two known hardlinks'
  foreach($row in $manifest.files){$r=$ctx.api.ReadFile(($l.package+'\'+$row.path),1);Require-Native ($r.evidence.sha256 -ceq $row.sha256 -and $r.evidence.bytes -eq $row.bytes) 'Same-handle immutable package readback failed'}
  Enter-NativeAdmission $ctx $backend
  [Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
  Add-Type -Path ($l.package+'\AzuriteLifecycle.FixtureOnly.dll')
  Require-Native ([Azurite.Restricted.LifecycleFixture]::Lab -ceq $l.lab) 'Compiled fixed lab differs'
  $null=& ($PSScriptRoot+'\Prepare-Control.ps1') $ctx $backend
  & $backend 'WriteEvidence' @{name='admission.json';bytes=(ConvertTo-NativeBytes @{packageSha256=$ctx.packageSha256;receiptSha256=$ctx.receiptSha256;originQpc=$ctx.originQpc;hostPid=$ctx.hostPid;hostCreationFileTime=$ctx.hostCreationFileTime;receiptReview='runtime-produced-and-verified';nativeExecuted=$false})}|Out-Null
  $result=& ($PSScriptRoot+'\Run-Fixture.ps1') $ctx $ctx.receiptSha256 $backend
  Require-Native (-not [Azurite.Restricted.CdbOwnedWait]::MustHoldHost()) 'Actual native owners unresolved'
  $ctx.nativeOwnersResolved=$true
  $after=& $backend 'Identity' $ctx.runId;Require-Native ((Get-NativeHash (ConvertTo-NativeBytes $after)) -ceq (Get-NativeHash (ConvertTo-NativeBytes $ctx.identity))) 'Original controller token changed'
  & $backend 'WriteEvidence' @{name='actual-result.json';bytes=(ConvertTo-NativeBytes $result)}|Out-Null
  & $backend 'WriteEvidence' @{name='final-native-ownership.json';bytes=(ConvertTo-NativeBytes @{runId=$ctx.runId;nativeOwnersResolved=$true;gate=[Azurite.Restricted.CdbOwnedWait]::Snapshot();pendingRemoval='not-yet-attempted';mutexRelease='not-yet-attempted';preparationHandleClose='not-yet-attempted'})}|Out-Null
  foreach($pair in @(@('controller-stdout.raw',$rawOut.Snapshot()),@('controller-stderr.raw',$rawError.Snapshot()))){$bytes=[Text.UTF8Encoding]::new($false).GetBytes($pair[1]);Require-Native ($bytes.Length -le 524288) 'Controller capture bound';& $backend 'WriteEvidence' @{name=$pair[0];bytes=$bytes}|Out-Null}
  $ctx.finalEvidenceDurable=$true
  $null=Assert-NativeDeadline $ctx.originQpc ([Diagnostics.Stopwatch]::GetTimestamp()) $ctx.frequency 0
  $pending=@($ctx.objects|Where-Object{$_.path -ceq ($l.lab+'\pending.json')});Require-Native ($pending.Count -eq 1) 'Exact owned pending required'
  $ctx.api.CloseAll();$ctx.api.DeletePending($pending[0])
  Require-Native (-not $ctx.api.HasUnresolvedHandles -and -not [Azurite.Restricted.CdbOwnedWait]::MustHoldHost()) 'Actual native/preparation owners must all resolve'
  $ctx.mutex.ReleaseMutex();$ctx.mutexHeld=$false;$ctx.mutex.Dispose();$ctx.releaseComplete=$true
  [Console]::SetOut($originalOut);[Console]::SetError($originalError)
  return [pscustomobject]@{passed=$true;runId=$ctx.runId;packageSha256=$ctx.packageSha256;receiptSha256=$ctx.receiptSha256;nativeOwnersResolved=$true;preparationHandlesClosed=$true;mutexReleased=$true;pendingRemoved=$true;durableFinalNativeDisposition=$true;controllerReleaseAcknowledgement='returned by original controller; not part of earlier durable native disposition'}
 }catch{
  $primary=$_;$ctx.primaryError=$primary.Exception.ToString();try{[Console]::Error.WriteLine($ctx.primaryError)}catch{$ctx.diagnosticErrors.Add($_.Exception.ToString())}
  # No created objects or native invocation: only original readonly prep refs
  # may close, once, followed by this thread's original nonabandoned mutex.
  if(-not $ctx.nativeInvoked -and -not $ctx.preparationStarted -and -not $ctx.prepared -and $ctx.attempts.Count -eq 0 -and $ctx.objects.Count -eq 0 -and $ctx.creator.Attempts.Count -eq 0 -and $ctx.mutexHeld -and -not $ctx.abandoned -and $ctx.mutexThreadId -eq [Threading.Thread]::CurrentThread.ManagedThreadId -and -not $ctx.failureCleanupAttempted){
   $ctx.failureCleanupAttempted=$true
   try{
    $ctx.api.CloseAll();Require-Native (-not $ctx.api.HasUnresolvedHandles) 'Early failure preparation references unresolved'
    $ctx.mutex.ReleaseMutex();$ctx.mutexHeld=$false;$ctx.mutex.Dispose()
    [Console]::SetOut($originalOut);[Console]::SetError($originalError)
    $ctx.failureCleanupComplete=$true
   }catch{$ctx.diagnosticErrors.Add($_.Exception.ToString())}
  }
  throw $primary
 }
}.GetNewClosure()
$decision={if($ctx.releaseComplete -or $ctx.failureCleanupComplete){return $false};if($ctx.failureCleanupAttempted -or $ctx.mutexHeld -or $ctx.preparationStarted -or $ctx.api.HasUnresolvedHandles){return $true};if('Azurite.Restricted.CdbOwnedWait' -as [type]){return [Azurite.Restricted.CdbOwnedWait]::MustHoldHost()};return $false}.GetNewClosure()
$snapshot={return @{primaryError=$ctx.primaryError;secondaryErrors=$ctx.diagnosticErrors.ToArray();runId=$ctx.runId;mutexHeld=$ctx.mutexHeld;prepared=$ctx.prepared;nativeInvoked=$ctx.nativeInvoked;nativeOwnersResolved=$ctx.nativeOwnersResolved;finalEvidenceDurable=$ctx.finalEvidenceDurable;releaseComplete=$ctx.releaseComplete;attempts=$ctx.attempts.ToArray();atomicAttempts=$ctx.creator.Attempts.ToArray();gate=$(if('Azurite.Restricted.CdbOwnedWait' -as [type]){[Azurite.Restricted.CdbOwnedWait]::Snapshot()}else{$null})}}.GetNewClosure()
$sink={param($state)if($ctx.preparationStarted -and -not $ctx.releaseComplete){if($ctx.prepared){& $backend 'WriteEvidence' @{name='retained-host-state.json';bytes=(ConvertTo-NativeBytes $state)}|Out-Null}else{$null=$ctx.creator.New(($l.lab+'\preparation-failure.json'),$false,$ctx.privateFile,(ConvertTo-NativeBytes $state))}}}.GetNewClosure()
$secondary={param($errorRecord)$ctx.diagnosticErrors.Add($errorRecord.Exception.ToString());try{$originalError.WriteLine('Secondary diagnostic failure: '+$errorRecord.Exception.Message)}catch{}}.GetNewClosure()
$hold={try{$originalError.WriteLine('Unresolved original controller owners or preparation failure. Preserve this host, mutex and artifacts; no retry, external kill, or cleanup.')}catch{};while($true){[Threading.Thread]::Sleep(1000)}}.GetNewClosure()
Invoke-NativeHeldBoundary $run $decision $snapshot $sink $hold $secondary
