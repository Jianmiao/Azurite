Set-StrictMode -Version Latest
$script:FixtureLab='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38\artifacts\aa-fr-native-lifecycle-fixture\lab-hkcr-control'
function Get-FixtureLab {return $script:FixtureLab}
function Assert-Fixture($Condition,[string]$Message){if(-not $Condition){throw "Fixture failed: $Message"}}
function Get-FixtureHash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read-FixtureJson([string]$Path,[int]$Limit=1048576){
 $i=Get-Item -LiteralPath $Path -Force;Assert-Fixture (-not $i.PSIsContainer -and -not($i.Attributes -band [IO.FileAttributes]::ReparsePoint) -and $i.Length -gt 1 -and $i.Length -le $Limit) 'JSON type/bound'
 $params=@{InputObject=[IO.File]::ReadAllText($Path);ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$params.DateKind='String'};ConvertFrom-Json @params
}
function Write-FixtureJson([string]$Path,$Value){$b=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 80 -Compress));Assert-Fixture ($b.Length -le 1048576) 'JSON write bound';$s=[IO.FileStream]::new($Path,'CreateNew','Write','Read');try{$s.Write($b,0,$b.Length);$s.Flush($true)}finally{$s.Dispose()}}
function New-FixtureStart([string]$File,[string]$Arguments,[string]$Working){$p=[Diagnostics.ProcessStartInfo]::new();$p.FileName=$File;$p.Arguments=$Arguments;$p.WorkingDirectory=$Working;$p.UseShellExecute=$false;$p.CreateNoWindow=$true;$p.RedirectStandardOutput=$true;$p.RedirectStandardError=$true;return $p}
function Assert-FixtureChild($Entry,$Control){
 Assert-Fixture ($Entry.schema -eq 1 -and $Entry.fixtureOnly -eq $true -and $Entry.productionTargetExecuted -eq $false -and $Entry.runId -ceq $Control.runId -and $Entry.scenario -ceq $Control.scenario -and $Entry.pid -gt 0) 'actual child correlation'
 Assert-Fixture ($Entry.userSid -ceq $Control.userSid -and $Entry.logonSid -ceq $Control.logonSid -and $Entry.session -eq $Control.session -and $Entry.integrityRid -eq $Control.integrityRid -and $Entry.integrityAttributes -eq 96 -and $Entry.mandatoryPolicy -eq $Control.mandatoryPolicy -and $Entry.elevated -eq 0 -and $Entry.appContainer -eq 0 -and $Entry.tokenType -eq 1 -and $Entry.isRestricted -eq $true) 'actual child identity/inherited policy'
 Assert-Fixture ($Entry.restrictedSidCount -eq 3 -and @($Entry.restrictingSids).Count -eq 3 -and (($Entry.restrictingSids|Sort-Object) -join '|') -ceq ((@($Control.logonSid,'S-1-1-0','S-1-5-32-545')|Sort-Object) -join '|') -and ($Entry.usersAttributes -band 4) -and -not($Entry.usersAttributes -band 16) -and $Entry.privilege -ceq 'SeChangeNotifyPrivilege' -and $Entry.privilegeEnabled -eq $true) 'actual child FR1 SID/privilege contract'
 Assert-Fixture ($Entry.desktop -ceq ('AzuriteFullCli_'+$Control.runId) -and $Entry.anyJobMembership -eq $true -and $Entry.exactJobClaimedByChild -eq $false) 'actual private desktop and correctly limited Job claim'
 Assert-Fixture (@($Entry.stdHandles).Count -eq 3 -and @($Entry.stdHandles|Select-Object -Unique).Count -eq 3 -and @($Entry.stdHandles|Where-Object{$_ -le 0}).Count -eq 0 -and @($Entry.stdTypes).Count -eq 3 -and @($Entry.stdTypes|Where-Object{$_ -ne 3}).Count -eq 0 -and @($Entry.stdFlags).Count -eq 3 -and @($Entry.stdFlags|Where-Object{-not($_ -band 1)}).Count -eq 0 -and $Entry.stdinEof -eq $true -and $Entry.streamsWritten -eq $true) 'actual standard endpoint directions/EOF'
}
function Assert-FixtureNativeEvidence($Evidence,$Entry){
 Assert-Fixture ($Evidence.actualTokenVerified -eq $true -and $Evidence.exactOwnedJobVerified -eq $true -and $Evidence.outerDesktopLeaseAcknowledged -eq $true -and $Evidence.creationFlags -eq 0x08084404) 'actual suspended token/exact Job/pre-resume desktop'
 Assert-Fixture (@($Evidence.pipeHandlesBeforeCreate).Count -eq 6) 'six real queried pipe endpoints'
 $children=@($Evidence.pipeHandlesBeforeCreate|Select-Object -First 3);for($i=0;$i -lt 3;$i++){Assert-Fixture ($children[$i].handle -eq $Entry.stdHandles[$i] -and $children[$i].flags -band 1 -and $children[$i].fileType -eq 3) 'parent HANDLE_LIST and child endpoint identity'}
 foreach($p in @($Evidence.pipeHandlesBeforeCreate|Select-Object -Skip 3)){Assert-Fixture (-not($p.flags -band 1)) 'parent endpoints noninherited'}
}
function Assert-FixtureOuter($Outer,[string]$Scenario){
 Assert-Fixture ($Outer.CleanupVerified -eq $true -and $Outer.DirectProcessExited -eq $true -and $Outer.JobDrained -eq $true -and $Outer.RemainingOwnedProcesses -eq 0 -and $Outer.JobObserved -eq $true -and $Outer.DesktopLeaseObserved -eq $true -and $Outer.DesktopLeaseClosed -eq $true -and $Outer.DesktopLeaseRetained -eq $false -and $Outer.FullJobObserverClosed -eq $true -and $Outer.FullJobObserverRetained -eq $false -and $Outer.StreamCaptureComplete -eq $true) 'actual outer cleanup/lease release'
 Assert-Fixture (-not $Outer.TimedOut -and -not $Outer.WindowViolation -and -not $Outer.OutputLimitExceeded -and [string]::IsNullOrEmpty($Outer.Error)) 'outer deadline/window/output/error'
 Assert-Fixture ($Outer.ExitCode -eq $(if($Scenario -ceq 'normal'){0}else{73})) 'exact finite scenario exit'
}
function Assert-FixtureCaptured([string]$Stdout,[string]$Stderr,[string]$RunId){Assert-Fixture ($Stdout -ceq ("FIXTURE_STDOUT "+$RunId+" "+[char]0x20ac+[char]10) -and $Stderr -ceq ("FIXTURE_STDERR "+$RunId+" "+[char]::ConvertFromUtf32(0x1f31f)+[char]10)) 'actual captured split UTF8 text'}
function Assert-FixtureImagePins($Pins){
 Assert-Fixture ($Pins -is [array] -and $Pins.Count -eq 2) 'imagePins must be exact two-row JSON array, never value/Count wrapper'
 $expected=@(@('user32.dll','4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91',[long]0x2a9a0),@('win32u.dll','ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4',[long]0x1610))
 $fields=@('name','path','expectedPath','sha256','expectedSha256','fixedFileVersion','expectedFixedFileVersion','rawFileVersion','rawProductVersion','language','exportOffset','expectedExportOffset','reparse','pathMatch','hashMatch','fixedVersionMatch','exportMatch','nonReparseMatch')
 for($i=0;$i -lt 2;$i++){
  $row=$Pins[$i];Assert-Fixture ($null -ne $row) 'image pin row missing'
  $names=if($row -is [Collections.IDictionary]){@($row.Keys)}else{@($row.PSObject.Properties.Name)}
  Assert-Fixture ($names.Count -eq $fields.Count -and @($fields|Where-Object {$names -cnotcontains $_}).Count -eq 0) 'image pin actual/expected field shape differs'
  $path='C:\Windows\System32\'+$expected[$i][0]
  Assert-Fixture ($row.name -ceq $expected[$i][0] -and $row.path -is [string] -and $row.expectedPath -is [string] -and [string]::Equals($row.path,$path,[StringComparison]::OrdinalIgnoreCase) -and [string]::Equals($row.expectedPath,$path,[StringComparison]::OrdinalIgnoreCase)) 'actual and expected loaded image paths must be exact pinned System32 files'
  Assert-Fixture ($row.sha256 -ceq $expected[$i][1] -and $row.expectedSha256 -ceq $expected[$i][1] -and $row.fixedFileVersion -ceq '10.0.26100.9818' -and $row.expectedFixedFileVersion -ceq '10.0.26100.9818') 'actual/expected image hash and fixed version must match reviewed bytes'
  Assert-Fixture (($row.exportOffset -is [int] -or $row.exportOffset -is [long]) -and ($row.expectedExportOffset -is [int] -or $row.expectedExportOffset -is [long]) -and $row.exportOffset -eq $expected[$i][2] -and $row.expectedExportOffset -eq $expected[$i][2]) 'actual/expected loaded export offsets must match'
  foreach($flag in @('pathMatch','hashMatch','fixedVersionMatch','exportMatch','nonReparseMatch')){Assert-Fixture ($row.$flag -is [bool] -and $row.$flag -eq $true) ('actual image pin flag '+$flag)}
  Assert-Fixture ($row.reparse -is [bool] -and $row.reparse -eq $false) 'actual image file must be nonreparse'
  foreach($raw in @('rawFileVersion','rawProductVersion','language')){Assert-Fixture ($row.$raw -is [string] -and -not [string]::IsNullOrWhiteSpace($row.$raw)) ('raw observed image metadata '+$raw+' required without a localized string whitelist')}
 }
}
function Assert-FixtureMonitorEvidence($Monitor,[string]$RunId){
 $pin='user32.dll|10.0.26100.9818|4f66c3c584276f7df0dbfb78332315990ef81276661c8eacd8ba93197931ff91|EnumDesktopWindows:0x2a9a0;win32u.dll|10.0.26100.9818|ad301c9614d1a769d165cd57d220c5000a5dacbab4b98c776c8f3d3ebf9876e4|NtUserBuildHwndList:0x1610'
 Assert-Fixture ($null -ne $Monitor -and $Monitor.emptyCount -gt 0 -and $Monitor.normalCount -eq 0 -and $Monitor.failedCount -eq 0 -and $Monitor.boundedStoredObservations -in @(1,2) -and $Monitor.pinnedImageIdentity -ceq $pin) 'actual pinned-empty monitor use/counters/version required, not default values'
 foreach($observation in @($Monitor.first,$Monitor.last)){
  Assert-FixtureImagePins $observation.imagePins
  Assert-Fixture ($null -ne $observation -and $observation.usedPath -ceq 'pinned-empty' -and $observation.expectedName -ceq ('AzuriteFullCli_'+$RunId) -and $observation.handle -gt 0 -and $observation.observedUtc -match 'Z$' -and $observation.foregroundOwned -eq $false -and $observation.violation -eq $false) 'real run-correlated completed monitor observation'
  Assert-Fixture ($observation.enumeration.returned -eq $false -and $observation.enumeration.error -eq 0 -and $observation.enumeration.callbacks -eq 0 -and $observation.enumeration.visible -eq $false -and $null -eq $observation.enumeration.callbackError) 'measured false/zero/zero-callback monitor input'
  Assert-Fixture ($observation.list.status -eq 0 -and $observation.list.lastError -eq 0 -and $observation.list.capacity -eq 64 -and $observation.list.needed -eq 1 -and $observation.list.first -eq 1 -and $observation.list.guardsIntact -eq $true -and $observation.list.tailIntact -eq $true) 'actual bounded status/count/sentinel1 observation'
  foreach($identity in @($observation.identityBefore,$observation.identityAfter)){
   Assert-Fixture ($identity.handle -eq $observation.handle -and $identity.name -ceq $observation.expectedName -and $identity.type -ceq 'Desktop' -and $identity.owner -ceq $identity.currentOwner -and $identity.owner -match '^S-1-5-21-' -and $identity.rightsQueryStatus -eq 0 -and ($identity.grantedAccess -band 1) -eq 1 -and $identity.inherited -eq $false) 'actual owned desktop identity/readrights before/after'
  }
 }
}
function Assert-FixtureCleanupOrdering($Trace,$Outer,[string]$RunId){
 function Test-CleanupInteger($Value){return ($Value -is [int] -or $Value -is [long])}
 function Require-CleanupShape($Value,[string[]]$Fields,[string]$Label){
  Assert-Fixture ($null -ne $Value -and $Value -isnot [array] -and $Value -isnot [string]) ($Label+' object required')
  $keys=if($Value -is [Collections.IDictionary]){@($Value.Keys)}else{@($Value.PSObject.Properties.Name)}
  Assert-Fixture ($keys.Count -eq $Fields.Count -and @($Fields|Where-Object {$keys -cnotcontains $_}).Count -eq 0) ($Label+' exact fields required')
 }
 $fields=@('schema','runId','bootstrapPid','processStarted','contextBound','jobRole','jobAcquired','desktopRole','desktopAcquired','desktopName','qpcFrequency','capacity','recordCount','droppedCount','complete','recordError','externalLiveDescendantIntervalClaimed','records')
 Require-CleanupShape $Trace $fields 'cleanup trace'
 Assert-Fixture ($RunId -cmatch '^[a-f0-9]{32}$' -and $Trace.schema -is [string] -and $Trace.schema -ceq 'cleanup-ordering.v1' -and $Trace.runId -is [string] -and $Trace.runId -ceq $RunId) 'cleanup schema/run identity'
 foreach($name in @('processStarted','contextBound','complete')){Assert-Fixture ($Trace.$name -is [bool] -and $Trace.$name) ('cleanup true Boolean '+$name)}
 Assert-Fixture ($Trace.externalLiveDescendantIntervalClaimed -is [bool] -and -not $Trace.externalLiveDescendantIntervalClaimed -and $null -eq $Trace.recordError) 'cleanup evidence does not claim old interval and has no record error'
 foreach($name in @('bootstrapPid','jobAcquired','desktopAcquired','qpcFrequency','capacity','recordCount','droppedCount')){Assert-Fixture (Test-CleanupInteger $Trace.$name) ('cleanup integer '+$name)}
 Assert-Fixture ($Trace.bootstrapPid -gt 0 -and $Trace.bootstrapPid -le [int]::MaxValue -and $Trace.jobAcquired -gt 0 -and $Trace.desktopAcquired -gt 0 -and $Trace.jobAcquired -ne $Trace.desktopAcquired -and $Trace.qpcFrequency -gt 0 -and $Trace.capacity -eq 2048 -and $Trace.droppedCount -eq 0 -and $Trace.records -is [array] -and $Trace.recordCount -ge 7 -and $Trace.recordCount -le 2048 -and $Trace.recordCount -eq $Trace.records.Count) 'cleanup bounds and accepted references'
 Assert-Fixture ($Trace.jobRole -is [string] -and $Trace.jobRole -ceq 'outer-job-observer' -and $Trace.desktopRole -is [string] -and $Trace.desktopRole -ceq 'outer-private-desktop' -and $Trace.desktopName -is [string] -and $Trace.desktopName -ceq ('AzuriteFullCli_'+$RunId)) 'cleanup owned reference roles/name'
 Assert-Fixture ($null -ne $Outer -and (Test-CleanupInteger $Outer.Pid) -and $Outer.Pid -eq $Trace.bootstrapPid -and $Outer.RunId -is [string] -and $Outer.RunId -ceq $RunId) 'cleanup outer PID/run binding'
 foreach($name in @('CleanupVerified','DirectProcessExited','JobDrained','JobObserved','DesktopLeaseObserved','DesktopLeaseClosed','FullJobObserverClosed','StreamCaptureComplete','FullRestrictedMode')){Assert-Fixture ($Outer.$name -is [bool] -and $Outer.$name) ('cleanup outer true Boolean '+$name)}
 foreach($name in @('TimedOut','WindowViolation','OutputLimitExceeded','DesktopLeaseRetained','FullJobObserverRetained','NoProcessCreated')){Assert-Fixture ($Outer.$name -is [bool] -and -not $Outer.$name) ('cleanup outer false Boolean '+$name)}
 foreach($name in @('RemainingOwnedProcesses','FullJobObserverCloseError')){Assert-Fixture ((Test-CleanupInteger $Outer.$name) -and $Outer.$name -eq 0) ('cleanup outer zero integer '+$name)}
 foreach($name in @('Error','CleanupError')){Assert-Fixture ($null -eq $Outer.$name -or ($Outer.$name -is [string] -and $Outer.$name.Length -eq 0)) ('cleanup outer error '+$name)}
 $start=[datetime]::MinValue
 if($Outer.StartedUtc -is [datetime]){$start=$Outer.StartedUtc;Assert-Fixture ($start.Kind -eq [DateTimeKind]::Utc) 'cleanup UTC process start'}
 else{Assert-Fixture ($Outer.StartedUtc -is [string] -and [datetime]::TryParseExact($Outer.StartedUtc,"yyyy-MM-dd'T'HH:mm:ss.fffffff'Z'",[Globalization.CultureInfo]::InvariantCulture,([Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal),[ref]$start)) 'cleanup canonical process start'}
 Assert-Fixture ($start -gt [datetime]::MinValue -and (Test-CleanupInteger $Outer.ExitCode) -and $Outer.ExitCode -in @(0,73)) 'cleanup actual start and finite scenario result'
 Assert-FixtureOuter $Outer $(if($Outer.ExitCode -eq 0){'normal'}else{'bootstrap-exit'})
 $rowFields=@('ordinal','parentOrdinal','phase','iteration','operation','beforeQpc','afterQpc','completed','threw','resultKind','boolean','number','error','jobAcquired','jobBefore','jobAfter','jobClosedBefore','jobClosedAfter','jobRetainedBefore','jobRetainedAfter','jobCloseAttemptedBefore','jobCloseAttemptedAfter','jobCloseErrorAfter','desktopAcquired','desktopBefore','desktopAfter','desktopClosedBefore','desktopClosedAfter','desktopRetainedBefore','desktopRetainedAfter','desktopCloseAttemptedBefore','desktopCloseAttemptedAfter','desktopCloseErrorAfter')
 $boolFields=@('completed','threw','jobClosedBefore','jobClosedAfter','jobRetainedBefore','jobRetainedAfter','jobCloseAttemptedBefore','jobCloseAttemptedAfter','desktopClosedBefore','desktopClosedAfter','desktopRetainedBefore','desktopRetainedAfter','desktopCloseAttemptedBefore','desktopCloseAttemptedAfter')
 $integerFields=@('ordinal','parentOrdinal','iteration','beforeQpc','afterQpc','jobAcquired','jobBefore','jobAfter','jobCloseErrorAfter','desktopAcquired','desktopBefore','desktopAfter','desktopCloseErrorAfter')
 $rows=$Trace.records;$lastStart=[long]0;$lastTopEnd=[long]0
 for($i=0;$i -lt $rows.Count;$i++){
  $row=$rows[$i];Require-CleanupShape $row $rowFields 'cleanup call'
  foreach($name in $boolFields){Assert-Fixture ($row.$name -is [bool]) ('cleanup call typed Boolean '+$name)}
  foreach($name in $integerFields){Assert-Fixture (Test-CleanupInteger $row.$name) ('cleanup call integer '+$name)}
  Assert-Fixture ($row.ordinal -eq $i+1 -and $row.iteration -gt 0 -and $row.parentOrdinal -ge 0 -and $row.completed -and -not $row.threw -and $null -eq $row.error -and $row.beforeQpc -gt 0 -and $row.beforeQpc -ge $lastStart -and $row.afterQpc -ge $row.beforeQpc) 'cleanup complete monotonic actual call'
  Assert-Fixture ($row.phase -is [string] -and $row.operation -is [string] -and $row.resultKind -is [string]) 'cleanup operation strings'
  if($row.parentOrdinal -eq 0){Assert-Fixture ($row.beforeQpc -ge $lastTopEnd) 'cleanup top-level call ordering';$lastTopEnd=$row.afterQpc}
  else{Assert-Fixture ($i -gt 0 -and $row.operation -ceq 'ProcessIds' -and $rows[$i-1].operation -ceq 'WindowViolation' -and $rows[$i-1].parentOrdinal -eq 0 -and $row.parentOrdinal -eq $rows[$i-1].ordinal -and $row.iteration -eq $rows[$i-1].iteration -and $row.beforeQpc -ge $rows[$i-1].beforeQpc -and $row.afterQpc -le $rows[$i-1].afterQpc) 'cleanup actual nested ProcessIds interval'}
  $lastStart=$row.beforeQpc
  if($row.operation -cin @('DirectExited','WindowViolation','FinishStreams')){Assert-Fixture ($row.resultKind -ceq 'boolean' -and $row.boolean -is [bool] -and $null -eq $row.number) 'cleanup Boolean return';if($row.operation -ceq 'WindowViolation'){Assert-Fixture (-not $row.boolean) 'cleanup native monitor has no violation'}}
  elseif($row.operation -cin @('ActiveProcesses','ProcessIds','Pause')){Assert-Fixture ($row.resultKind -ceq 'number' -and (Test-CleanupInteger $row.number) -and $row.number -ge 0 -and $null -eq $row.boolean) 'cleanup numeric return'}
  else{Assert-Fixture ($row.operation -cin @('CloseDesktop','FinalizeFullObserver') -and $row.resultKind -ceq 'void' -and $null -eq $row.boolean -and $null -eq $row.number) 'cleanup exact successful void operation'}
  Assert-Fixture ($row.jobAcquired -eq $Trace.jobAcquired -and $row.desktopAcquired -eq $Trace.desktopAcquired -and $row.jobCloseErrorAfter -eq 0 -and $row.desktopCloseErrorAfter -eq 0) 'cleanup same acquired references and zero close errors'
  foreach($name in @('jobRetainedBefore','jobRetainedAfter','desktopRetainedBefore','desktopRetainedAfter')){Assert-Fixture (-not $row.$name) ('cleanup no retained reference '+$name)}
  $final=$row.operation -ceq 'FinalizeFullObserver';$close=$row.operation -ceq 'CloseDesktop'
  Assert-Fixture ($row.jobBefore -eq $Trace.jobAcquired -and -not $row.jobClosedBefore -and -not $row.jobCloseAttemptedBefore -and $row.jobAfter -eq $(if($final){0}else{$Trace.jobAcquired}) -and $row.jobClosedAfter -eq $final -and $row.jobCloseAttemptedAfter -eq $final) 'cleanup Job stays owned until finalizer'
  Assert-Fixture ($row.desktopBefore -eq $(if($final){0}else{$Trace.desktopAcquired}) -and $row.desktopAfter -eq $(if($final -or $close){0}else{$Trace.desktopAcquired}) -and $row.desktopClosedBefore -eq $final -and $row.desktopCloseAttemptedBefore -eq $final -and $row.desktopClosedAfter -eq ($final -or $close) -and $row.desktopCloseAttemptedAfter -eq ($final -or $close)) 'cleanup desktop stays owned through monitor and closes once'
 }
 function Get-CleanupCall([int]$Index,[string]$Operation,[int]$Iteration,[string]$Phase,[int]$Parent=0){Assert-Fixture ($Index -ge 0 -and $Index -lt $rows.Count) 'cleanup expected call missing';$r=$rows[$Index];Assert-Fixture ($r.operation -ceq $Operation -and $r.iteration -eq $Iteration -and $r.phase -ceq $Phase -and $r.parentOrdinal -eq $Parent) ('cleanup exact call order '+$Operation);return $r}
 $position=0;$iteration=0;$exited=$false
 while($true){
  $iteration++;$direct=Get-CleanupCall $position 'DirectExited' $iteration 'drain';$active=Get-CleanupCall ($position+1) 'ActiveProcesses' $iteration 'drain';$window=Get-CleanupCall ($position+2) 'WindowViolation' $iteration 'drain';$ids=Get-CleanupCall ($position+3) 'ProcessIds' $iteration 'drain' $window.ordinal
  Assert-Fixture (-not $exited -or $direct.boolean) 'cleanup process cannot return to live after exit';$exited=$direct.boolean;$position+=4
  if($direct.boolean -and $active.number -eq 0){Assert-Fixture ($ids.number -eq 0) 'cleanup terminal Job is also empty at monitor';break}
  $pause=Get-CleanupCall $position 'Pause' $iteration 'drain';Assert-Fixture ($pause.number -eq 10) 'cleanup original Pause10';$position++
 }
 $streams=Get-CleanupCall $position 'FinishStreams' $iteration 'drain';Assert-Fixture $streams.boolean 'cleanup streams completed'
 $null=Get-CleanupCall ($position+1) 'CloseDesktop' $iteration 'drain'
 $null=Get-CleanupCall ($position+2) 'FinalizeFullObserver' $iteration 'finalize'
 Assert-Fixture ($position+3 -eq $rows.Count) 'cleanup no extra calls after final release'
 $monitor=$Outer.FullDesktopMonitorEvidence;Assert-FixtureMonitorEvidence $monitor $RunId
 foreach($name in @('normalCount','emptyCount','failedCount','boundedStoredObservations')){Assert-Fixture (Test-CleanupInteger $monitor.$name) ('cleanup monitor count '+$name)}
 Assert-Fixture ($monitor.emptyCount -ge $iteration) 'cleanup original monitor recorded every drain iteration'
 foreach($sample in @($monitor.first,$monitor.last)){
  Assert-Fixture ((Test-CleanupInteger $sample.handle) -and $sample.handle -eq $Trace.desktopAcquired -and $sample.expectedName -ceq $Trace.desktopName) 'cleanup raw monitor same accepted desktop'
  foreach($v in @($sample.foregroundOwned,$sample.violation,$sample.enumeration.returned,$sample.enumeration.visible)){Assert-Fixture ($v -is [bool] -and -not $v) 'cleanup raw monitor false Booleans'}
  foreach($v in @($sample.list.guardsIntact,$sample.list.tailIntact)){Assert-Fixture ($v -is [bool] -and $v) 'cleanup raw monitor true Booleans'}
  foreach($identity in @($sample.identityBefore,$sample.identityAfter)){Assert-Fixture ($identity.inherited -is [bool] -and -not $identity.inherited) 'cleanup monitor identity noninheritance typed'}
 }
 Assert-Fixture (($monitor.outerDrain|ConvertTo-Json -Depth 20 -Compress) -ceq ($Trace|ConvertTo-Json -Depth 20 -Compress)) 'cleanup exact trace attached to same outer result'
}
function Assert-FixtureObserverMonitor($Monitor,[string]$RunId,[long]$Handle){
 Assert-FixtureMonitorEvidence $Monitor $RunId
 foreach($sample in @($Monitor.first,$Monitor.last)){
  Assert-Fixture ($sample.handle -eq $Handle) 'observer monitor must use exact duplicated handle'
  foreach($identity in @($sample.identityBefore,$sample.identityAfter)){Assert-Fixture ($identity.grantedAccess -eq 0x20001) 'observer monitor grants exactly readobjects plus readcontrol'}
 }
}
function Assert-FixtureObservation($Observer,$Outer,$Entry){
 $id=$Entry.runId
 Assert-Fixture ($Observer.RunId -ceq $id -and $Observer.Verified -eq $true -and $Observer.ObservedDescendantAfterBootstrapExit -eq $true -and $Observer.NoVisibleOwnedWindow -eq $true -and $Observer.BootstrapPid -eq $Outer.Pid -and $Observer.ChildPid -eq $Entry.pid -and [string]::IsNullOrEmpty($Observer.Error)) 'actual correlated descendant interval observed'
 $permission=$Observer.DesktopPermission;$identity=$permission.identity
 Assert-Fixture ($permission.requestedAccess -eq 0x20001 -and $permission.inherit -eq $false -and $permission.options -eq 0 -and $permission.duplicateSucceeded -eq $true -and $permission.duplicateError -eq 0 -and $permission.returnedHandle -gt 0 -and $permission.sourceHandle -gt 0) 'minimal desktop duplicate request and actual success required'
 Assert-Fixture ($identity.handle -eq $permission.returnedHandle -and $identity.name -ceq ('AzuriteFullCli_'+$id) -and $identity.type -ceq 'Desktop' -and $identity.owner -ceq $identity.currentOwner -and $identity.owner -match '^S-1-5-21-' -and $identity.rightsQueryStatus -eq 0 -and $identity.grantedAccess -eq 0x20001 -and $identity.inherited -eq $false) 'actual duplicate identity owner rights and noninheritance required'
 Assert-FixtureObserverMonitor $Observer.FullDesktopMonitorEvidence $id $identity.handle
 Assert-FixtureObserverMonitor $Observer.QualifyingMonitorEvidence $id $identity.handle
 $sample=$Observer.QualifyingSample
 Assert-Fixture ($null -ne $sample -and $sample.runId -ceq $id -and $sample.bootstrapPid -eq $Outer.Pid -and $sample.childPid -eq $Entry.pid -and $sample.desktopHandle -eq $identity.handle -and $sample.observerDesktopHeld -eq $true -and $sample.monitorCompleted -eq $true -and $sample.visibleOwnedWindow -eq $false) 'qualifying sample must contain actual completed monitor on correlated reference'
 Assert-Fixture ($sample.bootstrapWaitBefore -eq 0 -and $sample.bootstrapWaitAfter -eq 0 -and $sample.childWaitBefore -eq 258 -and $sample.childWaitAfter -eq 258 -and $sample.activeBefore -gt 0 -and $sample.activeAfter -gt 0) 'bootstrap exited child alive and Job active both before and after monitor'
 Assert-Fixture ($sample.qpcFrequency -gt 0 -and $sample.sampleBeforeQpc -le $sample.monitorBeforeQpc -and $sample.monitorBeforeQpc -le $sample.monitorAfterQpc -and $sample.monitorAfterQpc -le $sample.sampleAfterQpc) 'monotonic monitor-bracket sample timing'
 Assert-Fixture ($Observer.Samples.Count -le 1024) 'observer sample history bounded'
 $roles=@('private-desktop-query','child-query','job-query','bootstrap-query')
 Assert-Fixture ($Observer.Closes.Count -eq 4) 'exactly four checked observer closes'
 foreach($role in $roles){$closed=@($Observer.Closes|Where-Object {$_.role -ceq $role});Assert-Fixture ($closed.Count -eq 1 -and $closed[0].closed -eq $true -and $closed[0].error -eq 0 -and $closed[0].value -gt 0 -and $closed[0].qpc -ge $sample.sampleAfterQpc) 'checked close after qualifying sample';if($role -ceq 'private-desktop-query'){Assert-Fixture ($closed[0].value -eq $identity.handle) 'actual observed desktop closed after snapshot'}}
}
function Assert-FixtureNormalReceipt($Receipt,[string]$PackageSha256,$ProductionSources){
 Assert-Fixture ($Receipt.schema -eq 1 -and $Receipt.fixtureOnly -eq $true -and $Receipt.productionTargetExecuted -eq $false -and $Receipt.scenario -ceq 'normal' -and $Receipt.passed -eq $true -and $Receipt.cleanupVerified -eq $true -and [string]::IsNullOrEmpty($Receipt.error) -and $Receipt.packageSha256 -ceq $PackageSha256 -and $Receipt.runId -cmatch '^[a-f0-9]{32}$') 'actual normal successful same-package final receipt required'
 foreach($name in @('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs')){Assert-Fixture ($Receipt.nativeSourceLineage.$name -ceq $ProductionSources.$name) 'normal receipt production lineage differs'}
 Assert-FixtureOuter $Receipt.outer normal
 Assert-Fixture ($Receipt.child.runId -ceq $Receipt.runId -and $Receipt.child.scenario -ceq 'normal' -and $Receipt.child.pid -eq $Receipt.native.Process.Pid -and $Receipt.native.Process.CleanupVerified -eq $true -and $Receipt.native.Process.ExitCode -eq 0 -and $Receipt.native.StreamsComplete -eq $true -and $Receipt.native.NativeHandlesClosed -eq $true -and $Receipt.native.Evidence.resumeCalls -eq 1 -and $Receipt.native.Evidence.resumeVerified -eq $true) 'actual normal child and native completion evidence required'
 Assert-FixtureNativeEvidence $Receipt.native.Evidence $Receipt.child
 Assert-FixtureCaptured $Receipt.native.Process.Stdout $Receipt.native.Process.Stderr $Receipt.runId
 Assert-FixtureMonitorEvidence $Receipt.outer.FullDesktopMonitorEvidence $Receipt.runId
 Assert-FixtureMonitorEvidence $Receipt.native.Process.FullDesktopMonitorEvidence $Receipt.runId
 Assert-FixtureMonitorEvidence $Receipt.native.Evidence.fullDesktopMonitor $Receipt.runId
 Assert-Fixture (($Receipt.native.Process.FullDesktopMonitorEvidence|ConvertTo-Json -Depth 30 -Compress) -ceq ($Receipt.native.Evidence.fullDesktopMonitor|ConvertTo-Json -Depth 30 -Compress)) 'normal receipt inner monitor evidence must agree'
}
function ConvertFrom-FixtureNormalReceiptBytes([byte[]]$Bytes,[string]$ExpectedSha256,[string]$PackageSha256,$ProductionSources){
 Assert-Fixture ($null -ne $Bytes -and $Bytes.Length -gt 1 -and $Bytes.Length -le 1048576 -and $ExpectedSha256 -cmatch '^[a-f0-9]{64}$') 'normal receipt byte and digest bounds'
 $sha=[Security.Cryptography.SHA256]::Create();try{$actual=([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
 Assert-Fixture ($actual -ceq $ExpectedSha256) 'same parsed normal receipt bytes must match explicit digest'
 $params=@{InputObject=([Text.UTF8Encoding]::new($false,$true).GetString($Bytes));ErrorAction='Stop'};if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')){$params.DateKind='String'}
 $receipt=ConvertFrom-Json @params
 Assert-FixtureNormalReceipt $receipt $PackageSha256 $ProductionSources
 return $receipt
}
function Read-FixtureNormalReceipt([string]$Path,[string]$ExpectedSha256,[string]$PackageSha256,$ProductionSources,[string]$EvidenceRoot){
 $full=[IO.Path]::GetFullPath($Path);$prefix=$EvidenceRoot.TrimEnd('\')+'\'
 Assert-Fixture ($full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -and $full.Substring($prefix.Length) -cmatch '^[a-f0-9]{32}\\result\.json$') 'normal receipt exact evidence run/result.json path required'
 $cursor=$full;while($cursor){$item=Get-Item -LiteralPath $cursor -Force;Assert-Fixture (-not($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) 'normal receipt reparse ancestry refused';$cursor=Split-Path -Parent $cursor}
 $stream=[IO.FileStream]::new($full,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
 try{Assert-Fixture ($stream.Length -gt 1 -and $stream.Length -le 1048576) 'normal receipt finite bytes';$reader=[IO.BinaryReader]::new($stream);$bytes=$reader.ReadBytes([int]$stream.Length);Assert-Fixture ($bytes.Length -eq $stream.Length) 'normal receipt complete same-stream read';$receipt=ConvertFrom-FixtureNormalReceiptBytes $bytes $ExpectedSha256 $PackageSha256 $ProductionSources}finally{$stream.Dispose()}
 Assert-Fixture ((Split-Path -Leaf (Split-Path -Parent $full)) -ceq $receipt.runId) 'normal receipt path/run correlation'
 return [pscustomobject]@{receipt=$receipt;bytesBase64=[Convert]::ToBase64String($bytes);path=$full;sha256=$ExpectedSha256}
}
function Assert-FixtureWaitRuntimePins($Pins){
 $paths=@('C:\Program Files\dotnet\host\fxr\6.0.36\hostfxr.dll','C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\hostpolicy.dll','C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\coreclr.dll','C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\System.Private.CoreLib.dll')
 Assert-Fixture (@($Pins).Count -eq 4) 'exact four wait runtime identity pins required'
 $seen=@{};foreach($pin in $Pins){Assert-Fixture ($pin.path -cin $paths -and -not $seen.ContainsKey($pin.path) -and $pin.sha256 -cmatch '^[a-f0-9]{64}$') 'fixed runtime source path/digest';$seen[$pin.path]=$true;$item=Get-Item -LiteralPath $pin.path -Force;Assert-Fixture (-not $item.PSIsContainer -and -not($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -and $item.Length -eq $pin.bytes -and (Get-FixtureHash $pin.path) -ceq $pin.sha256) 'fixed runtime identity bytes differ'}
}
function Assert-FixtureWaitProbe($HostEntry,$HostResult,$Probe,[string]$RunId,[int]$ProcessId,[long]$NativeThreadId,[long]$ProbeBytes){
 Assert-Fixture ($RunId -cmatch '^[a-f0-9]{32}$' -and $ProcessId -gt 0 -and $NativeThreadId -gt 0 -and $ProbeBytes -gt 1 -and $ProbeBytes -lt 32768) 'bounded actual wait probe correlation required'
 foreach($record in @($HostEntry,$HostResult)){Assert-Fixture ($record.schema -eq 1 -and $record.runId -ceq $RunId -and $record.pid -eq $ProcessId -and $record.nativeThreadId -eq $NativeThreadId) 'native wait hook run/process/initial-thread mismatch'}
 Assert-Fixture ($HostEntry.beforeManagedRuntime -is [bool] -and $HostEntry.beforeManagedRuntime) 'native apartment must precede CLR entry'
 Assert-Fixture ($HostResult.initializeHr -ge 0 -and $HostResult.delegateHr -ge 0 -and $HostResult.loadHr -ge 0 -and $HostResult.closeHr -ge 0 -and $HostResult.nativeError -eq 0 -and $HostResult.managedBytes -eq $ProbeBytes -and $HostResult.aaExecuted -is [bool] -and -not $HostResult.aaExecuted) 'fixed managed host did not return complete diagnostic bytes'
 Assert-Fixture (-not $Probe.PSObject.Properties['probeFailed']) 'managed diagnostic itself failed; retain its raw failure'
 Assert-Fixture ($Probe.schema -eq 1 -and $Probe.scope -ceq 'fixed wait diagnostic only, no AA acceptance' -and $Probe.pid -eq $ProcessId -and $Probe.nativeThreadId -eq $NativeThreadId -and $Probe.finalNativeThreadId -eq $NativeThreadId -and $Probe.sameInitialThread -is [bool] -and $Probe.sameInitialThread -and $Probe.before.nativeThreadId -eq $NativeThreadId) 'managed probe left the correlated startup thread'
 Assert-Fixture ($Probe.runtime -ceq '.NET 6.0.36' -and $Probe.corelib -ceq 'C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\System.Private.CoreLib.dll' -and $Probe.waitTimeoutMs -eq 100 -and $Probe.aaExecuted -is [bool] -and -not $Probe.aaExecuted) 'fixed runtime/finite wait scope differs'
 $phases=@('natural-host-thread');if($Probe.initializeStaHr -ge 0){$phases+='explicit-sta-probe'}
 Assert-Fixture (@($Probe.records).Count -eq ($phases.Count*6)) 'complete one-shot wait matrix required'
 $seen=@{};$mutexes=@{};$successes=0
 foreach($row in $Probe.records){
  Assert-Fixture ($row.phase -cin $phases -and $row.seed -in @(0,1008) -and $row.path -cin @('raw','com','managed') -and $row.before.nativeThreadId -eq $NativeThreadId -and $row.created -is [bool] -and $row.created -and $row.mutexName -cmatch '^Global\\AzuriteWaitFixture_[a-f0-9]{32}$') 'wait case identity or scope differs'
  $key=$row.phase+'|'+$row.seed+'|'+$row.path;Assert-Fixture (-not $seen.ContainsKey($key) -and -not $mutexes.ContainsKey($row.mutexName)) 'wait case or mutex repeated';$seen[$key]=$true;$mutexes[$row.mutexName]=$true
  Assert-Fixture ($row.acquired -is [bool] -and $row.released -is [bool]) 'typed acquisition/release evidence required'
  if($row.acquired -and $row.released -and -not $row.errorType -and -not $row.releaseError){$successes++}
 }
 return [pscustomobject]@{diagnosticOnly=$true;applicationAccepted=$false;correlationVerified=$true;caseCount=@($Probe.records).Count;successfulWaitCount=$successes;allWaitCallsSucceeded=($successes -eq @($Probe.records).Count);hostEntry=$HostEntry;hostResult=$HostResult;probe=$Probe}
}
function Assert-FixtureCanary($Probe,$Before,$After,[string]$RunId,[int]$ProcessId,[long]$NativeThreadId,[int]$RequestedFlags,[string]$OwnerSid,[string]$ExpectedHash,[int]$ExpectedBytes){
 Assert-Fixture ($RequestedFlags -in @(1,9) -and $Probe.protocol -ceq 'owned-canary-open.v1' -and $Probe.runId -ceq $RunId -and $Probe.pid -eq $ProcessId -and $Probe.nativeThreadId -eq $NativeThreadId -and $Probe.leaf -ceq 'read-write-canary.bin') 'canary must bind same diagnostic child and fixed leaf'
 foreach($record in @($Before,$After)){
  Assert-Fixture ($record.attributes -in @(32,128) -and $record.captureHandleRetained -is [bool] -and -not $record.captureHandleRetained -and $record.object.path -ceq ((Get-FixtureLab)+'\install\read-write-canary.bin') -and $record.object.owner -ceq $OwnerSid -and -not $record.object.directory -and -not $record.object.reparse -and $record.object.links -eq 1 -and $record.object.bytes -eq $ExpectedBytes -and $record.object.sha256 -ceq $ExpectedHash) 'canary must have plain non-ReadOnly attributes, unique identity, fixed content and no retained sharing handle'
 }
 foreach($key in @('path','identity','volume','owner','finalPath','directory','reparse','links','bytes','sha256','sddl','rawDescriptor')){Assert-Fixture ($Before.object.$key -ceq $After.object.$key) 'canary identity/content/security changed during probe'}
 Assert-Fixture ($Before.attributes -eq $After.attributes) 'canary attributes changed during probe'
 $sd=[Security.AccessControl.RawSecurityDescriptor]::new([string]$Before.object.sddl)
 Assert-Fixture ($sd.Owner.Value -ceq $OwnerSid -and $null -eq $sd.SystemAcl -and $null -ne $sd.DiscretionaryAcl -and $sd.DiscretionaryAcl.Count -eq 1 -and ([int]$sd.ControlFlags -band 0x1000) -ne 0) 'canary descriptor must be protected current-user only'
 $ace=$sd.DiscretionaryAcl[0];Assert-Fixture ($ace -is [Security.AccessControl.CommonAce] -and $ace.AceQualifier -eq [Security.AccessControl.AceQualifier]::AccessAllowed -and $ace.AceFlags -eq [Security.AccessControl.AceFlags]::None -and $ace.SecurityIdentifier.Value -ceq $OwnerSid -and $ace.AccessMask -eq 2032127) 'canary must contain exactly user FullAccess and no restricting SID grants'
 Assert-Fixture ($Probe.readDesiredAccess -eq 2147483648 -and $Probe.writeDesiredAccess -eq 1073741824 -and $Probe.creationDisposition -eq 3 -and $Probe.writeDataCalled -is [bool] -and -not $Probe.writeDataCalled -and $Probe.truncateCalled -is [bool] -and -not $Probe.truncateCalled) 'canary operations must be exact read/open-write-existing without data mutation'
 foreach($name in @('readOpened','readCallSucceeded','contentMatches','infoSucceeded','writeAttempted','writeOpened','readClosedBeforeWriteOpen')){Assert-Fixture ($Probe.$name -is [bool]) 'typed canary operation status required'}
 Assert-Fixture ($Probe.readCloseError -eq 0 -and $Probe.writeCloseError -eq 0 -and $Probe.readClosedBeforeWriteOpen -and $Probe.writeAttempted) 'canary handles must close before next access attempt'
 if($Probe.readOpened){Assert-Fixture ($Probe.readOpenError -eq 0 -and $Probe.readCallSucceeded -and $Probe.readError -eq 0 -and $Probe.infoSucceeded -and $Probe.infoError -eq 0 -and $Probe.attributes -in @(32,128) -and $Probe.links -eq 1 -and $Probe.fileSizeHigh -eq 0 -and $Probe.fileSizeLow -eq $ExpectedBytes -and $Probe.readBytes -eq $ExpectedBytes -and $Probe.contentMatches) 'successful canary read must return exact bytes from a plain single-link file'}
 else{Assert-Fixture ($Probe.readOpenError -gt 0 -and -not $Probe.readCallSucceeded -and $Probe.readBytes -eq 0) 'denied canary read must preserve its actual native error'}
 if($Probe.writeOpened){Assert-Fixture ($Probe.writeOpenError -eq 0) 'successful write-handle request must retain zero error'}else{Assert-Fixture ($Probe.writeOpenError -gt 0) 'failed write-handle request must retain actual native error'}
 $writeDenied=(-not $Probe.writeOpened -and $Probe.writeOpenError -eq 5);$readExpected=if($RequestedFlags -eq 1){-not $Probe.readOpened -and $Probe.readOpenError -eq 5}else{$Probe.readOpened -and $Probe.contentMatches}
 return [pscustomobject]@{diagnosticOnly=$true;generatedNativeCreateRestrictedTokenFlags=$RequestedFlags;tokenFlagsIndependentlyQueried=$false;productionFullRestrictionQualificationClaimed=$false;expectedOutcomeObserved=($readExpected -and $writeDenied);contentIdentitySecurityUnchanged=$true;readOpened=$Probe.readOpened;readOpenError=$Probe.readOpenError;writeOpened=$Probe.writeOpened;writeOpenError=$Probe.writeOpenError;native=$Probe;before=$Before;after=$After}
}
function Assert-FixtureProtection($Probe,$Before,$After,$DirectoryBefore,$DirectoryAfter,$AnchorsBefore,$AnchorsAfter,$Positive,[string]$RunId,[int]$ProcessId,[long]$NativeThreadId,[string]$OwnerSid,[string]$LogonSid,[string]$ExpectedHash,[int]$ExpectedBytes){
 $lab=Get-FixtureLab;$file=$lab+'\install\protected\proof.bin';$directory=$lab+'\install\protected'
 Assert-Fixture ($Probe.protocol -ceq 'owned-modification-rights.v1' -and $Probe.runId -ceq $RunId -and $Probe.pid -eq $ProcessId -and $Probe.nativeThreadId -eq $NativeThreadId -and $Probe.fileLeaf -ceq 'proof.bin' -and $Probe.directoryLeaf -ceq 'protected' -and $ExpectedBytes -eq 36) 'fixed protection targets and actual child required'
 foreach($pair in @(@($Before,$After,$file,$false),@($DirectoryBefore,$DirectoryAfter,$directory,$true))){
  $left=$pair[0];$right=$pair[1];$target=$pair[2];$isDirectory=$pair[3]
  foreach($snapshot in @($left,$right)){Assert-Fixture ($snapshot.object.path -ceq $target -and $snapshot.object.owner -ceq $OwnerSid -and $snapshot.object.directory -eq $isDirectory -and -not $snapshot.object.reparse -and $snapshot.captureHandleRetained -is [bool] -and -not $snapshot.captureHandleRetained) 'owned non-reparse protection object with closed observation handle required';if($isDirectory){Assert-Fixture ($snapshot.attributes -eq 16 -and @($snapshot.children).Count -eq 1 -and $snapshot.children[0] -ceq 'proof.bin') 'protected directory contents or attributes differ'}else{Assert-Fixture ($snapshot.attributes -in @(32,128) -and $snapshot.object.links -eq 1 -and $snapshot.object.sha256 -ceq $ExpectedHash -and $snapshot.object.bytes -eq $ExpectedBytes) 'protected file must be normal/archive, single-link and exact bytes'}}
  foreach($key in @('path','identity','volume','owner','finalPath','directory','reparse','links','bytes','sha256','sddl','rawDescriptor')){Assert-Fixture ($left.object.$key -ceq $right.object.$key) 'protected object identity/content/security changed'};Assert-Fixture ($left.attributes -eq $right.attributes) 'protected object attributes changed'
  $sd=[Security.AccessControl.RawSecurityDescriptor]::new([string]$left.object.sddl);Assert-Fixture ($sd.Owner.Value -ceq $OwnerSid -and $null -eq $sd.SystemAcl -and $null -ne $sd.DiscretionaryAcl -and $sd.DiscretionaryAcl.Count -eq 1 -and ([int]$sd.ControlFlags -band 0x1000) -ne 0) 'protected object must have protected user-only DACL'
  $ace=$sd.DiscretionaryAcl[0];Assert-Fixture ($ace -is [Security.AccessControl.CommonAce] -and $ace.AceQualifier -eq [Security.AccessControl.AceQualifier]::AccessAllowed -and $ace.AceFlags -eq [Security.AccessControl.AceFlags]::None -and $ace.AccessMask -eq 2032127 -and $ace.SecurityIdentifier.Value -ceq $OwnerSid) 'only user FullAccess is allowed on protected canaries'
 }
 Assert-Fixture (@($AnchorsBefore).Count -eq 2 -and @($AnchorsAfter).Count -eq 2) 'exact new-lab parent anchors required'
 for($i=0;$i -lt 2;$i++){$a=$AnchorsBefore[$i];$b=$AnchorsAfter[$i];$expected=if($i -eq 0){$lab}else{$lab+'\install'};Assert-Fixture ($a.path -ceq $expected -and $a.directory -and -not $a.reparse) 'fixed parent anchor differs';foreach($key in @('path','identity','volume','owner','finalPath','directory','reparse','sddl','rawDescriptor')){Assert-Fixture ($a.$key -ceq $b.$key) 'parent anchor identity/security changed'};$sd=[Security.AccessControl.RawSecurityDescriptor]::new([string]$a.sddl);$parentSids=@($OwnerSid,'S-1-5-18','S-1-5-32-544',$LogonSid);Assert-Fixture ($sd.Owner.Value -ceq $OwnerSid -and $sd.DiscretionaryAcl.Count -eq 4 -and ([int]$sd.ControlFlags -band 0x1000) -ne 0) 'exact protected parent ACL required';for($j=0;$j -lt 4;$j++){$ace=$sd.DiscretionaryAcl[$j];$mask=if($j -eq 3){0x1200A9}else{2032127};$flags=if($j -eq 3){0}else{3};Assert-Fixture ($ace -is [Security.AccessControl.CommonAce] -and $ace.AceQualifier -eq [Security.AccessControl.AceQualifier]::AccessAllowed -and $ace.SecurityIdentifier.Value -ceq $parentSids[$j] -and $ace.AccessMask -eq $mask -and [int]$ace.AceFlags -eq $flags) 'parent must not grant World/Users or Logon write/delete-child rights'}}
 Assert-Fixture ($Probe.readDesiredAccess -eq 2147483648 -and $Probe.creationDisposition -eq 3 -and $Probe.shareMode -eq 7 -and $Probe.readCloseError -eq 0) 'rights probe must use OPEN_EXISTING and fully shared, closed handles'
 foreach($name in @('dataWriteCalled','createCalled','deleteCalled','renameCalled','securitySetCalled')){Assert-Fixture ($Probe.$name -is [bool] -and -not $Probe.$name) 'protected target mutation API was called'}
 foreach($name in @('readOpened','readCallSucceeded','contentMatches','infoSucceeded')){Assert-Fixture ($Probe.$name -is [bool]) 'typed read evidence required'}
 $readSucceeded=$Probe.readOpened -and $Probe.readOpenError -eq 0 -and $Probe.readCallSucceeded -and $Probe.readError -eq 0 -and $Probe.readBytes -eq 36 -and $Probe.contentMatches -and $Probe.infoSucceeded -and $Probe.infoError -eq 0 -and $Probe.attributes -in @(32,128) -and $Probe.links -eq 1 -and $Probe.fileSizeHigh -eq 0 -and $Probe.fileSizeLow -eq 36
 $readDenied=-not $Probe.readOpened -and $Probe.readOpenError -eq 5 -and -not $Probe.readCallSucceeded -and $Probe.readError -eq 0 -and $Probe.readBytes -eq 0 -and -not $Probe.contentMatches -and -not $Probe.infoSucceeded -and $Probe.infoError -eq 0 -and $Probe.attributes -eq 0 -and $Probe.links -eq 0 -and $Probe.fileSizeHigh -eq 0 -and $Probe.fileSizeLow -eq 0
 if($Probe.infoSucceeded){$readIdentity=([uint32]$Probe.volumeSerial).ToString('x8')+'00000000'+([uint32]$Probe.fileIndexHigh).ToString('x8')+([uint32]$Probe.fileIndexLow).ToString('x8');Assert-Fixture ($readIdentity -ceq $Before.object.identity) 'native readable canary handle must match controller file identity'}
 $expected=@(@('file-write-data',2,$false),@('file-append-data',4,$false),@('file-delete',65536,$false),@('file-write-dac',262144,$false),@('file-write-owner',524288,$false),@('directory-add-file',2,$true),@('directory-add-subdirectory',4,$true),@('directory-delete-child',64,$true));Assert-Fixture (@($Probe.attempts).Count -eq 8) 'all eight individual rights must be observed';$denied=0
 for($i=0;$i -lt 8;$i++){$a=$Probe.attempts[$i];$e=$expected[$i];Assert-Fixture ($a.name -ceq $e[0] -and $a.desiredAccess -eq $e[1] -and $a.openFlags -eq $(if($e[2]){0x02200000}else{0x00200080}) -and $a.directory -is [bool] -and $a.directory -eq $e[2] -and $a.attempted -is [bool] -and $a.attempted -and $a.opened -is [bool] -and $a.closeError -eq 0) 'exact individual rights/open/close evidence required';if($a.opened){Assert-Fixture ($a.openError -eq 0) 'successful open must preserve grant before other checks'}else{Assert-Fixture ($a.openError -gt 0) 'failed open must preserve the native error';if($a.openError -eq 5){$denied++}}}
 $positivePath=$lab+'\runs\restricted-'+$RunId+'\request\protection-result.json';Assert-Fixture ($Positive.object.path -ceq $positivePath -and -not $Positive.object.directory -and -not $Positive.object.reparse -and $Positive.object.links -eq 1 -and $Positive.object.owner -ceq $OwnerSid -and $Positive.object.bytes -gt 1 -and $Positive.object.bytes -le 32768 -and $Positive.object.sha256 -cmatch '^[a-f0-9]{64}$' -and $Positive.absentBeforeLaunch -is [bool] -and $Positive.absentBeforeLaunch -and $Positive.controllerCreatedResult -is [bool] -and -not $Positive.controllerCreatedResult -and $Positive.captureHandleRetained -is [bool] -and -not $Positive.captureHandleRetained) 'fresh child-written private output is the positive create/write control'
 $positiveBytes=[Convert]::FromBase64String($Positive.object.content);$sha=[Security.Cryptography.SHA256]::Create();try{$positiveHash=([BitConverter]::ToString($sha.ComputeHash($positiveBytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()};Assert-Fixture ($positiveBytes.Length -eq $Positive.object.bytes -and $positiveHash -ceq $Positive.object.sha256) 'positive control exact captured bytes/hash differ';$capturedProbe=[Text.UTF8Encoding]::new($false,$true).GetString($positiveBytes)|ConvertFrom-Json;Assert-Fixture (($capturedProbe|ConvertTo-Json -Depth 30 -Compress) -ceq ($Probe|ConvertTo-Json -Depth 30 -Compress)) 'positive control bytes must be the actual parsed child result'
 return [pscustomobject]@{scope='eight single modification-right requests on fixed owned canaries';diagnosticOnly=$true;applicationAccepted=$false;productionFullRestrictionQualificationClaimed=$false;generatedNativeCreateRestrictedTokenFlags=1;readSucceeded=$readSucceeded;readDenied=$readDenied;deniedAccessCount=$denied;specifiedRightsDenied=(($readSucceeded -or $readDenied) -and $denied -eq 8);protectedObjectsUnchanged=$true;privateOutputCreateWriteProved=$true;universalWriteIsolationClaimed=$false;registryCovered=$false;native=$Probe;positiveOutput=$Positive;fileBefore=$Before;fileAfter=$After;directoryBefore=$DirectoryBefore;directoryAfter=$DirectoryAfter;anchorsBefore=$AnchorsBefore;anchorsAfter=$AnchorsAfter}
}
function Assert-FixtureHkcr($Before,$After,[string]$Mode,[string]$RunId,[int]$ProcessId,[int]$NativeThreadId){
 Assert-Fixture ($Mode -cin @('control','map')) 'fixed HKCR mode required'
 $paths=@('Software\Classes','Interface','Interface\{00000134-0000-0000-C000-000000000046}','Software\Classes\Interface\{00000134-0000-0000-C000-000000000046}')
 foreach($record in @($Before,$After)){
  Assert-Fixture ($record.protocol -ceq 'hkcr-machine-classes.v1' -and $record.runId -ceq $RunId -and $record.pid -eq $ProcessId -and $record.nativeThreadId -eq $NativeThreadId -and $record.mode -ceq $Mode -and $record.tokenFlags -eq 1 -and $record.accessMask -eq 0x20119) 'HKCR record must bind fixed mode, Full token, access and child'
  foreach($name in @('apisResolved','overrideAttempted','mappingActive','readyBeforeRuntime','waitAttempted','resetAttempted','targetCloseAttempted','targetRetained','final','processLocalOnly')){Assert-Fixture ($record.$name -is [bool]) 'typed HKCR lifecycle status required'}
  Assert-Fixture $record.processLocalOnly 'HKCR override scope must remain child-local'
  foreach($name in @('probeRegistryValuesRead','probeRegistryValuesWritten','probeRegistrySecurityWritten','probeRegistryKeysCreated','comCacheRollbackClaimed','treeWriteRestrictionClaimed')){Assert-Fixture ($record.$name -is [bool] -and -not $record.$name) 'HKCR probe scope exceeded'}
  Assert-Fixture (@($record.opens).Count -eq 8) 'both phases require four fixed read-open records'
  for($i=0;$i -lt 8;$i++){
   $r=$record.opens[$i];$index=$i%4;$phase=if($i -lt 4){'pre'}else{'post'};$root=if($index -in @(0,3)){'HKLM'}else{'HKCR'}
   Assert-Fixture ($r.index -eq $index -and $r.phase -ceq $phase -and $r.root -ceq $root -and $r.subkey -ceq $paths[$index]) 'fixed nonempty registry path and phase required'
   foreach($name in @('attempted','opened','realHandle','closeAttempted')){Assert-Fixture ($r.$name -is [bool]) 'typed registry open evidence required'}
   Assert-Fixture ($r.attempted -eq $record.apisResolved) 'no omitted or fabricated read open'
   if($r.attempted){Assert-Fixture ($r.status -ge 0 -and $r.opened -eq ($r.status -eq 0)) 'preserve actual RegOpenKeyEx LSTATUS'}else{Assert-Fixture ($r.status -eq -1 -and -not $r.opened) 'not-attempted status required'}
   Assert-Fixture (-not $r.realHandle -or $r.opened) 'real handle must come from successful open'
   $mustClose=$r.realHandle -and $i -ne 0
   Assert-Fixture ($r.closeAttempted -eq $mustClose) 'only real temporary keys close inside read phases'
   if($mustClose){Assert-Fixture ($r.closeStatus -ge 0) 'raw RegCloseKey status required'}else{Assert-Fixture ($r.closeStatus -eq -1) 'unattempted close cannot claim success'}
  }
 }
 Assert-Fixture (-not $Before.final -and $After.final -and -not $Before.waitAttempted -and $Before.waitResult -eq -1 -and -not $Before.resetAttempted -and $Before.resetStatus -eq -1 -and -not $Before.targetCloseAttempted -and $Before.targetCloseStatus -eq -1 -and $Before.afterRuntimeQpc -eq 0 -and $Before.endQpc -eq 0) 'before-runtime record cannot contain future cleanup evidence'
 foreach($key in @('apisResolved','overrideAttempted','overrideStatus','readyBeforeRuntime','qpcFrequency','beginQpc','beforeRuntimeQpc')){Assert-Fixture ($Before.$key -ceq $After.$key) 'frozen HKCR setup record drift'}
 Assert-Fixture (($Before.opens|ConvertTo-Json -Depth 8 -Compress) -ceq ($After.opens|ConvertTo-Json -Depth 8 -Compress)) 'open results must remain unchanged after runtime'
 Assert-Fixture ($Before.qpcFrequency -gt 0 -and $Before.beginQpc -gt 0 -and $Before.beforeRuntimeQpc -ge $Before.beginQpc -and $After.afterRuntimeQpc -ge $Before.beforeRuntimeQpc -and $After.endQpc -ge $After.afterRuntimeQpc) 'ordered native QPC observations required'
 $targetOpened=$Before.opens[0].realHandle
 $preOkay=$Before.apisResolved;$postOkay=$Before.apisResolved
 for($i=0;$i -lt 8;$i++){$r=$Before.opens[$i];if(($r.opened -and -not $r.realHandle) -or ($r.closeAttempted -and $r.closeStatus -ne 0)){if($i -lt 4){$preOkay=$false}else{$postOkay=$false}}}
 $mustOverride=$Mode -ceq 'map' -and $Before.apisResolved -and $preOkay -and $targetOpened
 Assert-Fixture ($Before.overrideAttempted -eq $mustOverride -and $Before.targetRetained -eq $targetOpened) 'override requires child-opened fixed machine Classes target'
 if($mustOverride){Assert-Fixture ($Before.overrideStatus -ge 0) 'raw override status required'}else{Assert-Fixture ($Before.overrideStatus -eq -1) 'unattempted override must not claim success'}
 $mapped=$mustOverride -and $Before.overrideStatus -eq 0
 $ready=$Before.apisResolved -and $preOkay -and $postOkay -and ($Mode -ceq 'control' -or $mapped)
 Assert-Fixture ($Before.mappingActive -eq $mapped -and $Before.readyBeforeRuntime -eq $ready -and $After.waitAttempted -eq $ready) 'runtime must only run in the established diagnostic condition'
 if($After.waitAttempted){Assert-Fixture ($After.waitResult -in @(0,1)) 'preserve actual managed hook return'}else{Assert-Fixture ($After.waitResult -eq -1) 'skipped wait cannot claim result'}
 Assert-Fixture ($After.resetAttempted -eq $mapped) 'exactly the successful map requires one explicit reset'
 if($mapped){Assert-Fixture ($After.resetStatus -ge 0) 'raw reset status required'}else{Assert-Fixture ($After.resetStatus -eq -1) 'no reset is sourced from control or failed map'}
 $stillMapped=$mapped -and $After.resetStatus -ne 0
 Assert-Fixture ($After.mappingActive -eq $stillMapped -and $After.targetCloseAttempted -eq ($targetOpened -and -not $stillMapped)) 'target stays owned until reset succeeds'
 if($After.targetCloseAttempted){Assert-Fixture ($After.targetCloseStatus -ge 0) 'raw target close status required'}else{Assert-Fixture ($After.targetCloseStatus -eq -1) 'unattempted target close cannot claim success'}
 $retained=$targetOpened -and (-not $After.targetCloseAttempted -or $After.targetCloseStatus -ne 0)
 Assert-Fixture ($After.targetRetained -eq $retained) 'target ownership status must preserve close failure'
 $complete=$ready -and $After.waitAttempted -and $After.waitResult -eq 0 -and -not $stillMapped -and -not $retained
 return [pscustomobject]@{scope='fixed child-local HKCR diagnostic only';mode=$Mode;completed=$complete;conditionEstablished=$ready;explicitResetSucceeded=($After.resetAttempted -and $After.resetStatus -eq 0);applicationAccepted=$false;fullTreeWriteProtectionClaimed=$false;COMCacheRollbackClaimed=$false;registryValueReadScope='explicit four-open probe only; CLR and COM may perform their own lookups';beforeRuntime=$Before;afterRuntime=$After}
}

Export-ModuleMember -Function Get-FixtureLab,Assert-Fixture,Get-FixtureHash,Read-FixtureJson,Write-FixtureJson,New-FixtureStart,Assert-FixtureChild,Assert-FixtureNativeEvidence,Assert-FixtureOuter,Assert-FixtureCaptured,Assert-FixtureCleanupOrdering,Assert-FixtureObservation,Assert-FixtureMonitorEvidence,Assert-FixtureImagePins,Assert-FixtureObserverMonitor,Assert-FixtureNormalReceipt,ConvertFrom-FixtureNormalReceiptBytes,Read-FixtureNormalReceipt,Assert-FixtureWaitRuntimePins,Assert-FixtureWaitProbe,Assert-FixtureCanary,Assert-FixtureProtection,Assert-FixtureHkcr
