param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
function Clone($x){$x|ConvertTo-Json -Depth 30|ConvertFrom-Json}
function NewCase([string]$Mode){
 $run='1234567890abcdef1234567890abcdef';$map=$Mode -ceq 'map';$paths=@('Software\Classes','Interface','Interface\{00000134-0000-0000-C000-000000000046}','Software\Classes\Interface\{00000134-0000-0000-C000-000000000046}')
 $opens=@(0..7|ForEach-Object{$index=$_%4;[pscustomobject]@{phase=$(if($_ -lt 4){'pre'}else{'post'});index=$index;root=$(if($index -in @(0,3)){'HKLM'}else{'HKCR'});subkey=$paths[$index];attempted=$true;status=0;opened=$true;realHandle=$true;closeAttempted=($_ -ne 0);closeStatus=$(if($_ -ne 0){0}else{-1})}})
 $b=[pscustomobject]@{protocol='hkcr-machine-classes.v1';runId=$run;pid=42;nativeThreadId=43;mode=$Mode;tokenFlags=1;accessMask=0x20119;processLocalOnly=$true;probeRegistryValuesRead=$false;probeRegistryValuesWritten=$false;probeRegistrySecurityWritten=$false;probeRegistryKeysCreated=$false;comCacheRollbackClaimed=$false;treeWriteRestrictionClaimed=$false;apisResolved=$true;overrideAttempted=$map;overrideStatus=$(if($map){0}else{-1});mappingActive=$map;readyBeforeRuntime=$true;waitAttempted=$false;waitResult=-1;resetAttempted=$false;resetStatus=-1;targetCloseAttempted=$false;targetCloseStatus=-1;targetRetained=$true;final=$false;qpcFrequency=10000000;beginQpc=100;beforeRuntimeQpc=200;afterRuntimeQpc=0;endQpc=0;opens=$opens}
 $f=[pscustomobject]@{mode=$Mode;run=$run;before=$b;after=$null};MakeAfter $f;return $f
}
function MakeAfter($f){$b=$f.before;$a=Clone $b;$a.final=$true;$a.waitAttempted=$b.readyBeforeRuntime;$a.waitResult=if($a.waitAttempted){0}else{-1};$a.resetAttempted=$b.mappingActive;$a.resetStatus=if($a.resetAttempted){0}else{-1};$a.mappingActive=$false;$a.targetCloseAttempted=$b.targetRetained;$a.targetCloseStatus=if($a.targetCloseAttempted){0}else{-1};$a.targetRetained=$false;$a.afterRuntimeQpc=300;$a.endQpc=400;$f.after=$a}
function Deny($row,[int]$Status){$row.status=$Status;$row.opened=$false;$row.realHandle=$false;$row.closeAttempted=$false;$row.closeStatus=-1}
function SkipWait($b){$b.readyBeforeRuntime=$false}
$names=@('control-valid','map-valid','control-root-denied','control-interface-missing','map-root-denied','map-override-denied','map-reset-denied','map-target-close-failed','map-pre-close-failed','map-post-close-failed','control-apis-missing','map-apis-missing','wrong-mode','wrong-run','wrong-thread','wrong-access','wrong-token','empty-subkey','missing-open','wrong-order','fake-control-reset','fake-control-override','fake-map-reset','before-future-result','changed-open-status','fake-open-zero','pseudo-handle-close','wrong-raw-close','failed-map-runs-wait','reset-failure-closes-target','fake-close-success','out-of-order-qpc','registry-write-claim','tree-boundary-claim','cache-rollback-claim','map-runtime-return-failed')
$results=@();foreach($name in $names){
 $mode=if($name.StartsWith('map-') -or $name -in @('fake-map-reset','failed-map-runs-wait','reset-failure-closes-target')){'map'}else{'control'};$f=NewCase $mode;$b=$f.before
 $expectedAccepted=$name -in @('control-valid','map-valid','control-root-denied','control-interface-missing','map-root-denied','map-override-denied','map-reset-denied','map-target-close-failed','map-pre-close-failed','map-post-close-failed','control-apis-missing','map-apis-missing','map-runtime-return-failed')
 $expectedCompleted=$name -in @('control-valid','map-valid','control-root-denied','control-interface-missing')
 switch($name){
  control-root-denied {Deny $b.opens[0] 5;$b.targetRetained=$false}
  control-interface-missing {Deny $b.opens[1] 2;Deny $b.opens[5] 2}
  map-root-denied {Deny $b.opens[0] 5;$b.targetRetained=$false;$b.overrideAttempted=$false;$b.overrideStatus=-1;$b.mappingActive=$false;SkipWait $b}
  map-override-denied {$b.overrideStatus=5;$b.mappingActive=$false;SkipWait $b}
  map-pre-close-failed {$b.opens[1].closeStatus=6;$b.overrideAttempted=$false;$b.overrideStatus=-1;$b.mappingActive=$false;SkipWait $b}
  map-post-close-failed {$b.opens[5].closeStatus=6;SkipWait $b}
  wrong-mode {$b.mode='map'}
  wrong-run {$b.runId='bad'}
  wrong-thread {$b.nativeThreadId=44}
  wrong-access {$b.accessMask=0x20019}
  wrong-token {$b.tokenFlags=9}
  empty-subkey {$b.opens[1].subkey=''}
  missing-open {$b.opens=$b.opens[0..6]}
  wrong-order {$b.opens[1].index=3}
  fake-control-override {$b.overrideAttempted=$true;$b.overrideStatus=0;$b.mappingActive=$true}
  before-future-result {$b.waitAttempted=$true;$b.waitResult=0}
  fake-open-zero {$b.opens[1].opened=$false;$b.opens[1].realHandle=$false;$b.opens[1].closeAttempted=$false;$b.opens[1].closeStatus=-1}
  pseudo-handle-close {$b.opens[1].realHandle=$false}
  wrong-raw-close {$b.opens[1].closeStatus=-1}
  failed-map-runs-wait {$b.overrideStatus=5;$b.mappingActive=$false;SkipWait $b}
  registry-write-claim {$b.probeRegistryValuesWritten=$true}
  tree-boundary-claim {$b.treeWriteRestrictionClaimed=$true}
  cache-rollback-claim {$b.comCacheRollbackClaimed=$true}
 }
 if($name -like '*apis-missing'){$b.apisResolved=$false;$b.overrideAttempted=$false;$b.overrideStatus=-1;$b.mappingActive=$false;$b.targetRetained=$false;SkipWait $b;foreach($r in $b.opens){Deny $r -1;$r.attempted=$false}}
 MakeAfter $f;$a=$f.after
 switch($name){
  map-reset-denied {$a.resetStatus=5;$a.mappingActive=$true;$a.targetCloseAttempted=$false;$a.targetCloseStatus=-1;$a.targetRetained=$true}
  map-target-close-failed {$a.targetCloseStatus=6;$a.targetRetained=$true}
  fake-control-reset {$a.resetAttempted=$true;$a.resetStatus=0}
  fake-map-reset {$a.resetAttempted=$false;$a.resetStatus=-1}
  changed-open-status {$a.opens[1].status=2}
  failed-map-runs-wait {$a.waitAttempted=$true;$a.waitResult=0}
  reset-failure-closes-target {$a.resetStatus=5;$a.mappingActive=$true}
  fake-close-success {$a.targetCloseAttempted=$false;$a.targetCloseStatus=0}
  out-of-order-qpc {$a.endQpc=1}
  map-runtime-return-failed {$a.waitResult=1}
 }
 $passed=$false;$errorText=$null;try{$r=Assert-FixtureHkcr $b $a $mode $f.run 42 43;$passed=$expectedAccepted -and $r.completed -eq $expectedCompleted -and -not $r.applicationAccepted -and -not $r.fullTreeWriteProtectionClaimed -and -not $r.COMCacheRollbackClaimed}catch{$errorText=$_.Exception.Message;$passed=-not $expectedAccepted}
 $results+=,[pscustomobject]@{name=$name;passed=$passed;expectedAccepted=$expectedAccepted;expectedCompleted=$expectedCompleted;error=$errorText}
}
$result=[pscustomobject]@{scope='HKCR result consumer on synthetic records only';passed=(@($results|Where-Object{-not $_.passed}).Count -eq 0);checks=$results.Count;results=$results;nativeExecuted=$false;registryAccessed=$false;AAExecuted=$false;host=$PSVersionTable.PSVersion.ToString()};if(Test-Path -LiteralPath $OutputPath){throw 'Preserve prior evidence'};[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$result|Select-Object passed,checks,host|ConvertTo-Json;if(-not $result.passed){exit 1}
