$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
function Assert-Preservation($v,[string]$m){if(-not $v){throw $m}}
$t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $repo 'tools\headless\Preserve-AzuriteFailedCapabilitiesRun9c.ps1'),[ref]$t,[ref]$e)
foreach($f in $ast.EndBlock.Statements){if($f -is [Management.Automation.Language.FunctionDefinitionAst] -and $f.Name -cin @('New-Preservation9cBackend','Assert-Preservation9cPending')){. ([scriptblock]::Create($f.Extent.Text))}}
. (Join-Path $PSScriptRoot 'PreBootstrap.Policy.ps1')
$run='F:\AzuriteLabs\Editor-20261108-normal\runs\restricted-72f854a6f85149f58d20f286283d932b'
$spec=[pscustomobject]@{RunRoot=$run;AllowedRuntimeExtraNames=@('shared-state\prelaunch-current.json','shared-state\prelaunch-delta.json');OriginalRuntimeCleanupVerified=$false;AaCreationProven=$false;AaCreationExcluded=$true;RuntimeFinalSha256='6163df860e04d4423d672ad7550d457904c0dff5cab070b048299ce6bd9e108d';NoAttemptEvidence=[pscustomobject]@{evidenceClass='source-correlated-no-attempt';nativeCleanupVerified=$false;nativeCountersCaptured=$false}}
$state=@{Spec=$spec;Prepared=@{};Observed=@{};ReviewedWrapper=(New-Preservation9cBackend);Inner={param($action,$a,$state)if($action -eq 'Persist'){$state.Last=$a.value};return};Last=$null}
$backend=New-PreBootstrapPreservationBackend;$passed=0;$failed=0
function Check([string]$name,[scriptblock]$body){try{& $body;$script:passed++;Write-Output ('PASS '+$name)}catch{$script:failed++;Write-Output ('FAIL '+$name+': '+$_.Exception.Message)}}
function Refuses([scriptblock]$body){$no=$false;try{& $body}catch{$no=$true};Assert-Preservation $no 'expected refusal'}
Check 'empty actual extra inventory does not invent two files' {& $backend Persist @{name='run-inventory';value=[pscustomobject]@{objects=@()}} $state;Assert-Preservation ($state.Last.objects.Count -eq 0) 'extras invented'}
Check 'one actually observed allowed extra is preserved as one' {& $backend Persist @{name='run-inventory';value=[pscustomobject]@{objects=@([pscustomobject]@{path=$run+'\shared-state\prelaunch-current.json';directory=$false})}} $state;Assert-Preservation ($state.Last.objects.Count -eq 1) 'inventory expanded'}
Check 'both actual allowed extras retain observed objects' {& $backend Persist @{name='run-inventory';value=[pscustomobject]@{objects=@([pscustomobject]@{path=$run+'\shared-state\prelaunch-current.json';directory=$false},[pscustomobject]@{path=$run+'\shared-state\prelaunch-delta.json';directory=$false})}} $state;Assert-Preservation ($state.Last.objects.Count -eq 2) 'actual inventory omitted'}
Check 'unexpected handoff record refuses this no-attempt branch' {Refuses {& $backend Persist @{name='run-inventory';value=[pscustomobject]@{objects=@([pscustomobject]@{path=$run+'\control\lease-offer.json';directory=$false})}} $state}}
Check 'allowed filename cannot be a directory' {Refuses {& $backend Persist @{name='run-inventory';value=[pscustomobject]@{objects=@([pscustomobject]@{path=$run+'\shared-state\prelaunch-current.json';directory=$true})}} $state}}
Check 'result keeps reconstructed no-attempt separate from native telemetry' {$result=[pscustomobject]@{originalRuntimeCleanupVerified=$true;aaCreationProven=$true;aaCreationExcluded=$false};& $backend Persist @{name='preservation-result';value=$result} $state;Assert-Preservation ($state.Last.originalRuntimeCleanupVerified -eq $false -and $state.Last.aaCreationProven -eq $false -and $state.Last.aaCreationExcluded -eq $true -and $state.Last.noAttemptEvidence.nativeCountersCaptured -eq $false -and $state.Last.noAttemptEvidence.nativeCleanupVerified -eq $false) 'native proof invented'}
[pscustomobject]@{scope='SOURCE-only-prebootstrap-preservation-adapter';passed=$passed;failed=$failed;testOnlySimulated=$true;FReadPerformed=$false;FWritePerformed=$false;nativeExecuted=$false}|ConvertTo-Json -Compress
if($failed){exit 1}
