param([Parameter(Mandatory)][string]$PolicyPath,[Parameter(Mandatory)][string]$ResultPath,[switch]$ExpectRejectActual)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh predicate evidence required'}
function Assert-Preservation($v,[string]$m){if(-not $v){throw $m}}
. $PolicyPath
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$run='72f854a6f85149f58d20f286283d932b'
function Read([string]$p){Get-Content -LiteralPath $p -Raw|ConvertFrom-Json -DateKind String}
$final=Read (Join-Path $repo 'artifacts\aa-fr-capabilities-runtime\44d377fba10c45428931dc5de444a80c\controller-final.json');$dir=Join-Path $repo ('artifacts\aa-fr-capabilities-sequence\run-'+$run)
$child=Read (Join-Path $dir 'Runtime-child-result.json');$owners=Read (Join-Path $dir 'Runtime-child-ownership.json');$sequence=Read (Join-Path $dir 'sequence-result.json');$supervisor=Read (Join-Path $repo ('artifacts\aa-actual-handoff-next-20261114\run-'+$run+'\72f8-qualification-supervision\process-state.json'))
function Clone($v){$v|ConvertTo-Json -Depth 50|ConvertFrom-Json -DateKind String}
$rows=[Collections.Generic.List[object]]::new()
function Case([string]$n,[scriptblock]$b){try{& $b;$rows.Add([pscustomobject]@{name=$n;passed=$true;error=$null})}catch{$rows.Add([pscustomobject]@{name=$n;passed=$false;error=$_.Exception.ToString()})}}
function Refuses([scriptblock]$b){$refused=$false;try{& $b|Out-Null}catch{$refused=$true};Assert-Preservation $refused 'Mutation was accepted'}
Case 'exact actual72 refuses legacy authorization or preserves truthful new proof' {
 if($ExpectRejectActual){Refuses {Assert-ExactPreBootstrapRefusal $final $child $owners $sequence $supervisor};return}
 $proof=Assert-ExactPreBootstrapRefusal $final $child $owners $sequence $supervisor
 Assert-Preservation ($proof.evidenceClass -ceq 'source-correlated-no-attempt' -and $proof.actualTargetLeaseClosedFlag -eq $false -and $proof.explicitTargetLeaseClosureProven -eq $false -and $proof.nativeCountersCaptured -eq $false -and $proof.nativeCleanupVerified -eq $false -and $proof.debuggerPreparedFilesStopObserved -eq $true -and $proof.actualRuntimeStageAttemptCount -eq 1 -and $proof.prelaunchComparisonIsPostfailureFreshProof -eq $false) 'Actual snapshot was relabeled closure/target telemetry'
}
if(-not $ExpectRejectActual){
 foreach($name in @('workerCreated','bootstrapStarted','outerPumpReturned','holdHost','leaseClosed','retainedOuter','originalResumeObserved')){Case ('actual false phase/ownership flag mutation: '+$name) {$x=Clone $final;$x.handoffSnapshot.$name=$true;Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}}
 Case 'string false is not an actual boolean' {$x=Clone $final;$x.handoffSnapshot.workerCreated='false';Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}
 Case 'null snapshot plus null Pump is not proof' {$x=Clone $final;$x.handoffSnapshot=$null;Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}
 Case 'arbitrary TypeLoad is not this boundary' {$x=Clone $final;$x.primaryError='System.TypeLoadException elsewhere';Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}
 Case 'later phase is refused' {$x=Clone $final;$x.handoffSnapshot.managedPhase='invoking-outer-bootstrap';Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}
 Case 'stop failure is not closed preparation files' {$x=Clone $final;$x.handoffSnapshot.stopProven=$false;Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}
 Case 'invented Pump is refused' {$x=Clone $final;$x.result=[pscustomobject]@{outer=[pscustomobject]@{NoProcessCreated=$true}};Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}
 Case 'pendingCleared mutation refuses' {$x=Clone $final;$x.pendingCleared=$true;Refuses {Assert-ExactPreBootstrapRefusal $x $child $owners $sequence $supervisor}}
 Case 'unclosed original Runtime child refuses' {$x=Clone $owners;$x.exitConfirmed=$false;Refuses {Assert-ExactPreBootstrapRefusal $final $child $x $sequence $supervisor}}
 Case 'Root supervisor kill refuses' {$x=Clone $supervisor;$x.terminatedBySupervisor=$true;Refuses {Assert-ExactPreBootstrapRefusal $final $child $owners $sequence $x}}
 Case 'another original process lifetime refuses' {$x=Clone $supervisor;$x.creationFileTime++;Refuses {Assert-ExactPreBootstrapRefusal $final $child $owners $sequence $x}}
 Case 'Runtime-stage counter cannot be fabricated as zero' {$x=Clone $sequence;$x.runtimeAttemptCount=0;Refuses {Assert-ExactPreBootstrapRefusal $final $child $owners $x $supervisor}}
}
$r=[ordered]@{scope='C-only exact actual72 pre-bootstrap predicate and in-memory negative controls';passed=(@($rows.ToArray()|Where-Object {-not $_.passed}).Count -eq 0);tests=@($rows.ToArray());legacyPolicyRefusal=[bool]$ExpectRejectActual;actualEvidenceModified=$false;nativeCountersSynthesized=$false;FReadPerformed=$false;FWritePerformed=$false;nativeExecuted=$false}
[IO.File]::WriteAllText($ResultPath,($r|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));[pscustomobject]@{passed=$r.passed;tests=$rows.Count;failures=@($rows.ToArray()|Where-Object {-not $_.passed})}|ConvertTo-Json -Depth 5;if(-not $r.passed){exit 1}
