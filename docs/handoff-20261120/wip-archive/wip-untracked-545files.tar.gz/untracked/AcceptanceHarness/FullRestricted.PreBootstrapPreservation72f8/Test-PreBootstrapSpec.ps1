param([Parameter(Mandatory)][string]$SourceManifestPath,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh spec test evidence required'}
$manifest=Get-Content -Raw -LiteralPath $SourceManifestPath|ConvertFrom-Json -DateKind String
$package=@{}
foreach($pin in $manifest.files){if(-not $pin.path.StartsWith($repo+'\',[StringComparison]::Ordinal)){throw 'C-only source tests'};$bytes=[IO.File]::ReadAllBytes($pin.path);if((Get-FileHash -LiteralPath $pin.path).Hash.ToLowerInvariant() -cne $pin.sha256 -or $bytes.Length -ne $pin.bytes){throw 'Source input drift'};$package[$pin.role]=[pscustomobject]@{pin=$pin;bytes=$bytes}}
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput([Text.Encoding]::UTF8.GetString($package.PreserveBase.bytes),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Base parse failure'}
foreach($definition in $ast.EndBlock.Statements){if($definition -is [Management.Automation.Language.FunctionDefinitionAst] -and $definition.Name -cin @('Assert-Preservation','ConvertFrom-PreservationJson','Get-PreservationHash','New-PreservationMap','Assert-PreservationObject','Assert-PreservationStable')){. ([scriptblock]::Create($definition.Extent.Text))}}
. (Join-Path $PSScriptRoot 'PreBootstrap.Policy.ps1')
$rows=[Collections.Generic.List[object]]::new()
function Case([string]$Name,[scriptblock]$Body){try{& $Body;$rows.Add([pscustomobject]@{name=$Name;passed=$true;error=$null})}catch{$rows.Add([pscustomobject]@{name=$Name;passed=$false;error=$_.Exception.ToString()})}}
function Refuses([scriptblock]$Body,[string]$Expected){$message=$null;try{& $Body|Out-Null}catch{$message=$_.Exception.Message};Assert-Preservation ($message -and $message.Contains($Expected)) ('Expected precise refusal: '+$Expected+'; actual: '+$message)}
function PackageWith([string]$Role,[scriptblock]$Mutation){$p=@{};foreach($key in $package.Keys){$p[$key]=$package[$key]};$v=ConvertFrom-PreservationJson $package[$Role].bytes;& $Mutation $v;$p[$Role]=[pscustomobject]@{pin=$package[$Role].pin;bytes=[Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 90 -Compress))};return ,$p}
$source=[Text.Encoding]::UTF8.GetString($package.FullSource.bytes);$runtime=[Text.Encoding]::UTF8.GetString($package.RuntimeSource.bytes)
Case 'actual28 package produces finite graph and truthful no-target source conclusion' {
 $s=Get-ExactPreBootstrapPreservationSpec $package
 Assert-Preservation ($s.Original.Count -eq 1228 -and $s.Prepared.Count -eq 1260 -and $s.InputBindings.Count -eq 28 -and $s.MutablePayloadPaths.Count -eq 1 -and $s.MutablePayloadPaths[0] -ceq $s.PendingPath -and $s.AaCreationExcluded -eq $true -and $s.AaCreationProven -eq $false -and $s.OriginalRuntimeCleanupVerified -eq $false -and $s.NoAttemptEvidence.actualHandoffSnapshot.leaseClosed -eq $false -and $s.NoAttemptEvidence.actualRuntimeStageAttemptCount -eq 1 -and $s.NoAttemptEvidence.prelaunchComparisonIsPostfailureFreshProof -eq $false) 'Spec relabeled graph/native/fresh-shared evidence'
}
Case 'different independent review pin refuses' {$p=@{};foreach($key in $package.Keys){$p[$key]=$package[$key]};$p.IndependentReview=[pscustomobject]@{pin=[pscustomobject]@{sha256=('0'*64)};bytes=$package.IndependentReview.bytes};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Exact actual/source/review pin differs: IndependentReview'}
Case 'worker scheduling before preparation refuses' {Refuses {Assert-ExactPreBootstrapSourceBoundary ($source.Replace('s.Native.PrepareBeforeTarget();','s.Worker=Task.Factory.StartNew; s.Native.PrepareBeforeTarget();')) $runtime} 'Pinned call order'}
Case 'another Deserialize call boundary refuses' {Refuses {Assert-ExactPreBootstrapSourceBoundary ($source.Replace('var manifest = serializer.Deserialize<Dictionary<string, object>>(json);','var manifest = another.Deserialize<Dictionary<string, object>>(json);')) $runtime} 'Exact actual Deserialize boundary'}
Case 'weakened preparation-only stop guard refuses' {Refuses {Assert-ExactPreBootstrapSourceBoundary ($source.Replace('Require(!createAttempted&&process==null&&job==null&&desktop==null,','Require(true&&process==null&&job==null&&desktop==null,')) $runtime} 'Preparation-only registered-file stop proof differs'}
Case 'null Pump cannot close target lease in source interpretation' {Refuses {Assert-ExactPreBootstrapSourceBoundary ($source.Replace('if(result==null||lease==null||(worker!=null&&!worker.IsCompleted))return false;','if(result==null||lease==null||(worker!=null&&!worker.IsCompleted))return true;')) $runtime} 'Null Pump must not become explicit target lease closure'}
Case 'NoPump guard after output refuses' {$g="if(`$null -eq `$outer){throw ('No actual outer PumpResult available: '+`$handoffError)}";Refuses {Assert-ExactPreBootstrapSourceBoundary $source ($runtime.Replace($g,'')+"`n"+$g)} 'Runtime pending/prelaunch/NoPump guard order differs'}
Case 'Root false lease closure claim remains false' {$p=PackageWith RootFailureReadback {param($v)$v.leaseClosedClaim=$true};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Root actual false flag differs: leaseClosedClaim'}
Case 'Root raw snapshot cannot upgrade leaseClosed' {$p=PackageWith RootFailureReadback {param($v)$v.handoffSnapshot.leaseClosed=$true};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Root snapshot must preserve'}
Case 'Root cannot convert Runtime attempt1 into zero' {$p=PackageWith RootFailureReadback {param($v)$v.runtimeStageAttemptCount=0};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Root terminal readback correlation differs'}
Case 'mixed-run preparation receipt refuses' {$p=PackageWith ReceiptBundle {param($v)$v.Plan.RunId='0e494be63f3248ffb7bd7bbd040987f8'};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Prepared graph mixes runs'}
Case 'different prepared Plan hash refuses' {$p=PackageWith ReceiptBundle {param($v)$v.Plan.PlanSha256=('0'*64)};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Exact prepared plan/qualification differs'}
Case 'missing actual prepared object refuses finite graph' {$p=PackageWith Observations {param($v)$v.objects=@($v.objects|Select-Object -Skip 1)};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Actual run72 finite preparation graph differs'}
Case 'prepared path outside fixed lab refuses' {$p=PackageWith Observations {param($v)$v.objects[0].path='F:\Outside72';$v.objects[0].finalPath='F:\Outside72'};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Prepared object escaped fixed lab'}
Case 'original raw identity mutation refuses' {$p=PackageWith BeforeImages {param($v)$v.objects[0].identity=('0'*32)};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Object changed during preservation (identity)'}
Case 'unrecorded absent path refuses' {$p=PackageWith BeforeImages {param($v)$v.absent[0]='F:\AzuriteLabs\Editor-20261108-normal\runs\restricted-72f854a6f85149f58d20f286283d932b\unrecorded.json'};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Actual created/absent coverage differs'}
Case 'prepared actor bytes must bind frozen actual source' {$p=PackageWith Observations {param($v)$target=@($v.objects|Where-Object {$_.path.EndsWith('\tooling\RestrictedCliNative.dll',[StringComparison]::Ordinal)});Assert-Preservation ($target.Count -eq 1) 'Test target ambiguous';$target[0].sha256=('0'*64)};Refuses {Get-ExactPreBootstrapPreservationSpec $p} 'Actual prepared executable/source differs'}
Case 'public default exits before helper loading or physical backend construction' {
 $e=[Text.Encoding]::UTF8.GetString($package.Entry.bytes);$plan=$e.IndexOf('if(-not $Capture)');$load=$e.IndexOf('[void][Reflection.Assembly]::Load(');$physical=$e.IndexOf('Inner=(New-PreservationPhysicalBackend)')
 Assert-Preservation ($plan -ge 0 -and $load -gt $plan -and $physical -gt $load -and $e.Substring($plan,$load-$plan).Contains('|ConvertTo-Json -Depth 8;return}')) 'Default Plan must return before physical path'
 Assert-Preservation (-not ('Azurite.Stage.FileSecurity' -as [type])) 'Metadata helper unexpectedly loaded in pure source tests'
}
$result=[ordered]@{scope='C-only actual72 package/spec/source-boundary and in-memory negative controls';tests=@($rows.ToArray());passed=(@($rows.ToArray()|Where-Object {-not $_.passed}).Count -eq 0);actualEvidenceModified=$false;metadataHelperLoaded=[bool]('Azurite.Stage.FileSecurity' -as [type]);FReadPerformed=$false;FWritePerformed=$false;nativeExecuted=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{passed=$result.passed;tests=$rows.Count;failures=@($rows.ToArray()|Where-Object {-not $_.passed})}|ConvertTo-Json -Depth 8
if(-not $result.passed){exit 1}
