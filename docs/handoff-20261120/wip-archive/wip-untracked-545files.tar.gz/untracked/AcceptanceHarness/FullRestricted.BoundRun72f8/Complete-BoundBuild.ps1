param()
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$directory=Join-Path $repo 'artifacts\aa-handoff-bound-72f8-20261114\candidate1';$overlay=Join-Path $directory 'overlay'
$compiler='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe';$reference='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll'
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save([string]$p,$value){$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 30));$f=[IO.File]::Open($p,'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}}
if((Hash $compiler) -cne 'eca02e6b15cde93009a59a3d129d5a77fb5008f2e1cf62cf573b6737c747ecc3'){throw 'Compiler differs'}
$errors=@();foreach($file in Get-ChildItem -LiteralPath $overlay -File|Where-Object Extension -In @('.ps1','.psm1')){$t=$null;$e=$null;[void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$t,[ref]$e);$errors+=@($e)};if($errors.Count){throw 'Bound overlay parse failed'}
Import-Module (Join-Path $repo 'AcceptanceHarness\FullRestricted.CdbOwnedWaitFixture\SourceProcess.psm1') -Force
$dll=Join-Path $overlay 'RestrictedCliNative.dll'
$compile=Invoke-FixtureSourceProcess -File $compiler -Arguments @('/nologo','/target:library','/platform:x64','/optimize+','/warnaserror+',('/out:'+$dll),('/r:'+$reference),(Join-Path $overlay 'RestrictedCliNative.cs'),(Join-Path $overlay 'RestrictedCliFullRestricted.cs')) -Record (Join-Path $directory 'native-compile-process.json') -Directory $repo -BoundMs 30000
if($compile.exitCode -ne 0 -or $compile.stderr){throw ('Actual two-input compile failed: '+$compile.stdout+' '+$compile.stderr)}
$sources=@(foreach($name in @('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs')){[pscustomobject]@{name=$name;sha256=(Hash (Join-Path $overlay $name))}})
$canonicalRelative='.superpowers/sdd/azurite-authoring-20261108/actual-no-trace-72f8-candidate1/result.json'
if($canonicalRelative -cnotmatch '^\.superpowers/sdd/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/result\.json$'){throw 'Production assembler canonical path contract differs'}
$resultPath=Join-Path $repo $canonicalRelative
if(Test-Path -LiteralPath (Split-Path -Parent $resultPath)){throw 'Fresh canonical receipt directory required'}
[void][IO.Directory]::CreateDirectory((Split-Path -Parent $resultPath))
$receipt=[ordered]@{scope='SOURCE-only-root-selected-72f8-no-trace-build';runId='72f854a6f85149f58d20f286283d932b';dllSha256=(Hash $dll);sourceArchiveSha256=(Hash (Join-Path $directory 'compiler-inputs.zip'));actualCompilerInputs=$sources;compositionSha256=(Hash (Join-Path $directory 'composition.json'));compilerSha256=(Hash $compiler);referenceSha256=(Hash $reference);actualCompilerProcessPath=(Join-Path $directory 'native-compile-process.json');actualCompilerProcessSha256=(Hash (Join-Path $directory 'native-compile-process.json'));actualCompilerPid=$compile.pid;actualCompilerCreationFileTime=$compile.creationFileTime;exitCode=0;aaExecuted=$false;cdbExecuted=$false;nativeFixtureExecuted=$false;stageWrites=$false;newCompilationPerformed=$true}
Save $resultPath $receipt;Save (Join-Path $directory 'compiler-build.json') $receipt
$runtime=Import-Module (Join-Path $overlay 'FullRestrictedCapabilitiesRuntime.psm1') -Force -PassThru -DisableNameChecking
$names=& $runtime {Get-AzuriteFullToolNames};$files=@(foreach($name in $names){[pscustomobject]@{name=$name;sha256=(Hash (Join-Path $overlay $name))}})
$tooling=[ordered]@{schema=1;scope='full-restricted-precompiled-tooling';files=$files;build=[ordered]@{target='library';platform='x64';exitCode=0;compilerSha256=(Hash $compiler);assemblySha256=(Hash $dll);sources=$sources;references=@([pscustomobject]@{name='System.Web.Extensions.dll';sha256=(Hash $reference)});canonicalBuildResultPath=$canonicalRelative;canonicalBuildResultSha256=(Hash $resultPath);sourceArchiveSha256=(Hash (Join-Path $directory 'compiler-inputs.zip'))}}
$hashes=[ordered]@{};foreach($file in $files){$hashes[$file.name]=$file.sha256};& $runtime {param($m,$h)Assert-AzuriteFullToolManifest $m ([pscustomobject]@{toolHashes=[pscustomobject]$h})} $tooling $hashes
Save (Join-Path $overlay 'tooling-manifest.json') $tooling
$seq=Import-Module (Join-Path $overlay 'AzuriteCapabilitiesSequence.psm1') -Force -PassThru -DisableNameChecking
$fixed=& $seq {Get-SequenceFixedRoles};if($fixed.Count -ne 28){throw 'Original 28-role count differs'}
$rows=@(foreach($role in $fixed.Keys){$p=$fixed[$role];[pscustomobject]@{role=$role;path=$p;bytes=(Get-Item -LiteralPath $p).Length;sha256=(Hash $p)}})
& $seq {param($r)Assert-SequenceSourcePins ([pscustomobject]@{SourceRows=$r})} $rows
Save (Join-Path $directory 'sequence-source-manifest.json') ([ordered]@{schema=1;scope='root-reviewed-fixed-capabilities-sequence-sources';files=$rows})
$helper=Get-Content -LiteralPath (Join-Path $directory 'helper-build\build.json') -Raw|ConvertFrom-Json
if($helper.moduleSha256 -cne (Hash (Join-Path $overlay 'FullRestrictedStageTransition.psm1')) -or $helper.assemblySha256 -cne (Hash (Join-Path $directory 'helper-build\FullRestrictedStageFileSecurity.dll')) -or $helper.sourceSha256 -cne (Hash (Join-Path $directory 'helper-build\FullRestrictedStageFileSecurity.cs'))){throw 'Unchanged stage-helper provenance differs'}
$build=[ordered]@{scope='bound-72f8-source-build';runId='72f854a6f85149f58d20f286283d932b';sourceOnly=$true;compilerNaturalExit=0;compilerInputs=$sources;assemblySha256=(Hash $dll);toolingManifestSha256=(Hash (Join-Path $overlay 'tooling-manifest.json'));sequenceSourceManifestSha256=(Hash (Join-Path $directory 'sequence-source-manifest.json'));sourceRoles=28;helperRecompiled=$false;helperAssemblySha256=$helper.assemblySha256;helperModuleSha256=$helper.moduleSha256;sourceArchiveSha256=(Hash (Join-Path $directory 'compiler-inputs.zip'));originalClocksStopHoldAclUnchanged=$true;baselineCollected=$false;freshCaptureCollected=$false;aaExecuted=$false;cdbExecuted=$false;nativeExecuted=$false;FReadPerformed=$false;FWritePerformed=$false}
Save (Join-Path $directory 'source-build-result.json') $build;$build|ConvertTo-Json -Depth 6
