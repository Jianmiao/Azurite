#requires -Version 7.0
param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ExpectedDeliveryManifestSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$candidate=[IO.Path]::GetFullPath($CandidateDirectory)
if([IO.Path]::GetDirectoryName($candidate) -cne (Join-Path $repo 'artifacts\aa-handoff-bound-72f8-20261114')){throw 'Exact C 72f8 bound candidate required'}
function Assert-QualificationPinnedDelivery([string]$Directory,[string]$ExpectedDigest,[string]$ExecutingDriver) {
 function Digest([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
 function PlainFile([string]$path,[long]$bytes,[string]$hash){
  $full=[IO.Path]::GetFullPath($path)
  if($full -cne $path -or -not $full.StartsWith('C:\',[StringComparison]::Ordinal) -or $hash -cnotmatch '\A[a-f0-9]{64}\z'){throw 'Pinned source must be exact C path and SHA-256'}
  $cursor=$full;while($cursor){$item=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop;if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Pinned source reparse ancestry refused'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
  $item=Get-Item -LiteralPath $full -Force
  if($item.PSIsContainer -or $item.Length -ne $bytes -or (Digest $full) -cne $hash){throw ('Frozen delivery member drift: '+$full)}
 }
 $manifestPath=Join-Path $Directory 'delivery-pinned-manifest.json'
 if($ExpectedDigest -cnotmatch '\A[a-f0-9]{64}\z' -or $ExpectedDigest -ceq ('0'*64) -or (Digest $manifestPath) -cne $ExpectedDigest){throw 'Externally expected pinned delivery digest differs'}
 $manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json -DateKind String
 if($manifest.schema -ne 1 -or $manifest.scope -cne 'fixed-72f8-qualification-pinned-delivery' -or $manifest.runId -cne '72f854a6f85149f58d20f286283d932b'){throw 'Pinned delivery scope/run differs'}
 $basePath=Join-Path $Directory 'delivery-manifest.json'
 if($manifest.baseDelivery.path -cne $basePath){throw 'Base candidate delivery path differs'}
 PlainFile $basePath $manifest.baseDelivery.bytes $manifest.baseDelivery.sha256
 $base=Get-Content -LiteralPath $basePath -Raw|ConvertFrom-Json -DateKind String
 if($base.schema -ne 1 -or $base.scope -cne 'actual-AA-no-trace-qualification-C-source-driver-delivery' -or $base.runId -cne $manifest.runId -or @($base.files).Count -ne 57 -or @($base.references).Count -ne 62){throw 'Frozen base candidate delivery closure differs'}
 $driver=@($manifest.references|Where-Object role -CEQ SourcePlan)
 if($driver.Count -ne 1 -or $driver[0].path -cne $ExecutingDriver){throw 'Executing failure binder is not the reviewed external reference'}
 $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($entry in @($base.files)+@($manifest.files)){
  $path=[IO.Path]::GetFullPath((Join-Path $Directory $entry.path))
  if(-not $path.StartsWith($Directory+'\',[StringComparison]::Ordinal) -or -not $seen.Add($path)){throw 'Pinned member escaped or duplicated its candidate scope'}
  PlainFile $path $entry.bytes $entry.sha256
 }
 foreach($entry in @($base.references)+@($manifest.references)){
  if(-not $seen.Add($entry.path)){throw 'Pinned external reference duplicated'}
  PlainFile $entry.path $entry.bytes $entry.sha256
 }
 return [pscustomobject]@{manifestPath=$manifestPath;manifestSha256=$ExpectedDigest;baseDeliverySha256=$manifest.baseDelivery.sha256;verifiedMemberCount=$seen.Count;verifiedBeforeModuleLoad=$true}
}
$frozenDelivery=Assert-QualificationPinnedDelivery $candidate $ExpectedDeliveryManifestSha256 $PSCommandPath
$planPath=Join-Path $candidate 'source-plan.json';$plan=Get-Content -LiteralPath $planPath -Raw|ConvertFrom-Json -DateKind String
[pscustomobject]@{scope='verified-72f8-source-plan';sourcesVerified=$true;delivery=$frozenDelivery;plan=$plan;liveInputsEvaluated=$false;moduleLoaded=$false;baselineCreated=$false;freshCapturePerformed=$false;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false}|ConvertTo-Json -Depth 20
