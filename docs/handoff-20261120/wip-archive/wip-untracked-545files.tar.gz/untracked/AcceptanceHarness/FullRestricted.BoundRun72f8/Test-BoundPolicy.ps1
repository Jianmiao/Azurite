param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh policy result required'}
. (Join-Path $CandidateDirectory 'overlay\Qualification.Policy.ps1')
$run='72f854a6f85149f58d20f286283d932b';$rows=[Collections.Generic.List[object]]::new()
function Check($v,[string]$m){if(-not $v){throw $m}}
function Case([string]$n,[scriptblock]$b){try{& $b;$rows.Add([pscustomobject]@{name=$n;passed=$true;error=$null})}catch{$rows.Add([pscustomobject]@{name=$n;passed=$false;error=$_.Exception.ToString()})}}
Case 'Root-selected new run binds the actual composed source and unique evidence path' {
 $q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run
 Check ($q.runId -ceq $run -and $q.runtimeTimeoutSeconds -eq 30 -and $q.nativeTimeoutSeconds -eq 10 -and $q.applicationAccepted -eq $false -and $q.nativeQualificationPreviouslyProven -eq $false) 'Run, original budgets or acceptance flags changed'
 Check ($q.nativeSourceSha256 -ceq (Get-FileHash (Join-Path $CandidateDirectory 'overlay\RestrictedCliFullRestricted.cs')).Hash.ToLowerInvariant() -and $q.sharedNativeSourceSha256 -ceq (Get-FileHash (Join-Path $CandidateDirectory 'overlay\RestrictedCliNative.cs')).Hash.ToLowerInvariant() -and $q.compositionSha256 -ceq (Get-FileHash (Join-Path $CandidateDirectory 'composition.json')).Hash.ToLowerInvariant()) 'Actual source/composition binding differs'
 Check ($q.debuggerEvidenceDirectory -ceq (Join-Path $CandidateDirectory ('native-evidence\runs\'+$run)) -and $q.controlDirectory -ceq ('F:\AzuriteLabs\Editor-20261108-normal\runs\restricted-'+$run+'\control')) 'Unique new run directories differ'
}
foreach($bad in @('0e494be63f3248ffb7bd7bbd040987f8','00000000000000000000000000000000','bfdd50364b9049c4a58e36be683d76c9')){Case ('Wrong run is refused: '+$bad) {$refused=$false;try{$null=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $bad}catch{$refused=$true};Check $refused 'Wrong run admitted'}}
Case 'different qualification selection is refused' {$refused=$false;try{$null=Get-AzuriteNoTraceQualification 'startup-exceptions.v1' $run}catch{$refused=$true};Check $refused 'Different qualification admitted'}
$r=[ordered]@{scope='pure actual qualification policy and source binding';passed=(@($rows.ToArray()|Where-Object {-not $_.passed}).Count -eq 0);tests=@($rows.ToArray());powerShell=$PSVersionTable.PSVersion.ToString();baselineCreated=$false;freshCapturePerformed=$false;nativeExecuted=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($r|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));$r|ConvertTo-Json -Depth 8;if(-not $r.passed){exit 1}
