# Root-owned 72f8 qualification: source plan, one attempt, preservation and recovery

Fixed RunId: `@RUN@`. Bound package: `@CANDIDATE@`.

This package must be selected before any new intent, capture, preparation, control or source manifest is assembled. Never prepare an older package and swap its DLL. Root owns every real F/shared-state read, preparation, AA/CDB process, preservation capture and recovery. Use Root's existing retained-Process supervisor; no new supervisor is supplied. The SOURCE compiler/test helper that may terminate its owned pure child must not supervise these live operations.

The retained runtime evidence is the prior CF95 harmless cleanup receipt and Root's two-host C IO proof for candidate3's unchanged portable IO component. Neither is the new 72 baseline, fresh shared snapshot, warm capture, AA result or handoff qualification. Root is separately collecting the new real baseline. The new composed DLL has not been executed natively.

## 1. Verify the SourcePlan, then collect the missing actual baseline

Set `$ExpectedDeliveryManifestSha256` to the externally reviewed digest of this package's `delivery-pinned-manifest.json` from the handoff. Do not compute an expected authority from whatever file happens to be current.

```powershell
$repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$candidate='@CANDIDATE@'
$source='@SOURCE_DIR@'
$run='@RUN@'
$plan=(& (Join-Path $source 'Get-SourcePlan.ps1') -CandidateDirectory $candidate -ExpectedDeliveryManifestSha256 $ExpectedDeliveryManifestSha256)|ConvertFrom-Json -DateKind String
```

This is C-only and checks the complete source authority before reading its plan. No baseline or intent is fabricated. Root now invokes the pinned baseline producer in a fresh supervised x64 host:

```powershell
$baselineEntry=$plan.plan.baselineProducer.path
# Root supervisor: $baselineEntry -RunId $run -Capture
```

The required actual result is a successful, released same-run `capture-result.json` with a sibling `identity-baseline.json`, both independently hashed/read back by Root. The unchanged fixed-stage policy requires 1,228 actual objects; a different inventory must be investigated, not accepted by changing this count. Baseline capture reads F under its existing lease and writes only C evidence. Its returned directory is not known in advance and is not supplied as a placeholder here.

## 2. Materialize a fresh intent from real supplied inputs

Only after that actual baseline exists, assign `$ActualBaselineCapturePath`, `$ActualBaselineCaptureSha256` and `$ActualBaselineIdentitySha256` from Root's specific returned result/readback. The existing harmless receipt below is a real CF95 baseline receipt explicitly permitted by the unchanged qualification policy; it is not a claimed harmless run of the new bound DLL.

```powershell
$intentArgs=@{
 CandidateDirectory=$candidate
 ExpectedDeliveryManifestSha256=$ExpectedDeliveryManifestSha256
 ExpectedSourceManifestSha256='@SEQUENCE_SHA@'
 BaselineCapturePath=$ActualBaselineCapturePath
 ExpectedBaselineCaptureSha256=$ActualBaselineCaptureSha256
 ExpectedBaselineIdentitySha256=$ActualBaselineIdentitySha256
 HarmlessReceiptPath=$plan.plan.existingHarmlessBaseline.path
 ExpectedHarmlessReceiptSha256=$plan.plan.existingHarmlessBaseline.sha256
}
$intent=(& (Join-Path $source 'New-RootIntent.ps1') @intentArgs)|ConvertFrom-Json -DateKind String
$sequenceArgs=@{
 InputRecordPath=$intent.InputRecordPath
 ExpectedInputRecordSha256=$intent.ExpectedInputRecordSha256
 ReviewedSourcesPath=$intent.ReviewedSourcesPath
 ExpectedReviewedSourcesSha256=$intent.ExpectedReviewedSourcesSha256
}
& $intent.EntryPath @sequenceArgs # Existing public C-only sequence Plan
```

The intent defaults to a fresh nine-minute expiry at materialization, or Root may supply an explicit future `-IntentValidUntilUtc`. Never edit an issued intent in place.

Root's existing supervisor may invoke the same entry/arguments with `-Execute` for exactly one Capture → Warm → Assemble → Approval → PreparePlan → Apply → Projection → RuntimePlan → Runtime chain. The existing Capture/Warm stages collect the missing fresh identity/shared/warm records using the reviewed CF95 helper. They are not supplied by this source package. Preparation and Runtime use this new 28-role package and DLL from the beginning.

`-Execute` is not a capture-only command. Native budgets remain the original outer 30,000 ms and inner 10,000 ms, with the original clocks/stop/hold boundaries. There is no automatic retry or recovery. No-trace qualification deliberately leaves application acceptance false and retains pending evidence; a failed overall exit alone does not determine whether attach/Resume/stop succeeded.

## 3. Bind the actual terminal evidence, without guessing closure

Use the exact same-run returned child result, not a newest-file search:

```powershell
$replyPath=Join-Path $repo ('artifacts\aa-fr-capabilities-sequence\run-'+$run+'\Runtime-child-result.json')
$reply=Get-Content -LiteralPath $replyPath -Raw|ConvertFrom-Json -DateKind String
$finalPin=$reply.files.ControllerFinal
```

If an original owner remains held, retain that controller and stop. A missing Pump, missing bootstrap copy, missing structured child reply or unknown stop/close proof does not mean no process was created. The new NoPump snapshot is diagnostic evidence only; this package does not generalize the closed Run0e-specific recovery adapter. NoPump or unknown ownership requires a separate Root assessment of the actual returned evidence.

For supported **actually closed** runtime evidence, the binder requires the original actual Pump, C bootstrap copy, debugger/lease/stream/desktop closure and prepared graph. It refuses wrong-run finals, retained ownership and null Pump before binding a recovery input.

```powershell
$failureDriver=Join-Path $source 'New-FailureInputs.Pinned.ps1'
$preserve=(& $failureDriver -Phase Preservation -CandidateDirectory $candidate -ControllerFinalPath $finalPin.path -ExpectedControllerFinalSha256 $finalPin.sha256 -ExpectedDeliveryManifestSha256 $ExpectedDeliveryManifestSha256)|ConvertFrom-Json -DateKind String
$preserveArgs=@{RunId=$preserve.RunId;EvidenceManifestPath=$preserve.EvidenceManifestPath;ExpectedEvidenceManifestSha256=$preserve.ExpectedEvidenceManifestSha256}
& $preserve.EntryPath @preserveArgs # C-only preservation Plan
# Root supervisor: $preserve.EntryPath @preserveArgs -Capture -OutputDirectory $preserve.OutputDirectory
```

Preservation captures F read-only and archives C evidence; it does not restore. Optional control records are admitted only according to actual events, with canonical wire bytes, lifetime identity, exact ACL, bounded content and hashes. Unknown runtime extras are refused.

## 4. Generate and apply only the inverse supported by the actual archive

```powershell
$recoveryArgs=@{
 Phase='Recovery';CandidateDirectory=$candidate
 ControllerFinalPath=$finalPin.path;ExpectedControllerFinalSha256=$finalPin.sha256
 PreservationDirectory=$preserve.OutputDirectory
 ExpectedDeliveryManifestSha256=$ExpectedDeliveryManifestSha256
}
$recovery=(& $failureDriver @recoveryArgs)|ConvertFrom-Json -DateKind String
$recoveryPlanArgs=@{ClosedFailedRuntimeRecovery=$true;RunId=$recovery.RunId;RecoveryEvidenceManifestPath=$recovery.RecoveryEvidenceManifestPath;ExpectedRecoveryEvidenceManifestSha256=$recovery.ExpectedRecoveryEvidenceManifestSha256}
& $recovery.EntryPath @recoveryPlanArgs # C-only recovery Plan
```

Before Apply, Root collects the existing read-only fresh shared comparison against this run's exact `artifacts\aa-fr-inputs\sequence-@RUN@\before.json` and `scope.json`. Supply their actual reviewed digests from the preparation/control records as `$ActualBeforeSha256` and `$ActualScopeSha256`:

```powershell
$freshArgs=@{CandidateDirectory=$candidate;ExpectedDeliveryManifestSha256=$ExpectedDeliveryManifestSha256;ExpectedBeforeSha256=$ActualBeforeSha256;ExpectedScopeSha256=$ActualScopeSha256;Capture=$true}
# Root supervisor invokes (Join-Path $source 'Capture-FreshShared.Bound.ps1') @freshArgs.
# Set $fresh only from that actual returned JSON, after the original producer has closed.
$recoveryArgs.SharedResultPath=$fresh.sharedResult.path
$recoveryArgs.SharedComparisonPath=$fresh.sharedComparison.path
$recovery=(& $failureDriver @recoveryArgs)|ConvertFrom-Json -DateKind String
$recoveryPlanArgs=@{ClosedFailedRuntimeRecovery=$true;RunId=$recovery.RunId;RecoveryEvidenceManifestPath=$recovery.RecoveryEvidenceManifestPath;ExpectedRecoveryEvidenceManifestSha256=$recovery.ExpectedRecoveryEvidenceManifestSha256}
& $recovery.EntryPath @recoveryPlanArgs
$applyArgs=$recoveryPlanArgs.Clone()
$applyArgs.Apply=$true
$applyArgs.SourceManifestPath=$recovery.SourceManifestPath
$applyArgs.ExpectedSourceManifestSha256=$recovery.ExpectedSourceManifestSha256
$applyArgs.EvidenceDirectory=$recovery.EvidenceDirectory
# Root supervisor: $recovery.EntryPath @applyArgs
```

The inverse uses only actual original payloads/descriptors and archived actual runtime extras. It keeps the existing separate recovery metadata helper and token-reader identities, verifies original restoration, and removes pending/runs only when their guards pass. It never restores shared preferences. A missing or nonzero/freshness-invalid shared comparison blocks Apply. No preparation or runtime receipt is prefilled here.

The debugger C evidence directory is `@CANDIDATE@\native-evidence\runs\@RUN@`, with the existing raw stdout/stderr shared 1 MiB bound, fixed command script, empty-symbols directory and result. This C evidence remains separate from F restoration and is retained for review.
