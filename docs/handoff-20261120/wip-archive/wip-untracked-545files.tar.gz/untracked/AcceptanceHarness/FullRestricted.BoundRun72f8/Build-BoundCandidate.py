"""C-only 72 source derivation; original actors remain unchanged except C evidence root."""
import pathlib,json,hashlib,re,difflib,zipfile,shutil
ROOT=pathlib.Path(__file__).resolve().parents[2]
BASE=ROOT/'artifacts/aa-handoff-bound-bfdd-20261114/candidate2'
OUT=ROOT/'artifacts/aa-handoff-bound-72f8-20261114/candidate1'
RUN='72f854a6f85149f58d20f286283d932b';PREVIOUS='bfdd50364b9049c4a58e36be683d76c8'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8') if isinstance(s,str) else s)
def js(p,v):put(p,json.dumps(v,ensure_ascii=False,indent=2))
checkpoint=BASE/'source-checkpoint.json';decision=ROOT/'artifacts/root-ps7-io-20261114/next-after-bfdd-intent.json'
if sha(checkpoint)!='c1f94c9422077b71fde046abcf1419b744f1f164fc85aa68dbb47ddd8b605bb9' or sha(decision)!='acd6643819544422418b84f3521cb5ca7d54fcfca59cf0b806f9325bb4e5945d':raise RuntimeError('Frozen parent or Root decision differs')
d=json.loads(read(decision))
if d['runId']!=RUN or d['previousRuntimeAttemptCount']!=0 or d['previousStagePreparationInvoked']:raise RuntimeError('Root independent-run decision differs')
for row in json.loads(read(checkpoint))['files']:
 p=BASE/row['path']
 if p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise RuntimeError('Parent source drift '+row['path'])
if OUT.exists():raise RuntimeError('Fresh 72 candidate required')
OUT.mkdir(parents=True);components=[];usings=set();bodies=[];diff=[]
for p in sorted((BASE/'components').glob('*.cs')):
 before=read(p);s=before
 if p.name=='CdbToolcheck.Policy.cs':
  old='\\'+str(BASE.relative_to(ROOT))+'\\native-evidence';new='\\'+str(OUT.relative_to(ROOT))+'\\native-evidence'
  if s.count(old)!=1:raise RuntimeError('Evidence constant anchor differs')
  s=s.replace(old,new)
  if s.replace(new,old)!=before:raise RuntimeError('Evidence-only inverse differs')
 put(OUT/'components'/p.name,s);components.append(dict(name=p.name,baseSha256=sha(p),boundSha256=hashlib.sha256(s.encode()).hexdigest(),unchanged=(s==before)))
 diff+=list(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='bfdd/components/'+p.name,tofile='72/components/'+p.name))
 if p.name=='RestrictedCliNative.cs':put(OUT/'overlay'/p.name,s);continue
 at=re.search(r'\bnamespace\s+',s);usings.update(re.findall(r'\busing\s+[^;]+;',s[:at.start()]));bodies.append('// COMPONENT '+p.name+'\n'+s[at.start():].rstrip()+'\n')
if len(components)!=18 or sum(1 for r in components if r['unchanged'])!=17:raise RuntimeError('Actor component scope differs')
full='// Truthful second compiler input; component bytes and composition are separately recorded.\n'+'\n'.join(sorted(usings))+'\n'+'\n'.join(bodies);put(OUT/'overlay/RestrictedCliFullRestricted.cs',full)
js(OUT/'composition.json',dict(scope='root-selected-72-two-input-bound-composition',runId=RUN,parentCheckpointSha256=sha(checkpoint),rootDecisionSha256=sha(decision),components=components,actualCompilerInputs=['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs'],rootRunIdAssigned=True,sourceOnly=True,nativeExecuted=False))
oldPolicy=read(BASE/'overlay/Qualification.Policy.ps1');oldFull=sha(BASE/'overlay/RestrictedCliFullRestricted.cs');oldComposition=sha(BASE/'composition.json')
if oldPolicy.count(oldFull)!=1 or oldPolicy.count(oldComposition)!=1:raise RuntimeError('Parent policy pins not exact')
policy=oldPolicy.replace(PREVIOUS,RUN).replace(str(BASE),str(OUT)).replace(oldFull,sha(OUT/'overlay/RestrictedCliFullRestricted.cs')).replace(oldComposition,sha(OUT/'composition.json'))
for p in sorted((BASE/'overlay').iterdir()):
 if p.name in ['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs','RestrictedCliNative.dll','tooling-manifest.json']:continue
 before=read(p);s=before.replace(oldPolicy,policy).replace(PREVIOUS,RUN).replace(str(BASE),str(OUT)).replace(str(BASE.relative_to(ROOT)),str(OUT.relative_to(ROOT)))
 if p.name=='Qualification.Policy.ps1':s=policy
 if PREVIOUS in s or '@ROOT_RUN_ID@' in s:raise RuntimeError('Previous or unbound run remains '+p.name)
 put(OUT/'overlay'/p.name,s);diff+=list(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='bfdd/overlay/'+p.name,tofile='72/overlay/'+p.name))
diff+=list(difflib.unified_diff(read(BASE/'overlay/RestrictedCliFullRestricted.cs').splitlines(True),full.splitlines(True),fromfile='bfdd/overlay/RestrictedCliFullRestricted.cs',tofile='72/overlay/RestrictedCliFullRestricted.cs'))
put(OUT/'candidate3-to-bound.diff',''.join(diff));shutil.copytree(BASE/'helper-build',OUT/'helper-build')
helper=json.loads(read(OUT/'helper-build/build.json'))
if helper['moduleSha256']!=sha(OUT/'overlay/FullRestrictedStageTransition.psm1'):raise RuntimeError('Unchanged helper module binding differs')
io=ROOT/'artifacts/root-ps7-io-20261114/actual-io-root-readback.json'
if sha(io)!='73841f6e095633f9cc9baa799e6b53185f00787583b0edf08ebd50586e3f63a5' or sha(OUT/'components/PortableAclIo.cs')!='9a1f91a43b2dca8ef21f2720ac4e842cd9f62d462312c1c3cfbede0bc3d420d7':raise RuntimeError('Actual C IO implementation proof differs')
ioData=json.loads(read(io));hosts=[]
for h in ioData['hosts']:
 p=pathlib.Path(h['resultPath']);r=json.loads(read(p))
 if sha(p)!=h['resultSha256'] or not r['passed'] or len(r['checks'])!=16 or h['naturalExitCode']!=0:raise RuntimeError('Actual C IO host proof differs')
 hosts.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,host=h['host']))
js(OUT/'io-qualification-binding.json',dict(scope='72 source preserves prior actually qualified portable IO component; not new native qualification',runId=RUN,rootReadback=dict(path=str(io),sha256=sha(io)),actualHostResults=hosts,originalTestedDllSha256=ioData['candidate3DllSha256'],portableComponentSha256=sha(OUT/'components/PortableAclIo.cs'),unchangedComponents=17,newDllActuallyIoTested=False,AAExecuted=False,nativeHandoffAcceptance=False))
with zipfile.ZipFile(OUT/'compiler-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs']:z.write(OUT/'overlay'/name,arcname=name)
 z.write(OUT/'composition.json',arcname='composition.json')
js(OUT/'derivation.json',dict(runId=RUN,parent=str(BASE),parentCheckpointSha256=sha(checkpoint),rootDecisionSha256=sha(decision),fullSha256=sha(OUT/'overlay/RestrictedCliFullRestricted.cs'),sharedSha256=sha(OUT/'overlay/RestrictedCliNative.cs'),compositionSha256=sha(OUT/'composition.json'),actorAlgorithmChanged=False,baselineCollectedByAgent=False,freshCaptureCollectedByAgent=False,nativeExecuted=False,FReadPerformed=False,FWritePerformed=False))
print(json.dumps(dict(candidate=str(OUT),runId=RUN,unchangedComponents=17,sourceOnly=True)))
