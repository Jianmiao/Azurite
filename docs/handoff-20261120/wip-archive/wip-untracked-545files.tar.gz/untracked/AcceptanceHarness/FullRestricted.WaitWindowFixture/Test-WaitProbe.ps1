param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
function Fixture {
 $id='1234567890abcdef1234567890abcdef';$rows=@();$counter=1
 foreach($phase in @('natural-host-thread','explicit-sta-probe')){foreach($seed in @(0,1008)){foreach($path in @('raw','com','managed')){$rows+=,[pscustomobject]@{phase=$phase;seed=$seed;path=$path;before=[pscustomobject]@{nativeThreadId=43};created=$true;mutexName=('Global\AzuriteWaitFixture_'+$counter.ToString('x32'));acquired=$true;released=$true;errorType=$null;releaseError=$null};$counter++}}}
 return [pscustomobject]@{id=$id;entry=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;beforeManagedRuntime=$true};host=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;initializeHr=0;delegateHr=0;loadHr=0;closeHr=0;nativeError=0;managedBytes=1000;aaExecuted=$false};probe=[pscustomobject]@{schema=1;scope='fixed wait diagnostic only, no AA acceptance';pid=42;nativeThreadId=43;finalNativeThreadId=43;sameInitialThread=$true;before=[pscustomobject]@{nativeThreadId=43};runtime='.NET 6.0.36';corelib='C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\System.Private.CoreLib.dll';waitTimeoutMs=100;aaExecuted=$false;initializeStaHr=0;records=$rows}}
}
$checks=@()
foreach($name in @('valid','captured-wait-failure','sta-init-failed','foreign-run','foreign-process','foreign-startup-thread','late-thread-hop','wrong-runtime','unbounded-wait','missing-case','duplicate-case','reused-mutex','truncated-bytes','failed-host','failed-managed-hook','AA-promotion')){
 $f=Fixture;$allow=$name -cin @('valid','captured-wait-failure','sta-init-failed')
 switch($name){
  captured-wait-failure {$f.probe.records[0].acquired=$false;$f.probe.records[0].released=$false;$f.probe.records[0].errorType='System.Runtime.InteropServices.COMException'}
  sta-init-failed {$f.probe.initializeStaHr=-1;$f.probe.records=@($f.probe.records|Where-Object phase -CEQ 'natural-host-thread')}
  foreign-run {$f.host.runId='00000000000000000000000000000001'}
  foreign-process {$f.probe.pid=41}
  foreign-startup-thread {$f.entry.nativeThreadId=44}
  late-thread-hop {$f.probe.records[3].before.nativeThreadId=44}
  wrong-runtime {$f.probe.runtime='.NET 8.0.0'}
  unbounded-wait {$f.probe.waitTimeoutMs=-1}
  missing-case {$f.probe.records=$f.probe.records[0..10]}
  duplicate-case {$f.probe.records[1]=$f.probe.records[0]}
  reused-mutex {$f.probe.records[1].mutexName=$f.probe.records[0].mutexName}
  truncated-bytes {$f.host.managedBytes=999}
  failed-host {$f.host.loadHr=-1}
  failed-managed-hook {$f.probe|Add-Member probeFailed $true}
  AA-promotion {$f.probe.aaExecuted=$true}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureWaitProbe $f.entry $f.host $f.probe $f.id 42 43 1000;$passed=$allow -and $r.correlationVerified -and -not $r.applicationAccepted;if($name -ceq 'captured-wait-failure'){$passed=$passed -and -not $r.allWaitCallsSucceeded -and $r.successfulWaitCount -eq 11}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
function WindowFixture {
 $f=Fixture
 function ObjectEvidence($name,$desired){return [pscustomobject]@{name=$name;securityError=0;securityBytes=256;sddl='D:(A;;GA;;;WD)';checks=@($desired|ForEach-Object{[pscustomobject]@{desired=$_;attempted=$true;callSucceeded=$true;error=0;granted=$_;accessStatus=$true}})}}
 $f.probe|Add-Member runId $f.id
 $f.probe|Add-Member windowDiagnostic ([pscustomobject]@{schema=1;pid=42;nativeThreadId=43;desktopBindingVerified=$true;creationAttempted=$true;windowStation=(ObjectEvidence 'WinSta0' @(131072,32,2));desktop=(ObjectEvidence ('AzuriteFullCli_'+$f.id) @(131072,2,129));processTokenOpenError=0;duplicateTokenError=0;primaryRestricted=$true;identificationRestricted=$true;threadTokenInstalled=$false;tokenCloseError=0;duplicateCloseError=0;requestedMessageOnly=$true;requestedStyle=0;requestedExStyle=0;created=$true;createError=0;visible=$false;windowPid=42;windowThread=43;actualStyle=0;actualExStyle=0;destroyed=$true;destroyError=0;stillWindow=$false;foregroundUnchanged=$true;threadFocusUnchanged=$true;threadActiveUnchanged=$true;userObjectSecurityChanged=$false})
 $f.probe|Add-Member postWindowCoWait ([pscustomobject]@{phase='post-message-window-sta';seed=0;path='com';before=[pscustomobject]@{nativeThreadId=43};created=$true;mutexName='Global\AzuriteWaitFixture_ffffffffffffffffffffffffffffffff';acquired=$false;released=$false})
 $f.probe|Add-Member phaseTimes ([pscustomobject]@{frequency=10000000;matrixCompleted=10;windowStarted=11;windowCompleted=12;postStarted=13;postCompleted=14})
 return $f
}
foreach($name in @('window-valid','creation-denied','access-denied','descriptor-unreadable','token-open-failed','foreground-observation-changed','foreign-window-run','foreign-desktop','visible-window','destroy-failed','foreign-window-owner','thread-token-installed','security-written','post-added-to-original','reused-post-mutex','reversed-phase-order','unexplained-access-skip','wrong-access-mask','unrestricted-access-token','token-close-failed')){
 $f=WindowFixture;$w=$f.probe.windowDiagnostic;$allow=$name -cin @('window-valid','creation-denied','access-denied','descriptor-unreadable','token-open-failed','foreground-observation-changed')
 switch($name){
  creation-denied {$w.created=$false;$w.createError=5;$w.windowPid=0;$w.windowThread=0;$w.destroyed=$false}
  access-denied {$w.desktop.checks[1].accessStatus=$false;$w.desktop.checks[1].granted=0}
  descriptor-unreadable {$w.desktop.securityError=5;$w.desktop.securityBytes=0;foreach($a in $w.desktop.checks){$a.attempted=$false;$a.callSucceeded=$false;$a.accessStatus=$false;$a.granted=0}}
  token-open-failed {$w.processTokenOpenError=5;foreach($o in @($w.desktop,$w.windowStation)){foreach($a in $o.checks){$a.attempted=$false;$a.callSucceeded=$false;$a.accessStatus=$false;$a.granted=0}}}
  foreground-observation-changed {$w.foregroundUnchanged=$false}
  foreign-window-run {$f.probe.runId='00000000000000000000000000000001'}
  foreign-desktop {$w.desktop.name='Default'}
  visible-window {$w.visible=$true}
  destroy-failed {$w.destroyed=$false;$w.destroyError=5;$w.stillWindow=$true}
  foreign-window-owner {$w.windowPid=100}
  thread-token-installed {$w.threadTokenInstalled=$true}
  security-written {$w.userObjectSecurityChanged=$true}
  post-added-to-original {$f.probe.records+=,$f.probe.postWindowCoWait}
  reused-post-mutex {$f.probe.postWindowCoWait.mutexName=$f.probe.records[0].mutexName}
  reversed-phase-order {$f.probe.phaseTimes.postStarted=9}
  unexplained-access-skip {$w.desktop.checks[1].attempted=$false}
  wrong-access-mask {$w.desktop.checks[1].desired=268435456}
  unrestricted-access-token {$w.identificationRestricted=$false}
  token-close-failed {$w.tokenCloseError=6}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureWindowProbe $f.entry $f.host $f.probe $f.id 42 43 1000;$passed=$allow -and $r.correlationVerified -and -not $r.applicationAccepted -and $r.caseCount -eq 12 -and -not $r.foregroundCausalityClaimed;if($name -ceq 'foreground-observation-changed'){$passed=$passed -and $r.foregroundObservationChanged}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
$result=[pscustomobject]@{scope='C-only wait and message-window diagnostic consumer behavior';passed=(@($checks|Where-Object{-not $_.passed}).Count -eq 0);checks=$checks.Count;results=$checks;nativeExecuted=$false;FReadPerformed=$false;AAExecuted=$false;host=$PSVersionTable.PSVersion.ToString()}
if(Test-Path -LiteralPath $OutputPath){throw 'Retain previous result'};[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$result|Select-Object passed,checks,host|ConvertTo-Json
if(-not $result.passed){exit 1}
