param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
function Fixture {
 $id='1234567890abcdef1234567890abcdef';$rows=@();$counter=1
 foreach($phase in @('natural-host-thread','explicit-sta-probe')){foreach($seed in @(0,1008)){foreach($path in @('raw','com','managed')){$rows+=,[pscustomobject]@{phase=$phase;seed=$seed;path=$path;before=[pscustomobject]@{nativeThreadId=43};created=$true;mutexName=('Global\AzuriteWaitFixture_'+$counter.ToString('x32'));acquired=$true;released=$true;errorType=$null;releaseError=$null};$counter++}}}
 return [pscustomobject]@{id=$id;entry=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;beforeManagedRuntime=$true};host=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;initializeHr=0;delegateHr=0;loadHr=0;closeHr=0;nativeError=0;managedBytes=1000;aaExecuted=$false};probe=[pscustomobject]@{schema=1;scope='fixed wait diagnostic only, no AA acceptance';pid=42;nativeThreadId=43;finalNativeThreadId=43;sameInitialThread=$true;before=[pscustomobject]@{nativeThreadId=43};runtime='.NET 6.0.36';corelib='C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\System.Private.CoreLib.dll';waitTimeoutMs=100;aaExecuted=$false;initializeStaHr=0;records=$rows}}
}
$checks=@()
foreach($name in @('valid','captured-wait-failure','sta-init-failed','foreign-run','foreign-process','foreign-startup-thread','late-thread-hop','wrong-runtime','unbounded-wait','missing-case','duplicate-case','reused-mutex','truncated-bytes','failed-host','failed-managed-hook','AA-promotion')){
 $f=Fixture;$allow=$name -cin @('valid','captured-wait-failure','sta-init-failed')
 switch($name){
  captured-wait-failure {$f.probe.records[0].acquired=$false;$f.probe.records[0].released=$false;$f.probe.records[0].errorType='System.Runtime.InteropServices.COMException'}
  sta-init-failed {$f.probe.initializeStaHr=-1;$f.probe.records=@($f.probe.records|Where-Object phase -CEQ 'natural-host-thread')}
  foreign-run {$f.host.runId='00000000000000000000000000000001'}
  foreign-process {$f.probe.pid=41}
  foreign-startup-thread {$f.entry.nativeThreadId=44}
  late-thread-hop {$f.probe.records[3].before.nativeThreadId=44}
  wrong-runtime {$f.probe.runtime='.NET 8.0.0'}
  unbounded-wait {$f.probe.waitTimeoutMs=-1}
  missing-case {$f.probe.records=$f.probe.records[0..10]}
  duplicate-case {$f.probe.records[1]=$f.probe.records[0]}
  reused-mutex {$f.probe.records[1].mutexName=$f.probe.records[0].mutexName}
  truncated-bytes {$f.host.managedBytes=999}
  failed-host {$f.host.loadHr=-1}
  failed-managed-hook {$f.probe|Add-Member probeFailed $true}
  AA-promotion {$f.probe.aaExecuted=$true}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureWaitProbe $f.entry $f.host $f.probe $f.id 42 43 1000;$passed=$allow -and $r.correlationVerified -and -not $r.applicationAccepted;if($name -ceq 'captured-wait-failure'){$passed=$passed -and -not $r.allWaitCallsSucceeded -and $r.successfulWaitCount -eq 11}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
function RpcFixture {
 $f=Fixture
 foreach($row in $f.probe.records){$row|Add-Member raw $(if($row.path -ceq 'managed'){$null}else{0});$row|Add-Member lastError 0;$row|Add-Member rpc $(if($row.path -ceq 'managed'){$null}else{[pscustomobject]@{attempted=$false}})}
 $row=$f.probe.records[7];$row.raw=[long]2147942414;$row.lastError=1008;$row.acquired=$false;$row.released=$false
 $row.rpc=[pscustomobject]@{attempted=$true;protocol='rpc-eeinfo.v1';processId=42;nativeThreadId=43;coWaitHr=[long]2147942414;waitLastError=1008;waitBeforeUtcFileTime='100';waitAfterUtcFileTime='101';causalityVerified=$false;startStatus=1761;nextStatus=0;endCalled=$false;endStatus=0;noInformation=$true;observedRecords=0;retainedRecords=0;recordLimit=$false;byteLimit=$false;timeLimit=$false;invalidRecord=$false;elapsedMs=0;maxRecords=8;maxStringUnits=128;maxBinaryBytes=32;maxBytes=4096;betweenCallBudgetMs=50;copyStrings=$false;errorInformationCleared=$false;records=@()}
 return $f
}
function AddRpcRecord($c){$c.startStatus=0;$c.nextStatus=1761;$c.endCalled=$true;$c.noInformation=$false;$c.observedRecords=1;$c.retainedRecords=1;$c.records=@([pscustomobject]@{version=1;processId=999;fileTime='100';component=11;status=5;detectionLocation=123;flags=4;parameterCount=1;parameters=@([pscustomobject]@{type=2;utf16Hex='0041';null=$false;truncated=$false})})}
foreach($name in @('rpc-no-information','rpc-record','rpc-missing-record-flag','rpc-end-failure-visible','rpc-truncation-visible','rpc-foreign-thread','rpc-foreign-process','rpc-wrong-hr','rpc-wrong-last-error','rpc-false-absence','rpc-not-ended','rpc-copied-strings','rpc-cleared-errors','rpc-too-many-records','rpc-too-long-string','rpc-causal-claim','rpc-after-success','rpc-claimed-after-managed','rpc-unbound-time')){
 $f=RpcFixture;$c=$f.probe.records[7].rpc;$allow=$name -cin @('rpc-no-information','rpc-record','rpc-missing-record-flag','rpc-end-failure-visible','rpc-truncation-visible')
 switch($name){
  rpc-record {AddRpcRecord $c}
  rpc-missing-record-flag {AddRpcRecord $c;$c.records[0].flags=5}
  rpc-end-failure-visible {AddRpcRecord $c;$c.endStatus=87}
  rpc-truncation-visible {AddRpcRecord $c;$c.byteLimit=$true}
  rpc-foreign-thread {$c.nativeThreadId=44}
  rpc-foreign-process {$c.processId=41}
  rpc-wrong-hr {$c.coWaitHr=0}
  rpc-wrong-last-error {$c.waitLastError=0}
  rpc-false-absence {AddRpcRecord $c;$c.noInformation=$true}
  rpc-not-ended {AddRpcRecord $c;$c.endCalled=$false}
  rpc-copied-strings {$c.copyStrings=$true}
  rpc-cleared-errors {$c.errorInformationCleared=$true}
  rpc-too-many-records {$c.observedRecords=9}
  rpc-too-long-string {AddRpcRecord $c;$c.records[0].parameters[0].utf16Hex='0041'*129}
  rpc-causal-claim {$c.causalityVerified=$true}
  rpc-after-success {$f.probe.records[7].raw=0}
  rpc-claimed-after-managed {$f.probe.records[2].rpc=$c}
  rpc-unbound-time {$c.waitBeforeUtcFileTime='yesterday'}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureRpcProbe $f.entry $f.host $f.probe $f.id 42 43 1000;$passed=$allow -and $r.caseCount -eq 12 -and -not $r.applicationAccepted;$capture=@($r.rpcCaptures|Where-Object attempted)[0];if($name -cin @('rpc-missing-record-flag','rpc-end-failure-visible','rpc-truncation-visible')){$passed=$passed -and -not $capture.complete}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
$result=[pscustomobject]@{scope='C-only wait and RPC capture consumer behavior';passed=(@($checks|Where-Object{-not $_.passed}).Count -eq 0);checks=$checks.Count;results=$checks;nativeExecuted=$false;FReadPerformed=$false;AAExecuted=$false;host=$PSVersionTable.PSVersion.ToString()}
if(Test-Path -LiteralPath $OutputPath){throw 'Retain previous result'};[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$result|Select-Object passed,checks,host|ConvertTo-Json
if(-not $result.passed){exit 1}
