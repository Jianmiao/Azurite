param([Parameter(Mandatory)][string]$NativeRecordsPath,[Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
$rows=@(Get-Content -LiteralPath $NativeRecordsPath|ForEach-Object{$_|ConvertFrom-Json});$checks=@()
function Evaluate($name,$capture,[bool]$expected){$wait=[pscustomobject]@{path='com';raw=$capture.coWaitHr;lastError=$capture.waitLastError};$errorText=$null;$accepted=$false;try{$null=Assert-FixtureRpcCapture $capture $wait $capture.processId $capture.nativeThreadId;$accepted=$true}catch{$errorText=$_.Exception.Message};$script:checks+=,[pscustomobject]@{name=$name;expectedAccepted=$expected;accepted=$accepted;passed=($accepted -eq $expected);error=$errorText}}
function Clone($value){$value|ConvertTo-Json -Depth 30|ConvertFrom-Json}
foreach($row in $rows|Where-Object case -NE 'actual-current-thread-no-record'){Evaluate ('actual SDK '+$row.case) $row.capture $true}
$typed=@($rows|Where-Object case -CEQ 'typed-parameters')[0].capture;$unicode=@($rows|Where-Object case -CEQ 'string-and-byte-bound')[0].capture
foreach($case in @('actual ANSI type1 overflow','actual UTF16 type2 overflow','actual pointer type5 malformed','actual binary type7 overflow','actual ANSI mislabeled Unicode','actual parameter count overflow')){
 $c=Clone $(if($case -like '*UTF16*'){$unicode}else{$typed})
 switch($case){
  'actual ANSI type1 overflow' {$c.records[0].parameters[0].ansiHex='aa'*129}
  'actual UTF16 type2 overflow' {$c.records[0].parameters[0].utf16Hex='0041'*129}
  'actual pointer type5 malformed' {$c.records[0].parameters[2].pointerHex='1'*17}
  'actual binary type7 overflow' {$c.records[0].parameters[1].binaryHex='aa'*33}
  'actual ANSI mislabeled Unicode' {$c.records[0].parameters[0].type=2}
  'actual parameter count overflow' {$c.records[0].parameterCount=5}
 }
 Evaluate $case $c $false
}
$result=[pscustomobject]@{scope='actual SDK-produced C records through production consumer';passed=(@($checks|Where-Object{-not $_.passed}).Count -eq 0);checks=$checks.Count;results=$checks;inputSha256=(Get-FileHash -LiteralPath $NativeRecordsPath).Hash.ToLowerInvariant();nativeRerun=$false;AAExecuted=$false;host=$PSVersionTable.PSVersion.ToString()}
if(Test-Path -LiteralPath $OutputPath){throw 'Retain previous SDK consumer evidence'};[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$result|Select-Object passed,checks,host|ConvertTo-Json;if(-not $result.passed){exit 1}
