param([Parameter(Mandatory)][string]$AssemblyPath,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh result required'}
Add-Type -Path (Join-Path $PSScriptRoot 'PortableAclIoTests.cs') -WarningAction SilentlyContinue
$rows=[Azurite.IoCompatibilityTests.AdapterTests]::Run($AssemblyPath)
$result=[ordered]@{scope='actual portable helper with exact-argument managed fake BCL creation endpoints and uninitialized fake FileStream overrides';powerShell=$PSVersionTable.PSVersion.ToString();passed=(@($rows|Where-Object {-not $_.Passed}).Count -eq 0);tests=$rows;targetFilesystemOperationsInvoked=$false;filesystemAclBehaviorProven=$false;nativeExecuted=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false));$result|ConvertTo-Json -Depth 10
if(-not $result.passed){exit 1}
