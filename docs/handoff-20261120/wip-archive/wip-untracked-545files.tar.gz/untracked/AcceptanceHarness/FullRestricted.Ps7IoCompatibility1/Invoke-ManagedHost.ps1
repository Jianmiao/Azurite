param([Parameter(Mandatory)][string]$HostPath,[Parameter(Mandatory)][string]$ScriptPath,[Parameter(Mandatory)][string[]]$ScriptArguments,[Parameter(Mandatory)][string]$Record)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
Import-Module (Join-Path $repo 'AcceptanceHarness\FullRestricted.CdbOwnedWaitFixture\SourceProcess.psm1') -Force
$arguments=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$ScriptPath)+$ScriptArguments
Invoke-FixtureSourceProcess -File $HostPath -Arguments $arguments -Record $Record -Directory $repo -BoundMs 30000
