using System;using System.IO;using System.Reflection;using System.Runtime.ExceptionServices;using System.Security.AccessControl;
namespace Azurite.Restricted {
 // Both supported BCL paths pass the explicit descriptor at creation. There is
 // deliberately no create-with-defaults, ACL repair, invocation retry or downgrade.
 internal sealed class PortableAclIo {
  internal static readonly PortableAclIo Current=new PortableAclIo(typeof(Directory),typeof(FileStream),ExtensionType());
  readonly MethodInfo directory;readonly MethodBase record;readonly bool legacyDirectory;
  static Type ExtensionType(){return Type.GetType("System.IO.FileSystemAclExtensions, System.IO.FileSystem.AccessControl",false);}
  static MethodInfo Exact(Type type,string name,Type returns,params Type[] arguments){
   if(type==null)return null;var method=type.GetMethod(name,BindingFlags.Public|BindingFlags.Static|BindingFlags.DeclaredOnly,null,arguments,null);
   if(method==null||method.DeclaringType!=type||!method.IsPublic||!method.IsStatic||method.ReturnType!=returns||method.ContainsGenericParameters)return null;
   var parameters=method.GetParameters();if(parameters.Length!=arguments.Length)return null;for(int i=0;i<parameters.Length;i++)if(parameters[i].ParameterType!=arguments[i])return null;return method;
  }
  internal PortableAclIo(Type directoryType,Type fileStreamType,Type extensionType){
   directory=Exact(directoryType,"CreateDirectory",typeof(DirectoryInfo),typeof(string),typeof(DirectorySecurity));legacyDirectory=directory!=null;
   if(directory==null)directory=Exact(extensionType,"Create",typeof(void),typeof(DirectoryInfo),typeof(DirectorySecurity));
   Type[] fileArguments={typeof(string),typeof(FileMode),typeof(FileSystemRights),typeof(FileShare),typeof(int),typeof(FileOptions),typeof(FileSecurity)};
   if(fileStreamType!=null&&typeof(FileStream).IsAssignableFrom(fileStreamType)){
    var constructor=fileStreamType.GetConstructor(BindingFlags.Public|BindingFlags.Instance|BindingFlags.DeclaredOnly,null,fileArguments,null);
    if(constructor!=null&&constructor.DeclaringType==fileStreamType&&constructor.IsPublic&&!constructor.IsStatic&&!constructor.ContainsGenericParameters){
     var parameters=constructor.GetParameters();bool exact=parameters.Length==fileArguments.Length;
     for(int i=0;exact&&i<parameters.Length;i++)if(parameters[i].ParameterType!=fileArguments[i])exact=false;
     if(exact)record=constructor;
    }
   }
   if(record==null)record=Exact(extensionType,"Create",typeof(FileStream),typeof(FileInfo),typeof(FileMode),typeof(FileSystemRights),typeof(FileShare),typeof(int),typeof(FileOptions),typeof(FileSecurity));
   if(directory==null||record==null)throw new MissingMethodException("Exact atomic directory and record ACL creation members are required");
  }
  static object Invoke(MethodBase member,object[] arguments){
   try{var constructor=member as ConstructorInfo;return constructor!=null?constructor.Invoke(arguments):((MethodInfo)member).Invoke(null,arguments);}
   catch(TargetInvocationException error){if(error.InnerException!=null)ExceptionDispatchInfo.Capture(error.InnerException).Throw();throw;}
  }
  internal void CreateDirectory(string path,DirectorySecurity security){
   if(security==null)throw new ArgumentNullException("security");
   object first=legacyDirectory?(object)path:new DirectoryInfo(path);
   var result=Invoke(directory,new object[]{first,security});if(legacyDirectory&&result==null)throw new InvalidOperationException("Directory ACL creator returned no directory");
  }
  internal void CreateRecord(string path,byte[] data,FileSecurity security){
   if(data==null||data.Length<2||data.Length>4096)throw new InvalidOperationException("gate record bound");if(security==null)throw new ArgumentNullException("security");
   object first=record is ConstructorInfo?(object)path:new FileInfo(path);
   var file=(FileStream)Invoke(record,new object[]{first,FileMode.CreateNew,FileSystemRights.WriteData,FileShare.Read,4096,FileOptions.WriteThrough,security});
   if(file==null)throw new InvalidOperationException("Record ACL creator returned no stream");
   using(file){file.Write(data,0,data.Length);file.Flush(true);}
  }
 }
}
