param([Parameter(Mandatory)][string]$AssemblyPath,[Parameter(Mandatory)][string]$ExpectedSha256,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1')
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Utility\Microsoft.PowerShell.Utility.psd1')
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Management\Microsoft.PowerShell.Management.psd1')
foreach($path in @($AssemblyPath,$ResultPath)){if(-not ([IO.Path]::GetFullPath($path)).StartsWith('C:\',[StringComparison]::OrdinalIgnoreCase)){throw 'C-only metadata paths required'}}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh result required'}
if((Get-FileHash -LiteralPath $AssemblyPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ExpectedSha256){throw 'Candidate DLL differs'}
$assembly=[Reflection.Assembly]::LoadFrom($AssemblyPath)
$rows=@();$flags=[Reflection.BindingFlags]'Public,NonPublic,Instance,Static,DeclaredOnly'
foreach($pair in @(@('Azurite.Restricted.CdbNativeRun','PrepareBeforeTarget'),@('Azurite.Restricted.LeaseFiles','Create'))){
 $method=$assembly.GetType($pair[0],$true).GetMethod($pair[1],$flags);if($null -eq $method){throw 'Exact candidate method missing'}
 $errorText=$null;$ok=$false
 try{[Runtime.CompilerServices.RuntimeHelpers]::PrepareMethod($method.MethodHandle);$ok=$true}catch{$errorText=$_.Exception.ToString()}
 $rows+=,[pscustomobject]@{type=$pair[0];method=$pair[1];prepared=$ok;error=$errorText;invoked=$false}
}
$extension=$null;try{$extension=[Type]::GetType('System.IO.FileSystemAclExtensions, System.IO.FileSystem.AccessControl',$false)}catch{}
$members=@()
foreach($type in @([IO.Directory],[IO.FileStream],$extension)){
 if($null -eq $type){continue}
 foreach($method in @($type.GetMethods([Reflection.BindingFlags]'Public,Static,DeclaredOnly'))+@($type.GetConstructors([Reflection.BindingFlags]'Public,Instance,DeclaredOnly'))){
  $types=@($method.GetParameters()|ForEach-Object {$_.ParameterType.FullName})
  if(($types -join '|') -notmatch 'Security.AccessControl.(DirectorySecurity|FileSecurity)'){continue}
  $members+=,[pscustomobject]@{declaringType=$method.DeclaringType.FullName;name=$method.Name;isStatic=$method.IsStatic;returnType=$(if($method -is [Reflection.MethodInfo]){$method.ReturnType.FullName}else{'System.Void'});parameters=$types}
 }
}
$portable=$assembly.GetType('Azurite.Restricted.PortableAclIo',$false);$bindings=$null;$bindingError=$null
if($portable){
 try{
  $instance=$portable.GetField('Current',$flags).GetValue($null)
  $directory=$portable.GetField('directory',$flags).GetValue($instance);$record=$portable.GetField('record',$flags).GetValue($instance)
  $bindings=[pscustomobject]@{directory=($directory.DeclaringType.FullName+' :: '+$directory.ToString());record=($record.DeclaringType.FullName+' :: '+$record.ToString());directoryAssembly=$directory.DeclaringType.Assembly.FullName;recordAssembly=$record.DeclaringType.Assembly.FullName;creationMembersInvoked=$false}
  foreach($method in $portable.GetMethods($flags)){[Runtime.CompilerServices.RuntimeHelpers]::PrepareMethod($method.MethodHandle)}
 }catch{$bindingError=$_.Exception.ToString()}
}
$result=[ordered]@{scope='same-host managed preparation and BCL signature metadata only';powerShell=$PSVersionTable.PSVersion.ToString();runtimeVersion=[Environment]::Version.ToString();assemblySha256=$ExpectedSha256;rows=$rows;aclMembers=$members;portableBindings=$bindings;portableBindingError=$bindingError;allPrepared=(@($rows|Where-Object {-not $_.prepared}).Count -eq 0 -and $null -eq $bindingError);targetMethodsInvoked=$false;filesystemAclBehaviorProven=$false;nativeExecuted=$false;FReadPerformed=$false;FWritePerformed=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
$result|ConvertTo-Json -Depth 10
if(-not $result.allPrepared){exit 1}
