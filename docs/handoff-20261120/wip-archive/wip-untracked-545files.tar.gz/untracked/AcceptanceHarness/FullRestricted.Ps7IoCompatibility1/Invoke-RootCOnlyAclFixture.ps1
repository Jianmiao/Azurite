# Prepared for Root review/execution only. Runtime owner must not invoke this file.
param([Parameter(Mandatory)][ValidateSet('ps7','ps51')][string]$HostVariant,[Parameter(Mandatory)][ValidatePattern('\A[a-f0-9]{64}\z')][string]$ReviewedManifestSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management','Security')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
$candidate=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$repo='C:\Users\21294\.codex\worktrees\azurite-authoring-20261108\Azurite-github-publish-1.0.38'
$expected=Join-Path $repo 'artifacts\aa-handoff-ps7-io-compatibility-20261114\candidate3'
if($candidate -cne $expected){throw 'Only the reviewed fixed candidate3/source copy may execute'}
$manifestPath=Join-Path $candidate 'source-checkpoint.json'
if((Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ReviewedManifestSha256){throw 'Reviewed source checkpoint differs'}
$manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
foreach($name in @('source/Invoke-RootCOnlyAclFixture.ps1','components/PortableAclIo.cs','overlay/RestrictedCliNative.dll')){
 $rows=@($manifest.files|Where-Object path -CEQ $name);$path=Join-Path $candidate $name
 if($rows.Count -ne 1 -or (Get-Item -LiteralPath $path).Length -ne $rows[0].bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $rows[0].sha256){throw 'Reviewed fixture/DLL/source differs'}
}
if(($HostVariant -eq 'ps7' -and $PSVersionTable.PSVersion.Major -ne 7) -or ($HostVariant -eq 'ps51' -and $PSVersionTable.PSVersion.Major -ne 5)){throw 'Actual host variant differs'}
$fixture=Join-Path $candidate ('root-io-fixture-'+$HostVariant);$resultPath=Join-Path $candidate ('root-io-'+$HostVariant+'-result.json')
if((Test-Path -LiteralPath $fixture) -or (Test-Path -LiteralPath $resultPath)){throw 'Fresh exact fixture and result paths required; no retry or overwrite'}
$cursor=$candidate
while($cursor){if(([IO.File]::GetAttributes($cursor) -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Fixture ancestor is a reparse point'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
$identity=[Security.Principal.WindowsIdentity]::GetCurrent();$stream=$null;$clock=[Diagnostics.Stopwatch]::StartNew()
$r=[ordered]@{scope='Root actual C-only portable ACL creation fixture';hostVariant=$HostVariant;powerShell=$PSVersionTable.PSVersion.ToString();runtimeVersion=[Environment]::Version.ToString();manifestSha256=$ReviewedManifestSha256;fixture=$fixture;passed=$false;error=$null;elapsedMs=$null;created=@();checks=@();directorySddl=$null;recordSddl=$null;selectedBindings=$null;readOnWriteData=$null;shareWriteFailure=$null;aaExecuted=$false;cdbExecuted=$false;tokensDesktopsJobsInvoked=$false;existingObjectAclChanges=$false;deletionPerformed=$false;FReadPerformed=$false;FWritePerformed=$false}
function Need($condition,[string]$message){if(-not $condition){throw $message};$r.checks+=,$message}
function Budget {if($clock.ElapsedMilliseconds -gt 10000){throw 'Original 10-second C fixture observation budget exceeded; preserve owned files and evidence'}}
function Invoke-Exact($method,$instance,[object[]]$arguments){try{return $method.Invoke($instance,$arguments)}catch{if($_.Exception.InnerException){throw $_.Exception.InnerException};throw}}
try{
 Need (-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) 'Exact fixture uses unelevated current account'
 $owner=$identity.User.Value;$logons=@($identity.Groups|ForEach-Object {$_.Value}|Where-Object {$_ -cmatch '\AS-1-5-5-[0-9]+-[0-9]+\z'})
 Need ($logons.Count -eq 1) 'Exactly one current logon SID is available';$logon=$logons[0]
 $assembly=[Reflection.Assembly]::LoadFrom((Join-Path $candidate 'overlay\RestrictedCliNative.dll'));$type=$assembly.GetType('Azurite.Restricted.PortableAclIo',$true);$flags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
 $io=$type.GetField('Current',$flags).GetValue($null);$directoryMethod=$type.GetMethod('CreateDirectory',$flags);$recordMethod=$type.GetMethod('CreateRecord',$flags);$recordBcl=$type.GetField('record',$flags).GetValue($io)
 $r.selectedBindings=[ordered]@{directory=$type.GetField('directory',$flags).GetValue($io).ToString();record=$recordBcl.ToString();recordDeclaringType=$recordBcl.DeclaringType.FullName}
 $directoryAcl=[Security.AccessControl.DirectorySecurity]::new();$directoryAcl.SetOwner($identity.User);$directoryAcl.SetAccessRuleProtection($true,$false);$directoryAcl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($identity.User,[Security.AccessControl.FileSystemRights]::FullControl,([Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'),[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow))
 Budget;$null=Invoke-Exact $directoryMethod $io @($fixture,$directoryAcl);$r.created+=,$fixture
 $sections=[Security.AccessControl.AccessControlSections]'Owner,Access';$r.directorySddl=(Get-Acl -LiteralPath $fixture).GetSecurityDescriptorSddlForm($sections)
 Need ($r.directorySddl -ceq $directoryAcl.GetSecurityDescriptorSddlForm($sections)) 'Directory owner and protected DACL exactly match at observation'
 $sddl='O:'+$owner+'D:P(A;;RC;;;OW)(A;;FA;;;'+$owner+')(A;;FR;;;'+$logon+')(A;;FR;;;WD)';$fileAcl=[Security.AccessControl.FileSecurity]::new();$fileAcl.SetSecurityDescriptorSddlForm($sddl)
 $minimum=Join-Path $fixture 'record-min.json';$maximum=Join-Path $fixture 'record-max.bin';$rightsPath=Join-Path $fixture 'rights-probe.bin'
 Budget;$null=Invoke-Exact $recordMethod $io @($minimum,[byte[]](123,125),$fileAcl);$r.created+=,$minimum
 $r.recordSddl=(Get-Acl -LiteralPath $minimum).GetSecurityDescriptorSddlForm($sections);Need ($r.recordSddl -ceq $fileAcl.GetSecurityDescriptorSddlForm($sections)) 'Record owner and protected OW/owner/logon/WD DACL exactly match'
 Need ([BitConverter]::ToString([IO.File]::ReadAllBytes($minimum)) -ceq '7B-7D') 'Actual helper writes and flushes exact minimum bytes'
 $refused=$false;try{$null=Invoke-Exact $recordMethod $io @($minimum,[byte[]](9,9),$fileAcl)}catch{$refused=$true}
 Need ($refused -and [BitConverter]::ToString([IO.File]::ReadAllBytes($minimum)) -ceq '7B-7D') 'CreateNew refuses existing record without changing its bytes'
 $bytes=[byte[]]::new(4096);$bytes[4095]=200;Budget;$null=Invoke-Exact $recordMethod $io @($maximum,$bytes,$fileAcl);$r.created+=,$maximum;$read=[IO.File]::ReadAllBytes($maximum)
 Need ($read.Length -eq 4096 -and $read[4095] -eq 200) 'Actual helper preserves maximum bounded bytes'
 foreach($bad in @(@('null',$null),@('zero',[byte[]]::new(0)),@('one',[byte[]]::new(1)),@('large',[byte[]]::new(4097)))){$path=Join-Path $fixture ('bad-'+$bad[0]+'.bin');$refused=$false;try{$null=Invoke-Exact $recordMethod $io @($path,$bad[1],$fileAcl)}catch{$refused=$true};Need ($refused -and -not (Test-Path -LiteralPath $path)) ('Invalid '+$bad[0]+' record never creates a file')}
 # Inspect actual selected BCL handle rights/share while this fixture owns it.
 # This creates one additional file with the same explicit creation arguments.
 Budget;$first=if($recordBcl -is [Reflection.ConstructorInfo]){$rightsPath}else{[IO.FileInfo]::new($rightsPath)};$arguments=[object[]]@($first,[IO.FileMode]::CreateNew,[Security.AccessControl.FileSystemRights]::WriteData,[IO.FileShare]::Read,4096,[IO.FileOptions]::WriteThrough,$fileAcl)
 if($recordBcl -is [Reflection.ConstructorInfo]){$stream=$recordBcl.Invoke($arguments)}else{$stream=$recordBcl.Invoke($null,$arguments)};$r.created+=,$rightsPath
 $stream.Write([byte[]](1,2),0,2);$stream.Flush($true);$stream.Position=0;$readRefused=$false;try{$value=$stream.ReadByte();$r.readOnWriteData=[ordered]@{returned=$value;error=$null}}catch{$readRefused=$true;$r.readOnWriteData=[ordered]@{returned=$null;error=$_.Exception.ToString()}}
 Need $readRefused 'WriteData-only creation handle cannot read file content'
 $reader=[IO.File]::Open($rightsPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite);try{Need ($reader.ReadByte() -eq 1) 'FileShare.Read admits a compatible reader'}finally{$reader.Dispose()}
 $writer=$null;$writeRefused=$false;try{$writer=[IO.File]::Open($rightsPath,[IO.FileMode]::Open,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)}catch{$writeRefused=$true;$r.shareWriteFailure=$_.Exception.ToString()}finally{if($writer){$writer.Dispose()}}
 Need $writeRefused 'FileShare.Read excludes a second writer';$stream.Dispose();$stream=$null
 Need ((Get-Acl -LiteralPath $rightsPath).GetSecurityDescriptorSddlForm($sections) -ceq $fileAcl.GetSecurityDescriptorSddlForm($sections)) 'Rights-probe creation retains identical explicit file ACL'
 Budget;$r.passed=$true
}catch{$r.error=$_.Exception.ToString()}
finally{
 if($stream){try{$stream.Dispose()}catch{$r.passed=$false;$r.error+=' Stream disposal: '+$_.Exception.ToString()}}
 $identity.Dispose();$r.elapsedMs=$clock.ElapsedMilliseconds
 $data=[Text.UTF8Encoding]::new($false).GetBytes(($r|ConvertTo-Json -Depth 12));$f=[IO.File]::Open($resultPath,'CreateNew','Write','Read');try{$f.Write($data,0,$data.Length);$f.Flush($true)}finally{$f.Dispose()}
}
$r|ConvertTo-Json -Depth 12
if(-not $r.passed){throw 'Root C-only IO fixture failed; preserve exact files/result and review before any new attempt'}
