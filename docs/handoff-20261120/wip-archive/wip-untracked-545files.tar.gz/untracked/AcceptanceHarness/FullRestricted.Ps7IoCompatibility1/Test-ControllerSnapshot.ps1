param([Parameter(Mandatory)][string]$AssemblyPath,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh result required'}
$a=[Reflection.Assembly]::LoadFrom($AssemblyPath);$type=$a.GetType('Azurite.Restricted.ActualAaHandoff',$true);$flags=[Reflection.BindingFlags]'NonPublic,Public,Instance,Static';$current=$type.GetField('current',$flags);$sessionType=$type.GetNestedType('Session',[Reflection.BindingFlags]::NonPublic)
function Set-SessionField($session,[string]$name,$value){$sessionType.GetField($name,$flags).SetValue($session,$value)}
$rows=@();$initial=[Azurite.Restricted.ActualAaHandoff]::Snapshot();$rows+=,[pscustomobject]@{name='absent session stays absent without invented Pump';passed=($initial.session -eq $false -and $initial.holdHost -eq $false -and $null -eq $initial.PSObject.Properties['outerPumpReturned']);snapshot=$initial}
$session=[Activator]::CreateInstance($sessionType,$true);Set-SessionField $session 'Run' 'pure-managed-snapshot';Set-SessionField $session 'ManagedPhase' 'preparing-debugger-files';$current.SetValue($null,$session)
try{
 $snapshot=[Azurite.Restricted.ActualAaHandoff]::Snapshot();$rows+=,[pscustomobject]@{name='actual phase preserves unresolved stop hold and absent owners';passed=($snapshot.managedPhase -ceq 'preparing-debugger-files' -and $snapshot.holdHost -eq $true -and $snapshot.stopProven -eq $false -and $snapshot.workerCreated -eq $false -and $snapshot.bootstrapStarted -eq $false -and $snapshot.outerPumpReturned -eq $false);snapshot=$snapshot}
 Set-SessionField $session 'StopProven' $true;$completion=[Threading.Tasks.TaskCompletionSource[object]]::new();Set-SessionField $session 'Worker' $completion.Task
 $snapshot=[Azurite.Restricted.ActualAaHandoff]::Snapshot();$rows+=,[pscustomobject]@{name='unfinished actual worker remains held despite proven stop';passed=($snapshot.holdHost -eq $true -and $snapshot.workerCreated -eq $true -and $snapshot.workerCompleted -eq $false);snapshot=$snapshot}
 $completion.SetResult($null);$snapshot=[Azurite.Restricted.ActualAaHandoff]::Snapshot();$rows+=,[pscustomobject]@{name='completed actual worker permits original no-owner hold result';passed=($snapshot.holdHost -eq $false -and $snapshot.workerCreated -eq $true -and $snapshot.workerCompleted -eq $true -and $snapshot.outerPumpReturned -eq $false -and $snapshot.bootstrapStarted -eq $false);snapshot=$snapshot}
}finally{$current.SetValue($null,$null);$sessionType.GetField('Started',$flags).GetValue($session).Dispose()}
$result=[ordered]@{scope='actual controller Snapshot and MustHoldHost on isolated managed Session states';passed=(@($rows|Where-Object {-not $_.passed}).Count -eq 0);tests=$rows;powerShell=$PSVersionTable.PSVersion.ToString();nativeExecuted=$false;RunPreparedInvoked=$false;targetSessionConstructed=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false));[pscustomobject]@{passed=$result.passed;tests=$rows.Count}|ConvertTo-Json
if(-not $result.passed){exit 1}
