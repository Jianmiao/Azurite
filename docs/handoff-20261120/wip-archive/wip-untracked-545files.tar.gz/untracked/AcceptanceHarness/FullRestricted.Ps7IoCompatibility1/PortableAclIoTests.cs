using System;using System.IO;using System.Reflection;using System.Runtime.Serialization;using System.Security.AccessControl;using System.Collections.Generic;
namespace Azurite.IoCompatibilityTests {
 public sealed class FakeRecordFile:FileStream {
  public static readonly List<string> Events=new List<string>();public static string FailAt;public static byte[] Written;
  private FakeRecordFile():base("NEVER-CONSTRUCT-THIS-TEST-TYPE",FileMode.Open){throw new InvalidOperationException("Test constructor must not run");}
  // Test-only object has no native handle. Only overridden members are invoked.
  public static FakeRecordFile New(){var factory=Type.GetType("System.Runtime.Serialization.FormatterServices, mscorlib",true).GetMethod("GetUninitializedObject");var value=(FakeRecordFile)factory.Invoke(null,new object[]{typeof(FakeRecordFile)});GC.SuppressFinalize(value);return value;}
  public override void Write(byte[] data,int offset,int count){Events.Add("write");if(FailAt=="write")throw new IOException("write-failure");Written=new byte[count];Array.Copy(data,offset,Written,0,count);}
  public override void Flush(bool toDisk){Events.Add("flush:"+toDisk);if(FailAt=="flush")throw new IOException("flush-failure");}
  protected override void Dispose(bool disposing){Events.Add("dispose:"+disposing);if(FailAt=="dispose")throw new IOException("dispose-failure");}
 }
 public static class LegacyDirectory {
  public static int Calls;public static bool Throw;public static object Security;public static string Path;
  public static DirectoryInfo CreateDirectory(string path,DirectorySecurity security){Calls++;Path=path;Security=security;if(Throw)throw new IOException("legacy-directory-failure");return new DirectoryInfo(path);}
 }
 public sealed class NoLegacyMembers {}
 public sealed class WrongPathParameterFileStream:FileStream {
  // Resolution-only negative control: this constructor must never be invoked.
  public WrongPathParameterFileStream(object path,FileMode mode,FileSystemRights rights,FileShare share,int buffer,FileOptions options,FileSecurity security):base("NEVER-CONSTRUCT-THIS-TEST-TYPE",FileMode.Open){throw new InvalidOperationException("Resolution-only constructor was invoked");}
 }
 public static class WrongExtensions {
  public static object Create(DirectoryInfo d,DirectorySecurity s){return null;}
  public static Stream Create(FileInfo f,FileMode m,FileSystemRights r,FileShare s,int b,FileOptions o,FileSecurity a){return null;}
 }
 public static class ModernExtensions {
  public static int DirectoryCalls,FileCalls;public static string DirectoryPath,FilePath,Failure;public static object DirectoryAcl,FileAcl;public static object[] FileArguments;
  public static void Create(DirectoryInfo path,DirectorySecurity security){DirectoryCalls++;DirectoryPath=path.FullName;DirectoryAcl=security;if(Failure=="directory")throw new IOException("modern-directory-failure");}
  public static FileStream Create(FileInfo path,FileMode mode,FileSystemRights rights,FileShare share,int buffer,FileOptions options,FileSecurity security){FileCalls++;FilePath=path.FullName;FileAcl=security;FileArguments=new object[]{mode,rights,share,buffer,options};if(Failure=="create")throw new IOException("record-create-failure");if(Failure=="null")return null;return FakeRecordFile.New();}
 }
 public sealed class TestRow {public string Name;public bool Passed;public string Error;}
 public static class AdapterTests {
  static Type adapter;static object modern;static readonly List<TestRow> rows=new List<TestRow>();static readonly string path=@"C:\pure-managed-fixture\record.json";
  static void Need(bool value,string message){if(!value)throw new InvalidOperationException(message);}
  static object New(Type directory,Type stream,Type extensions){return Activator.CreateInstance(adapter,BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{directory,stream,extensions},null);}
  static object Call(object instance,string name,params object[] args){try{return adapter.GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic).Invoke(instance,args);}catch(TargetInvocationException e){throw e.InnerException;}}
  static void Reset(){ModernExtensions.DirectoryCalls=0;ModernExtensions.FileCalls=0;ModernExtensions.Failure=null;LegacyDirectory.Calls=0;LegacyDirectory.Throw=false;FakeRecordFile.Events.Clear();FakeRecordFile.FailAt=null;FakeRecordFile.Written=null;}
  static void Case(string name,Action body){Reset();try{body();rows.Add(new TestRow{Name=name,Passed=true});}catch(Exception e){rows.Add(new TestRow{Name=name,Passed=false,Error=e.ToString()});}}
  static void Throws(Action action,string expected){try{action();}catch(Exception e){Need(e.GetType()==typeof(IOException)&&e.Message==expected,"Original exception identity/type was masked: "+e);return;}throw new InvalidOperationException("Expected failure was swallowed");}
  public static TestRow[] Run(string assemblyPath){
   rows.Clear();adapter=Assembly.LoadFrom(assemblyPath).GetType("Azurite.Restricted.PortableAclIo",false);
   if(adapter==null)return new[]{new TestRow{Name="portable secure-creation adapter exists",Passed=false,Error="Legacy candidate contains direct unavailable ACL member calls; no portable secure-creation adapter exists"}};
   modern=New(typeof(NoLegacyMembers),typeof(NoLegacyMembers),typeof(ModernExtensions));
   Case("modern directory forwards exact path and ACL once",()=>{var acl=new DirectorySecurity();Call(modern,"CreateDirectory",path,acl);Need(ModernExtensions.DirectoryCalls==1&&ModernExtensions.DirectoryPath==path&&Object.ReferenceEquals(ModernExtensions.DirectoryAcl,acl),"Directory identity/ACL forwarding differs");});
   Case("legacy directory forwards exact path and ACL",()=>{var acl=new DirectorySecurity();Call(New(typeof(LegacyDirectory),typeof(NoLegacyMembers),typeof(ModernExtensions)),"CreateDirectory",path,acl);Need(LegacyDirectory.Calls==1&&LegacyDirectory.Path==path&&Object.ReferenceEquals(LegacyDirectory.Security,acl)&&ModernExtensions.DirectoryCalls==0,"Wrong directory branch or ACL");});
   Case("legacy invocation failure never falls back or retries",()=>{LegacyDirectory.Throw=true;Throws(()=>Call(New(typeof(LegacyDirectory),typeof(NoLegacyMembers),typeof(ModernExtensions)),"CreateDirectory",path,new DirectorySecurity()),"legacy-directory-failure");Need(LegacyDirectory.Calls==1&&ModernExtensions.DirectoryCalls==0,"Invocation was retried or fell back");});
   Case("modern directory failure retains original exception",()=>{ModernExtensions.Failure="directory";Throws(()=>Call(modern,"CreateDirectory",path,new DirectorySecurity()),"modern-directory-failure");Need(ModernExtensions.DirectoryCalls==1,"Directory creation retried");});
   Case("wrong return signatures fail closed before any invocation",()=>{bool refused=false;try{New(typeof(NoLegacyMembers),typeof(NoLegacyMembers),typeof(WrongExtensions));}catch(TargetInvocationException e){refused=e.InnerException is MissingMethodException;}Need(refused&&ModernExtensions.FileCalls==0&&ModernExtensions.DirectoryCalls==0,"Inexact signature admitted");});
   Case("assignable Object constructor parameter fails closed without exact fallback",()=>{bool refused=false;try{New(typeof(LegacyDirectory),typeof(WrongPathParameterFileStream),typeof(NoLegacyMembers));}catch(TargetInvocationException e){refused=e.InnerException is MissingMethodException;}Need(refused,"Default binder accepted Object where exact String constructor parameter is required");});
   Case("inexact legacy constructor resolves only an exact modern alternative",()=>{var binding=New(typeof(LegacyDirectory),typeof(WrongPathParameterFileStream),typeof(ModernExtensions));var selected=(MethodBase)adapter.GetField("record",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(binding);Need(selected is MethodInfo&&selected.DeclaringType==typeof(ModernExtensions),"Inexact assignable legacy constructor was selected");});
   Case("record forwards CreateNew WriteData Read 4096 WriteThrough and exact ACL",()=>{var acl=new FileSecurity();Call(modern,"CreateRecord",path,new byte[]{12,34,56},acl);var a=ModernExtensions.FileArguments;Need(ModernExtensions.FileCalls==1&&ModernExtensions.FilePath==path&&Object.ReferenceEquals(ModernExtensions.FileAcl,acl),"Record identity/ACL forwarding differs");Need((FileMode)a[0]==FileMode.CreateNew&&(FileSystemRights)a[1]==FileSystemRights.WriteData&&(FileShare)a[2]==FileShare.Read&&(int)a[3]==4096&&(FileOptions)a[4]==FileOptions.WriteThrough,"Secure creation arguments changed");Need(String.Join(",",FakeRecordFile.Events.ToArray())=="write,flush:True,dispose:True"&&BitConverter.ToString(FakeRecordFile.Written)=="0C-22-38","Write/flush/disposal order or bytes differ");});
   foreach(string at in new[]{"write","flush","dispose"}){string captured=at;Case(captured+" failure is propagated with one disposal",()=>{FakeRecordFile.FailAt=captured;Throws(()=>Call(modern,"CreateRecord",path,new byte[]{1,2},new FileSecurity()),captured+"-failure");Need(ModernExtensions.FileCalls==1&&FakeRecordFile.Events.FindAll(x=>x=="dispose:True").Count==1,"Resource leaked or retried");if(captured=="write")Need(!FakeRecordFile.Events.Contains("flush:True"),"Flush ran after failed write");});}
   Case("create failure never writes or retries",()=>{ModernExtensions.Failure="create";Throws(()=>Call(modern,"CreateRecord",path,new byte[]{1,2},new FileSecurity()),"record-create-failure");Need(ModernExtensions.FileCalls==1&&FakeRecordFile.Events.Count==0,"Creation failure triggered fallback or write");});
   Case("null stream fails closed",()=>{ModernExtensions.Failure="null";bool failed=false;try{Call(modern,"CreateRecord",path,new byte[]{1,2},new FileSecurity());}catch(InvalidOperationException){failed=true;}Need(failed&&ModernExtensions.FileCalls==1&&FakeRecordFile.Events.Count==0,"Null record stream accepted");});
   Case("invalid record bounds never create",()=>{foreach(byte[] bytes in new byte[][]{null,new byte[0],new byte[1],new byte[4097]}){bool failed=false;try{Call(modern,"CreateRecord",path,bytes,new FileSecurity());}catch(InvalidOperationException){failed=true;}Need(failed,"Invalid bound admitted");}Need(ModernExtensions.FileCalls==0,"Invalid record reached creation");});
   Case("maximum record length remains supported",()=>{var bytes=new byte[4096];bytes[4095]=200;Call(modern,"CreateRecord",path,bytes,new FileSecurity());Need(FakeRecordFile.Written.Length==4096&&FakeRecordFile.Written[4095]==200,"Maximum bounded record truncated");});
   return rows.ToArray();
  }
 }
}
