param([Parameter(Mandatory)][string]$RunnerPath,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh parse result required'}
$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($RunnerPath,[ref]$tokens,[ref]$errors)
$result=[ordered]@{scope='Root-only real IO runner syntax check, not invocation';powerShell=$PSVersionTable.PSVersion.ToString();passed=($errors.Count -eq 0);errors=@($errors|ForEach-Object {$_.Message});runnerSha256=(Get-FileHash -LiteralPath $RunnerPath -Algorithm SHA256).Hash.ToLowerInvariant();runnerInvoked=$false;filesystemAclBehaviorProven=$false}
[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false));$result|ConvertTo-Json -Depth 5
if(-not $result.passed){exit 1}
