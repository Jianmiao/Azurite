"""C-only source derivation. No native/ACL invocation and no actual RunId selection."""
import difflib,hashlib,json,pathlib,re,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[2]
HERE=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'artifacts/aa-actual-no-trace-qualification-20261114/candidate10'
OUT=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114'/sys.argv[1]
if OUT.exists():raise RuntimeError('Fresh candidate required')
def sha(b):return hashlib.sha256(b).hexdigest()
def text(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf-8') if isinstance(s,str) else s)
def js(p,v):put(p,json.dumps(v,ensure_ascii=False,indent=2))
checkpoint=BASE/'source-checkpoint.json'
if sha(checkpoint.read_bytes())!='86ababded2dee98dad1e4a1653467253084d5bbb73920c22bf3e21628f83e894':raise RuntimeError('Frozen checkpoint differs')
for row in json.loads(checkpoint.read_text())['files']:
 b=(BASE/row['path']).read_bytes()
 if len(b)!=row['bytes'] or sha(b)!=row['sha256']:raise RuntimeError('Frozen source drift '+row['path'])
changes=[];diffs=[]
def rep(s,old,new,label,count=1):
 if s.count(old)!=count:raise RuntimeError(label+': exact anchor count differs')
 changes.append(dict(label=label,before=old,after=new,count=count));return s.replace(old,new)
components=[];usings=set();bodies=[]
for path in sorted((BASE/'components').glob('*.cs')):
 name=path.name;before=text(path);s=before;start=len(changes)
 if name=='CdbAttach.FilePreparation.generated.cs':s=rep(s,'Directory.CreateDirectory(RunDirectory, security);','PortableAclIo.Current.CreateDirectory(RunDirectory, security);','secure portable directory creation')
 if name=='CdbLeaseNative.cs':s=rep(s,'using(var file=new FileStream(path,FileMode.CreateNew,FileSystemRights.WriteData,FileShare.Read,4096,FileOptions.WriteThrough,security)){file.Write(data,0,data.Length);file.Flush(true);}','PortableAclIo.Current.CreateRecord(path,data,security);','secure portable bounded record creation')
 if name=='Handoff.Controller.cs':
  s=rep(s,'internal string Run,Directory,Owner,Logon;','internal string Run,Directory,Owner,Logon;internal volatile string ManagedPhase="session-created";','truthful managed phase field')
  for old,new,label in [
   ('    s.Directories=LeaseFiles.HoldControl','    s.ManagedPhase="holding-control-directory";s.Directories=LeaseFiles.HoldControl','before control-directory hold'),
   ('    s.Pins.Add(FullRestrictedContract.Executable','    s.ManagedPhase="pinning-images-and-lease";s.Pins.Add(FullRestrictedContract.Executable','before image/lease setup'),
   ('    s.Native=new CdbNativeRun','    s.ManagedPhase="preparing-debugger-files";s.Native=new CdbNativeRun','before debugger file preparation'),
   ('    s.Worker=Task.Factory.StartNew','    s.ManagedPhase="starting-controller-worker";s.Worker=Task.Factory.StartNew','before worker scheduling'),
   ('    result=ProcessPump.RunBootstrapFullRestricted','    s.ManagedPhase="invoking-outer-bootstrap";result=ProcessPump.RunBootstrapFullRestricted','before outer bootstrap call'),
   ('s.Pump=result;','s.Pump=result;s.ManagedPhase="outer-bootstrap-returned";','after actual Pump return'),
   ('    FullRestrictedContract.Require(s.Lease.CloseAfterDrain(true)','    s.ManagedPhase="closing-target-lease";FullRestrictedContract.Require(s.Lease.CloseAfterDrain(true)','before lease close'),
   ('throw new InvalidOperationException("Actual-AA debugger handoff failed",s.FirstError);return result;','throw new InvalidOperationException("Actual-AA debugger handoff failed",s.FirstError);s.ManagedPhase="completed";return result;','only after successful completion'),
   ('runId=s.Run,holdHost=MustHoldHost()','runId=s.Run,managedPhase=s.ManagedPhase,workerCreated=s.Worker!=null,bootstrapStarted=s.Lease!=null&&s.Lease.BootstrapStarted,outerPumpReturned=s.Pump!=null,holdHost=MustHoldHost()','actual phase and ownership snapshot')]:s=rep(s,old,new,label)
 if name=='CdbToolcheck.Policy.cs':
  s=rep(s,r'\artifacts\aa-actual-no-trace-qualification-20261114\candidate10\native-evidence','\\'+str(OUT.relative_to(ROOT)).replace('/','\\')+r'\native-evidence','new independent evidence directory binding')
 inverse=s
 for change in reversed(changes[start:]):inverse=inverse.replace(change['after'],change['before'])
 if inverse!=before:raise RuntimeError('Inverse mismatch '+name)
 put(OUT/'components'/name,s)
 components.append(dict(name=name,originalSha256=sha(path.read_bytes()),candidateSha256=sha(s.encode()),inverseNormalizedEqual=True,changes=changes[start:]))
 diffs+=list(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='candidate10/components/'+name,tofile='candidate/components/'+name))
helper=text(HERE/'PortableAclIo.cs');put(OUT/'components/PortableAclIo.cs',helper)
diffs+=list(difflib.unified_diff([],helper.splitlines(True),fromfile='/dev/null',tofile='candidate/components/PortableAclIo.cs'))
components.append(dict(name='PortableAclIo.cs',originalSha256=None,candidateSha256=sha(helper.encode()),newComponent=True))
for path in sorted((OUT/'components').glob('*.cs')):
 s=text(path)
 if path.name=='RestrictedCliNative.cs':put(OUT/'overlay'/path.name,s);continue
 m=re.search(r'\bnamespace\s+',s)
 if not m:raise RuntimeError('No namespace '+path.name)
 header=s[:m.start()];usings.update(re.findall(r'\busing\s+[^;]+;',header))
 residue=re.sub(r'\busing\s+[^;]+;','',header);residue=re.sub(r'//[^\n]*|/\*.*?\*/','',residue,flags=re.S)
 if residue.strip():raise RuntimeError('Unsupported aggregate header')
 bodies.append('// COMPONENT '+path.name+'\n'+s[m.start():].rstrip()+'\n')
aggregate='// Truthful second compiler input; component bytes and composition are separately recorded.\n'+'\n'.join(sorted(usings))+'\n'+'\n'.join(bodies)
put(OUT/'overlay/RestrictedCliFullRestricted.cs',aggregate)
diffs+=list(difflib.unified_diff(text(BASE/'overlay/RestrictedCliFullRestricted.cs').splitlines(True),aggregate.splitlines(True),fromfile='candidate10/overlay/RestrictedCliFullRestricted.cs',tofile='candidate/overlay/RestrictedCliFullRestricted.cs'))
composition=dict(scope='ps7-io-compatibility-source-candidate-unbound',baseCheckpointSha256=sha(checkpoint.read_bytes()),components=components,actualCompilerInputs=['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs'],rootRunIdAssigned=False,sourceOnly=True,nativeExecuted=False)
js(OUT/'composition.json',composition)
old_policy=text(BASE/'overlay/Qualification.Policy.ps1')
policy=old_policy.replace('0e494be63f3248ffb7bd7bbd040987f8','@ROOT_RUN_ID@').replace('cbe3db55b1aed5106ca590d74e30b37c23a7c011137c5f597191ea96364df59a',sha(aggregate.encode())).replace('ce109c85801d5dac615c7cedd44453a35895223dd369c82de58cdf9a9edb6a1a',sha((OUT/'composition.json').read_bytes())).replace(str(BASE),str(OUT))
# The unbound package must refuse execution even if a caller supplies the token.
policy=policy.replace(' if($null -eq $Selection){return $null}',' throw "SOURCE/BUILD candidate is unbound; Root must assign and review a fresh actual RunId"\n if($null -eq $Selection){return $null}',1)
for path in sorted((BASE/'overlay').iterdir()):
 if path.name in ['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs','RestrictedCliNative.dll','tooling-manifest.json']:continue
 before=text(path);s=before.replace(old_policy,policy).replace(str(BASE),str(OUT)).replace(str(BASE.relative_to(ROOT)),str(OUT.relative_to(ROOT))).replace('0e494be63f3248ffb7bd7bbd040987f8','@ROOT_RUN_ID@')
 if path.name=='Qualification.Policy.ps1':s=policy
 if path.name=='FullRestrictedCapabilitiesRuntime.psm1':
  s=rep(s,'PendingEvidence=$null;Result=$null}','PendingEvidence=$null;Result=$null;HandoffSnapshot=$null;HandoffSnapshotError=$null;HandoffError=$null;HandoffPumpError=$null}','retain independent actual diagnostics state')
  s=rep(s,'result=$state.Result;runtimeAllowed=$false}','result=$state.Result;handoffSnapshot=$state.HandoffSnapshot;handoffSnapshotError=$state.HandoffSnapshotError;handoffError=$state.HandoffError;handoffPumpError=$state.HandoffPumpError;runtimeAllowed=$false}','persist actual snapshot when result absent')
  s=rep(s,'catch{$handoffError=$_.Exception.ToString();$outer=[Azurite.Restricted.ActualAaHandoff]::SavedPump($Plan.RunId)}\n  $handoff=[Azurite.Restricted.ActualAaHandoff]::Snapshot()',
   'catch{$handoffError=$_.Exception.ToString();$Execution.HandoffError=$handoffError;try{$outer=[Azurite.Restricted.ActualAaHandoff]::SavedPump($Plan.RunId)}catch{$Execution.HandoffPumpError=$_.Exception.ToString()}}\n  try{$handoff=[Azurite.Restricted.ActualAaHandoff]::Snapshot();$Execution.HandoffSnapshot=$handoff}catch{$Execution.HandoffSnapshotError=$_.Exception.ToString()}','save actual snapshot before NoPump and retain secondary diagnostics')
 put(OUT/'overlay'/path.name,s)
 diffs+=list(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='candidate10/overlay/'+path.name,tofile='candidate/overlay/'+path.name))
put(OUT/'candidate10-to-candidate.diff',''.join(diffs))
js(OUT/'generation-changes.json',changes)
put(OUT/'BINDING-STATUS.md','SOURCE/BUILD only. No Root RunId assigned. Qualification selection deliberately refuses. All new preparation inputs, tool/source/helper bindings and 28 sequence roles require fresh reviewed binding before execution. No old 0e command is supplied.\n')
with zipfile.ZipFile(OUT/'compiler-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs']:z.write(OUT/'overlay'/name,arcname=name)
js(OUT/'generation-result.json',dict(candidate=str(OUT),rootRunIdAssigned=False,actualCompilerInputs=['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs'],sharedSha256=sha((OUT/'overlay/RestrictedCliNative.cs').read_bytes()),fullSha256=sha(aggregate.encode()),compositionSha256=sha((OUT/'composition.json').read_bytes()),sourceOnly=True,nativeExecuted=False,FReadPerformed=False,FWritePerformed=False))
print(json.dumps(dict(candidate=str(OUT),components=len(components),sourceOnly=True)))
