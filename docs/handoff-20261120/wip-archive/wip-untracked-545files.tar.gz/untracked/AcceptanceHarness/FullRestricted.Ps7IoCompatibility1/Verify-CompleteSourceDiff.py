"""Apply the delivered unified source diff in memory and check every changed source."""
import hashlib,json,pathlib,re,sys
root=pathlib.Path(__file__).resolve().parents[2]
base=root/'artifacts/aa-actual-no-trace-qualification-20261114/candidate10'
candidate=root/'artifacts/aa-handoff-ps7-io-compatibility-20261114'/sys.argv[1]
diff=candidate/'candidate10-to-candidate.diff';result=candidate/'tests/complete-source-diff.json'
if result.exists():raise RuntimeError('Fresh verification result required')
def read(p):return p.read_text(encoding='utf-8-sig').replace('\r\n','\n')
lines=read(diff).splitlines(True);i=0;seen=set();rows=[]
while i<len(lines):
 if not lines[i].startswith('--- '):raise RuntimeError('Expected old-file header')
 old=lines[i][4:].strip();i+=1
 if i>=len(lines) or not lines[i].startswith('+++ '):raise RuntimeError('Expected new-file header')
 new=lines[i][4:].strip();i+=1
 if not new.startswith('candidate/'):raise RuntimeError('Unexpected candidate target')
 relative=new[len('candidate/'):]
 if relative in seen:raise RuntimeError('Repeated file diff '+relative)
 seen.add(relative)
 source=[] if old=='/dev/null' else read(base/old[len('candidate10/'):]).splitlines(True)
 output=[];cursor=0
 while i<len(lines) and lines[i].startswith('@@ '):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);i+=1
  if not match:raise RuntimeError('Malformed hunk')
  oldStart,oldCount,newStart,newCount=[int(v) if v is not None else 1 for v in match.groups()]
  start=oldStart-1 if oldCount else oldStart
  if start<cursor:raise RuntimeError('Overlapping hunks')
  output+=source[cursor:start];cursor=start;oldSeen=newSeen=0
  while oldSeen<oldCount or newSeen<newCount:
   if i>=len(lines):raise RuntimeError('Truncated hunk')
   line=lines[i];i+=1;prefix=line[0];value=line[1:]
   if prefix in [' ','-']:
    if cursor>=len(source) or source[cursor]!=value:raise RuntimeError('Old source mismatch '+relative)
    cursor+=1;oldSeen+=1
   if prefix in [' ','+']:output.append(value);newSeen+=1
   if prefix not in [' ','-','+']:raise RuntimeError('Invalid hunk line')
  if oldSeen!=oldCount or newSeen!=newCount:raise RuntimeError('Hunk count mismatch')
 output+=source[cursor:]
 if ''.join(output)!=read(candidate/relative):raise RuntimeError('Applied diff does not reproduce delivered source '+relative)
 rows.append(relative)
changed=set();examined=0
for directory in ['components','overlay']:
 for p in (candidate/directory).iterdir():
  if not p.is_file() or p.suffix not in ['.cs','.ps1','.psm1']:continue
  examined+=1;relative=p.relative_to(candidate).as_posix();prior=base/relative
  if not prior.exists() or read(prior)!=read(p):changed.add(relative)
if changed!=seen:raise RuntimeError('Diff coverage mismatch missing='+str(sorted(changed-seen))+' extra='+str(sorted(seen-changed)))
report=dict(scope='complete source-diff independent in-memory application and changed-file coverage',passed=True,examinedSourceFiles=examined,changedSourceFiles=len(changed),appliedFiles=rows,newPortableHelperBodyApplied='components/PortableAclIo.cs' in seen,aggregateCompilerInputApplied='overlay/RestrictedCliFullRestricted.cs' in seen,diffSha256=hashlib.sha256(diff.read_bytes()).hexdigest(),nativeExecuted=False)
result.write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
