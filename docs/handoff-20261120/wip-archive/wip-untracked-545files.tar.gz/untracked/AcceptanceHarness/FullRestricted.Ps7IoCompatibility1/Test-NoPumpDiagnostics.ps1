param([Parameter(Mandatory)][string]$RuntimePath,[Parameter(Mandatory)][string]$ResultPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
foreach($name in @('Utility','Management')){Import-Module (Join-Path $PSHOME ('Modules\Microsoft.PowerShell.'+$name+'\Microsoft.PowerShell.'+$name+'.psd1'))}
if(Test-Path -LiteralPath $ResultPath){throw 'Fresh test result required'}
Add-Type -TypeDefinition @'
namespace Azurite.Restricted {
 public static class ActualAaHandoff {
  public static object State; public static int Mode;
  public static object RunPrepared(object info,string run,string control,string target,string shell,string owner,string logon,long qpc){throw new System.InvalidOperationException("primary-preparation-failure");}
  public static object SavedPump(string run){if(Mode==2)throw new System.InvalidOperationException("saved-pump-failure");return null;}
  public static object Snapshot(){if(Mode==1)throw new System.InvalidOperationException("snapshot-acquisition-failure");return State;}
 }
}
'@
$source=[IO.File]::ReadAllText($RuntimePath);$tokens=$null;$parseErrors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count){throw 'Runtime parse errors'}
$wrapper=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Invoke-AzuriteFullCapabilitiesPreparedRun'},$false))[0]
$assignments=@($wrapper.FindAll({param($n) $n -is [Management.Automation.Language.AssignmentStatementAst]},$true))
$stateCode=@($assignments|Where-Object {$_.Left.Extent.Text -ceq '$state'})[0].Extent.Text
$finalCode=@($assignments|Where-Object {$_.Left.Extent.Text -ceq '$final'})[0].Extent.Text
$start=$source.IndexOf('  $q=Get-AzuriteNoTraceQualification $control.noTraceQualification $Plan.RunId;',[StringComparison]::Ordinal)
$end=$source.IndexOf('  Write-AzuriteFullCapturedText ',$start,[StringComparison]::Ordinal)
if($start -lt 0 -or $end -le $start){throw 'Exact real runtime handoff section missing'}
$handoffCode=$source.Substring($start,$end-$start)
function Get-AzuriteNoTraceQualification {param($Selection,$RunId) [pscustomobject]@{targetImageSha256='target-pin';bootstrapImageSha256='shell-pin'}}
$rows=@();$failures=@()
foreach($mode in @(0,1,2)){
 $Plan=[pscustomobject]@{RunId='pure-no-pump'};$control=[pscustomobject]@{noTraceQualification='pure'};$Gate=[pscustomobject]@{controlSha256='control-pin'};$Facts=[pscustomobject]@{acl=[pscustomobject]@{actualLogonSid='logon'}};$sid='owner';$psi=$null;$noTraceAdmissionQpc=100;$evidence='pure-artifact';$final=$null
 . ([scriptblock]::Create($stateCode));$Execution=$state
 $actualSnapshot=[pscustomobject]@{session=$true;runId='pure-no-pump';managedPhase='preparing-debugger-files';holdHost=($mode -eq 2);stopProven=($mode -ne 2);leaseClosed=$false;workerCreated=$false;workerCompleted=$true;bootstrapStarted=$false;outerPumpReturned=$false;ownerError='primary-preparation-failure'}
 [Azurite.Restricted.ActualAaHandoff]::State=$actualSnapshot;[Azurite.Restricted.ActualAaHandoff]::Mode=$mode
 try{. ([scriptblock]::Create($handoffCode))}catch{$state.PrimaryError=$_.Exception.ToString();$state.OverallPassed=$false}
 . ([scriptblock]::Create($finalCode))
 $serialized=$final|ConvertTo-Json -Depth 12;$observed=$serialized|ConvertFrom-Json
 $problems=@()
 if($observed.result -ne $null){$problems+='NoPump result was fabricated'}
 if($observed.passed -ne $false){$problems+='NoPump was marked passed'}
 if($serialized -match 'NoProcessCreated|noTraceBootstrapEvidence'){ $problems+='Absent process/bootstrap evidence was fabricated' }
 if($observed.primaryError -notlike '*primary-preparation-failure*'){$problems+='Primary handoff failure was masked'}
 $snapshotProperty=$observed.PSObject.Properties['handoffSnapshot'];$errorProperty=$observed.PSObject.Properties['handoffSnapshotError']
 if($mode -eq 1){if($null -eq $errorProperty -or $errorProperty.Value -notlike '*snapshot-acquisition-failure*'){$problems+='Snapshot acquisition failure was discarded'};if($snapshotProperty -and $snapshotProperty.Value -ne $null){$problems+='Unavailable snapshot was fabricated'}}
 else{if($null -eq $snapshotProperty -or ($snapshotProperty.Value|ConvertTo-Json -Compress -Depth 10) -cne ($actualSnapshot|ConvertTo-Json -Compress -Depth 10)){$problems+='Actual phase/ownership snapshot was discarded or changed'}}
 if($mode -eq 2){$pumpProperty=$observed.PSObject.Properties['handoffPumpError'];if($null -eq $pumpProperty -or $pumpProperty.Value -notlike '*saved-pump-failure*'){$problems+='SavedPump failure was discarded'}}
 $rows+=,[pscustomobject]@{mode=$mode;passed=($problems.Count -eq 0);problems=$problems;actualFinal=$observed}
 $failures+=@($problems)
}
$report=[ordered]@{scope='actual runtime AST state, handoff/NoPump branch, and final-construction expressions with fake managed handoff only';passed=($failures.Count -eq 0);tests=$rows;runtimePath=$RuntimePath;powerShell=$PSVersionTable.PSVersion.ToString();nativeExecuted=$false;wholeRuntimeInvoked=$false;filesystemAclBehaviorProven=$false}
[IO.File]::WriteAllText($ResultPath,($report|ConvertTo-Json -Depth 15),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{passed=$report.passed;cases=$rows.Count;failures=$failures;result=$ResultPath}|ConvertTo-Json -Depth 4
if(-not $report.passed){exit 1}
