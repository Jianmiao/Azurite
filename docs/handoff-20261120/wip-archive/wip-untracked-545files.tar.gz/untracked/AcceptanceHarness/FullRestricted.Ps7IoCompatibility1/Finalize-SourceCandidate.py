"""Freeze verified SOURCE/BUILD evidence, not runtime authorization."""
import hashlib,json,pathlib,shutil,sys
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'artifacts/aa-actual-no-trace-qualification-20261114/candidate10'
OUT=ROOT/'artifacts/aa-handoff-ps7-io-compatibility-20261114'/sys.argv[1]
ACTION=sys.argv[2]
if ACTION not in ['prepare','freeze']:raise RuntimeError('Explicit prepare or freeze required')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p,v):
 if p.exists():raise RuntimeError('Fresh evidence file required '+str(p))
 p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
if (OUT/'source-checkpoint.json').exists():raise RuntimeError('Frozen checkpoint already exists')
if ACTION=='freeze':
 diffCheck=json.loads((OUT/'tests/complete-source-diff.json').read_text(encoding='utf-8-sig'))
 if not diffCheck['passed'] or not diffCheck['newPortableHelperBodyApplied'] or not diffCheck['aggregateCompilerInputApplied'] or diffCheck['diffSha256']!=sha(OUT/'candidate10-to-candidate.diff'):raise RuntimeError('Complete source diff is not verified')
 for host in ['ps7','ps51']:
  result=json.loads((OUT/'tests'/(host+'-binding-complete.json')).read_text(encoding='utf-8-sig'));process=json.loads((OUT/'tests'/(host+'-binding-complete-process.json')).read_text(encoding='utf-8-sig'))
  if not result['passed'] or not result['inventoryCompared'] or result['roleCount']!=28 or process['exitCode']!=0 or process['stderr'] or process['timedOut']:raise RuntimeError('Actual role/binding tests incomplete')
  parsed=json.loads((OUT/'tests'/(host+'-root-runner-parse.json')).read_text(encoding='utf-8-sig'))
  if not parsed['passed'] or parsed['runnerInvoked'] or parsed['runnerSha256']!=sha(HERE/'Invoke-RootCOnlyAclFixture.ps1'):raise RuntimeError('Root runner source parse evidence differs')
 shutil.copytree(HERE,OUT/'source')
 roles=json.loads((OUT/'sequence-source-manifest.unbound.json').read_text(encoding='utf-8-sig'))
 files=[dict(path=p.relative_to(OUT).as_posix(),sha256=sha(p),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file()]
 js(OUT/'source-checkpoint.json',dict(scope='ps7-io-source-build-review-checkpoint-unbound',nativeQualification=False,rootRunIdAssigned=False,rootIoFixtureExecuted=False,files=files,externalReferences=[r for r in roles['files'] if not pathlib.Path(r['path']).is_relative_to(OUT)]))
 print(json.dumps(dict(candidate=str(OUT),files=len(files),manifestSha256=sha(OUT/'source-checkpoint.json'),dllSha256=sha(OUT/'overlay/RestrictedCliNative.dll'),runtimeAllowed=False)))
 sys.exit(0)
compile=json.loads((OUT/'native-compile-process.json').read_text(encoding='utf-8-sig'))
if compile['exitCode']!=0 or compile['timedOut'] or compile['stderr'] or compile['terminatedOwnedPureChild']:raise RuntimeError('Compiler did not finish cleanly')
checks=[]
reuse=None
if (OUT/'reused-evidence.json').exists():
 reuse=json.loads((OUT/'reused-evidence.json').read_text(encoding='utf-8-sig'))
 if not reuse['validationPassed'] or reuse['destinationCandidate']!=str(OUT) or reuse['destinationDllSha256']!=sha(OUT/'overlay/RestrictedCliNative.dll') or len(reuse['unchangedComponents'])!=16 or len(reuse['noPumpActualAstExpressions'])!=3 or len(reuse['reusedTests'])!=4:raise RuntimeError('Unchanged diagnostic reuse binding incomplete')
 for row in reuse['reusedTests']:
  for kind in ['result','process']:
   if sha(pathlib.Path(row[kind+'Path']))!=row[kind+'Sha256']:raise RuntimeError('Original diagnostic evidence changed')
for host in ['ps7','ps51']:
 for test in (['prepare','adapter'] if reuse else ['prepare','adapter','nopump','snapshot']):
  name=host+'-'+test;p=OUT/'tests'/(name+'.json');r=json.loads(p.read_text(encoding='utf-8-sig'));process=json.loads((OUT/'tests'/(name+'-process.json')).read_text(encoding='utf-8-sig'))
  if not r.get('allPrepared',r.get('passed',False)) or process['exitCode']!=0 or process['stderr'] or process['timedOut']:raise RuntimeError('Green evidence incomplete '+name)
  checks.append(dict(name=name,resultSha256=sha(p),caseCount=len(r.get('tests',r.get('rows',[]))),naturalExit=process['exitCode']))
# Copy original stage-helper bytes, preserving its independent metadata identity.
shutil.copytree(BASE/'helper-build',OUT/'helper-build')
tooling=json.loads((BASE/'overlay/tooling-manifest.json').read_text(encoding='utf-8-sig'))
for row in tooling['files']:
 p=OUT/'overlay'/row['name']
 if not p.exists():raise RuntimeError('Missing actual tooling '+row['name'])
 row['sha256']=sha(p)
nativeSources=[dict(name=name,sha256=sha(OUT/'overlay'/name)) for name in ['RestrictedCliNative.cs','RestrictedCliFullRestricted.cs']]
reference=pathlib.Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll')
compilerBuild=dict(scope='SOURCE-only-ps7-io-compatibility-build',dllSha256=sha(OUT/'overlay/RestrictedCliNative.dll'),sourceArchiveSha256=sha(OUT/'compiler-inputs.zip'),actualCompilerInputs=nativeSources,compositionSha256=sha(OUT/'composition.json'),compilerSha256=sha(pathlib.Path(compile['file'])),referenceSha256=sha(reference),exitCode=0,aaExecuted=False,cdbExecuted=False,nativeFixtureExecuted=False,stageWrites=False)
js(OUT/'compiler-build.json',compilerBuild)
tooling['build']=dict(target='library',platform='x64',exitCode=0,compilerSha256=compilerBuild['compilerSha256'],assemblySha256=compilerBuild['dllSha256'],sources=nativeSources,references=[dict(name=reference.name,sha256=sha(reference))],canonicalBuildResultPath=(OUT/'compiler-build.json').relative_to(ROOT).as_posix(),canonicalBuildResultSha256=sha(OUT/'compiler-build.json'),sourceArchiveSha256=sha(OUT/'compiler-inputs.zip'))
js(OUT/'overlay/tooling-manifest.json',tooling)
roles=json.loads((BASE/'sequence-source-manifest.json').read_text(encoding='utf-8-sig'))
for row in roles['files']:
 original=pathlib.Path(row['path'])
 if not original.is_file() or sha(original)!=row['sha256'] or original.stat().st_size!=row['bytes']:raise RuntimeError('Base external role drift '+row['role'])
 try:relative=original.relative_to(BASE)
 except ValueError:replacement=original
 else:replacement=OUT/relative
 row['path']=str(replacement);row['bytes']=replacement.stat().st_size;row['sha256']=sha(replacement)
roles['scope']='unbound-source-sequence-role-inventory';roles['rootRunIdAssigned']=False;roles['runtimeAllowed']=False
js(OUT/'sequence-source-manifest.unbound.json',roles)
inputs=[OUT/'overlay/RestrictedCliNative.cs',OUT/'overlay/RestrictedCliFullRestricted.cs']
js(OUT/'source-build-result.json',dict(scope='unbound-source-build-result',sourceOnly=True,rootRunIdAssigned=False,nativeQualification=False,compilerNaturalExit=0,compiler=compile['file'],compilerSha256=sha(pathlib.Path(compile['file'])),actualCompilerInputs=[dict(name=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in inputs],assemblySha256=sha(OUT/'overlay/RestrictedCliNative.dll'),toolingManifestSha256=sha(OUT/'overlay/tooling-manifest.json'),sequenceSourceInventorySha256=sha(OUT/'sequence-source-manifest.unbound.json'),sequenceRoles=len(roles['files']),executedTests=checks,reusedDiagnostics=(dict(path='reused-evidence.json',sha256=sha(OUT/'reused-evidence.json'),tests=reuse['reusedTests']) if reuse else None),rootIoFixtureExecuted=False,filesystemAclBehaviorProven=False,FReadPerformed=False,FWritePerformed=False))
print(json.dumps(dict(candidate=str(OUT),stage='bindings prepared, awaiting actual source-role tests before freeze',dllSha256=sha(OUT/'overlay/RestrictedCliNative.dll'),runtimeAllowed=False)))
