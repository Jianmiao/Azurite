param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ExpectedSourceManifestSha256,[string]$IntentValidUntilUtc)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$candidate=[IO.Path]::GetFullPath($CandidateDirectory)
if([IO.Path]::GetDirectoryName($candidate) -cne (Join-Path $repo 'artifacts\aa-actual-no-trace-qualification-20261114')){throw 'Fixed C qualification candidate directory required'}
function Hash([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function ReadPin([string]$p,[string]$h){if((Hash $p) -cne $h){throw ('C input bytes drift: '+$p)};return ([IO.File]::ReadAllText($p,[Text.Encoding]::UTF8)|ConvertFrom-Json -DateKind String)}
$run='0e494be63f3248ffb7bd7bbd040987f8'
$capture=Join-Path $repo 'artifacts\aa-fr-stage-baseline\capture-0e494be63f3248ffb7bd7bbd040987f8-2c588b09402a49bdab1e0171bed38576\capture-result.json'
$captureSha='72c990c549a4debd500478a6f4302ad332d145e29294b326737f8e023670e97d'
$identity=Join-Path (Split-Path $capture -Parent) 'identity-baseline.json';$identitySha='048a187c696bdb8ce3c9e2ecc6915d5b848760645450f77f0707b5d225e0559d'
$harmless=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\cleanup9974-root-supervision\harmless-cleanup-v2.json';$harmlessSha='3609ced64ba027750871940236411869392f2ff0255bba74508df78df0272d28'
$sources=Join-Path $candidate 'sequence-source-manifest.json';$null=ReadPin $sources $ExpectedSourceManifestSha256
$b=ReadPin $capture $captureSha;$bi=ReadPin $identity $identitySha;$h=ReadPin $harmless $harmlessSha
if($b.runId -cne $run -or $b.success -ne $true -or $b.observedObjects -ne 1228 -or $b.lease.state -cne 'released' -or $b.baselineSha256 -cne $identitySha -or $bi.runId -cne $run -or @($bi.objects).Count -ne 1228){throw 'Root actual completed baseline differs'}
if(-not $IntentValidUntilUtc){$IntentValidUntilUtc=[datetime]::UtcNow.AddMinutes(9).ToString('yyyy-MM-ddTHH:mm:ssZ')}
if($IntentValidUntilUtc -cnotmatch '\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\z' -or [datetimeoffset]::Parse($IntentValidUntilUtc) -le [datetimeoffset]::UtcNow){throw 'Fresh explicit future intent expiry required'}
$inputRecord=[ordered]@{schema=1;scope='root-authorized-one-capabilities-sequence';runId=$run;baselineCapture=[ordered]@{path=$capture;sha256=$captureSha};harmless=[ordered]@{path=$harmless;sha256=$harmlessSha};intentValidUntilUtc=$IntentValidUntilUtc;runtimeTimeoutSeconds=30;sourcesSha256=$ExpectedSourceManifestSha256;noTraceQualification='actual-aa-debugger-no-trace-qualification.v1'}
$folder=Join-Path $candidate 'root-intents';[void][IO.Directory]::CreateDirectory($folder);$path=Join-Path $folder ([guid]::NewGuid().ToString('N')+'.json')
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($inputRecord|ConvertTo-Json -Depth 6));$stream=[IO.File]::Open($path,'CreateNew','Write','Read');try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
[pscustomobject]@{RunId=$run;EntryPath=(Join-Path $candidate 'overlay\Invoke-AzuriteCapabilitiesSequence.ps1');InputRecordPath=$path;ExpectedInputRecordSha256=Hash $path;ReviewedSourcesPath=$sources;ExpectedReviewedSourcesSha256=$ExpectedSourceManifestSha256;ExpectedReviewedBaselineSha256=$identitySha;freshCapturePerformed=$false;stageRead=$false;stageWrite=$false;aaExecuted=$false;executeAddsOneActualNativeAttempt=$true}|ConvertTo-Json -Depth 4
