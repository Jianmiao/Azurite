function Assert-AzuriteNoTraceRemainingBudget([int]$Remaining,[int]$FixedMilliseconds) {
 if($FixedMilliseconds -notin @(10000,30000) -or $Remaining -lt $FixedMilliseconds -or $Remaining -gt 300000){throw 'Original remaining budget cannot fund the fixed qualification entry'}
}
function Copy-AzuriteNoTraceBootstrap([string]$Run,[string]$EvidenceDirectory) {
 $source=Join-Path $Run 'output\bootstrap-result.json';$obj=[Azurite.Stage.FileSecurity]::Read($source,$true)
 if($obj.bytes -gt 1048576 -or $obj.directory -or $obj.reparse -or $obj.links -ne 1){throw 'Actual bootstrap source is not a bounded regular file'}
 $bytes=[Convert]::FromBase64String($obj.content);$path=Join-Path $EvidenceDirectory 'bootstrap-result.json'
 $stream=[IO.File]::Open($path,'CreateNew','Write','Read');try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
 if((Get-AzuriteSha256 $path).ToLowerInvariant() -cne $obj.sha256){throw 'C bootstrap copy readback differs'}
 return [pscustomobject]@{path=$path;sha256=$obj.sha256;bytes=$obj.bytes;source=$source;sourceIdentity=$obj.identity;copiedAfterHandoffReturn=$true}
}
function Read-AzuriteNoTraceLiveRecords($Plan,$Control,$Facts,$Prepared,$Bootstrap) {
 $q=Get-AzuriteNoTraceQualification $Control.noTraceQualification $Plan.RunId
 $base=Get-AzuriteFullExpectedInventory $Plan $Control BeforeNative
 $categories=Get-AzuriteNoTraceRuntimeCategories;$run=[IO.Path]::GetDirectoryName($q.controlDirectory)
 $extras=@{};$records=@{};$identities=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
 foreach($directory in $base.Keys){
  $actual=@([IO.Directory]::EnumerateFileSystemEntries($directory))
  if($actual.Count -gt 2048){throw 'No-trace directory inventory exceeded fixed bound'}
  foreach($expected in $base[$directory]){if($actual -cnotcontains (Join-Path $directory $expected)){throw 'Prepared object disappeared during qualification'}}
  foreach($path in $actual){
   if($base[$directory].Contains([IO.Path]::GetFileName($path))){continue}
   if(-not $path.StartsWith($run+'\',[StringComparison]::Ordinal) -or -not $categories.ContainsKey($path.Substring($run.Length+1))){throw 'Unknown post-native object outside declared no-trace inventory'}
   $capture=[IO.Path]::GetDirectoryName($path) -ceq $q.controlDirectory
   $obj=[Azurite.Stage.FileSecurity]::Read($path,$capture)
   if($obj.directory -or $obj.reparse -or $obj.links -ne 1 -or $obj.owner -cne $Control.controllerSid -or $obj.volume -cne $Facts.volumeGuid -or -not $identities.Add($obj.identity)){throw 'Runtime extra identity/type/owner/volume differs'}
   $extras[$path]=$obj
   if($capture){$records[[IO.Path]::GetFileName($path)]=[Convert]::FromBase64String($obj.content)}
  }
 }
 $null=Assert-AzuriteNoTraceObjectGraph $q $Prepared $extras $Control.controllerSid $Facts.acl.actualLogonSid
 $null=Assert-AzuriteNoTraceRecords $records $q $Bootstrap
 return [pscustomobject]@{runId=$Plan.RunId;scope='actual-no-trace-finite-runtime-records';controlDirectoryPreparedIdentity=$Prepared[$q.controlDirectory].identity;controlFiles=@($extras.Values|Where-Object {[IO.Path]::GetDirectoryName($_.path) -ceq $q.controlDirectory});unknownNamesRejected=$true;recordsValidated=$true;applicationAccepted=$false}
}
