param([Parameter(Mandatory)][string]$Candidate)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$directory=Join-Path $repo ('artifacts\aa-actual-no-trace-qualification-20261114\'+$Candidate)
if($Candidate -cnotmatch '\Acandidate[1-9][0-9]*\z' -or -not [IO.Directory]::Exists($directory)){throw 'Exact generated C candidate required'}
$overlay=Join-Path $directory 'overlay';$compiler='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe';$reference='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll'
function Hash([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Save([string]$p,$value){$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 40));$f=[IO.File]::Open($p,'CreateNew','Write','Read');try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}}
if((Hash $compiler) -cne 'eca02e6b15cde93009a59a3d129d5a77fb5008f2e1cf62cf573b6737c747ecc3'){throw 'Reviewed compiler drift'}
Import-Module (Join-Path $repo 'AcceptanceHarness\FullRestricted.CdbOwnedWaitFixture\SourceProcess.psm1') -Force
$errors=@();foreach($file in Get-ChildItem $overlay -File|Where-Object Extension -In @('.ps1','.psm1')){$t=$null;$e=$null;$null=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$t,[ref]$e);foreach($failure in $e){$errors+=($file.Name+': '+$failure.Message)}}
if($errors.Count){throw ($errors -join "`n")}
$dll=Join-Path $overlay 'RestrictedCliNative.dll'
$compile=Invoke-FixtureSourceProcess -File $compiler -Arguments @('/nologo','/target:library','/platform:x64','/optimize+','/warnaserror+',('/out:'+$dll),('/r:'+$reference),(Join-Path $overlay 'RestrictedCliNative.cs'),(Join-Path $overlay 'RestrictedCliFullRestricted.cs')) -Record (Join-Path $directory 'native-compile-process.json') -Directory $repo
if($compile.exitCode -ne 0){throw $compile.stdout}
Import-Module (Join-Path $overlay 'FullRestrictedStageTransition.psm1') -Force -DisableNameChecking
$helper=New-AzuriteStageTransitionHelper -OutputDirectory (Join-Path $directory 'helper-build')
if($helper.exitCode -ne 0 -or $helper.nativeOperationsExecuted -ne $false){throw 'Metadata helper SOURCE build failed'}
# A real archive of exactly the actual compiler inputs plus the composition proof.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive=Join-Path $directory 'compiler-inputs.zip';$zip=[IO.Compression.ZipFile]::Open($archive,'Create')
try{foreach($p in @((Join-Path $overlay 'RestrictedCliNative.cs'),(Join-Path $overlay 'RestrictedCliFullRestricted.cs'),(Join-Path $directory 'composition.json'))){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$p,[IO.Path]::GetFileName($p))}}finally{$zip.Dispose()}
$resultRelative='.superpowers/sdd/azurite-authoring-20261108/actual-no-trace-'+$Candidate+'/result.json';$resultPath=Join-Path $repo $resultRelative
if(Test-Path (Split-Path $resultPath -Parent)){throw 'Fresh canonical result directory required'}
[void][IO.Directory]::CreateDirectory((Split-Path $resultPath -Parent))
$nativeSources=@(foreach($name in @('RestrictedCliNative.cs','RestrictedCliFullRestricted.cs')){[pscustomobject]@{name=$name;sha256=Hash (Join-Path $overlay $name)}})
Save $resultPath ([ordered]@{scope='SOURCE-only-actual-AA-no-trace-qualification-build';dllSha256=Hash $dll;sourceArchiveSha256=Hash $archive;actualCompilerInputs=$nativeSources;compositionSha256=Hash (Join-Path $directory 'composition.json');compilerSha256=Hash $compiler;referenceSha256=Hash $reference;exitCode=$compile.exitCode;aaExecuted=$false;cdbExecuted=$false;nativeFixtureExecuted=$false;stageWrites=$false})
$runtime=Import-Module (Join-Path $overlay 'FullRestrictedCapabilitiesRuntime.psm1') -Force -PassThru -DisableNameChecking
$names=& $runtime {Get-AzuriteFullToolNames}
$tooling=[ordered]@{schema=1;scope='full-restricted-precompiled-tooling';files=@(foreach($name in $names){[pscustomobject]@{name=$name;sha256=Hash (Join-Path $overlay $name)}});build=[ordered]@{target='library';platform='x64';exitCode=0;compilerSha256=Hash $compiler;assemblySha256=Hash $dll;sources=$nativeSources;references=@([pscustomobject]@{name='System.Web.Extensions.dll';sha256=Hash $reference});canonicalBuildResultPath=$resultRelative;canonicalBuildResultSha256=Hash $resultPath;sourceArchiveSha256=Hash $archive}}
Save (Join-Path $overlay 'tooling-manifest.json') $tooling
$seq=Import-Module (Join-Path $overlay 'AzuriteCapabilitiesSequence.psm1') -Force -PassThru -DisableNameChecking
$fixed=& $seq {Get-SequenceFixedRoles};if($fixed.Count -ne 28){throw 'Expected original 28 source roles'}
$rows=@(foreach($role in $fixed.Keys){$p=$fixed[$role];[pscustomobject]@{role=$role;path=$p;bytes=(Get-Item $p).Length;sha256=Hash $p}})
& $seq {param($r)Assert-SequenceSourcePins ([pscustomobject]@{SourceRows=$r})} $rows
Save (Join-Path $directory 'sequence-source-manifest.json') ([ordered]@{schema=1;scope='root-reviewed-fixed-capabilities-sequence-sources';files=$rows})
$build=[ordered]@{sourceOnly=$true;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false;cdbExecuted=$false;nativeExecuted=$false;compilerNaturalExit=$compile.exitCode;compilerInputs=$nativeSources;assemblySha256=Hash $dll;helperSha256=$helper.assemblySha256;helperModuleSha256=$helper.moduleSha256;toolingManifestSha256=Hash (Join-Path $overlay 'tooling-manifest.json');sequenceSourceManifestSha256=Hash (Join-Path $directory 'sequence-source-manifest.json');sourceRoles=28;canonicalBuildResultPath=$resultPath;canonicalBuildResultSha256=Hash $resultPath;runtimeQualificationPending=$true}
Save (Join-Path $directory 'source-build-result.json') $build
$build|ConvertTo-Json -Depth 6
