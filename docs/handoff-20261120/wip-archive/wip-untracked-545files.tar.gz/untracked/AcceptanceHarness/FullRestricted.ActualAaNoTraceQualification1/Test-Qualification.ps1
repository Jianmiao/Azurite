param([string]$OverlayDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
if(-not $OverlayDirectory){$OverlayDirectory=Join-Path $PSScriptRoot 'overlay'}
$path=Join-Path $OverlayDirectory 'Qualification.Policy.ps1'
if(-not [IO.File]::Exists($path)){throw 'RED: qualification policy is not implemented'}
. $path
$passed=0;$failed=0
function Check([string]$Name,[scriptblock]$Action){try{& $Action;$script:passed++;Write-Output ('PASS '+$Name)}catch{$script:failed++;Write-Output ('FAIL '+$Name+': '+$_.Exception.Message)}}
function Require($Value,[string]$Why){if(-not $Value){throw $Why}}
function Refuses([scriptblock]$Action){$rejected=$false;try{& $Action}catch{$rejected=$true};Require $rejected 'expected refusal'}
$run='0e494be63f3248ffb7bd7bbd040987f8'
Check 'explicit fixed no-trace selection' {$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run;Require ($q.id -ceq 'actual-aa-debugger-no-trace-qualification.v1' -and $q.applicationAccepted -eq $false -and $q.nativeQualificationPreviouslyProven -eq $false) 'selection claimed application/native acceptance'}
Check 'unknown selection refuses' {Refuses {Get-AzuriteNoTraceQualification 'startup-exceptions.v1' $run}}
Check 'wrong run refuses' {Refuses {Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' ('1'*32)}}
Check 'null selection remains ordinary' {Require ($null -eq (Get-AzuriteNoTraceQualification $null $run)) 'unselected branch changed'}
Check 'control records are exactly five names' {$a=@(Get-AzuriteNoTraceControlNames);Require (($a -join ',') -ceq 'lease-offer.json,lease-ack.json,original-resume.record,debug-stop.request,debug-stop.ack') 'control names changed'}
Check 'unknown activity is never no-create' {$p=[pscustomobject]@{NoProcessCreated=$false;Pid=0};$e=[pscustomobject]@{};Require ((Get-AzuriteNoTraceCreationStatus $p $e) -ceq 'unknown') 'unknown activity relabeled'}
Check 'created suspended remains distinct' {$p=[pscustomobject]@{NoProcessCreated=$false;Pid=42};$e=[pscustomobject]@{created=$true;createError=0;resumeCalls=0;resumeVerified=$false};Require ((Get-AzuriteNoTraceCreationStatus $p $e) -ceq 'created-suspended') 'suspended creation relabeled'}
Check 'created resumed requires actual resume proof' {$p=[pscustomobject]@{NoProcessCreated=$false;Pid=42};$e=[pscustomobject]@{created=$true;createError=0;resumeCalls=1;resumeVerified=$true};Require ((Get-AzuriteNoTraceCreationStatus $p $e) -ceq 'created-resumed') 'actual resume not retained'}
Check 'failed resume is unknown activity' {$p=[pscustomobject]@{NoProcessCreated=$false;Pid=42};$e=[pscustomobject]@{created=$true;createError=0;resumeCalls=1;resumeVerified=$false};Require ((Get-AzuriteNoTraceCreationStatus $p $e) -ceq 'created-activity-unknown') 'failed resume was relabeled suspended'}
Check 'not created requires affirmative native evidence' {$p=[pscustomobject]@{NoProcessCreated=$true;Pid=0};$e=[pscustomobject]@{created=$false;resumeCalls=0;resumeVerified=$false};Require ((Get-AzuriteNoTraceCreationStatus $p $e) -ceq 'not-created') 'no-create proof not recognized'}
Check 'contradictory no-create refuses classification' {$p=[pscustomobject]@{NoProcessCreated=$true;Pid=42};$e=[pscustomobject]@{created=$true;resumeCalls=0;resumeVerified=$false};Require ((Get-AzuriteNoTraceCreationStatus $p $e) -ceq 'unknown') 'contradiction accepted'}
Check 'control plan binding cannot select trace' {$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run;$p=[pscustomobject]@{RunId=$run;NoTraceQualification=$q;StartupDiagnostic='x'};$c=[pscustomobject]@{runId=$run;noTraceQualification=$q.id};Refuses {Assert-AzuriteNoTraceBinding $p $c}}
Check 'unselected plan cannot accept selected control' {$p=[pscustomobject]@{RunId=$run};$c=[pscustomobject]@{runId=$run;noTraceQualification='actual-aa-debugger-no-trace-qualification.v1'};Refuses {Assert-AzuriteNoTraceBinding $p $c}}
Check 'selected plan cannot lose control selection' {$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run;$p=[pscustomobject]@{RunId=$run;NoTraceQualification=$q};$c=[pscustomobject]@{runId=$run};Refuses {Assert-AzuriteNoTraceBinding $p $c}}
Check 'matching selection is accepted' {$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run;Assert-AzuriteNoTraceBinding ([pscustomobject]@{RunId=$run;NoTraceQualification=$q}) ([pscustomobject]@{runId=$run;noTraceQualification=$q.id})}
$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$receiptPath=Join-Path $repo 'artifacts\aa-fr-native-lifecycle-fixture\cleanup9974-root-supervision\harmless-cleanup-v2.json'
$receiptBytes=[IO.File]::ReadAllBytes($receiptPath);$sha=[Security.Cryptography.SHA256]::Create();try{$receiptHash=([BitConverter]::ToString($sha.ComputeHash($receiptBytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()};$receipt=[Text.Encoding]::UTF8.GetString($receiptBytes)|ConvertFrom-Json
$t=$null;$e=$null;$inputAst=[Management.Automation.Language.Parser]::ParseFile((Join-Path $OverlayDirectory 'New-AzuriteFullCapabilitiesInputs.ps1'),[ref]$t,[ref]$e)
foreach($name in @('Assert-Inputs','Test-HarmlessReceiptKind','Assert-InputsHarmless')){$f=@($inputAst.EndBlock.Statements|Where-Object {$_ -is [Management.Automation.Language.FunctionDefinitionAst] -and $_.Name -ceq $name});Require ($f.Count -eq 1) 'input consumer function missing';. ([scriptblock]::Create($f[0].Extent.Text))}
$selected=@{'RestrictedCliFullRestricted.cs'=[pscustomobject]@{sha256=$q.nativeSourceSha256};'RestrictedCliNative.cs'=[pscustomobject]@{sha256=$q.sharedNativeSourceSha256}}
$ordinary=@{'RestrictedCliFullRestricted.cs'=[pscustomobject]@{sha256=$q.baselineNativeSourceSha256};'RestrictedCliNative.cs'=[pscustomobject]@{sha256=$q.baselineSharedNativeSourceSha256}}
Check 'actual inherited harmless receipt bytes remain pinned' {Require ($receiptHash -ceq $q.harmlessReceiptSha256) 'actual receipt bytes changed';Assert-InputsHarmless $receipt $selected reviewed-real $q $receiptHash}
Check 'ordinary path still requires same-source receipt' {Assert-InputsHarmless $receipt $ordinary reviewed-real $null $receiptHash;Refuses {Assert-InputsHarmless $receipt $selected reviewed-real $null $receiptHash}}
Check 'qualification refuses a rewritten baseline source hash' {$bad=$receipt|ConvertTo-Json -Depth 20|ConvertFrom-Json;$bad.nativeSourceSha256=$q.nativeSourceSha256;Refuses {Assert-InputsHarmless $bad $selected reviewed-real $q $receiptHash}}
Check 'qualification refuses wrong receipt pin' {Refuses {Assert-InputsHarmless $receipt $selected reviewed-real $q ('a'*64)}}
Check 'qualification refuses arbitrary new source' {$bad=@{'RestrictedCliFullRestricted.cs'=[pscustomobject]@{sha256=('a'*64)};'RestrictedCliNative.cs'=$selected['RestrictedCliNative.cs']};Refuses {Assert-InputsHarmless $receipt $bad reviewed-real $q $receiptHash}}
Check 'qualification refuses simulated harmless record promotion' {$bad=$receipt|ConvertTo-Json -Depth 20|ConvertFrom-Json;$bad|Add-Member testOnlySimulated $true;Refuses {Assert-InputsHarmless $bad $selected reviewed-real $q $receiptHash}}
[pscustomobject]@{scope='SOURCE-only-no-trace-qualification-policy';passed=$passed;failed=$failed;testOnlySimulated=$true;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false;nativeFixtureExecuted=$false}|ConvertTo-Json -Compress
if($failed){exit 1}
