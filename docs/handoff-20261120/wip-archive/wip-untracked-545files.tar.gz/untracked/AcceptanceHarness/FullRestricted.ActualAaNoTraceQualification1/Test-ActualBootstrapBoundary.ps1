param([Parameter(Mandatory)][string]$OverlayDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$path=Join-Path $OverlayDirectory 'FullRestrictedCapabilitiesRuntime.psm1';$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Runtime parse failed'}
$functions=@($ast.EndBlock.Statements|Where-Object {$_ -is [Management.Automation.Language.FunctionDefinitionAst]})
foreach($name in @('Invoke-FixtureHeldBoundary','Assert-AzuriteNoTraceRemainingBudget')){$f=@($functions|Where-Object Name -CEQ $name);if($f.Count -ne 1){throw 'Actual helper not unique'};. ([scriptblock]::Create($f[0].Extent.Text))}
$bootstrap=@($functions|Where-Object Name -CEQ 'Invoke-AzuriteFullRestrictedBootstrap')[0]
$try=@($bootstrap.Body.EndBlock.Statements|Where-Object {$_ -is [Management.Automation.Language.TryStatementAst]});if($try.Count -ne 1){throw 'Actual bootstrap final boundary is not unique'}
$text=$try[0].Finally.Extent.Text
$sleep='[Threading.Thread]::Sleep([Threading.Timeout]::Infinite)'
if(($text.Split([string[]]@($sleep),[StringSplitOptions]::None)).Count -ne 2){throw 'Exactly one reviewed infinite-hold callback expected'}
# Only the infinite wait is replaced in this simulated harness. Actual finally,
# decision, snapshot, sink, default-hold helper, and Terminate call are executed.
$body=$text.Substring(1,$text.Length-2).Replace($sleep,"`$script:HoldCount++;throw 'TEST-HOLD'")
$finalBlock=[scriptblock]::Create($body)
Add-Type -TypeDefinition @'
namespace Azurite.Restricted {
 public static class ActualAaBootstrapHandoff {
  public static bool Need,FailDecision,FailSnapshot;public static int Decisions,Snapshots;
  public static bool MustHoldHost(string run){Decisions++;if(FailDecision)throw new System.InvalidOperationException("TEST-DECISION");return Need;}
  public static object Snapshot(){Snapshots++;if(FailSnapshot)throw new System.InvalidOperationException("TEST-SNAPSHOT");return new { holdHost=Need };}
 }
 public sealed class TestJob {public int Terminations;public void TerminateFull(uint code){Terminations++;}}
}
'@
function Write-AzuriteFlushedJson($path,$value){$script:SinkCount++;if($script:SinkFail){throw 'TEST-SINK'}}
$passed=0;$failed=0
function Require($value,[string]$why){if(-not $value){throw $why}}
function Refuses([scriptblock]$action){$no=$false;try{& $action}catch{$no=$true};Require $no 'expected rejection'}
function Check([string]$name,[scriptblock]$action){try{& $action;$script:passed++;Write-Output ('PASS '+$name)}catch{$script:failed++;Write-Output ('FAIL '+$name+': '+$_.Exception.Message)}}
function Scenario([bool]$Entered,[bool]$Need,[bool]$DecisionFail,[bool]$SnapshotFail,[bool]$SinkFailure){
 [Azurite.Restricted.ActualAaBootstrapHandoff]::Need=$Need;[Azurite.Restricted.ActualAaBootstrapHandoff]::FailDecision=$DecisionFail;[Azurite.Restricted.ActualAaBootstrapHandoff]::FailSnapshot=$SnapshotFail;[Azurite.Restricted.ActualAaBootstrapHandoff]::Decisions=0;[Azurite.Restricted.ActualAaBootstrapHandoff]::Snapshots=0
 $script:HoldCount=0;$script:SinkCount=0;$script:SinkFail=$SinkFailure
 $job=[Azurite.Restricted.TestJob]::new();$r=[ordered]@{noTraceNativeEntryReached=$Entered;noTraceBootstrapHandoff=$null};$Control=[pscustomobject]@{runId='0e494be63f3248ffb7bd7bbd040987f8'};$output='C:\SIMULATED-NO-FILE-WRITES';$exit=1;$errorText=$null
 try{& $finalBlock}catch{$errorText=$_.Exception.Message}
 return [pscustomobject]@{holds=$script:HoldCount;sinks=$script:SinkCount;terminations=$job.Terminations;decisions=[Azurite.Restricted.ActualAaBootstrapHandoff]::Decisions;snapshots=[Azurite.Restricted.ActualAaBootstrapHandoff]::Snapshots;error=$errorText}
}
Check 'actual finally holds on decision failure' {$x=Scenario $true $false $true $false $false;Require ($x.holds -eq 1 -and $x.terminations -eq 0 -and $x.decisions -eq 1) 'decision uncertainty escaped'}
Check 'actual finally holds despite snapshot failure' {$x=Scenario $true $true $false $true $false;Require ($x.holds -eq 1 -and $x.terminations -eq 0 -and $x.sinks -eq 0) 'snapshot failure escaped owner'}
Check 'actual finally holds despite sink failure' {$x=Scenario $true $true $false $false $true;Require ($x.holds -eq 1 -and $x.terminations -eq 0 -and $x.sinks -eq 1) 'sink failure escaped owner'}
Check 'actual finally survives both decision and snapshot failures' {$x=Scenario $true $false $true $true $false;Require ($x.holds -eq 1 -and $x.terminations -eq 0) 'combined failure escaped owner'}
Check 'proved no-owner decision allows final Job termination' {$x=Scenario $true $false $false $false $false;Require ($x.holds -eq 0 -and $x.terminations -eq 1 -and $x.sinks -eq 1) 'closed owner did not terminate'}
Check 'before-native stage never queries an unconfigured native owner' {$x=Scenario $false $true $true $true $false;Require ($x.holds -eq 0 -and $x.terminations -eq 1 -and $x.decisions -eq 0 -and $x.snapshots -eq 0) 'pre-entry state invented owner'}
Check 'snapshot failure after proven closure cannot invent ownership' {$x=Scenario $true $false $false $true $false;Require ($x.holds -eq 0 -and $x.terminations -eq 1) 'proven close was relabeled unknown'}
Check 'outer short remaining budget refuses fixed 30 seconds' {Refuses {Assert-AzuriteNoTraceRemainingBudget 1000 30000};Refuses {Assert-AzuriteNoTraceRemainingBudget 29999 30000}}
Check 'inner short remaining budget refuses fixed 10 seconds' {Refuses {Assert-AzuriteNoTraceRemainingBudget 1000 10000};Refuses {Assert-AzuriteNoTraceRemainingBudget 9999 10000}}
Check 'full original allowances fund the fixed entries' {Assert-AzuriteNoTraceRemainingBudget 30000 30000;Assert-AzuriteNoTraceRemainingBudget 10000 10000;Assert-AzuriteNoTraceRemainingBudget 20000 10000}
$controller=@($functions|Where-Object Name -CEQ 'Invoke-AzuriteFullCapabilitiesPreparedRunCore')[0].Extent.Text
Check 'actual controller consumes original remaining before RunPrepared' {Require ($controller.IndexOf('Assert-AzuriteNoTraceRemainingBudget $remaining 30000') -lt $controller.IndexOf('::RunPrepared(') -and $controller.Contains('$Facts.acl.actualLogonSid,$noTraceAdmissionQpc)') -and $controller.IndexOf('$noTraceAdmissionQpc=[Diagnostics.Stopwatch]::GetTimestamp()') -lt $controller.IndexOf('Assert-AzuriteNoTraceRemainingBudget $remaining 30000')) 'actual controller call discarded original budget'}
Check 'actual bootstrap consumes original remaining before native entry' {$t=$bootstrap.Extent.Text;Require ($t.IndexOf('Assert-AzuriteNoTraceRemainingBudget $remaining 10000') -lt $t.IndexOf('$r.noTraceNativeEntryReached=$true') -and $t.IndexOf('$r.noTraceNativeEntryReached=$true') -lt $t.IndexOf('::RunNormal(')) 'actual bootstrap call discarded original budget'}
[pscustomobject]@{scope='SOURCE-only-actual-finally-and-budget-consumers';passed=$passed;failed=$failed;testOnlySimulated=$true;nativeApiExecuted=$false;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false;cdbExecuted=$false;actualFinallyExtracted=$true;onlyHoldSleepSubstituted=$true}|ConvertTo-Json -Compress
if($failed){exit 1}
