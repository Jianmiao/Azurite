param([Parameter(Mandatory)][string]$OverlayDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
. (Join-Path $OverlayDirectory 'Qualification.Policy.ps1')
$passed=0;$failed=0
function Check([string]$Name,[scriptblock]$Action){try{& $Action;$script:passed++;Write-Output ('PASS '+$Name)}catch{$script:failed++;Write-Output ('FAIL '+$Name+': '+$_.Exception.Message)}}
function Require($v,[string]$why){if(-not $v){throw $why}}
function Refuses([scriptblock]$Action){$no=$false;try{& $Action}catch{$no=$true};Require $no 'expected refusal'}
function Bytes([string]$text){return ,[Text.Encoding]::ASCII.GetBytes($text)}
function Clone($v){return ($v|ConvertTo-Json -Depth 30 -Compress|ConvertFrom-Json)}
$run='0e494be63f3248ffb7bd7bbd040987f8';$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run
$owner='S-1-5-21-222280291-4039000738-1914192245-1001';$logon='S-1-5-5-100-200'
$assembly=[Reflection.Assembly]::LoadFrom((Join-Path $OverlayDirectory 'RestrictedCliNative.dll'))
$fileType=$assembly.GetType('Azurite.Restricted.LeaseFiles',$true);$method=$fileType.GetMethod('AssertControlDescriptor',[Reflection.BindingFlags]'Static,NonPublic')
$aclType=$assembly.GetType('Azurite.Restricted.LeaseAcl',$true);$factory=$aclType.GetMethod('Directory',[Reflection.BindingFlags]'Static,NonPublic')
$expected=$factory.Invoke($null,@($owner,$logon))
$production='O:'+$owner+'D:P(A;OICI;FA;;;'+$owner+')(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;;FRFX;;;'+$logon+')'
function DescriptorBytes([string]$s){$d=[Security.AccessControl.RawSecurityDescriptor]::new($s);$b=New-Object byte[] $d.BinaryLength;$d.GetBinaryForm($b,0);return ,$b}
function ValidateAcl([string]$s){$invokeArgs=New-Object object[] 2;$invokeArgs[0]=[byte[]](DescriptorBytes $s);$invokeArgs[1]=$expected;try{[void]$method.Invoke($null,$invokeArgs)}catch{if($_.Exception.InnerException){throw $_.Exception.InnerException};throw}}
Check 'qualification directory equals production exact four ACEs' {Require ($expected -ceq $production) 'directory metadata mismatch';ValidateAcl $production}
Check 'old full7 control descriptor is refused' {$old='O:'+$owner+'D:P(A;;RC;;;OW)(A;;FA;;;'+$owner+')(A;;FRFX;;;'+$logon+')(A;;FRFX;;;WD)';Refuses {ValidateAcl $old}}
Check 'extra ACL principal is refused' {Refuses {ValidateAcl ($production+'(A;;FR;;;WD)')}}
Check 'duplicate ACL principal is refused' {Refuses {ValidateAcl ($production+'(A;;FRFX;;;'+$logon+')')}}
Check 'selected logon write mask is refused' {Refuses {ValidateAcl ($production.Replace('FRFX','FA'))}}
Check 'changed inheritance is refused' {Refuses {ValidateAcl ($production.Replace('(A;OICI;FA;;;SY)','(A;;FA;;;SY)'))}}
Check 'unprotected descriptor is refused' {Refuses {ValidateAcl ($production.Replace('D:P','D:'))}}
Check 'metadata helper type is excluded from target controller library' {Require ($null -eq $assembly.GetType('Azurite.Stage.FileSecurity',$false)) 'type collision remains'}
Check 'actual saved Pump accessor has correct type' {Require ($assembly.GetType('Azurite.Restricted.ActualAaHandoff').GetMethod('SavedPump').ReturnType.FullName -ceq 'Azurite.Restricted.PumpResult') 'Pump accessor substitutes schema'}
$bootstrap=[pscustomobject]@{bootstrapPid=40;aaPid=42;noTraceBootstrapHandoff=[pscustomobject]@{targetIdentity=[pscustomobject]@{runId=$run;pid=42;creationFileTime=[long]123456;threadId=43}};restrictedNative=[pscustomobject]@{Evidence=[pscustomobject]@{resumeCalls=1;resumeVerified=$true}}}
$offer=[ordered]@{protocol='lease-offer.v1';runId=$run;bootstrapPid=40;childPid=42;mainTid=43;bootstrapCreated=[long]123450;childCreated=[long]123456;threadCreated=[long]123457;processSource=100;threadSource=101;jobSource=102;desktopSource=103;nativeStart=[long]1000;nativeDeadline=[long]11000;frequency=[long]1000;imageHash=$q.targetImageSha256}
$ack=[ordered]@{protocol='lease-ack.v1';runId=$run;bootstrapPid=40;childPid=42;mainTid=43;creation=[long]123456}
$records=@{'lease-offer.json'=(Bytes ($offer|ConvertTo-Json -Compress));'lease-ack.json'=(Bytes ($ack|ConvertTo-Json -Compress));'original-resume.record'=(Bytes ('AZURITE_ORIGINAL_RESUME_V1 '+$run+" 42 000000000001e240 43 1 2000`n"));'debug-stop.request'=(Bytes ('AZURITE_CDB_STOP_V1 '+$run+" 42 000000000001e240 7000`n"))}
$h=[Security.Cryptography.SHA256]::Create();try{$digest=([BitConverter]::ToString($h.ComputeHash($records['debug-stop.request']))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()};$records['debug-stop.ack']=Bytes ('AZURITE_CDB_STOP_ACK_V1 '+$digest+" CLOSED`n")
Check 'canonical five records bind original bootstrap lifetime' {$null=Assert-AzuriteNoTraceRecords $records $q $bootstrap}
Check 'optional absence stays absent' {$null=Assert-AzuriteNoTraceRecords @{} $q $bootstrap}
Check 'unknown filename refuses' {$bad=$records.Clone();$bad['foreign.json']=Bytes '{}';Refuses {Assert-AzuriteNoTraceRecords $bad $q $bootstrap}}
Check 'orphan ACK refuses' {Refuses {Assert-AzuriteNoTraceRecords @{'lease-ack.json'=$records['lease-ack.json']} $q $bootstrap}}
Check 'different target creation refuses' {$bad=Clone $bootstrap;$bad.noTraceBootstrapHandoff.targetIdentity.creationFileTime++;Refuses {Assert-AzuriteNoTraceRecords $records $q $bad}}
Check 'retained stop does not close' {$bad=$records.Clone();$bad['debug-stop.ack']=Bytes ('AZURITE_CDB_STOP_ACK_V1 '+$digest+" RETAINED`n");Refuses {Assert-AzuriteNoTraceRecords $bad $q $bootstrap}}
Check 'wrong stop digest refuses' {$bad=$records.Clone();$bad['debug-stop.ack']=Bytes ('AZURITE_CDB_STOP_ACK_V1 '+('a'*64)+" CLOSED`n");Refuses {Assert-AzuriteNoTraceRecords $bad $q $bootstrap}}
Check 'noncanonical duplicate offer refuses' {$bad=$records.Clone();$s=[Text.Encoding]::ASCII.GetString($bad['lease-offer.json']);$bad['lease-offer.json']=Bytes ($s.Substring(0,$s.Length-1)+',"childPid":42}');Refuses {Assert-AzuriteNoTraceRecords $bad $q $bootstrap}}
Check 'fixed extra categories cover all five and no trace file' {$c=Get-AzuriteNoTraceRuntimeCategories;foreach($name in Get-AzuriteNoTraceControlNames){Require ($c['control\'+$name] -ceq 'no-trace-handoff-control') 'missing recovery category'};Require (-not $c.ContainsKey('history\post-run\startup-exceptions.nettrace')) 'trace category leaked'}
$planModule=Import-Module (Join-Path $OverlayDirectory 'FullRestrictedCapabilitiesPlan.psm1') -PassThru -Force -DisableNameChecking
$runtimeModule=Import-Module (Join-Path $OverlayDirectory 'FullRestrictedCapabilitiesRuntime.psm1') -PassThru -Force -DisableNameChecking
$control=[pscustomobject]@{runId=$run;noTraceQualification=$q.id}
$plan=[pscustomobject]@{RunId=$run;LabRoot='F:\AzuriteLabs\Editor-20261108-normal';NoTraceQualification=$q;Grants=[pscustomobject]@{files=@();directories=@()};MutableLeaves=@()}
Check 'prepared role contains the native run control directory' {$roles=& $runtimeModule {param($p,$c)Get-AzuriteFullExpectedRoles $p $c} $plan $control;Require (($roles[$q.controlDirectory]-join ',') -ceq 'run-directory,0x1200A9') 'control role differs'}
Check 'BeforeNative control inventory is exactly empty' {$p=Clone $plan;$p.Grants.directories=@([pscustomobject]@{path='F:\AzuriteLabs';mask='0x1200A9'},[pscustomobject]@{path=$p.LabRoot;mask='0x1200A9'});$map=& $runtimeModule {param($p,$c)Get-AzuriteFullExpectedInventory $p $c BeforeNative} $p $control;Require ($map[$q.controlDirectory].Count -eq 0) 'control was precreated'}
Check 'qualification changes intent facts hash' {$a=[pscustomobject]@{runId=$run};$b=[pscustomobject]@{runId=$run;noTraceQualification=$q.id};$x=& $planModule {param($a)Get-IntentFactsHash $a} $a;$y=& $planModule {param($a)Get-IntentFactsHash $a} $b;Require ($x -cne $y) 'selection missing from hash'}
[pscustomobject]@{scope='SOURCE-only-qualification-integration';passed=$passed;failed=$failed;testOnlySimulated=$true;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false;cdbExecuted=$false;nativeFixtureExecuted=$false}|ConvertTo-Json -Compress
if($failed){exit 1}
