param([Parameter(Mandatory)][string]$OverlayDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
. (Join-Path $OverlayDirectory 'Qualification.Policy.ps1')
$passed=0;$failed=0
function Check([string]$Name,[scriptblock]$Action){try{& $Action;$script:passed++;Write-Output ('PASS '+$Name)}catch{$script:failed++;Write-Output ('FAIL '+$Name+': '+$_.Exception.Message)}}
function Require($v,[string]$why){if(-not $v){throw $why}}
function Refuses([scriptblock]$Action){$no=$false;try{& $Action}catch{$no=$true};Require $no 'expected refusal'}
function Clone($v){return ($v|ConvertTo-Json -Depth 35 -Compress|ConvertFrom-Json)}
$run='0e494be63f3248ffb7bd7bbd040987f8';$q=Get-AzuriteNoTraceQualification 'actual-aa-debugger-no-trace-qualification.v1' $run
$plan=[pscustomobject]@{RunId=$run;PlanSha256=('d'*64);NoTraceQualification=$q}
$outer=[pscustomobject]@{RunId=$run;Pid=40;NoProcessCreated=$false;DirectProcessExited=$true;JobDrained=$true;RemainingOwnedProcesses=0;StreamCaptureComplete=$true;DesktopLeaseObserved=$false;DesktopLeaseClosed=$false;DesktopLeaseRetained=$false;FullJobObserverClosed=$true;FullJobObserverRetained=$false;FullJobObserverCloseError=0}
$handoff=[pscustomobject]@{session=$true;runId=$run;holdHost=$false;stopProven=$true;leaseClosed=$true;workerCompleted=$true;retainedOuter=$false;applicationAccepted=$false;originalResumeObserved=$false;attachedContextObserved=$false;attachedContextQpc=0;ackBeforeQpc=0;originalResumeQpc=0}
$debugger=[pscustomobject]@{runId=$run;runDirectory=$q.debuggerEvidenceDirectory;scope='actual-aa-debugger-no-trace-handoff';applicationAccepted=$false;outcome=[pscustomobject]@{CleanupVerified=$true;AllClosed=$true;OwnerRetained=$false};owners=@();files=@();evidenceErrors=@();rawBytesStored=0;createAttempted=$false;createCallReturned=$false;creationSucceeded=$false;directProcessSignaled=$false;jobEmpty=$false;streamsComplete=$false;stdoutEof=$false;stderrEof=$false;targetPid=0}
$final=[pscustomobject]@{runId=$run;passed=$false;runtimeAllowed=$false;pendingCleared=$false;runtimeLeaseReleased=$true;runtimeMutexDisposed=$true;leaseHeld=$false;ownerRetained=$false;releaseError=$null;disposeError=$null;result=[pscustomobject]@{runId=$run;passed=$false;noTraceQualification=$q.id;applicationAccepted=$false;zeroSharedDelta=$true;restorationPerformed=$false;outer=$outer;noTraceHandoff=$handoff;noTraceDebuggerEvidence=[pscustomobject]@{path=($q.debuggerEvidenceDirectory+'\result.json');sha256=('e'*64);result=$debugger}}}
$bootstrap=[pscustomobject]@{runId=$run;bootstrapPid=40;planSha256=$plan.PlanSha256;noTraceQualification=$q.id;applicationAccepted=$false;status='failed';noTraceNativeEntryReached=$false;restrictedNative=$null;aaPid=0;noTraceBootstrapHandoff=[pscustomobject]@{holdHost=$false}}
Check 'closed before-native bootstrap is honestly not-created' {Require ((Assert-AzuriteNoTraceClosed $final $bootstrap $plan) -ceq 'not-created') 'wrong creation status'}
Check 'retained controller is refused' {$f=Clone $final;$f.result.noTraceHandoff.holdHost=$true;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'unjoined worker is refused' {$f=Clone $final;$f.result.noTraceHandoff.workerCompleted=$false;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'unclosed target lease is refused' {$f=Clone $final;$f.result.noTraceHandoff.leaseClosed=$false;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'runtime mutex release uncertainty is refused' {$f=Clone $final;$f.runtimeMutexDisposed=$false;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'outer target Job nonempty is refused' {$f=Clone $final;$f.result.outer.RemainingOwnedProcesses=1;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'shared delta is refused' {$f=Clone $final;$f.result.zeroSharedDelta=$false;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'missing actual debugger result is refused' {$f=Clone $final;$f.result.noTraceDebuggerEvidence=$null;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'unclosed debugger owner is refused' {$f=Clone $final;$f.result.noTraceDebuggerEvidence.result.owners=@([pscustomobject]@{closed=$false;retained=$true;error=0;exception=$null});Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'unknown debugger creation return is refused' {$f=Clone $final;$f.result.noTraceDebuggerEvidence.result.createAttempted=$true;Refuses {Assert-AzuriteNoTraceClosed $f $bootstrap $plan}}
Check 'AA native entry without actual result remains unknown' {$b=Clone $bootstrap;$b.noTraceNativeEntryReached=$true;Refuses {Assert-AzuriteNoTraceClosed $final $b $plan}}
$created=Clone $bootstrap;$created.noTraceNativeEntryReached=$true;$created.aaPid=42;$created.restrictedNative=[pscustomobject]@{Process=[pscustomobject]@{NoProcessCreated=$false;Pid=42;DirectProcessExited=$true};Evidence=[pscustomobject]@{created=$true;createError=0;resumeCalls=0;resumeVerified=$false;actualTokenVerified=$true;exactOwnedJobVerified=$true};NativeHandlesClosed=$true;StreamsComplete=$true}
Check 'closed created-suspended failure is recoverable as suspended' {Require ((Assert-AzuriteNoTraceClosed $final $created $plan) -ceq 'created-suspended') 'suspended status lost'}
Check 'failed Resume remains created activity unknown' {$b=Clone $created;$b.restrictedNative.Evidence.resumeCalls=1;Require ((Assert-AzuriteNoTraceClosed $final $b $plan) -ceq 'created-activity-unknown') 'failed Resume activity relabeled'}
Check 'created child requires native owner closure' {$b=Clone $created;$b.restrictedNative.NativeHandlesClosed=$false;Refuses {Assert-AzuriteNoTraceClosed $final $b $plan}}
Check 'created child requires bootstrap retention guard closure' {$b=Clone $created;$b.noTraceBootstrapHandoff.holdHost=$true;Refuses {Assert-AzuriteNoTraceClosed $final $b $plan}}
Check 'successful Resume cannot bypass attached debugger evidence' {$b=Clone $created;$b.restrictedNative.Evidence.resumeCalls=1;$b.restrictedNative.Evidence.resumeVerified=$true;Refuses {Assert-AzuriteNoTraceClosed $final $b $plan}}
$resumed=Clone $created;$resumed.restrictedNative.Evidence.resumeCalls=1;$resumed.restrictedNative.Evidence.resumeVerified=$true;$resumedFinal=Clone $final;$s=$resumedFinal.result.noTraceHandoff;$s.originalResumeObserved=$true;$s.attachedContextObserved=$true;$s.attachedContextQpc=100;$s.ackBeforeQpc=110;$s.originalResumeQpc=120;$d=$resumedFinal.result.noTraceDebuggerEvidence.result;$d.createAttempted=$true;$d.createCallReturned=$true;$d.creationSucceeded=$true;$d.directProcessSignaled=$true;$d.jobEmpty=$true;$d.streamsComplete=$true;$d.stdoutEof=$true;$d.stderrEof=$true;$d.targetPid=42
Check 'closed created-resumed failure preserves actual sequence' {Require ((Assert-AzuriteNoTraceClosed $resumedFinal $resumed $plan) -ceq 'created-resumed') 'resume status lost'}
Check 'CDB stderr EOF is required after actual creation' {$f=Clone $resumedFinal;$f.result.noTraceDebuggerEvidence.result.stderrEof=$false;Refuses {Assert-AzuriteNoTraceClosed $f $resumed $plan}}
Check 'ACK before attached context is refused' {$f=Clone $resumedFinal;$f.result.noTraceHandoff.ackBeforeQpc=99;Refuses {Assert-AzuriteNoTraceClosed $f $resumed $plan}}
Check 'observed desktop must actually close' {$f=Clone $resumedFinal;$f.result.outer.DesktopLeaseObserved=$true;Refuses {Assert-AzuriteNoTraceClosed $f $resumed $plan}}
$owner='S-1-5-21-222280291-4039000738-1914192245-1001';$logon='S-1-5-5-100-200';$path=$q.controlDirectory+'\lease-offer.json'
$fileSddl='O:'+$owner+'D:P(A;;RC;;;OW)(A;;FA;;;'+$owner+')(A;;FR;;;'+$logon+')(A;;FR;;;WD)'
$prepared=@{};$prepared[$q.controlDirectory]=[pscustomobject]@{directory=$true};$current=@{};$current[$path]=[pscustomobject]@{path=$path;finalPath=$path;owner=$owner;directory=$false;reparse=$false;links=1;bytes=512;sha256=('a'*64);identity=('b'*32);sddl=$fileSddl}
Check 'actual control object has fixed identity hash and ACL' {$null=Assert-AzuriteNoTraceObjectGraph $q $prepared $current $owner $logon}
Check 'unknown run file cannot enter recovery extras' {$bad=$current.Clone();$p=[IO.Path]::GetDirectoryName($q.controlDirectory)+'\arbitrary.bin';$bad[$p]=[pscustomobject]@{directory=$false};Refuses {Assert-AzuriteNoTraceObjectGraph $q $prepared $bad $owner $logon}}
Check 'precreated handoff record is refused' {$bad=$prepared.Clone();$bad[$path]=$current[$path];Refuses {Assert-AzuriteNoTraceObjectGraph $q $bad $current $owner $logon}}
Check 'record ACL write grant is refused' {$bad=Clone $current[$path];$bad.sddl=$fileSddl.Replace('(A;;FR;;;'+$logon+')','(A;;FA;;;'+$logon+')');$map=@{};$map[$path]=$bad;Refuses {Assert-AzuriteNoTraceObjectGraph $q $prepared $map $owner $logon}}
Check 'record oversized payload is refused' {$bad=Clone $current[$path];$bad.bytes=4097;$map=@{};$map[$path]=$bad;Refuses {Assert-AzuriteNoTraceObjectGraph $q $prepared $map $owner $logon}}
[pscustomobject]@{scope='SOURCE-only-qualification-closure';passed=$passed;failed=$failed;testOnlySimulated=$true;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false;cdbExecuted=$false;nativeFixtureExecuted=$false}|ConvertTo-Json -Compress
if($failed){exit 1}
