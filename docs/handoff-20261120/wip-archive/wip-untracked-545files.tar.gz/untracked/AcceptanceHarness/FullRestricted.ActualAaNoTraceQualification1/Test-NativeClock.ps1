param([Parameter(Mandatory)][string]$OverlayDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$assembly=[Reflection.Assembly]::LoadFrom((Join-Path $OverlayDirectory 'RestrictedCliNative.dll'))
$type=$assembly.GetType('Azurite.Restricted.FullRestrictedSpawn',$true);$ctor=@($type.GetConstructors([Reflection.BindingFlags]'NonPublic,Instance'))[0]
$clockField=$type.GetField('clock',[Reflection.BindingFlags]'NonPublic,Instance');$remainingMethod=$type.GetMethod('Remaining',[Reflection.BindingFlags]'NonPublic,Instance')
$passed=0;$failed=0
function Require($v,[string]$why){if(-not $v){throw $why}}
function Refuses([scriptblock]$action){$no=$false;try{& $action}catch{$no=$true};Require $no 'expected refusal'}
function Check([string]$name,[scriptblock]$action){try{& $action;$script:passed++;Write-Output ('PASS '+$name)}catch{$script:failed++;Write-Output ('FAIL '+$name+': '+$_.Exception.Message)}}
function Construct([int]$milliseconds,$borrowed){
 $arguments=New-Object object[] 13;$arguments[0]=[Diagnostics.ProcessStartInfo]::new();$arguments[1]=$milliseconds;$arguments[2]=$null;$arguments[3]='0e494be63f3248ffb7bd7bbd040987f8';$arguments[4]='C:\SIMULATED-NOT-ACCESSED';$arguments[5]='a'*64;$arguments[6]=262144;$arguments[7]=[string[]]@();$arguments[8]=[long]4194304;$arguments[9]=$null;$arguments[10]=$null;$arguments[11]=$null;$arguments[12]=$borrowed
 return $ctor.Invoke($arguments)
}
Check 'borrowed actual clock retains delay before native constructor' {$watch=[Diagnostics.Stopwatch]::StartNew();[Threading.Thread]::Sleep(60);$instance=Construct 1000 $watch;Require ([object]::ReferenceEquals($clockField.GetValue($instance),$watch)) 'constructor restarted clock';$remaining=[int]$remainingMethod.Invoke($instance,@());Require ($remaining -gt 0 -and $remaining -le 940) 'pre-constructor delay was replenished'}
Check 'expired original clock refuses before native constructor work' {$watch=[Diagnostics.Stopwatch]::StartNew();[Threading.Thread]::Sleep(30);Refuses {Construct 20 $watch}}
Check 'stopped borrowed clock is refused' {$watch=[Diagnostics.Stopwatch]::new();Refuses {Construct 1000 $watch}}
Check 'ordinary constructor retains original default clock behavior' {$instance=Construct 1000 $null;$clock=$clockField.GetValue($instance);Require ($clock.IsRunning -and [int]$remainingMethod.Invoke($instance,@()) -gt 0) 'default native behavior changed'}
Check 'actual bridge requires Stopwatch and original QPC parameters' {$m=$assembly.GetType('Azurite.Restricted.LifecycleFixture').GetMethod('RunNormal');$p=$m.GetParameters();Require ($p.Count -eq 10 -and $p[8].ParameterType -eq [Diagnostics.Stopwatch] -and $p[9].ParameterType -eq [long]) 'actual bridge lacks original allowance inputs'}
Check 'actual source forwards one clock to lease and native monitor' {$source=[IO.File]::ReadAllText((Join-Path $OverlayDirectory 'RestrictedCliFullRestricted.cs'));Require ($source.Contains('long start=originalStartQpc;var deadline=new LeaseDeadline(start,Stopwatch.Frequency,10000,Stopwatch.GetTimestamp)') -and $source.Contains('4194304,null,null,null,originalClock)')) 'lease/native clock propagation differs'}
Check 'actual PS caller samples before budget and passes that original clock' {$source=[IO.File]::ReadAllText((Join-Path $OverlayDirectory 'FullRestrictedCapabilitiesRuntime.psm1'));Require ($source.Contains('$noTraceNativeStartQpc=[Diagnostics.Stopwatch]::GetTimestamp();$noTraceNativeClock=[Diagnostics.Stopwatch]::StartNew()') -and $source.Contains('$identity.token.logon_sid,$noTraceNativeClock,$noTraceNativeStartQpc)')) 'PS bridged clock renewed'}
[pscustomobject]@{scope='SOURCE-only-original-native-clock-propagation';passed=$passed;failed=$failed;testOnlySimulated=$true;nativeProcessOperationsExecuted=$false;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false;cdbExecuted=$false}|ConvertTo-Json -Compress
if($failed){exit 1}
