# Pure qualification selection and evidence rules. No filesystem/native operations.
function Get-AzuriteNoTraceQualification($Selection,[string]$RunId) {
 if($null -eq $Selection){return $null}
 if($Selection -isnot [string] -or $Selection -cne 'actual-aa-debugger-no-trace-qualification.v1' -or $RunId -cne '0e494be63f3248ffb7bd7bbd040987f8'){throw 'Only the fixed Root-selected actual-AA no-trace qualification is permitted'}
 return [pscustomobject][ordered]@{schema=1;id=$Selection;runId=$RunId;taskBDeliverySha256='317064c89f19910c05c3a39d88b054fd5f930ae8d8b00019b2587b0e0099d057';baselineNativeSourceSha256='cf950c62b9c74448ba43b63e0057f5d017c52111e857b4ab240763854d1ce533';baselineSharedNativeSourceSha256='f503fd643a97d6fe39e8f95af761f3f7ca6a2a38187ba3d8bc112229b0ceb921';baselineCleanupPackageSha256='c5b1526dac603d8881d61eb2d7a5d8f4da72f556d8e12a32880da1fa966927d9';harmlessReceiptSha256='3609ced64ba027750871940236411869392f2ff0255bba74508df78df0272d28';nativeSourceSha256='@FULL_SHA@';sharedNativeSourceSha256='@SHARED_SHA@';compositionSha256='@COMPOSITION_SHA@';targetImageSha256='@TARGET_SHA@';bootstrapImageSha256='@SHELL_SHA@';controlDirectory=('F:\AzuriteLabs\Editor-20261108-normal\runs\restricted-'+$RunId+'\control');controlNames=@('lease-offer.json','lease-ack.json','original-resume.record','debug-stop.request','debug-stop.ack');debuggerEvidenceDirectory='@EVIDENCE@';rawOutputLimitBytes=1048576;runtimeTimeoutSeconds=30;nativeTimeoutSeconds=10;applicationAccepted=$false;nativeQualificationPreviouslyProven=$false}
}
function Get-AzuriteNoTraceControlNames {return @('lease-offer.json','lease-ack.json','original-resume.record','debug-stop.request','debug-stop.ack')}
function Get-AzuriteNoTraceRuntimeCategories {
 $categories=@{'bootstrap.stderr.log'='bootstrap-stream';'bootstrap.stdout.log'='bootstrap-stream';'controller-result.json'='controller-result';'output\aa.stderr.log'='aa-stream';'output\aa.stdout.log'='aa-stream';'output\bootstrap-result.json'='bootstrap-result';'output\identity.json'='native-identity';'shared-state\after.json'='shared-snapshot';'shared-state\delta.json'='shared-comparison';'shared-state\prelaunch-current.json'='shared-snapshot';'shared-state\prelaunch-delta.json'='shared-comparison';'request\response.json'='failed-command-response'}
 foreach($name in Get-AzuriteNoTraceControlNames){$categories['control\'+$name]='no-trace-handoff-control'}
 return $categories
}
function Assert-AzuriteNoTraceObjectGraph($Qualification,$Prepared,$Current,[string]$Owner,[string]$Logon) {
 $dir=$Qualification.controlDirectory;$root=[IO.Path]::GetDirectoryName($dir)
 if(-not $Prepared.ContainsKey($dir) -or -not $Prepared[$dir].directory){throw 'Control directory is not in actual preparation graph'}
 foreach($name in Get-AzuriteNoTraceControlNames){if($Prepared.ContainsKey($dir+'\'+$name)){throw 'Runtime handoff record was precreated'}}
 $categories=Get-AzuriteNoTraceRuntimeCategories
 $sddl='O:'+$Owner+'D:P(A;;RC;;;OW)(A;;FA;;;'+$Owner+')(A;;FR;;;'+$Logon+')(A;;FR;;;WD)'
 $expected=[Security.AccessControl.RawSecurityDescriptor]::new($sddl).GetSddlForm([Security.AccessControl.AccessControlSections]'Owner,Access')
 foreach($path in $Current.Keys){
  if($Prepared.ContainsKey($path)){continue}
  if(-not $path.StartsWith($root+'\',[StringComparison]::Ordinal)){throw 'Runtime extra escaped exact run'}
  $relative=$path.Substring($root.Length+1);$obj=$Current[$path]
  if(-not $categories.ContainsKey($relative) -or $obj.directory){throw 'Unknown runtime extra is not admitted'}
  if($relative.StartsWith('control\',[StringComparison]::Ordinal)){
   if($obj.path -cne $path -or $obj.finalPath -cne $path -or $obj.owner -cne $Owner -or $obj.reparse -or $obj.links -ne 1 -or $obj.bytes -lt 2 -or $obj.bytes -gt 4096 -or $obj.sha256 -cnotmatch '\A[a-f0-9]{64}\z' -or $obj.identity -cnotmatch '\A[a-f0-9]{32}\z'){throw 'Handoff control object identity/bounds differ'}
   $actual=[Security.AccessControl.RawSecurityDescriptor]::new($obj.sddl).GetSddlForm([Security.AccessControl.AccessControlSections]'Owner,Access')
   if($actual -cne $expected){throw 'Handoff control file exact ACL differs'}
  }
 }
 return $true
}
function Assert-AzuriteNoTraceBinding($Plan,$Control) {
 $selected=$null;if($Control.PSObject.Properties['noTraceQualification']){$selected=$Control.noTraceQualification;if($null -eq $selected){throw 'Null no-trace selection is not explicit'}}
 $expected=Get-AzuriteNoTraceQualification $selected $Plan.RunId;$actual=$null;if($Plan.PSObject.Properties['NoTraceQualification']){$actual=$Plan.NoTraceQualification}
 if($expected -and $Control.PSObject.Properties['runtimeTimeoutSeconds'] -and $Control.runtimeTimeoutSeconds -ne $expected.runtimeTimeoutSeconds){throw 'Qualification runtime duration differs from original fixed bound'}
 if($expected -and $Control.PSObject.Properties['runId'] -and $Control.runId -cne $Plan.RunId){throw 'Qualification control run differs'}
 if(($null -ne $actual -or $null -ne $expected) -and ($Plan.PSObject.Properties['StartupDiagnostic'] -or $Control.PSObject.Properties['startupDiagnostic'])){throw 'No-trace and EventPipe diagnostic are mutually exclusive'}
 if(($expected|ConvertTo-Json -Depth 10 -Compress) -cne ($actual|ConvertTo-Json -Depth 10 -Compress)){throw 'Plan/control no-trace qualification binding differs'}
}
function Test-AzuriteNoTraceHarmlessBinding($Receipt,$Qualification,[string]$FullSha,[string]$SharedSha,[string]$ReceiptSha) {
 if($null -eq $Qualification){return $false}
 return ($Receipt.nativeSourceSha256 -ceq $Qualification.baselineNativeSourceSha256 -and $Receipt.sharedNativeSourceSha256 -ceq $Qualification.baselineSharedNativeSourceSha256 -and $Receipt.PSObject.Properties['packageSha256'] -and $Receipt.packageSha256 -ceq $Qualification.baselineCleanupPackageSha256 -and $ReceiptSha -ceq $Qualification.harmlessReceiptSha256 -and $FullSha -ceq $Qualification.nativeSourceSha256 -and $SharedSha -ceq $Qualification.sharedNativeSourceSha256 -and -not $Receipt.PSObject.Properties['testOnlySimulated'])
}
function Get-AzuriteNoTraceCreationStatus($Process,$Evidence) {
 if($null -eq $Process -or $null -eq $Evidence){return 'unknown'}
 $created=$Evidence.PSObject.Properties['created'];$calls=$Evidence.PSObject.Properties['resumeCalls'];$verified=$Evidence.PSObject.Properties['resumeVerified']
 if(-not $calls -or -not $verified){return 'unknown'}
 if($Process.NoProcessCreated -eq $true -and $Process.Pid -eq 0 -and (-not $created -or $created.Value -eq $false) -and $calls.Value -eq 0 -and $verified.Value -eq $false){return 'not-created'}
 if($Process.NoProcessCreated -ne $false -or $Process.Pid -le 0 -or -not $created -or $created.Value -ne $true -or -not $Evidence.PSObject.Properties['createError'] -or $Evidence.createError -ne 0){return 'unknown'}
 if($calls.Value -eq 0 -and $verified.Value -eq $false){return 'created-suspended'}
 if($calls.Value -eq 1 -and $verified.Value -eq $true){return 'created-resumed'}
 return 'created-activity-unknown'
}
function Assert-AzuriteNoTraceClosed($Final,$Bootstrap,$Plan) {
 if(-not $Plan.PSObject.Properties['NoTraceQualification']){throw 'No explicit qualification plan'}
 $q=Get-AzuriteNoTraceQualification $Plan.NoTraceQualification.id $Plan.RunId
 $r=$Final.result;$o=$r.outer;$h=$r.noTraceHandoff
 if($Final.runId -cne $q.runId -or $r.runId -cne $q.runId -or $r.noTraceQualification -cne $q.id -or $r.applicationAccepted -ne $false -or $r.passed -ne $false -or $Final.passed -ne $false -or $Final.runtimeAllowed -ne $false -or $Final.pendingCleared -ne $false -or $Final.runtimeLeaseReleased -ne $true -or $Final.runtimeMutexDisposed -ne $true -or $Final.leaseHeld -ne $false -or $Final.ownerRetained -ne $false -or $Final.releaseError -or $Final.disposeError -or $r.zeroSharedDelta -ne $true -or $r.restorationPerformed -ne $false){throw 'Qualification runtime lease/shared/outcome is not closed'}
 if($null -eq $o -or $o.RunId -cne $q.runId -or $o.Pid -le 0 -or $o.NoProcessCreated -ne $false -or $o.DirectProcessExited -ne $true -or $o.JobDrained -ne $true -or $o.RemainingOwnedProcesses -ne 0 -or $o.StreamCaptureComplete -ne $true -or $o.DesktopLeaseRetained -ne $false -or $o.FullJobObserverRetained -ne $false -or $o.FullJobObserverClosed -ne $true -or $o.FullJobObserverCloseError -ne 0){throw 'Qualification original outer owners are not closed'}
 if($o.DesktopLeaseObserved -eq $true -and $o.DesktopLeaseClosed -ne $true){throw 'Observed desktop lease did not close'}
 if($h.session -ne $true -or $h.runId -cne $q.runId -or $h.holdHost -ne $false -or $h.stopProven -ne $true -or $h.leaseClosed -ne $true -or $h.workerCompleted -ne $true -or $h.retainedOuter -ne $false -or $h.applicationAccepted -ne $false){throw 'Qualification debugger/controller/lease owner closure is incomplete'}
 $de=$r.noTraceDebuggerEvidence;$d=$de.result
 if($de.path -cne ($q.debuggerEvidenceDirectory+'\result.json') -or $de.sha256 -cnotmatch '\A[a-f0-9]{64}\z' -or $d.runId -cne $q.runId -or $d.runDirectory -cne $q.debuggerEvidenceDirectory -or $d.scope -cne 'actual-aa-debugger-no-trace-handoff' -or $d.applicationAccepted -ne $false -or $d.outcome.CleanupVerified -ne $true -or $d.outcome.AllClosed -ne $true -or $d.outcome.OwnerRetained -ne $false -or @($d.owners|Where-Object {$_.closed -ne $true -or $_.retained -ne $false -or $_.error -ne 0 -or $_.exception}).Count -or @($d.files|Where-Object {$_.closed -ne $true -or $_.error}).Count -or @($d.evidenceErrors).Count -or $d.rawBytesStored -gt $q.rawOutputLimitBytes){throw 'Actual debugger evidence does not prove all recorded owners closed'}
 if($d.createAttempted -and (-not $d.createCallReturned)){throw 'Unreturned debugger creation cannot be recovered'}
 if($d.creationSucceeded -and ($d.directProcessSignaled -ne $true -or $d.jobEmpty -ne $true -or $d.streamsComplete -ne $true -or $d.stdoutEof -ne $true -or $d.stderrEof -ne $true)){throw 'Created debugger process/Job/EOF closure incomplete'}
 if($Bootstrap.runId -cne $q.runId -or $Bootstrap.bootstrapPid -ne $o.Pid -or $Bootstrap.planSha256 -cne $Plan.PlanSha256 -or $Bootstrap.noTraceQualification -cne $q.id -or $Bootstrap.applicationAccepted -ne $false -or $Bootstrap.status -cne 'failed'){throw 'Qualification bootstrap correlation differs'}
 if($Bootstrap.noTraceNativeEntryReached -eq $false){if($Bootstrap.restrictedNative -or $Bootstrap.aaPid -ne 0 -or $d.createAttempted -or $d.creationSucceeded -or $h.originalResumeObserved){throw 'Before-native entry proof contradicts native output'};return 'not-created'}
 if($Bootstrap.noTraceNativeEntryReached -ne $true -or -not $Bootstrap.restrictedNative){throw 'Native entry reached with unknown creation state'}
 $n=$Bootstrap.restrictedNative;$status=Get-AzuriteNoTraceCreationStatus $n.Process $n.Evidence
 if($status -notin @('not-created','created-suspended','created-resumed','created-activity-unknown')){throw 'Unknown native activity is not automatic recovery admission'}
 if($n.NativeHandlesClosed -ne $true -or $n.StreamsComplete -ne $true -or $n.Process.DirectProcessExited -ne $true -or $Bootstrap.noTraceBootstrapHandoff.holdHost -ne $false){throw 'Native owner or stream closure incomplete'}
 if($status -clike 'created-*' -and ($Bootstrap.aaPid -ne $n.Process.Pid -or $Bootstrap.aaPid -le 0)){throw 'Created child PID correlation differs'}
 if($status -ceq 'created-resumed' -and ($n.Evidence.actualTokenVerified -ne $true -or $n.Evidence.exactOwnedJobVerified -ne $true -or $h.originalResumeObserved -ne $true -or $h.attachedContextObserved -ne $true -or $h.attachedContextQpc -le 0 -or $h.ackBeforeQpc -lt $h.attachedContextQpc -or $h.originalResumeQpc -lt $h.ackBeforeQpc -or $d.creationSucceeded -ne $true -or $d.targetPid -ne $Bootstrap.aaPid)){throw 'Resumed child lacks actual token/Job/attached-context/ACK sequence'}
 if($status -ceq 'created-suspended' -and $h.originalResumeObserved){throw 'Suspended child contradicts actual Resume observation'}
 return $status
}
function Assert-AzuriteNoTraceRecords($Records,$Qualification,$Bootstrap) {
 function NeedRecord($value,[string]$why){if(-not $value){throw ('No-trace record binding: '+$why)}}
 function RecordText([byte[]]$bytes,[int]$maximum){NeedRecord ($bytes.Length -ge 2 -and $bytes.Length -le $maximum -and @($bytes|Where-Object {$_ -ne 10 -and ($_ -lt 32 -or $_ -gt 126)}).Count -eq 0) 'bounded canonical ASCII required';return [Text.Encoding]::ASCII.GetString($bytes)}
 function CanonicalJson($value){return ($value|ConvertTo-Json -Depth 6 -Compress)}
 $names=Get-AzuriteNoTraceControlNames
 foreach($name in $Records.Keys){NeedRecord ($name -cin $names) 'unknown control filename'}
 $run=$Qualification.runId;$target=$null;$offer=$null
 if($Bootstrap.noTraceBootstrapHandoff -and $Bootstrap.noTraceBootstrapHandoff.PSObject.Properties['targetIdentity']){$target=$Bootstrap.noTraceBootstrapHandoff.targetIdentity}
 if($Records.ContainsKey('lease-offer.json')){
  $text=RecordText $Records['lease-offer.json'] 4096;$offer=$text|ConvertFrom-Json
  $fields=@('protocol','runId','bootstrapPid','childPid','mainTid','bootstrapCreated','childCreated','threadCreated','processSource','threadSource','jobSource','desktopSource','nativeStart','nativeDeadline','frequency','imageHash')
  NeedRecord (@($offer.PSObject.Properties).Count -eq 16 -and (@($offer.PSObject.Properties.Name)-join ',') -ceq ($fields-join ',') -and $offer.protocol -ceq 'lease-offer.v1' -and $offer.runId -ceq $run -and $offer.bootstrapPid -eq $Bootstrap.bootstrapPid -and $offer.childPid -eq $Bootstrap.aaPid -and $offer.imageHash -ceq $Qualification.targetImageSha256) 'offer shape/run/image/process mismatch'
  foreach($field in $fields[2..14]){NeedRecord (($offer.$field -is [int] -or $offer.$field -is [long]) -and $offer.$field -gt 0) ('offer positive integer '+$field)}
  NeedRecord ($offer.nativeDeadline-$offer.nativeStart -eq (10*$offer.frequency) -and @(@($offer.processSource,$offer.threadSource,$offer.jobSource,$offer.desktopSource)|Select-Object -Unique).Count -eq 4 -and (CanonicalJson $offer) -ceq $text) 'offer canonical bytes/clock/handle uniqueness mismatch'
  NeedRecord ($null -ne $target -and $target.runId -ceq $run -and $target.pid -eq $offer.childPid -and $target.creationFileTime -eq $offer.childCreated -and $target.threadId -eq $offer.mainTid) 'offer differs from original bootstrap handle snapshot'
 }
 if($Records.ContainsKey('lease-ack.json')){NeedRecord ($null -ne $offer) 'ACK without offer';$expected=[ordered]@{protocol='lease-ack.v1';runId=$run;bootstrapPid=$offer.bootstrapPid;childPid=$offer.childPid;mainTid=$offer.mainTid;creation=$offer.childCreated};NeedRecord ((RecordText $Records['lease-ack.json'] 4096) -ceq (CanonicalJson $expected)) 'ACK canonical identity differs'}
 if($Records.ContainsKey('original-resume.record')){NeedRecord ($null -ne $offer -and $null -ne $target -and $Records.ContainsKey('lease-ack.json')) 'Resume without actual offer/ACK';$text=RecordText $Records['original-resume.record'] 512;$pattern='\AAZURITE_ORIGINAL_RESUME_V1 '+$run+' '+$offer.childPid+' '+([long]$offer.childCreated).ToString('x16')+' '+$offer.mainTid+' (0|[1-9][0-9]{0,9}) ([1-9][0-9]{0,18})\n\z';NeedRecord ($text -cmatch $pattern) 'Resume identity/codec differs';$previous=[uint32]::Parse($matches[1],[Globalization.CultureInfo]::InvariantCulture);$qpc=[long]::Parse($matches[2],[Globalization.CultureInfo]::InvariantCulture);NeedRecord ($qpc -ge $offer.nativeStart -and $Bootstrap.restrictedNative.Evidence.resumeCalls -eq 1) 'Resume QPC/native call differs';if($Bootstrap.restrictedNative.Evidence.resumeVerified){NeedRecord ($previous -eq 1) 'Verified Resume previous count differs'}}
 $stop=$null
 if($Records.ContainsKey('debug-stop.request')){NeedRecord ($null -ne $target -and $target.pid -eq $Bootstrap.aaPid) 'Stop without original target identity';$stop=RecordText $Records['debug-stop.request'] 512;$pattern='\AAZURITE_CDB_STOP_V1 '+$run+' '+$target.pid+' '+([long]$target.creationFileTime).ToString('x16')+' ([1-9][0-9]{0,18})\n\z';NeedRecord ($stop -cmatch $pattern) 'Stop canonical target differs';NeedRecord ([long]::Parse($matches[1],[Globalization.CultureInfo]::InvariantCulture) -gt 0) 'Stop expiry invalid'}
 if($Records.ContainsKey('debug-stop.ack')){NeedRecord ($null -ne $stop) 'Stop ACK without request';$h=[Security.Cryptography.SHA256]::Create();try{$digest=([BitConverter]::ToString($h.ComputeHash($Records['debug-stop.request']))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()};NeedRecord ((RecordText $Records['debug-stop.ack'] 512) -ceq ('AZURITE_CDB_STOP_ACK_V1 '+$digest+" CLOSED`n")) 'Stop ACK not canonical closed request digest'}
 return $true
}
