param([Parameter(Mandatory)][string]$CandidateDirectory,[Parameter(Mandatory)][string]$ResultDirectory)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'));$driver=Join-Path $PSScriptRoot 'New-FailureInputs.Pinned.ps1'
$basePath=Join-Path $CandidateDirectory 'delivery-manifest.json';$baseSha=(Get-FileHash $basePath).Hash.ToLowerInvariant()
if($baseSha -cne '6900bab5c246fcea39783eb281523b0e9371d910b1dddbb3bf79ac97704d6de4'){throw 'Original candidate10 delivery must stay fixed'}
$base=Get-Content $basePath -Raw|ConvertFrom-Json -DateKind String
if(Test-Path $ResultDirectory){throw 'Fresh SOURCE check output required'};[void][IO.Directory]::CreateDirectory($ResultDirectory)
function Pin([string]$p){return [ordered]@{path=$p;sha256=(Get-FileHash $p).Hash.ToLowerInvariant();bytes=(Get-Item $p).Length}}
function Save([string]$p,$v){[IO.File]::WriteAllText($p,($v|ConvertTo-Json -Depth 15),[Text.UTF8Encoding]::new($false))}
function CopyCandidate([string]$name){
 $dir=Join-Path (Split-Path $CandidateDirectory -Parent) ('candidate10-pin-test-'+$name+'-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($dir)
 foreach($entry in $base.files){$to=Join-Path $dir $entry.path;[void][IO.Directory]::CreateDirectory((Split-Path $to -Parent));[IO.File]::Copy((Join-Path $CandidateDirectory $entry.path),$to,$false)}
 [IO.File]::Copy($basePath,(Join-Path $dir 'delivery-manifest.json'),$false)
 $driverPin=Pin $driver;$driverPin.role='FailureBinder'
 $manifest=[ordered]@{schema=1;scope='fixed-no-trace-failure-binder-pinned-delivery';runId='0e494be63f3248ffb7bd7bbd040987f8';baseDelivery=(Pin (Join-Path $dir 'delivery-manifest.json'));files=@();references=@($driverPin);testOnlySimulated=$true}
 $path=Join-Path $dir 'delivery-pinned-manifest.json';Save $path $manifest
 return [pscustomobject]@{path=$dir;sha256=(Get-FileHash $path).Hash.ToLowerInvariant()}
}
$checks=[Collections.Generic.List[object]]::new()
function CallActual($fixture,[string]$hash,[string]$expectedError){
 $result=$null;$errorText=$null
 try{$json=& $driver -Phase Preservation -CandidateDirectory $fixture.path -ControllerFinalPath 'C:\SOURCE-CHECK-NOT-READ.json' -ExpectedControllerFinalSha256 ('c'*64) -ExpectedDeliveryManifestSha256 $hash -VerifySourcesOnly;$result=$json|ConvertFrom-Json -DateKind String}catch{$errorText=$_.Exception.Message}
 $loaded=@(Get-Module FullRestrictedPreparationRecovery,FullRestrictedCapabilitiesRuntime);$policy=Get-Command Get-AzuriteNoTraceQualification -ErrorAction SilentlyContinue
 if($loaded.Count -or $policy){throw 'A policy or recovery loader ran before SOURCE-only return/refusal'}
 if($expectedError){if(-not $errorText -or $errorText -notlike $expectedError){throw ('Wrong refusal: '+$errorText)}}else{if($errorText -or $result.sourcesVerified -ne $true -or $result.moduleLoaded -ne $false -or $result.runtimeEvidenceRead -ne $false -or $result.delivery.verifiedBeforeModuleLoad -ne $true){throw ('Correct frozen input failed: '+$errorText)}}
 return [pscustomobject]@{fixture=$fixture;expectedError=$expectedError;error=$errorText;result=$result;policyAndRecoveryNotLoaded=$true}
}
$positive=CopyCandidate positive;$checks.Add((CallActual $positive $positive.sha256 $null))
$checks.Add((CallActual $positive ('a'*64) '*Externally expected pinned delivery digest differs*'))
$policy=CopyCandidate policy-drift;[IO.File]::AppendAllText((Join-Path $policy.path 'overlay\Qualification.Policy.ps1'),"`n# Deliberate SOURCE negative drift`n");$checks.Add((CallActual $policy $policy.sha256 '*Frozen delivery member drift:*Qualification.Policy.ps1'))
$recovery=CopyCandidate recovery-drift;[IO.File]::AppendAllText((Join-Path $recovery.path 'overlay\FullRestrictedPreparationRecovery.psm1'),"`n# Deliberate SOURCE negative drift`n");$checks.Add((CallActual $recovery $recovery.sha256 '*Frozen delivery member drift:*FullRestrictedPreparationRecovery.psm1'))
$source=[IO.File]::ReadAllText($driver);if($source.IndexOf('$frozenDelivery=Assert-QualificationPinnedDelivery') -gt $source.IndexOf(". (Join-Path `$overlay 'Qualification.Policy.ps1')") -or $source.IndexOf('$frozenDelivery=Assert-QualificationPinnedDelivery') -gt $source.IndexOf('Import-Module')){throw 'Actual driver source gate is after a loader'}
$summary=[ordered]@{scope='SOURCE-only-actual-pinned-failure-binder-front-end';passed=5;failed=0;driver=Pin $driver;baseDeliverySha256=$baseSha;checks=$checks.ToArray();actualDriverInvoked=$true;noPolicyOrRecoveryModuleLoaded=$true;testOnlySimulated=$true;runtimeEvidenceRead=$false;FReadPerformed=$false;FWritePerformed=$false;aaExecuted=$false;cdbExecuted=$false}
Save (Join-Path $ResultDirectory 'result.json') $summary
$summary|ConvertTo-Json -Depth 8 -Compress
