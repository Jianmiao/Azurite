param([Parameter(Mandatory)][string]$OutputPath)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
function Fixture {
 $id='1234567890abcdef1234567890abcdef';$rows=@();$counter=1
 foreach($phase in @('natural-host-thread','explicit-sta-probe')){foreach($seed in @(0,1008)){foreach($path in @('raw','com','managed')){$rows+=,[pscustomobject]@{phase=$phase;seed=$seed;path=$path;before=[pscustomobject]@{nativeThreadId=43};created=$true;mutexName=('Global\AzuriteWaitFixture_'+$counter.ToString('x32'));acquired=$true;released=$true;errorType=$null;releaseError=$null};$counter++}}}
 return [pscustomobject]@{id=$id;entry=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;beforeManagedRuntime=$true};host=[pscustomobject]@{schema=1;runId=$id;pid=42;nativeThreadId=43;initializeHr=0;delegateHr=0;loadHr=0;closeHr=0;nativeError=0;managedBytes=1000;aaExecuted=$false};probe=[pscustomobject]@{schema=1;scope='fixed wait diagnostic only, no AA acceptance';pid=42;nativeThreadId=43;finalNativeThreadId=43;sameInitialThread=$true;before=[pscustomobject]@{nativeThreadId=43};runtime='.NET 6.0.36';corelib='C:\Program Files\dotnet\shared\Microsoft.NETCore.App\6.0.36\System.Private.CoreLib.dll';waitTimeoutMs=100;aaExecuted=$false;initializeStaHr=0;records=$rows}}
}
$checks=@()
foreach($name in @('valid','captured-wait-failure','sta-init-failed','foreign-run','foreign-process','foreign-startup-thread','late-thread-hop','wrong-runtime','unbounded-wait','missing-case','duplicate-case','reused-mutex','truncated-bytes','failed-host','failed-managed-hook','AA-promotion')){
 $f=Fixture;$allow=$name -cin @('valid','captured-wait-failure','sta-init-failed')
 switch($name){
  captured-wait-failure {$f.probe.records[0].acquired=$false;$f.probe.records[0].released=$false;$f.probe.records[0].errorType='System.Runtime.InteropServices.COMException'}
  sta-init-failed {$f.probe.initializeStaHr=-1;$f.probe.records=@($f.probe.records|Where-Object phase -CEQ 'natural-host-thread')}
  foreign-run {$f.host.runId='00000000000000000000000000000001'}
  foreign-process {$f.probe.pid=41}
  foreign-startup-thread {$f.entry.nativeThreadId=44}
  late-thread-hop {$f.probe.records[3].before.nativeThreadId=44}
  wrong-runtime {$f.probe.runtime='.NET 8.0.0'}
  unbounded-wait {$f.probe.waitTimeoutMs=-1}
  missing-case {$f.probe.records=$f.probe.records[0..10]}
  duplicate-case {$f.probe.records[1]=$f.probe.records[0]}
  reused-mutex {$f.probe.records[1].mutexName=$f.probe.records[0].mutexName}
  truncated-bytes {$f.host.managedBytes=999}
  failed-host {$f.host.loadHr=-1}
  failed-managed-hook {$f.probe|Add-Member probeFailed $true}
  AA-promotion {$f.probe.aaExecuted=$true}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureWaitProbe $f.entry $f.host $f.probe $f.id 42 43 1000;$passed=$allow -and $r.correlationVerified -and -not $r.applicationAccepted;if($name -ceq 'captured-wait-failure'){$passed=$passed -and -not $r.allWaitCallsSucceeded -and $r.successfulWaitCount -eq 11}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
function CanaryFixture([int]$Flags){
 $owner='S-1-5-21-111-222-333-1001';$id='1234567890abcdef1234567890abcdef';$hash='a'*64;$sddl='O:'+$owner+'G:'+ $owner+'D:P(A;;FA;;;'+$owner+')';$bytes=33
 $object=[pscustomobject]@{path=((Get-FixtureLab)+'\install\read-write-canary.bin');identity='identity1';volume='volume1';owner=$owner;finalPath=((Get-FixtureLab)+'\install\read-write-canary.bin');directory=$false;reparse=$false;links=1;bytes=$bytes;sha256=$hash;sddl=$sddl;rawDescriptor='raw1'}
 $before=[pscustomobject]@{object=$object;attributes=32;captureHandleRetained=$false};$after=$before|ConvertTo-Json -Depth 5|ConvertFrom-Json;$read=$Flags -eq 9
 $probe=[pscustomobject]@{protocol='owned-canary-open.v1';runId=$id;pid=42;nativeThreadId=43;leaf='read-write-canary.bin';readDesiredAccess=[long]2147483648;writeDesiredAccess=[long]1073741824;creationDisposition=3;readOpened=$read;readOpenError=$(if($read){0}else{5});readCallSucceeded=$read;readError=0;readBytes=$(if($read){$bytes}else{0});contentMatches=$read;readCloseError=0;infoSucceeded=$read;infoError=0;attributes=32;links=1;fileSizeHigh=0;fileSizeLow=$bytes;writeAttempted=$true;writeOpened=$false;writeOpenError=5;writeCloseError=0;writeDataCalled=$false;truncateCalled=$false;readClosedBeforeWriteOpen=$true}
 return [pscustomobject]@{flags=$Flags;owner=$owner;id=$id;hash=$hash;bytes=$bytes;before=$before;after=$after;probe=$probe}
}
foreach($name in @('full-read-write-denied','write-restricted-read-only','unexpected-write-granted','sharing-error-not-restriction-proof','wrong-child','wrong-thread','read-only-attribute','reparse-leaf','multiple-links','changed-identity','changed-hash','changed-sddl','outside-leaf','extra-logon-ace','retained-controller-handle','read-close-uncertain','data-write-called','truncate-called','create-always','read-content-mismatch')){
 $f=CanaryFixture $(if($name -ceq 'full-read-write-denied'){1}else{9});$p=$f.probe;$allow=$name -cin @('full-read-write-denied','write-restricted-read-only','unexpected-write-granted','sharing-error-not-restriction-proof')
 switch($name){
  unexpected-write-granted {$p.writeOpened=$true;$p.writeOpenError=0}
  sharing-error-not-restriction-proof {$p.writeOpenError=32}
  wrong-child {$p.pid=41}
  wrong-thread {$p.nativeThreadId=44}
  read-only-attribute {$f.before.attributes=33;$f.after.attributes=33}
  reparse-leaf {$f.before.object.reparse=$true;$f.after.object.reparse=$true}
  multiple-links {$f.before.object.links=2;$f.after.object.links=2}
  changed-identity {$f.after.object.identity='identity2'}
  changed-hash {$f.after.object.sha256='b'*64}
  changed-sddl {$f.after.object.sddl+='(A;;FR;;;WD)'}
  outside-leaf {$f.before.object.path='C:\outside.bin';$f.after.object.path='C:\outside.bin'}
  extra-logon-ace {$f.before.object.sddl+='(A;;FA;;;S-1-5-5-11-22)';$f.after.object.sddl=$f.before.object.sddl}
  retained-controller-handle {$f.before.captureHandleRetained=$true}
  read-close-uncertain {$p.readCloseError=6;$p.writeAttempted=$false;$p.readClosedBeforeWriteOpen=$false}
  data-write-called {$p.writeDataCalled=$true}
  truncate-called {$p.truncateCalled=$true}
  create-always {$p.creationDisposition=2}
  read-content-mismatch {$p.contentMatches=$false}
 }
 $passed=$false;$errorText=$null
 try{$r=Assert-FixtureCanary $p $f.before $f.after $f.id 42 43 $f.flags $f.owner $f.hash $f.bytes;$passed=$allow -and $r.contentIdentitySecurityUnchanged -and -not $r.productionFullRestrictionQualificationClaimed -and -not $r.tokenFlagsIndependentlyQueried;if($name -cin @('unexpected-write-granted','sharing-error-not-restriction-proof')){$passed=$passed -and -not $r.expectedOutcomeObserved}else{$passed=$passed -and $r.expectedOutcomeObserved}}catch{$errorText=$_.Exception.Message;$passed=-not $allow}
 $checks+=,[pscustomobject]@{name=$name;passed=$passed;error=$errorText}
}
$result=[pscustomobject]@{scope='C-only wait and fixed canary consumer behavior';passed=(@($checks|Where-Object{-not $_.passed}).Count -eq 0);checks=$checks.Count;results=$checks;nativeExecuted=$false;FReadPerformed=$false;AAExecuted=$false;host=$PSVersionTable.PSVersion.ToString()}
if(Test-Path -LiteralPath $OutputPath){throw 'Retain previous result'};[IO.File]::WriteAllText($OutputPath,($result|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));$result|Select-Object passed,checks,host|ConvertTo-Json
if(-not $result.passed){exit 1}
