#requires -Version 5.1
param([Parameter(Mandatory)][string]$ControlPath,[Parameter(Mandatory)][string]$ReviewedControlSha256)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest

[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
if($ReviewedControlSha256 -cnotmatch '^[a-f0-9]{64}$' -or (Get-FileHash -LiteralPath $ControlPath).Hash.ToLowerInvariant() -cne $ReviewedControlSha256){throw 'Fixture control digest mismatch'}
$c=[IO.File]::ReadAllText($ControlPath)|ConvertFrom-Json
if($c.fixtureOnly -ne $true -or $c.productionTargetExecuted -ne $false -or $c.evidenceProtocol -cne 'cleanup-ordering.v1' -or $c.scenario -cne 'normal' -or $c.runId -cnotmatch '^[a-f0-9]{32}$'){throw 'Not a build-wait5-write finite cleanup-ordering scenario control'}
if($c.externalLiveDescendantIntervalClaimed -isnot [bool] -or $c.externalLiveDescendantIntervalClaimed){throw 'Cleanup ordering cannot claim an external live descendant interval'}
foreach($name in @('FixtureRules.psm1','AzuriteLifecycle.FixtureOnly.dll','RestrictedCliBootstrap.ps1')){if((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $name)).Hash.ToLowerInvariant() -cne $c.toolHashes.$name){throw 'Fixture tooling pin mismatch'}}
Import-Module (Join-Path $PSScriptRoot 'FixtureRules.psm1') -Force -DisableNameChecking
if($c.scenario -ceq 'bootstrap-exit'){$normalReceipt=ConvertFrom-FixtureNormalReceiptBytes ([Convert]::FromBase64String($c.normalReceiptBase64)) $c.normalReceiptSha256 $c.packageSha256 $c.productionSources;Assert-Fixture ((Split-Path -Leaf (Split-Path -Parent $c.normalReceiptPath)) -ceq $normalReceipt.runId) 'protected prerequisite run/path binding';Assert-Fixture ($normalReceipt.evidenceProtocol -ceq 'cleanup-ordering.v1' -and $normalReceipt.externalLiveDescendantIntervalClaimed -is [bool] -and -not $normalReceipt.externalLiveDescendantIntervalClaimed) 'protected normal cleanup protocol';Assert-FixtureCleanupOrdering $normalReceipt.outer.FullDesktopMonitorEvidence.outerDrain $normalReceipt.outer $normalReceipt.runId}
$run=(Get-FixtureLab)+'\runs\restricted-'+$c.runId
Assert-Fixture ($PSScriptRoot -ceq ($run+'\tooling') -and $ControlPath -ceq ($run+'\tooling\control.json')) 'fixed bootstrap layout'
if($c.scenario -ceq 'bootstrap-exit'){Write-FixtureJson ($run+'\output\normal-prerequisite.json') ([ordered]@{fixtureOnly=$true;productionTargetExecuted=$false;runId=$c.runId;normalRunId=$normalReceipt.runId;normalReceiptPath=$c.normalReceiptPath;normalReceiptSha256=$c.normalReceiptSha256;normalPackageSha256=$normalReceipt.packageSha256;currentPackageSha256=$c.packageSha256;sourceLineage=$c.productionSources})}
Add-Type -Path (Join-Path $PSScriptRoot 'AzuriteLifecycle.FixtureOnly.dll')
$identity=[Azurite.Restricted.FullBootstrapIdentity]::Read($c.runId)
Assert-Fixture ($identity['identitySid'] -ceq $c.userSid -and $identity['token']['logon_sid'] -ceq $c.logonSid -and $identity['token']['session_id'] -eq $c.session -and -not $identity['isAdministrator']) 'actual original bootstrap identity'
Assert-Fixture ((Get-FixtureHash ($run+'\request\arguments.json')) -ceq $c.argumentsSha256 -and (Get-FixtureHash ($run+'\request\fixture-input.txt')) -ceq $c.inputSha256) 'protected child inputs'
$job=[Azurite.Restricted.OwnedJob]::CreateAndJoinCurrent();$exit=1;$r=[ordered]@{fixtureOnly=$true;productionTargetExecuted=$false;runId=$c.runId;scenario=$c.scenario;bootstrapPid=$PID;passed=$false}
try{
 $job.AnnounceAndAwaitControllerFull($c.runId,5000)
 $exe=[Azurite.Restricted.LifecycleFixture]::Target
 $psi=New-FixtureStart $exe ('-batchmode -nographics -disableaudio -logFile '+$run+'\output\unity.log') ((Get-FixtureLab)+'\install')
 $psi.EnvironmentVariables['AZUREARCHIVE_CLI_DIRECTORY']=$run+'\request'
 if($c.scenario -ceq 'normal'){
  $native=[Azurite.Restricted.ProcessPump]::RunFullRestrictedCapabilities($psi,10000,$job,$c.runId,$run,$c.argumentsSha256,262144,@($run+'\request',$run+'\output'),4194304)
 }else{
  $native=[Azurite.Restricted.LifecycleFixture]::RunCleanupInstrumented($psi,$job,$c.runId,$c.argumentsSha256)
 }
 $r.native=$native
 Assert-Fixture ($c.scenario -ceq 'normal' -and $native.Process.CleanupVerified -and $native.Process.ExitCode -eq 0 -and -not $native.Process.TimedOut -and [string]::IsNullOrEmpty($native.Process.Error)) 'normal same-public-entry cleanup'
 Assert-FixtureCaptured $native.Process.Stdout $native.Process.Stderr $c.runId
 [Console]::Out.Write($native.Process.Stdout);[Console]::Error.Write($native.Process.Stderr)
 $r.passed=$true;$exit=0
}catch{$r.error=$_.Exception.ToString()}
finally{try{Write-FixtureJson ($run+'\output\fixture-bootstrap-result.json') $r;[Console]::Out.Flush();[Console]::Error.Flush()}finally{$job.TerminateFull([uint32]$exit)}}
